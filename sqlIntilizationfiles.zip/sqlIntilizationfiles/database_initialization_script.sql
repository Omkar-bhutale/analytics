-- ============================================================================
-- CBL Backend - Complete Database Initialization Script
-- Generated: October 27, 2025
-- Description: Creates all tables with proper schema and constraints
-- ============================================================================

-- Drop existing tables in reverse order of dependencies
DROP TABLE IF EXISTS user_problem_engagement CASCADE;
DROP TABLE IF EXISTS user_topic_engagement CASCADE;
DROP TABLE IF EXISTS user_main_topic_engagement CASCADE;
DROP TABLE IF EXISTS user_batch_assignments CASCADE;
DROP TABLE IF EXISTS batch_course_assignments CASCADE;
DROP TABLE IF EXISTS problem_submissions CASCADE;
DROP TABLE IF EXISTS user_problem_reports CASCADE;
DROP TABLE IF EXISTS pseudocode_submissions CASCADE;
DROP TABLE IF EXISTS algorithm_submissions CASCADE;
DROP TABLE IF EXISTS problem_test_cases CASCADE;
DROP TABLE IF EXISTS mcqs CASCADE;
DROP TABLE IF EXISTS notebooks CASCADE;
DROP TABLE IF EXISTS problems CASCADE;
DROP TABLE IF EXISTS topics CASCADE;
DROP TABLE IF EXISTS course_main_topics CASCADE;
DROP TABLE IF EXISTS main_topics CASCADE;
DROP TABLE IF EXISTS courses CASCADE;
DROP TABLE IF EXISTS batches CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- ============================================================================
-- Core Tables
-- ============================================================================

-- Users Table
CREATE TABLE users (
    user_id VARCHAR(255) PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    insights JSONB
);

-- Batches Table
CREATE TABLE batches (
    batch_id SERIAL PRIMARY KEY,
    batch_name VARCHAR(255) NOT NULL,
    start_date TIMESTAMP,
    end_date TIMESTAMP
);

-- Courses Table
CREATE TABLE courses (
    course_id SERIAL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    creator_id VARCHAR(255),
    FOREIGN KEY (creator_id) REFERENCES users(user_id) ON DELETE SET NULL
);

-- Main Topics Table
CREATE TABLE main_topics (
    main_topic_id SERIAL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    creator_id VARCHAR(255) NOT NULL,
    main_problem_id INTEGER,
    FOREIGN KEY (creator_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Topics Table
CREATE TABLE topics (
    topic_id SERIAL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content JSONB NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    creator_id VARCHAR(255) NOT NULL,
    created_using VARCHAR(255) NOT NULL,
    main_topic_id INTEGER NOT NULL,
    FOREIGN KEY (creator_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (main_topic_id) REFERENCES main_topics(main_topic_id) ON DELETE CASCADE
);

-- Problems Table
CREATE TABLE problems (
    problem_id SERIAL PRIMARY KEY,
    title TEXT,
    description TEXT NOT NULL,
    difficulty VARCHAR(20) NOT NULL CHECK (difficulty IN ('EASY', 'MEDIUM', 'HARD')),
    created_using VARCHAR(255),
    hint JSONB,
    topic_id INTEGER NOT NULL,
    FOREIGN KEY (topic_id) REFERENCES topics(topic_id) ON DELETE CASCADE
);

-- Add foreign key constraint for main_problem_id in main_topics
ALTER TABLE main_topics
ADD CONSTRAINT fk_main_topics_main_problem
FOREIGN KEY (main_problem_id) REFERENCES problems(problem_id) ON DELETE SET NULL;

-- Notebooks Table
CREATE TABLE notebooks (
    notebook_id SERIAL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    file_path TEXT NOT NULL,
    file_type VARCHAR(10) NOT NULL CHECK (file_type IN ('PDF', 'IPYNB')),
    uploaded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    language VARCHAR(20) NOT NULL CHECK (language IN ('JAVA', 'PYTHON', 'JAVASCRIPT', 'TYPESCRIPT')),
    uploaded_by VARCHAR(255) NOT NULL,
    main_topic_id INTEGER NOT NULL,
    FOREIGN KEY (main_topic_id) REFERENCES main_topics(main_topic_id) ON DELETE CASCADE
);

-- MCQs Table
CREATE TABLE mcqs (
    mcq_id SERIAL PRIMARY KEY,
    content JSONB NOT NULL,
    topic_id INTEGER NOT NULL,
    FOREIGN KEY (topic_id) REFERENCES topics(topic_id) ON DELETE CASCADE
);

-- Problem Test Cases Table
CREATE TABLE problem_test_cases (
    test_case_id SERIAL PRIMARY KEY,
    input TEXT,
    expected_output TEXT,
    is_public BOOLEAN NOT NULL DEFAULT TRUE,
    problem_id INTEGER NOT NULL,
    FOREIGN KEY (problem_id) REFERENCES problems(problem_id) ON DELETE CASCADE
);

-- ============================================================================
-- Relationship/Assignment Tables
-- ============================================================================

-- Course-MainTopic Many-to-Many Relationship
CREATE TABLE course_main_topics (
    course_id INTEGER NOT NULL,
    main_topic_id INTEGER NOT NULL,
    PRIMARY KEY (course_id, main_topic_id),
    FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE,
    FOREIGN KEY (main_topic_id) REFERENCES main_topics(main_topic_id) ON DELETE CASCADE
);

-- Batch-Course Assignments
CREATE TABLE batch_course_assignments (
    batch_id INTEGER NOT NULL,
    course_id INTEGER NOT NULL,
    PRIMARY KEY (batch_id, course_id),
    FOREIGN KEY (batch_id) REFERENCES batches(batch_id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE
);

-- User-Batch Assignments
CREATE TABLE user_batch_assignments (
    user_id VARCHAR(255) NOT NULL,
    batch_id INTEGER NOT NULL,
    PRIMARY KEY (user_id, batch_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (batch_id) REFERENCES batches(batch_id) ON DELETE CASCADE
);

-- ============================================================================
-- Submission and Report Tables
-- ============================================================================

-- Algorithm Submissions Table
CREATE TABLE algorithm_submissions (
    algorithm_id SERIAL PRIMARY KEY,
    content TEXT NOT NULL,
    version INTEGER NOT NULL DEFAULT 0,
    total_second_spent INTEGER DEFAULT 0,
    submitted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    is_correct BOOLEAN NOT NULL DEFAULT FALSE,
    user_id VARCHAR(255) NOT NULL,
    problem_id INTEGER NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (problem_id) REFERENCES problems(problem_id) ON DELETE CASCADE
);

-- Pseudocode Submissions Table
CREATE TABLE pseudocode_submissions (
    pseudocode_submission_id SERIAL PRIMARY KEY,
    content TEXT,
    version INTEGER NOT NULL DEFAULT 0,
    submitted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    total_second_spent INTEGER DEFAULT 0,
    is_correct BOOLEAN NOT NULL DEFAULT FALSE,
    user_id VARCHAR(255) NOT NULL,
    problem_id INTEGER NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (problem_id) REFERENCES problems(problem_id) ON DELETE CASCADE
);

-- User Problem Reports Table
CREATE TABLE user_problem_reports (
    user_problem_report_id SERIAL PRIMARY KEY,
    is_solved BOOLEAN NOT NULL DEFAULT FALSE,
    total_attempts INTEGER NOT NULL DEFAULT 0,
    languages_used JSON NOT NULL DEFAULT '[]',
    insights JSONB NOT NULL DEFAULT '{}',
    user_id VARCHAR(255) NOT NULL,
    problem_id INTEGER NOT NULL,
    UNIQUE (user_id, problem_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (problem_id) REFERENCES problems(problem_id) ON DELETE CASCADE
);

-- Problem Submissions Table
CREATE TABLE problem_submissions (
    submission_id SERIAL PRIMARY KEY,
    language VARCHAR(20) NOT NULL CHECK (language IN ('JAVA', 'PYTHON', 'JAVASCRIPT', 'TYPESCRIPT')),
    code TEXT NOT NULL,
    submitted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version INTEGER NOT NULL DEFAULT 0,
    insights JSONB,
    total_test_cases INTEGER DEFAULT 0,
    passed_test_cases INTEGER DEFAULT 0,
    is_solved BOOLEAN,
    problem_id INTEGER NOT NULL,
    user_id VARCHAR(255) NOT NULL,
    user_problem_report_id INTEGER NOT NULL,
    UNIQUE (problem_id, user_id, language),
    FOREIGN KEY (problem_id) REFERENCES problems(problem_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (user_problem_report_id) REFERENCES user_problem_reports(user_problem_report_id) ON DELETE CASCADE
);

-- ============================================================================
-- Engagement/Tracking Tables
-- ============================================================================

-- User Main Topic Engagement
CREATE TABLE user_main_topic_engagement (
    user_id VARCHAR(255) NOT NULL,
    main_topic_id INTEGER NOT NULL,
    total_seconds_spent INTEGER NOT NULL DEFAULT 0,
    last_activity_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    java_time_seconds BIGINT DEFAULT 0,
    python_time_seconds BIGINT DEFAULT 0,
    javascript_time_seconds BIGINT DEFAULT 0,
    typescript_time_seconds BIGINT DEFAULT 0,
    java_completed BOOLEAN DEFAULT FALSE,
    python_completed BOOLEAN DEFAULT FALSE,
    javascript_completed BOOLEAN DEFAULT FALSE,
    typescript_completed BOOLEAN DEFAULT FALSE,
    is_completed BOOLEAN NOT NULL DEFAULT FALSE,
    PRIMARY KEY (user_id, main_topic_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (main_topic_id) REFERENCES main_topics(main_topic_id) ON DELETE CASCADE
);

-- User Topic Engagement
CREATE TABLE user_topic_engagement (
    user_id VARCHAR(255) NOT NULL,
    topic_id INTEGER NOT NULL,
    total_seconds_spent INTEGER NOT NULL DEFAULT 0,
    last_activity_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    java_time_seconds BIGINT DEFAULT 0,
    python_time_seconds BIGINT DEFAULT 0,
    javascript_time_seconds BIGINT DEFAULT 0,
    typescript_time_seconds BIGINT DEFAULT 0,
    java_visited BOOLEAN DEFAULT FALSE,
    python_visited BOOLEAN DEFAULT FALSE,
    javascript_visited BOOLEAN DEFAULT FALSE,
    typescript_visited BOOLEAN DEFAULT FALSE,
    mcq_visited BOOLEAN DEFAULT FALSE,
    is_completed BOOLEAN NOT NULL DEFAULT FALSE,
    PRIMARY KEY (user_id, topic_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (topic_id) REFERENCES topics(topic_id) ON DELETE CASCADE
);

-- User Problem Engagement
CREATE TABLE user_problem_engagement (
    user_id VARCHAR(255) NOT NULL,
    problem_id INTEGER NOT NULL,
    total_seconds_spent INTEGER NOT NULL DEFAULT 0,
    saved_codes JSONB,
    is_solved BOOLEAN NOT NULL DEFAULT FALSE,
    total_attempts INTEGER NOT NULL DEFAULT 0,
    last_activity_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    java_time_seconds BIGINT DEFAULT 0,
    python_time_seconds BIGINT DEFAULT 0,
    javascript_time_seconds BIGINT DEFAULT 0,
    typescript_time_seconds BIGINT DEFAULT 0,
    java_completed BOOLEAN DEFAULT FALSE,
    python_completed BOOLEAN DEFAULT FALSE,
    javascript_completed BOOLEAN DEFAULT FALSE,
    typescript_completed BOOLEAN DEFAULT FALSE,
    PRIMARY KEY (user_id, problem_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (problem_id) REFERENCES problems(problem_id) ON DELETE CASCADE
);

-- ============================================================================
-- Indexes for Performance Optimization
-- ============================================================================

-- Users
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_name ON users(name);

-- Courses
CREATE INDEX idx_courses_creator_id ON courses(creator_id);

-- Main Topics
CREATE INDEX idx_main_topics_creator_id ON main_topics(creator_id);
CREATE INDEX idx_main_topics_main_problem_id ON main_topics(main_problem_id);

-- Topics
CREATE INDEX idx_topics_main_topic_id ON topics(main_topic_id);
CREATE INDEX idx_topics_creator_id ON topics(creator_id);

-- Problems
CREATE INDEX idx_problems_topic_id ON problems(topic_id);
CREATE INDEX idx_problems_difficulty ON problems(difficulty);

-- Notebooks
CREATE INDEX idx_notebooks_main_topic_id ON notebooks(main_topic_id);
CREATE INDEX idx_notebooks_language ON notebooks(language);
CREATE INDEX idx_notebooks_uploaded_by ON notebooks(uploaded_by);

-- MCQs
CREATE INDEX idx_mcqs_topic_id ON mcqs(topic_id);

-- Problem Test Cases
CREATE INDEX idx_problem_test_cases_problem_id ON problem_test_cases(problem_id);

-- Algorithm Submissions
CREATE INDEX idx_algorithm_submissions_user_id ON algorithm_submissions(user_id);
CREATE INDEX idx_algorithm_submissions_problem_id ON algorithm_submissions(problem_id);
CREATE INDEX idx_algorithm_submissions_submitted_at ON algorithm_submissions(submitted_at);

-- Pseudocode Submissions
CREATE INDEX idx_pseudocode_submissions_user_id ON pseudocode_submissions(user_id);
CREATE INDEX idx_pseudocode_submissions_problem_id ON pseudocode_submissions(problem_id);

-- Problem Submissions
CREATE INDEX idx_problem_submissions_user_id ON problem_submissions(user_id);
CREATE INDEX idx_problem_submissions_problem_id ON problem_submissions(problem_id);
CREATE INDEX idx_problem_submissions_language ON problem_submissions(language);

-- User Problem Reports
CREATE INDEX idx_user_problem_reports_user_id ON user_problem_reports(user_id);
CREATE INDEX idx_user_problem_reports_problem_id ON user_problem_reports(problem_id);

-- Engagement Tables
CREATE INDEX idx_user_main_topic_engagement_last_activity ON user_main_topic_engagement(last_activity_at);
CREATE INDEX idx_user_topic_engagement_last_activity ON user_topic_engagement(last_activity_at);
CREATE INDEX idx_user_problem_engagement_last_activity ON user_problem_engagement(last_activity_at);

-- ============================================================================
-- Comments on Tables
-- ============================================================================

COMMENT ON TABLE users IS 'Stores user information and authentication details';
COMMENT ON TABLE batches IS 'Represents student batches or cohorts';
COMMENT ON TABLE courses IS 'Educational courses created by instructors';
COMMENT ON TABLE main_topics IS 'High-level topics within courses';
COMMENT ON TABLE topics IS 'Subtopics within main topics containing learning content';
COMMENT ON TABLE problems IS 'Coding problems for practice';
COMMENT ON TABLE notebooks IS 'Jupyter notebooks (.ipynb) or PDF files for main topics';
COMMENT ON TABLE mcqs IS 'Multiple choice questions for topics';
COMMENT ON TABLE problem_test_cases IS 'Test cases for validating problem solutions';
COMMENT ON TABLE algorithm_submissions IS 'User algorithm design submissions';
COMMENT ON TABLE pseudocode_submissions IS 'User pseudocode submissions';
COMMENT ON TABLE problem_submissions IS 'User code submissions for problems';
COMMENT ON TABLE user_problem_reports IS 'Aggregated user performance on problems';
COMMENT ON TABLE user_main_topic_engagement IS 'Tracks user engagement with main topics';
COMMENT ON TABLE user_topic_engagement IS 'Tracks user engagement with topics';
COMMENT ON TABLE user_problem_engagement IS 'Tracks user engagement with problems';
COMMENT ON TABLE course_main_topics IS 'Many-to-many relationship between courses and main topics';
COMMENT ON TABLE batch_course_assignments IS 'Assigns courses to batches';
COMMENT ON TABLE user_batch_assignments IS 'Assigns users to batches';

-- ============================================================================
-- Verification Query
-- ============================================================================

-- Verify all tables are created
SELECT
    table_name,
    (SELECT COUNT(*) FROM information_schema.columns WHERE table_name = t.table_name) as column_count
FROM information_schema.tables t
WHERE table_schema = 'public'
  AND table_type = 'BASE TABLE'
ORDER BY table_name;

-- ============================================================================
-- End of Script
-- ============================================================================

-- Script Summary:
-- - Total Tables: 21
-- - Core Tables: 8 (users, batches, courses, main_topics, topics, problems, notebooks, mcqs)
-- - Relationship Tables: 3 (course_main_topics, batch_course_assignments, user_batch_assignments)
-- - Submission Tables: 4 (algorithm_submissions, pseudocode_submissions, problem_submissions, user_problem_reports)
-- - Engagement Tables: 3 (user_main_topic_engagement, user_topic_engagement, user_problem_engagement)
-- - Support Tables: 2 (problem_test_cases)
-- - All tables are initialized empty and ready for data insertion

