-- ============================================================================
-- CBL Backend - Main Topics Data Insertion Script
-- Generated: October 27, 2025
-- Description: Inserts initial main topics data into the main_topics table
-- ============================================================================

-- 🚀 Common Programming Main Topics (Java + Python Shared Concepts)

-- Main Topic 1: Data Types & Operators
INSERT INTO main_topics (main_topic_id, title, description, creator_id, created_at)
VALUES
(1, 'Data Types & Operators',
 'Covers primitive and non-primitive data types, variable declarations, type casting, and operator usage in Java and Python.',
 'learnin', CURRENT_TIMESTAMP);+

-- Main Topic 2: Conditionals & Loops
INSERT INTO main_topics (main_topic_id, title, description, creator_id, created_at)
VALUES
(2, 'Conditionals & Loops',
 'Master decision-making and iteration with if-else, switch/case, for, while, and do-while loops applicable across Java and Python.',
 'learnin', CURRENT_TIMESTAMP);

-- Main Topic 3: Functions
INSERT INTO main_topics (main_topic_id, title, description, creator_id, created_at)
VALUES
(3, 'Functions',
 'Learn how to define, call, and return values from functions, including parameter handling and method overloading/recursion.',
 'learnin', CURRENT_TIMESTAMP);

-- Main Topic 4: Sets & Collections
INSERT INTO main_topics (main_topic_id, title, description, creator_id, created_at)
VALUES
(4, 'Sets & Collections',
 'Understand collection types like lists, sets, tuples, and maps for efficient data storage and manipulation in both languages.',
 'learnin', CURRENT_TIMESTAMP);

-- Main Topic 5: Classes and Objects
INSERT INTO main_topics (main_topic_id, title, description, creator_id, created_at)
VALUES
(5, 'Classes and Objects',
 'Dive into OOP principles — class design, constructors, encapsulation, and object lifecycle in Java and Python.',
 'learnin', CURRENT_TIMESTAMP);

-- Main Topic 6: Exception Handling
INSERT INTO main_topics (main_topic_id, title, description, creator_id, created_at)
VALUES
(6, 'Exception Handling',
 'Handle runtime errors gracefully using try-catch-finally and explore custom exceptions.',
 'learnin', CURRENT_TIMESTAMP);

-- Main Topic 7: Inheritance & Polymorphism
INSERT INTO main_topics (main_topic_id, title, description, creator_id, created_at)
VALUES
(7, 'Inheritance & Polymorphism',
 'Explore OOP extensions including inheritance, overriding, and polymorphism concepts common in both languages.',
 'learnin', CURRENT_TIMESTAMP);

-- ============================================================================
-- Verification Query
-- ============================================================================

-- Verify all main topics were inserted successfully
SELECT main_topic_id, title, description, creator_id, created_at
FROM main_topics
ORDER BY main_topic_id;

-- Count total main topics
SELECT COUNT(*) as total_main_topics FROM main_topics;

-- ============================================================================
-- End of Script
-- ============================================================================

-- Script Summary:
-- - Total Main Topics Inserted: 7
-- - Main Topic IDs: 1 to 7
-- - Creator: learnin
-- - Categories: Data Types, Conditionals, Functions, Collections, OOP Basics, Exception Handling, Advanced OOP

