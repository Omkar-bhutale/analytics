-- ============================================================================
-- CBL Backend - User Data Insertion Script
-- Generated: October 27, 2025
-- Description: Inserts initial user data into the users table
-- ============================================================================

-- Insert User 1: Stefy Merlin Faustinaa
INSERT INTO users (user_id, created_at, email, name, insights)
VALUES
('2852985', NOW(), '2852985@tcs.com', 'Stefy Merlin Faustinaa', '{
  "overall_performance_score": 80,
  "suggested_streams": [
    "Data Structures & Algorithms",
    "Concurrent & Parallel Programming",
    "System Design & Scalability"
  ],
  "language_summary": [
    {
      "language": "python",
      "performance_score": 85,
      "avg_difficulty_mastered": "Easy-Medium",
      "total_attempts": 2
    },
    {
      "language": "java",
      "performance_score": 70,
      "avg_difficulty_mastered": "Medium-Hard",
      "total_attempts": 3
    }
  ],
  "general_recommendations": "Python is a strong choice for data structures and algorithms, while Java shines in concurrent programming and system design. To improve, focus on boundary conditions and optimize slow-running algorithms in Python, and work on recursion and efficient hash map usage in Java."
}');

-- Insert User 2: Gopanwar Srikanth
INSERT INTO users (user_id, created_at, email, name, insights)
VALUES
('2854134', NOW(), '2854134@tcs.com', 'Gopanwar Srikanth', '{
  "overall_performance_score": 80,
  "suggested_streams": [
    "Data Structures & Algorithms",
    "Concurrent & Parallel Programming",
    "System Design & Scalability"
  ],
  "language_summary": [
    {
      "language": "python",
      "performance_score": 85,
      "avg_difficulty_mastered": "Easy-Medium",
      "total_attempts": 2
    },
    {
      "language": "java",
      "performance_score": 70,
      "avg_difficulty_mastered": "Medium-Hard",
      "total_attempts": 3
    }
  ],
  "general_recommendations": "Python is a strong choice for data structures and algorithms, while Java shines in concurrent programming and system design. To improve, focus on boundary conditions and optimize slow-running algorithms in Python, and work on recursion and efficient hash map usage in Java."
}');

-- Insert User 3: Debasish Routray
INSERT INTO users (user_id, created_at, email, name, insights)
VALUES
('2853304', NOW(), '2853304@tcs.com', 'Debasish Routray', '{
  "overall_performance_score": 80,
  "suggested_streams": [
    "Data Structures & Algorithms",
    "Concurrent & Parallel Programming",
    "System Design & Scalability"
  ],
  "language_summary": [
    {
      "language": "python",
      "performance_score": 85,
      "avg_difficulty_mastered": "Easy-Medium",
      "total_attempts": 2
    },
    {
      "language": "java",
      "performance_score": 70,
      "avg_difficulty_mastered": "Medium-Hard",
      "total_attempts": 3
    }
  ],
  "general_recommendations": "Python is a strong choice for data structures and algorithms, while Java shines in concurrent programming and system design. To improve, focus on boundary conditions and optimize slow-running algorithms in Python, and work on recursion and efficient hash map usage in Java."
}');

-- Insert User 4: Ankit Gupta
INSERT INTO users (user_id, created_at, email, name, insights)
VALUES
('2928088', NOW(), '2928088@tcs.com', 'Ankit Gupta', '{
  "overall_performance_score": 80,
  "suggested_streams": [
    "Data Structures & Algorithms",
    "Concurrent & Parallel Programming",
    "System Design & Scalability"
  ],
  "language_summary": [
    {
      "language": "python",
      "performance_score": 85,
      "avg_difficulty_mastered": "Easy-Medium",
      "total_attempts": 2
    },
    {
      "language": "java",
      "performance_score": 70,
      "avg_difficulty_mastered": "Medium-Hard",
      "total_attempts": 3
    }
  ],
  "general_recommendations": "Python is a strong choice for data structures and algorithms, while Java shines in concurrent programming and system design. To improve, focus on boundary conditions and optimize slow-running algorithms in Python, and work on recursion and efficient hash map usage in Java."
}');

-- Insert User 5: Maria Grazia
INSERT INTO users (user_id, created_at, email, name, insights)
VALUES
('2927944', NOW(), '2927944@tcs.com', 'Maria Grazia', '{
  "overall_performance_score": 80,
  "suggested_streams": [
    "Data Structures & Algorithms",
    "Concurrent & Parallel Programming",
    "System Design & Scalability"
  ],
  "language_summary": [
    {
      "language": "python",
      "performance_score": 85,
      "avg_difficulty_mastered": "Easy-Medium",
      "total_attempts": 2
    },
    {
      "language": "java",
      "performance_score": 70,
      "avg_difficulty_mastered": "Medium-Hard",
      "total_attempts": 3
    }
  ],
  "general_recommendations": "Python is a strong choice for data structures and algorithms, while Java shines in concurrent programming and system design. To improve, focus on boundary conditions and optimize slow-running algorithms in Python, and work on recursion and efficient hash map usage in Java."
}');

-- Insert User 6: Sunny Gupta
INSERT INTO users (user_id, created_at, email, name, insights)
VALUES
('2918448', NOW(), '2918448@tcs.com', 'Sunny Gupta', '{
  "overall_performance_score": 80,
  "suggested_streams": [
    "Data Structures & Algorithms",
    "Concurrent & Parallel Programming",
    "System Design & Scalability"
  ],
  "language_summary": [
    {
      "language": "python",
      "performance_score": 85,
      "avg_difficulty_mastered": "Easy-Medium",
      "total_attempts": 2
    },
    {
      "language": "java",
      "performance_score": 70,
      "avg_difficulty_mastered": "Medium-Hard",
      "total_attempts": 3
    }
  ],
  "general_recommendations": "Python is a strong choice for data structures and algorithms, while Java shines in concurrent programming and system design. To improve, focus on boundary conditions and optimize slow-running algorithms in Python, and work on recursion and efficient hash map usage in Java."
}');

-- Insert User 7: Amit Patel
INSERT INTO users (user_id, created_at, email, name, insights)
VALUES
('2918705', NOW(), '2918705@tcs.com', 'Amit Patel', '{
  "overall_performance_score": 80,
  "suggested_streams": [
    "Data Structures & Algorithms",
    "Concurrent & Parallel Programming",
    "System Design & Scalability"
  ],
  "language_summary": [
    {
      "language": "python",
      "performance_score": 85,
      "avg_difficulty_mastered": "Easy-Medium",
      "total_attempts": 2
    },
    {
      "language": "java",
      "performance_score": 70,
      "avg_difficulty_mastered": "Medium-Hard",
      "total_attempts": 3
    }
  ],
  "general_recommendations": "Python is a strong choice for data structures and algorithms, while Java shines in concurrent programming and system design. To improve, focus on boundary conditions and optimize slow-running algorithms in Python, and work on recursion and efficient hash map usage in Java."
}');

-- Insert User 8: Kondeti Pavan Kumar
INSERT INTO users (user_id, created_at, email, name, insights)
VALUES
('2922684', NOW(), '2922684@tcs.com', 'Kondeti Pavan Kumar', '{
  "overall_performance_score": 80,
  "suggested_streams": [
    "Data Structures & Algorithms",
    "Concurrent & Parallel Programming",
    "System Design & Scalability"
  ],
  "language_summary": [
    {
      "language": "python",
      "performance_score": 85,
      "avg_difficulty_mastered": "Easy-Medium",
      "total_attempts": 2
    },
    {
      "language": "java",
      "performance_score": 70,
      "avg_difficulty_mastered": "Medium-Hard",
      "total_attempts": 3
    }
  ],
  "general_recommendations": "Python is a strong choice for data structures and algorithms, while Java shines in concurrent programming and system design. To improve, focus on boundary conditions and optimize slow-running algorithms in Python, and work on recursion and efficient hash map usage in Java."
}');
-- Insert User 8: Kondeti Pavan Kumar
INSERT INTO users (user_id, created_at, email, name, insights)
VALUES
    ('learnin', NOW(), 'learning@tcs.com', 'learning Pavan Kumar', '{
  "overall_performance_score": 80,
  "suggested_streams": [
    "Data Structures & Algorithms",
    "Concurrent & Parallel Programming",
    "System Design & Scalability"
  ],
  "language_summary": [
    {
      "language": "python",
      "performance_score": 85,
      "avg_difficulty_mastered": "Easy-Medium",
      "total_attempts": 2
    },
    {
      "language": "java",
      "performance_score": 70,
      "avg_difficulty_mastered": "Medium-Hard",
      "total_attempts": 3
    }
  ],
  "general_recommendations": "Python is a strong choice for data structures and algorithms, while Java shines in concurrent programming and system design. To improve, focus on boundary conditions and optimize slow-running algorithms in Python, and work on recursion and efficient hash map usage in Java."
}');

-- ============================================================================
-- Verification Query
-- ============================================================================

-- Verify all users were inserted successfully
SELECT user_id, name, email, created_at
FROM users
ORDER BY user_id;

-- Count total users
SELECT COUNT(*) as total_users FROM users;

-- ============================================================================
-- End of Script
-- ============================================================================

-- Script Summary:
-- - Total Users Inserted: 8
-- - User IDs: 2852985, 2854134, 2853304, 2928088, 2927944, 2918448, 2918705, 2922684

