-- ============================================================================
-- CBL Backend - Problem Test Cases (Part 1 / 4)
-- Covers problem_id 1–42
-- 4 test cases per problem: 2 public, 2 private
-- ============================================================================

-- 🧩 problem_id = 1: Identify the Data Type
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('25', 'Integer', TRUE, 1),
                                                                                   ('true', 'Boolean', TRUE, 1),
                                                                                   ('25.78', 'Float', FALSE, 1),
                                                                                   ('"Hello"', 'String', FALSE, 1);

-- 🧩 problem_id = 2: String to Integer Conversion
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('"123"', '123', TRUE, 2),
                                                                                   ('"42"', '42', TRUE, 2),
                                                                                   ('"abc"', 'Invalid input', FALSE, 2),
                                                                                   ('"-56"', '-56', FALSE, 2);

-- 🧩 problem_id = 3: Find Range of Data Types
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('"int"', 'Range: -2147483648 to 2147483647', TRUE, 3),
                                                                                   ('"float"', 'Approx Range: ±3.4E38', TRUE, 3),
                                                                                   ('"byte"', 'Range: -128 to 127', FALSE, 3),
                                                                                   ('"double"', 'Approx Range: ±1.7E308', FALSE, 3);

-- 🧩 problem_id = 4: Type Casting Demonstration
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('5 2', 'Result: 2.5', TRUE, 4),
                                                                                   ('10 4', 'Result: 2.5', TRUE, 4),
                                                                                   ('7 2', 'Result: 3 (after cast)', FALSE, 4),
                                                                                   ('8 3', 'Result: 2 (after cast)', FALSE, 4);

-- 🧩 problem_id = 5: Dynamic Type Classifier
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('["12", "Hello", "True"]', '["Integer","String","Boolean"]', TRUE, 5),
                                                                                   ('["9.8", "Hi"]', '["Float","String"]', TRUE, 5),
                                                                                   ('["1", "False", "6.6"]', '["Integer","Boolean","Float"]', FALSE, 5),
                                                                                   ('["Name", "100", "true"]', '["String","Integer","Boolean"]', FALSE, 5);

-- 🧩 problem_id = 6: Precision and Overflow Test
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('9999999999', 'Overflow occurred', TRUE, 6),
                                                                                   ('3.141592653589793', 'Precision loss detected', TRUE, 6),
                                                                                   ('2147483648', 'Overflow beyond int range', FALSE, 6),
                                                                                   ('1.234567890123456789', 'Rounded to 1.23456789012346', FALSE, 6);

-- 🧩 problem_id = 7: Arithmetic Operators Practice
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('5 2', 'Add:7 Sub:3 Mul:10 Div:2.5', TRUE, 7),
                                                                                   ('8 4', 'Add:12 Sub:4 Mul:32 Div:2', TRUE, 7),
                                                                                   ('10 0', 'Division by zero error', FALSE, 7),
                                                                                   ('3 7', 'Add:10 Sub:-4 Mul:21 Div:0.43', FALSE, 7);

-- 🧩 problem_id = 8: Comparison Operator Test
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('5 8', '5 < 8', TRUE, 8),
                                                                                   ('4 4', '4 == 4', TRUE, 8),
                                                                                   ('9 3', '9 > 3', FALSE, 8),
                                                                                   ('2 10', '2 != 10', FALSE, 8);

-- 🧩 problem_id = 9: Logical Operator Evaluator
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('true false', 'AND:false OR:true NOT:false', TRUE, 9),
                                                                                   ('false false', 'AND:false OR:false NOT:true', TRUE, 9),
                                                                                   ('true true', 'AND:true OR:true NOT:false', FALSE, 9),
                                                                                   ('false true', 'AND:false OR:true NOT:true', FALSE, 9);

-- 🧩 problem_id = 10: Expression Evaluator
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('"3+5"', '8', TRUE, 10),
                                                                                   ('"7*2"', '14', TRUE, 10),
                                                                                   ('"10/0"', 'Division Error', FALSE, 10),
                                                                                   ('"4*(3+2)"', '20', FALSE, 10);

-- 🧩 problem_id = 11: Bitwise Operations Demo
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('5 3', 'AND:1 OR:7 XOR:6', TRUE, 11),
                                                                                   ('8 4', 'AND:0 OR:12 XOR:12', TRUE, 11),
                                                                                   ('10 6', 'AND:2 OR:14 XOR:12', FALSE, 11),
                                                                                   ('9 5', 'AND:1 OR:13 XOR:12', FALSE, 11);

-- 🧩 problem_id = 12: Operator Precedence Analyzer
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('"3+5*2"', '13', TRUE, 12),
                                                                                   ('"(3+5)*2"', '16', TRUE, 12),
                                                                                   ('"10-4/2+3"', '11', FALSE, 12),
                                                                                   ('"6*2+3^2"', '15', FALSE, 12);

-- 🧩 problem_id = 13: Implicit Conversion
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('5 2.5', 'Converted result: 7.5', TRUE, 13),
                                                                                   ('10 1.5', 'Converted result: 11.5', TRUE, 13),
                                                                                   ('3 4.8', 'Converted result: 7.8', FALSE, 13),
                                                                                   ('2.5 5', 'Converted result: 7.5', FALSE, 13);

-- 🧩 problem_id = 14: Explicit Casting
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('5.8', 'Casted int: 5', TRUE, 14),
                                                                                   ('12.3', 'Casted int: 12', TRUE, 14),
                                                                                   ('-3.9', 'Casted int: -3', FALSE, 14),
                                                                                   ('7.999', 'Casted int: 7', FALSE, 14);

-- 🧩 problem_id = 15: Widening Conversion Chain
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('10', 'byte→short→int→float→double successful', TRUE, 15),
                                                                                   ('100', 'All conversions valid', TRUE, 15),
                                                                                   ('256', 'byte overflow to short', FALSE, 15),
                                                                                   ('99999', 'precision warning in float', FALSE, 15);

-- 🧩 problem_id = 16: Narrowing Conversion Practice
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('12.56', 'After cast to int: 12', TRUE, 16),
                                                                                   ('89.9', 'After cast to int: 89', TRUE, 16),
                                                                                   ('345.89', 'Truncated to 345', FALSE, 16),
                                                                                   ('0.999', 'Truncated to 0', FALSE, 16);

-- 🧩 problem_id = 17: Mixed-Type Arithmetic
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('"A" 5', 'Result: 70', TRUE, 17),
                                                                                   ('"B" 2', 'Result: 68', TRUE, 17),
                                                                                   ('"C" 10', 'Result: 77', FALSE, 17),
                                                                                   ('"Z" 1', 'Result: 91', FALSE, 17);

-- 🧩 problem_id = 18: Custom Type Converter
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('"int 45"', 'Converted: 45', TRUE, 18),
                                                                                   ('"float 3.5"', 'Converted: 3.5', TRUE, 18),
                                                                                   ('"bool yes"', 'Converted: true', FALSE, 18),
                                                                                   ('"string hello"', 'Converted: hello', FALSE, 18);

-- 🧩 problem_id = 19: Global vs Local Variable
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Global:10 Local:5', TRUE, 19),
                                                                                   ('', 'Global:20 Local:15', TRUE, 19),
                                                                                   ('', 'Global modified successfully', FALSE, 19),
                                                                                   ('', 'Shadowing observed', FALSE, 19);

-- 🧩 problem_id = 20: Constant Declaration
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Constant value cannot be reassigned', TRUE, 20),
                                                                                   ('', 'Declared constant PI=3.14', TRUE, 20),
                                                                                   ('', 'Attempt to modify constant raises error', FALSE, 20),
                                                                                   ('', 'Immutable variable test passed', FALSE, 20);
-- ============================================================================
-- CBL Backend - Problem Test Cases (Part 1 / 4 - Continued)
-- Covers problem_id 21–42
-- 4 test cases per problem: 2 public, 2 private
-- ============================================================================

-- 🧩 problem_id = 21: Shadowing Demonstration
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Local variable shadows global', TRUE, 21),
                                                                                   ('', 'Global accessed via scope', TRUE, 21),
                                                                                   ('', 'Shadow variable hides outer scope', FALSE, 21),
                                                                                   ('', 'Printed both global and local', FALSE, 21);

-- 🧩 problem_id = 22: Static vs Instance Variables
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Static shared across objects', TRUE, 22),
                                                                                   ('', 'Instance unique to each object', TRUE, 22),
                                                                                   ('', 'Object count updated globally', FALSE, 22),
                                                                                   ('', 'Static modifies all instances', FALSE, 22);

-- 🧩 problem_id = 23: Scope Lifetime Tracker
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Variable created in function, destroyed after exit', TRUE, 23),
                                                                                   ('', 'Global variable persists', TRUE, 23),
                                                                                   ('', 'Garbage collection executed', FALSE, 23),
                                                                                   ('', 'Local variable reclaimed', FALSE, 23);

-- 🧩 problem_id = 24: Memory Reference Challenge
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Immutable data unaffected', TRUE, 24),
                                                                                   ('', 'Mutable object changed externally', TRUE, 24),
                                                                                   ('', 'Function modifies original object', FALSE, 24),
                                                                                   ('', 'Reference equality test passed', FALSE, 24);

-- 🧩 problem_id = 25: Check Even or Odd
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('4', 'Even', TRUE, 25),
                                                                                   ('9', 'Odd', TRUE, 25),
                                                                                   ('0', 'Even', FALSE, 25),
                                                                                   ('-3', 'Odd', FALSE, 25);

-- 🧩 problem_id = 26: Find Maximum of Two Numbers
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('5 7', '7', TRUE, 26),
                                                                                   ('9 3', '9', TRUE, 26),
                                                                                   ('10 10', 'Equal', FALSE, 26),
                                                                                   ('-2 4', '4', FALSE, 26);

-- 🧩 problem_id = 27: Positive, Negative, or Zero
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('5', 'Positive', TRUE, 27),
                                                                                   ('-3', 'Negative', TRUE, 27),
                                                                                   ('0', 'Zero', FALSE, 27),
                                                                                   ('-1', 'Negative', FALSE, 27);

-- 🧩 problem_id = 28: Grade Calculator
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('85', 'Grade: A', TRUE, 28),
                                                                                   ('72', 'Grade: B', TRUE, 28),
                                                                                   ('59', 'Grade: C', FALSE, 28),
                                                                                   ('30', 'Grade: F', FALSE, 28);

-- 🧩 problem_id = 29: Nested If Example
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('5 9 2', 'Largest: 9', TRUE, 29),
                                                                                   ('8 3 6', 'Largest: 8', TRUE, 29),
                                                                                   ('4 4 4', 'All equal', FALSE, 29),
                                                                                   ('-1 -5 -3', 'Largest: -1', FALSE, 29);

-- 🧩 problem_id = 30: Eligibility Checker
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('16', 'Not eligible to vote', TRUE, 30),
                                                                                   ('20', 'Eligible for vote & drive', TRUE, 30),
                                                                                   ('25', 'Eligible for all', FALSE, 30),
                                                                                   ('12', 'Minor', FALSE, 30);

-- 🧩 problem_id = 31: Weekday Finder
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('1', 'Monday', TRUE, 31),
                                                                                   ('7', 'Sunday', TRUE, 31),
                                                                                   ('8', 'Invalid day', FALSE, 31),
                                                                                   ('0', 'Invalid day', FALSE, 31);

-- 🧩 problem_id = 32: Calculator using Switch
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('5 3 +', '8', TRUE, 32),
                                                                                   ('9 2 *', '18', TRUE, 32),
                                                                                   ('8 0 /', 'Division by zero', FALSE, 32),
                                                                                   ('7 4 -', '3', FALSE, 32);

-- 🧩 problem_id = 33: Vowel or Consonant
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('a', 'Vowel', TRUE, 33),
                                                                                   ('z', 'Consonant', TRUE, 33),
                                                                                   ('E', 'Vowel', FALSE, 33),
                                                                                   ('y', 'Consonant', FALSE, 33);

-- 🧩 problem_id = 34: Month Days Calculator
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('2', '28 or 29 days', TRUE, 34),
                                                                                   ('4', '30 days', TRUE, 34),
                                                                                   ('11', '30 days', FALSE, 34),
                                                                                   ('13', 'Invalid month', FALSE, 34);

-- 🧩 problem_id = 35: Menu-Driven Program
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('1', 'Add operation selected', TRUE, 35),
                                                                                   ('4', 'Exit program', TRUE, 35),
                                                                                   ('2', 'Subtraction selected', FALSE, 35),
                                                                                   ('6', 'Invalid choice', FALSE, 35);

-- 🧩 problem_id = 36: Character Category Identifier
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('A', 'Alphabet', TRUE, 36),
                                                                                   ('5', 'Digit', TRUE, 36),
                                                                                   ('#', 'Symbol', FALSE, 36),
                                                                                   ('z', 'Alphabet', FALSE, 36);

-- 🧩 problem_id = 37: Print 1 to N
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('5', '1 2 3 4 5', TRUE, 37),
                                                                                   ('3', '1 2 3', TRUE, 37),
                                                                                   ('0', 'No output', FALSE, 37),
                                                                                   ('1', '1', FALSE, 37);

-- 🧩 problem_id = 38: Sum of Natural Numbers
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('5', '15', TRUE, 38),
                                                                                   ('10', '55', TRUE, 38),
                                                                                   ('0', '0', FALSE, 38),
                                                                                   ('1', '1', FALSE, 38);

-- 🧩 problem_id = 39: Multiplication Table
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('2', '2 4 6 8 10 12 14 16 18 20', TRUE, 39),
                                                                                   ('5', '5 10 15 20 25 30 35 40 45 50', TRUE, 39),
                                                                                   ('9', '9 18 27 36 45 54 63 72 81 90', FALSE, 39),
                                                                                   ('7', '7 14 21 28 35 42 49 56 63 70', FALSE, 39);

-- 🧩 problem_id = 40: Factorial Finder
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('5', '120', TRUE, 40),
                                                                                   ('3', '6', TRUE, 40),
                                                                                   ('0', '1', FALSE, 40),
                                                                                   ('7', '5040', FALSE, 40);

-- 🧩 problem_id = 41: Prime Numbers in Range
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('10', '2 3 5 7', TRUE, 41),
                                                                                   ('20', '2 3 5 7 11 13 17 19', TRUE, 41),
                                                                                   ('5', '2 3 5', FALSE, 41),
                                                                                   ('1', 'No primes', FALSE, 41);

-- 🧩 problem_id = 42: Pattern Printer
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('3', '*\n**\n***', TRUE, 42),
                                                                                   ('4', '*\n**\n***\n****', TRUE, 42),
                                                                                   ('5', '*\n**\n***\n****\n*****', FALSE, 42),
                                                                                   ('2', '*\n**', FALSE, 42);

-- ============================================================================
-- CBL Backend - Problem Test Cases (Part 2 / 4)
-- Covers problem_id 43–84
-- 4 test cases per problem: 2 public, 2 private
-- ============================================================================

-- 🧩 problem_id = 43: Sum Until Zero
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('5 3 2 0', 'Sum: 10', TRUE, 43),
                                                                                   ('10 20 0', 'Sum: 30', TRUE, 43),
                                                                                   ('1 1 1 0', 'Sum: 3', FALSE, 43),
                                                                                   ('9 9 9 9 0', 'Sum: 36', FALSE, 43);

-- 🧩 problem_id = 44: Countdown Timer
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('5', '5 4 3 2 1', TRUE, 44),
                                                                                   ('3', '3 2 1', TRUE, 44),
                                                                                   ('1', '1', FALSE, 44),
                                                                                   ('0', 'No countdown', FALSE, 44);

-- 🧩 problem_id = 45: Digit Counter
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('123', 'Digits: 3', TRUE, 45),
                                                                                   ('5', 'Digits: 1', TRUE, 45),
                                                                                   ('98765', 'Digits: 5', FALSE, 45),
                                                                                   ('100000', 'Digits: 6', FALSE, 45);

-- 🧩 problem_id = 46: Reverse Number
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('1234', '4321', TRUE, 46),
                                                                                   ('789', '987', TRUE, 46),
                                                                                   ('100', '1', FALSE, 46),
                                                                                   ('5050', '0505', FALSE, 46);

-- 🧩 problem_id = 47: Menu-Driven While Program
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('1\n4', 'Option 1 executed\nExit', TRUE, 47),
                                                                                   ('2\n4', 'Option 2 executed\nExit', TRUE, 47),
                                                                                   ('3\n4', 'Option 3 executed\nExit', FALSE, 47),
                                                                                   ('5\n4', 'Invalid Option\nExit', FALSE, 47);

-- 🧩 problem_id = 48: Do-While Authentication
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('"pass"\n"pass"', 'Login Successful', TRUE, 48),
                                                                                   ('"wrong"\n"pass"', 'Login Successful', TRUE, 48),
                                                                                   ('"wrong"\n"wrong"\n"pass"', 'Login Successful', FALSE, 48),
                                                                                   ('"abc"\n"1234"\n"pass"', 'Login Successful', FALSE, 48);

-- 🧩 problem_id = 49: Simple Function Call
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Welcome to Functions!', TRUE, 49),
                                                                                   ('', 'Function executed successfully', TRUE, 49),
                                                                                   ('', 'Output: Function works fine', FALSE, 49),
                                                                                   ('', 'Printed: Hello Function', FALSE, 49);

-- 🧩 problem_id = 50: Add Two Numbers Function
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('5 10', '15', TRUE, 50),
                                                                                   ('2 3', '5', TRUE, 50),
                                                                                   ('100 200', '300', FALSE, 50),
                                                                                   ('-5 5', '0', FALSE, 50);

-- 🧩 problem_id = 51: Area Calculator
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('"circle" 7', 'Area: 153.94', TRUE, 51),
                                                                                   ('"rectangle" 5 4', 'Area: 20', TRUE, 51),
                                                                                   ('"triangle" 3 6', 'Area: 9', FALSE, 51),
                                                                                   ('"hexagon" 5', 'Invalid shape', FALSE, 51);

-- 🧩 problem_id = 52: Palindrome Checker
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('"madam"', 'Palindrome', TRUE, 52),
                                                                                   ('"hello"', 'Not Palindrome', TRUE, 52),
                                                                                   ('"racecar"', 'Palindrome', FALSE, 52),
                                                                                   ('"abcba"', 'Palindrome', FALSE, 52);

-- 🧩 problem_id = 53: Prime Checker
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('5', 'Prime', TRUE, 53),
                                                                                   ('8', 'Not Prime', TRUE, 53),
                                                                                   ('11', 'Prime', FALSE, 53),
                                                                                   ('1', 'Not Prime', FALSE, 53);

-- 🧩 problem_id = 54: Fibonacci Generator
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('5', '0 1 1 2 3', TRUE, 54),
                                                                                   ('7', '0 1 1 2 3 5 8', TRUE, 54),
                                                                                   ('1', '0', FALSE, 54),
                                                                                   ('10', '0 1 1 2 3 5 8 13 21 34', FALSE, 54);

-- 🧩 problem_id = 55: Square a Number
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('4', '16', TRUE, 55),
                                                                                   ('9', '81', TRUE, 55),
                                                                                   ('-3', '9', FALSE, 55),
                                                                                   ('0', '0', FALSE, 55);

-- 🧩 problem_id = 56: Greeting Function
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('"Alice"', 'Hello Alice!', TRUE, 56),
                                                                                   ('"Bob"', 'Hello Bob!', TRUE, 56),
                                                                                   ('"Sita"', 'Hello Sita!', FALSE, 56),
                                                                                   ('"Ram"', 'Hello Ram!', FALSE, 56);

-- 🧩 problem_id = 57: Average Calculator
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('[2,4,6]', '4.0', TRUE, 57),
                                                                                   ('[10,20,30]', '20.0', TRUE, 57),
                                                                                   ('[5,5,5,5]', '5.0', FALSE, 57),
                                                                                   ('[1,2,3,4,5]', '3.0', FALSE, 57);

-- 🧩 problem_id = 58: Find Max and Min
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('[1,5,3]', 'Max:5 Min:1', TRUE, 58),
                                                                                   ('[10,10,10]', 'Max:10 Min:10', TRUE, 58),
                                                                                   ('[-1,-5,-3]', 'Max:-1 Min:-5', FALSE, 58),
                                                                                   ('[7,9,2,4]', 'Max:9 Min:2', FALSE, 58);

-- 🧩 problem_id = 59: Custom Power Function
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('2 3', '8', TRUE, 59),
                                                                                   ('5 0', '1', TRUE, 59),
                                                                                   ('3 4', '81', FALSE, 59),
                                                                                   ('4 2', '16', FALSE, 59);

-- 🧩 problem_id = 60: Multi-Return Function
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('[1,2,3]', '{"sum":6,"avg":2.0,"prod":6}', TRUE, 60),
                                                                                   ('[4,5]', '{"sum":9,"avg":4.5,"prod":20}', TRUE, 60),
                                                                                   ('[10,2,2]', '{"sum":14,"avg":4.6,"prod":40}', FALSE, 60),
                                                                                   ('[5,5,5]', '{"sum":15,"avg":5.0,"prod":125}', FALSE, 60);

-- 🧩 problem_id = 61: Variable Scope Demo
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Local overrides global', TRUE, 61),
                                                                                   ('', 'Global variable retained', TRUE, 61),
                                                                                   ('', 'Scope isolated between functions', FALSE, 61),
                                                                                   ('', 'No cross-function leakage', FALSE, 61);

-- 🧩 problem_id = 62: Nested Function
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Inner function executed', TRUE, 62),
                                                                                   ('', 'Outer calls inner', TRUE, 62),
                                                                                   ('', 'Nested output validated', FALSE, 62),
                                                                                   ('', 'Inner scope variable accessed', FALSE, 62);

-- 🧩 problem_id = 63: Closure Example
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Closure retains variable value', TRUE, 63),
                                                                                   ('', 'Outer variable remembered', TRUE, 63),
                                                                                   ('', 'State persisted between calls', FALSE, 63),
                                                                                   ('', 'No reinitialization occurred', FALSE, 63);

-- 🧩 problem_id = 64: Counter Closure
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Count:1', TRUE, 64),
                                                                                   ('', 'Count:2', TRUE, 64),
                                                                                   ('', 'Count:3', FALSE, 64),
                                                                                   ('', 'Count:4', FALSE, 64);

-- 🧩 problem_id = 65: Scope Resolution Experiment
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Found in local scope', TRUE, 65),
                                                                                   ('', 'Found in global scope', TRUE, 65),
                                                                                   ('', 'Resolved in enclosing scope', FALSE, 65),
                                                                                   ('', 'Built-in variable used', FALSE, 65);

-- 🧩 problem_id = 66: Function Object Inspector
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Function name printed', TRUE, 66),
                                                                                   ('', 'Docstring found', TRUE, 66),
                                                                                   ('', 'Attributes listed', FALSE, 66),
                                                                                   ('', 'Callable confirmed', FALSE, 66);

-- 🧩 problem_id = 67: Factorial Using Recursion
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('5', '120', TRUE, 67),
                                                                                   ('0', '1', TRUE, 67),
                                                                                   ('7', '5040', FALSE, 67),
                                                                                   ('10', '3628800', FALSE, 67);

-- 🧩 problem_id = 68: Sum of Digits Recursively
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('123', '6', TRUE, 68),
                                                                                   ('999', '27', TRUE, 68),
                                                                                   ('5', '5', FALSE, 68),
                                                                                   ('4567', '22', FALSE, 68);

-- 🧩 problem_id = 69: Fibonacci Recursion
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('5', '5th term: 5', TRUE, 69),
                                                                                   ('7', '7th term: 13', TRUE, 69),
                                                                                   ('1', '1st term: 0', FALSE, 69),
                                                                                   ('10', '10th term: 34', FALSE, 69);

-- 🧩 problem_id = 70: Recursive List Sum
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('[1,2,3]', '6', TRUE, 70),
                                                                                   ('[10,20]', '30', TRUE, 70),
                                                                                   ('[5]', '5', FALSE, 70),
                                                                                   ('[3,3,3,3]', '12', FALSE, 70);

-- 🧩 problem_id = 71: Lambda Map Filter Demo
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('[1,2,3,4]', '[2,4,6,8]', TRUE, 71),
                                                                                   ('[5,6,7]', '[10,12,14]', TRUE, 71),
                                                                                   ('[0,1,2]', '[0,2,4]', FALSE, 71),
                                                                                   ('[10,20]', '[20,40]', FALSE, 71);

-- 🧩 problem_id = 72: Recursive Permutations
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('"abc"', '["abc","acb","bac","bca","cab","cba"]', TRUE, 72),
                                                                                   ('"ab"', '["ab","ba"]', TRUE, 72),
                                                                                   ('"a"', '["a"]', FALSE, 72),
                                                                                   ('"xyz"', '["xyz","xzy","yxz","yzx","zxy","zyx"]', FALSE, 72);

-- 🧩 problem_id = 73: Sum of List Elements
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('[1,2,3]', '6', TRUE, 73),
                                                                                   ('[10,20,30]', '60', TRUE, 73),
                                                                                   ('[]', '0', FALSE, 73),
                                                                                   ('[5,5,5]', '15', FALSE, 73);

-- 🧩 problem_id = 74: Find Largest Element
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('[3,5,7]', '7', TRUE, 74),
                                                                                   ('[10,2,8]', '10', TRUE, 74),
                                                                                   ('[-1,-9,-3]', '-1', FALSE, 74),
                                                                                   ('[4]', '4', FALSE, 74);

-- 🧩 problem_id = 75: Second Largest Finder
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('[1,2,3]', '2', TRUE, 75),
                                                                                   ('[10,9,8]', '9', TRUE, 75),
                                                                                   ('[5,5,5]', 'No second largest', FALSE, 75),
                                                                                   ('[7,3,5,2]', '5', FALSE, 75);

-- 🧩 problem_id = 76: Array Rotation
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('[1,2,3,4,5] 2', '[4,5,1,2,3]', TRUE, 76),
                                                                                   ('[10,20,30,40] 1', '[40,10,20,30]', TRUE, 76),
                                                                                   ('[1,2,3] 3', '[1,2,3]', FALSE, 76),
                                                                                   ('[1,2,3,4,5] 0', '[1,2,3,4,5]', FALSE, 76);

-- 🧩 problem_id = 77: Merge Two Sorted Arrays
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('[1,3,5] [2,4,6]', '[1,2,3,4,5,6]', TRUE, 77),
                                                                                   ('[10,20] [5,15,25]', '[5,10,15,20,25]', TRUE, 77),
                                                                                   ('[1] [2]', '[1,2]', FALSE, 77),
                                                                                   ('[1,2,3] []', '[1,2,3]', FALSE, 77);

-- 🧩 problem_id = 78: Subarray Sum Finder
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('[-2,1,-3,4,-1,2,1,-5,4]', '6', TRUE, 78),
                                                                                   ('[1,2,3]', '6', TRUE, 78),
                                                                                   ('[5,-9,6,7,-2]', '13', FALSE, 78),
                                                                                   ('[-1,-2,-3]', '-1', FALSE, 78);

-- 🧩 problem_id = 79: Remove Duplicates
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('[1,1,2,3]', '[1,2,3]', TRUE, 79),
                                                                                   ('[5,5,5]', '[5]', TRUE, 79),
                                                                                   ('["a","b","a"]', '["a","b"]', FALSE, 79),
                                                                                   ('[10,20,10,30]', '[10,20,30]', FALSE, 79);

-- 🧩 problem_id = 80: Set Operations
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('[1,2,3] [2,3,4]', 'Union:[1,2,3,4]', TRUE, 80),
                                                                                   ('[5,6] [6,7]', 'Intersection:[6]', TRUE, 80),
                                                                                   ('[1,2,3] [3,4]', 'Difference:[1,2]', FALSE, 80),
                                                                                   ('[2,2,3] [3,4]', 'Union:[2,3,4]', FALSE, 80);

-- 🧩 problem_id = 81: Find Common Elements
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('[1,2,3] [2,3,4]', '[2,3]', TRUE, 81),
                                                                                   ('[10,20,30] [40,50]', '[]', TRUE, 81),
                                                                                   ('[7,8,9] [9,10,11]', '[9]', FALSE, 81),
                                                                                   ('[5,6,7] [5,6,7]', '[5,6,7]', FALSE, 81);

-- 🧩 problem_id = 82: Unique Word Counter
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('"hello world hello"', 'Unique:2', TRUE, 82),
                                                                                   ('"a b c a b"', 'Unique:3', TRUE, 82),
                                                                                   ('"this is test"', 'Unique:3', FALSE, 82),
                                                                                   ('"repeat repeat"', 'Unique:1', FALSE, 82);

-- 🧩 problem_id = 83: Subset Checker
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('[1,2] [1,2,3]', 'True', TRUE, 83),
                                                                                   ('[2,3] [1,2,4]', 'False', TRUE, 83),
                                                                                   ('[1,2,3] [1,2,3]', 'True', FALSE, 83),
                                                                                   ('[5,6] [1,2,3]', 'False', FALSE, 83);

-- 🧩 problem_id = 84: Set Difference Application
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('[1,2,3] [2,3,4]', '[1]', TRUE, 84),
                                                                                   ('[5,6,7] [7,8,9]', '[5,6]', TRUE, 84),
                                                                                   ('[10,20] [5,10,15]', '[20]', FALSE, 84),
                                                                                   ('[1,1,2] [1]', '[2]', FALSE, 84);


-- ============================================================================
-- CBL Backend - Problem Test Cases (Part 3 / 4)
-- Covers problem_id 85–126
-- 4 test cases per problem: 2 public, 2 private
-- ============================================================================

-- 🧩 problem_id = 85: Basic Dictionary Creation
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('{"Alice":85,"Bob":90}', '2 entries stored', TRUE, 85),
                                                                                   ('{"A":10}', '1 entry stored', TRUE, 85),
                                                                                   ('{}', 'Empty dictionary created', FALSE, 85),
                                                                                   ('{"X":100,"Y":50}', 'Dictionary created', FALSE, 85);

-- 🧩 problem_id = 86: Key Existence Check
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('{"A":1,"B":2} A', 'Exists', TRUE, 86),
                                                                                   ('{"A":1,"B":2} C', 'Does not exist', TRUE, 86),
                                                                                   ('{"X":5,"Y":10} Y', 'Exists', FALSE, 86),
                                                                                   ('{"Z":9} A', 'Does not exist', FALSE, 86);

-- 🧩 problem_id = 87: Word Frequency Counter
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('"a a b c"', '{"a":2,"b":1,"c":1}', TRUE, 87),
                                                                                   ('"apple banana apple"', '{"apple":2,"banana":1}', TRUE, 87),
                                                                                   ('"cat cat cat"', '{"cat":3}', FALSE, 87),
                                                                                   ('"one two three two"', '{"one":1,"two":2,"three":1}', FALSE, 87);

-- 🧩 problem_id = 88: Invert Dictionary
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('{"A":1,"B":2}', '{"1":"A","2":"B"}', TRUE, 88),
                                                                                   ('{"x":10,"y":20}', '{"10":"x","20":"y"}', TRUE, 88),
                                                                                   ('{"a":1,"b":1}', '{"1":["a","b"]}', FALSE, 88),
                                                                                   ('{"key":"value"}', '{"value":"key"}', FALSE, 88);

-- 🧩 problem_id = 89: Merge Two Maps
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('{"A":1,"B":2} {"B":3,"C":4}', '{"A":1,"B":5,"C":4}', TRUE, 89),
                                                                                   ('{"X":5} {"Y":10}', '{"X":5,"Y":10}', TRUE, 89),
                                                                                   ('{"A":1} {"A":1}', '{"A":2}', FALSE, 89),
                                                                                   ('{} {"B":2}', '{"B":2}', FALSE, 89);

-- 🧩 problem_id = 90: JSON Parser Simulation
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('"{a:1,b:2}"', '{"a":1,"b":2}', TRUE, 90),
                                                                                   ('"{x:10}"', '{"x":10}', TRUE, 90),
                                                                                   ('"{a:1,a:2}"', '{"a":2}', FALSE, 90),
                                                                                   ('"{empty:true}"', '{"empty":true}', FALSE, 90);

-- 🧩 problem_id = 91: Iterate Over List
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('[1,2,3]', '1 2 3', TRUE, 91),
                                                                                   ('["a","b","c"]', 'a b c', TRUE, 91),
                                                                                   ('[]', 'Empty list', FALSE, 91),
                                                                                   ('[10]', '10', FALSE, 91);

-- 🧩 problem_id = 92: Sum of Collection
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('[1,2,3,4]', '10', TRUE, 92),
                                                                                   ('[10,20]', '30', TRUE, 92),
                                                                                   ('[]', '0', FALSE, 92),
                                                                                   ('[5,5,5]', '15', FALSE, 92);

-- 🧩 problem_id = 93: Remove Duplicates from List
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('[1,1,2,3]', '[1,2,3]', TRUE, 93),
                                                                                   ('["a","a","b"]', '["a","b"]', TRUE, 93),
                                                                                   ('[5,5,5,5]', '[5]', FALSE, 93),
                                                                                   ('[2,3,2,4]', '[2,3,4]', FALSE, 93);

-- 🧩 problem_id = 94: Filter Even Numbers
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('[1,2,3,4]', '[2,4]', TRUE, 94),
                                                                                   ('[5,6,7,8]', '[6,8]', TRUE, 94),
                                                                                   ('[10,11,12]', '[10,12]', FALSE, 94),
                                                                                   ('[]', '[]', FALSE, 94);

-- 🧩 problem_id = 95: Sort Custom Objects
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('[{"name":"A","age":25},{"name":"B","age":20}]', '[{"name":"B","age":20},{"name":"A","age":25}]', TRUE, 95),
                                                                                   ('[{"n":"x","v":2},{"n":"y","v":1}]', '[{"n":"y","v":1},{"n":"x","v":2}]', TRUE, 95),
                                                                                   ('[{"a":3},{"a":1},{"a":2}]', '[{"a":1},{"a":2},{"a":3}]', FALSE, 95),
                                                                                   ('[{"x":10},{"x":5}]', '[{"x":5},{"x":10}]', FALSE, 95);

-- 🧩 problem_id = 96: Nested Collection Iterator
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('[[1,2],[3,4]]', '1 2 3 4', TRUE, 96),
                                                                                   ('[[a,b],[c,d]]', 'a b c d', TRUE, 96),
                                                                                   ('[[x],[y],[z]]', 'x y z', FALSE, 96),
                                                                                   ('[[1],[2,3],[4]]', '1 2 3 4', FALSE, 96);

-- 🧩 problem_id = 97: Simple Class Example
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Student: name=Alice, age=20', TRUE, 97),
                                                                                   ('', 'Student: name=Bob, age=22', TRUE, 97),
                                                                                   ('', 'Student object created successfully', FALSE, 97),
                                                                                   ('', 'Class attributes accessible', FALSE, 97);

-- 🧩 problem_id = 98: Multiple Object Creation
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', '2 objects created', TRUE, 98),
                                                                                   ('', '5 students created', TRUE, 98),
                                                                                   ('', 'List length matches count', FALSE, 98),
                                                                                   ('', 'Objects printed correctly', FALSE, 98);

-- 🧩 problem_id = 99: Class with Behavior
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('5000', 'Annual Salary: 60000', TRUE, 99),
                                                                                   ('3000', 'Annual Salary: 36000', TRUE, 99),
                                                                                   ('10000', 'Annual Salary: 120000', FALSE, 99),
                                                                                   ('4500', 'Annual Salary: 54000', FALSE, 99);

-- 🧩 problem_id = 100: Bank Account Class
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('Deposit 100', 'Balance: 100', TRUE, 100),
                                                                                   ('Deposit 50 Withdraw 20', 'Balance: 30', TRUE, 100),
                                                                                   ('Withdraw 100', 'Insufficient funds', FALSE, 100),
                                                                                   ('Deposit 200 Withdraw 50', 'Balance: 150', FALSE, 100);

-- 🧩 problem_id = 101: Copy Constructor Example
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Original copied successfully', TRUE, 101),
                                                                                   ('', 'Different memory address verified', TRUE, 101),
                                                                                   ('', 'Deep copy validated', FALSE, 101),
                                                                                   ('', 'Shallow copy not allowed', FALSE, 101);

-- 🧩 problem_id = 102: Object Comparison
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Equal objects', TRUE, 102),
                                                                                   ('', 'Not equal objects', TRUE, 102),
                                                                                   ('', 'Equality based on fields', FALSE, 102),
                                                                                   ('', 'Hash code matched', FALSE, 102);

-- 🧩 problem_id = 103: Default Constructor Example
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Default values initialized', TRUE, 103),
                                                                                   ('', 'Constructor executed automatically', TRUE, 103),
                                                                                   ('', 'No args constructor confirmed', FALSE, 103),
                                                                                   ('', 'Default age set to 0', FALSE, 103);

-- 🧩 problem_id = 104: Parameterized Constructor
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('John 25', 'Name:John Age:25', TRUE, 104),
                                                                                   ('Alice 20', 'Name:Alice Age:20', TRUE, 104),
                                                                                   ('Ram 30', 'Name:Ram Age:30', FALSE, 104),
                                                                                   ('Bob 18', 'Name:Bob Age:18', FALSE, 104);

-- 🧩 problem_id = 105: Constructor Overloading
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Constructor A called', TRUE, 105),
                                                                                   ('', 'Constructor B called', TRUE, 105),
                                                                                   ('', 'Different params constructor', FALSE, 105),
                                                                                   ('', 'Overload resolved', FALSE, 105);

-- 🧩 problem_id = 106: Chained Constructor Calls
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'this() invoked', TRUE, 106),
                                                                                   ('', 'super() invoked', TRUE, 106),
                                                                                   ('', 'Execution order verified', FALSE, 106),
                                                                                   ('', 'Chained initialization complete', FALSE, 106);

-- 🧩 problem_id = 107: Static Block Initialization
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Static block executed', TRUE, 107),
                                                                                   ('', 'Initialized before main()', TRUE, 107),
                                                                                   ('', 'Static initialized once', FALSE, 107),
                                                                                   ('', 'Execution order confirmed', FALSE, 107);

-- 🧩 problem_id = 108: Object Initialization Order
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Static->Instance->Constructor', TRUE, 108),
                                                                                   ('', 'Order verified', TRUE, 108),
                                                                                   ('', 'Same order repeated for each object', FALSE, 108),
                                                                                   ('', 'No mismatch found', FALSE, 108);

-- 🧩 problem_id = 109: Private Variable Example
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Access via getter works', TRUE, 109),
                                                                                   ('', 'Setter updated variable', TRUE, 109),
                                                                                   ('', 'Direct access denied', FALSE, 109),
                                                                                   ('', 'Encapsulation verified', FALSE, 109);

-- 🧩 problem_id = 110: Access Modifier Scope
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Public accessible', TRUE, 110),
                                                                                   ('', 'Private not accessible', TRUE, 110),
                                                                                   ('', 'Protected accessible in subclass', FALSE, 110),
                                                                                   ('', 'Default restricted to package', FALSE, 110);

-- 🧩 problem_id = 111: Read-Only Property
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Value readable', TRUE, 111),
                                                                                   ('', 'Setter missing', TRUE, 111),
                                                                                   ('', 'Modification error', FALSE, 111),
                                                                                   ('', 'Property remains unchanged', FALSE, 111);

-- 🧩 problem_id = 112: Encapsulation in Banking System
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Deposit successful', TRUE, 112),
                                                                                   ('', 'Balance accessed via getter', TRUE, 112),
                                                                                   ('', 'Direct modification blocked', FALSE, 112),
                                                                                   ('', 'Withdrawal logic secured', FALSE, 112);

-- 🧩 problem_id = 113: Custom Access Control
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Package-private access allowed', TRUE, 113),
                                                                                   ('', 'Other package blocked', TRUE, 113),
                                                                                   ('', 'Default scope verified', FALSE, 113),
                                                                                   ('', 'Access outside failed', FALSE, 113);

-- 🧩 problem_id = 114: Immutable Class Design
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'No setters present', TRUE, 114),
                                                                                   ('', 'Final fields used', TRUE, 114),
                                                                                   ('', 'Attempt to modify fails', FALSE, 114),
                                                                                   ('', 'Constructor-only assignment', FALSE, 114);

-- 🧩 problem_id = 115: Method Definition Example
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Hello from method', TRUE, 115),
                                                                                   ('', 'Method called successfully', TRUE, 115),
                                                                                   ('', 'Execution complete', FALSE, 115),
                                                                                   ('', 'Output verified', FALSE, 115);

-- 🧩 problem_id = 116: Method Overloading Example
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'int method called', TRUE, 116),
                                                                                   ('', 'double method called', TRUE, 116),
                                                                                   ('', 'string method called', FALSE, 116),
                                                                                   ('', 'overload resolved', FALSE, 116);

-- 🧩 problem_id = 117: Return Value Method
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('3 4', '7', TRUE, 117),
                                                                                   ('10 5', '15', TRUE, 117),
                                                                                   ('9 1', '10', FALSE, 117),
                                                                                   ('100 200', '300', FALSE, 117);

-- 🧩 problem_id = 118: Instance Variable Updater
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Updated value: 10', TRUE, 118),
                                                                                   ('', 'Value incremented', TRUE, 118),
                                                                                   ('', 'Variable modified successfully', FALSE, 118),
                                                                                   ('', 'Latest value reflected', FALSE, 118);

-- 🧩 problem_id = 119: Static vs Instance Method
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Static called via class', TRUE, 119),
                                                                                   ('', 'Instance called via object', TRUE, 119),
                                                                                   ('', 'Both executed', FALSE, 119),
                                                                                   ('', 'Order of call validated', FALSE, 119);

-- 🧩 problem_id = 120: Method Chaining
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Chained call complete', TRUE, 120),
                                                                                   ('', 'Fluent API executed', TRUE, 120),
                                                                                   ('', 'Returned this reference', FALSE, 120),
                                                                                   ('', 'Sequence executed properly', FALSE, 120);

-- 🧩 problem_id = 121: Basic Exception Handling
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('5 0', 'Exception caught', TRUE, 121),
                                                                                   ('10 2', 'Division successful', TRUE, 121),
                                                                                   ('8 0', 'Handled divide by zero', FALSE, 121),
                                                                                   ('9 3', 'Result: 3', FALSE, 121);

-- 🧩 problem_id = 122: Multiple Catch Blocks
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Arithmetic caught', TRUE, 122),
                                                                                   ('', 'Array caught', TRUE, 122),
                                                                                   ('', 'String caught', FALSE, 122),
                                                                                   ('', 'All handled', FALSE, 122);

-- 🧩 problem_id = 123: File Reading Exception
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('"data.txt"', 'File found', TRUE, 123),
                                                                                   ('"nofile.txt"', 'FileNotFound handled', TRUE, 123),
                                                                                   ('"corrupt.txt"', 'IOException handled', FALSE, 123),
                                                                                   ('"close.txt"', 'Finally executed', FALSE, 123);

-- 🧩 problem_id = 124: Custom Exception Creation
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('15', 'Within limit', TRUE, 124),
                                                                                   ('0', 'CustomException triggered', TRUE, 124),
                                                                                   ('-1', 'Error handled', FALSE, 124),
                                                                                   ('100', 'Handled properly', FALSE, 124);

-- 🧩 problem_id = 125: Nested Try Example
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Inner exception caught', TRUE, 125),
                                                                                   ('', 'Outer executed', TRUE, 125),
                                                                                   ('', 'Nested blocks verified', FALSE, 125),
                                                                                   ('', 'Flow maintained', FALSE, 125);

-- 🧩 problem_id = 126: Finally Block Validation
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Finally executed', TRUE, 126),
                                                                                   ('', 'Return ignored finally runs', TRUE, 126),
                                                                                   ('', 'Always executes', FALSE, 126),
                                                                                   ('', 'Cleaned up resources', FALSE, 126);
-- ============================================================================
-- CBL Backend - Problem Test Cases (Part 4 / 4)
-- Covers problem_id 127–168
-- 4 test cases per problem: 2 public, 2 private
-- ============================================================================

-- 🧩 problem_id = 127: Exception Hierarchy Demo
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'RuntimeException caught', TRUE, 127),
                                                                                   ('', 'Exception hierarchy verified', TRUE, 127),
                                                                                   ('', 'Throwable root confirmed', FALSE, 127),
                                                                                   ('', 'Error subclass excluded', FALSE, 127);

-- 🧩 problem_id = 128: Checked vs Unchecked
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Checked exception handled', TRUE, 128),
                                                                                   ('', 'Unchecked propagated', TRUE, 128),
                                                                                   ('', 'Compile-time validation success', FALSE, 128),
                                                                                   ('', 'Runtime thrown', FALSE, 128);

-- 🧩 problem_id = 129: Custom Exception Throw
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('25', 'Valid', TRUE, 129),
                                                                                   ('-1', 'InvalidInputException thrown', TRUE, 129),
                                                                                   ('0', 'Boundary error handled', FALSE, 129),
                                                                                   ('101', 'Custom exception triggered', FALSE, 129);

-- 🧩 problem_id = 130: Exception Propagation
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Exception propagated to main', TRUE, 130),
                                                                                   ('', 'Handled at top level', TRUE, 130),
                                                                                   ('', 'Method chain maintained', FALSE, 130),
                                                                                   ('', 'No suppression detected', FALSE, 130);

-- 🧩 problem_id = 131: Try-With-Resources
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Resource closed automatically', TRUE, 131),
                                                                                   ('', 'No finally required', TRUE, 131),
                                                                                   ('', 'Multiple resources handled', FALSE, 131),
                                                                                   ('', 'AutoCloseable verified', FALSE, 131);

-- 🧩 problem_id = 132: Throw vs Throws
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', '"throw" used inside method', TRUE, 132),
                                                                                   ('', '"throws" used in declaration', TRUE, 132),
                                                                                   ('', 'Both combined correctly', FALSE, 132),
                                                                                   ('', 'Compilation success', FALSE, 132);

-- 🧩 problem_id = 133: Nested Exception Handling
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Inner handled first', TRUE, 133),
                                                                                   ('', 'Outer executed after inner', TRUE, 133),
                                                                                   ('', 'Control flow validated', FALSE, 133),
                                                                                   ('', 'Nested finally executed', FALSE, 133);

-- 🧩 problem_id = 134: Multi-Catch Example
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Caught IOException or ArithmeticException', TRUE, 134),
                                                                                   ('', 'No duplicate catch allowed', TRUE, 134),
                                                                                   ('', 'Common superclass used', FALSE, 134),
                                                                                   ('', 'Handled gracefully', FALSE, 134);

-- 🧩 problem_id = 135: Custom Message in Exception
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Message: Invalid age', TRUE, 135),
                                                                                   ('', 'Printed custom text', TRUE, 135),
                                                                                   ('', 'Getter returns same message', FALSE, 135),
                                                                                   ('', 'Stack trace included', FALSE, 135);

-- 🧩 problem_id = 136: Exception Re-throwing
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Caught and rethrown', TRUE, 136),
                                                                                   ('', 'Handled by caller', TRUE, 136),
                                                                                   ('', 'Original preserved', FALSE, 136),
                                                                                   ('', 'Cause chain maintained', FALSE, 136);

-- 🧩 problem_id = 137: Logging Exceptions
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Logged to file', TRUE, 137),
                                                                                   ('', 'Printed stack trace', TRUE, 137),
                                                                                   ('', 'Timestamp recorded', FALSE, 137),
                                                                                   ('', 'Logger flushed', FALSE, 137);

-- 🧩 problem_id = 138: Retry Logic with Exception
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Attempt 1 failed, retry succeeded', TRUE, 138),
                                                                                   ('', 'Max retries reached', TRUE, 138),
                                                                                   ('', 'Backoff strategy applied', FALSE, 138),
                                                                                   ('', 'Retry count logged', FALSE, 138);

-- 🧩 problem_id = 139: Exception Hierarchy Printer
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Printed superclass chain', TRUE, 139),
                                                                                   ('', 'Ends with Throwable', TRUE, 139),
                                                                                   ('', 'No cycles found', FALSE, 139),
                                                                                   ('', 'Accurate hierarchy depth', FALSE, 139);

-- 🧩 problem_id = 140: Base Class Example
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Parent method executed', TRUE, 140),
                                                                                   ('', 'Parent field accessed', TRUE, 140),
                                                                                   ('', 'Inheritance successful', FALSE, 140),
                                                                                   ('', 'Parent method overridden', FALSE, 140);

-- 🧩 problem_id = 141: Derived Class Example
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Child extends Parent', TRUE, 141),
                                                                                   ('', 'Inherited methods accessible', TRUE, 141),
                                                                                   ('', 'Override executed', FALSE, 141),
                                                                                   ('', 'Parent constructor called', FALSE, 141);

-- 🧩 problem_id = 142: Method Overriding
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Child method executed', TRUE, 142),
                                                                                   ('', 'Parent reference Child object works', TRUE, 142),
                                                                                   ('', 'Runtime polymorphism confirmed', FALSE, 142),
                                                                                   ('', 'Same signature verified', FALSE, 142);

-- 🧩 problem_id = 143: super Keyword Demo
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'super() called', TRUE, 143),
                                                                                   ('', 'Accessed parent method', TRUE, 143),
                                                                                   ('', 'Constructor chaining done', FALSE, 143),
                                                                                   ('', 'Parent variable accessed', FALSE, 143);

-- 🧩 problem_id = 144: Dynamic Binding Example
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Runtime method selection', TRUE, 144),
                                                                                   ('', 'Base ref Child obj executed child version', TRUE, 144),
                                                                                   ('', 'Resolved during execution', FALSE, 144),
                                                                                   ('', 'Polymorphic dispatch works', FALSE, 144);

-- 🧩 problem_id = 145: Method Overloading vs Overriding
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Overloading compile-time', TRUE, 145),
                                                                                   ('', 'Overriding runtime', TRUE, 145),
                                                                                   ('', 'Both concepts demonstrated', FALSE, 145),
                                                                                   ('', 'Signatures differ', FALSE, 145);

-- 🧩 problem_id = 146: Hierarchical Inheritance Example
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Common parent shared', TRUE, 146),
                                                                                   ('', 'Multiple children created', TRUE, 146),
                                                                                   ('', 'Inheritance tree valid', FALSE, 146),
                                                                                   ('', 'No diamond issue', FALSE, 146);

-- 🧩 problem_id = 147: Multilevel Inheritance Example
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Grandchild inherits from parent', TRUE, 147),
                                                                                   ('', 'Chain of constructors called', TRUE, 147),
                                                                                   ('', 'All levels accessed', FALSE, 147),
                                                                                   ('', 'No redundancy detected', FALSE, 147);

-- 🧩 problem_id = 148: Abstract Class Demo
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Cannot instantiate abstract class', TRUE, 148),
                                                                                   ('', 'Subclass implemented methods', TRUE, 148),
                                                                                   ('', 'Abstract method overridden', FALSE, 148),
                                                                                   ('', 'Dynamic dispatch works', FALSE, 148);

-- 🧩 problem_id = 149: Abstract Method Implementation
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Abstract method implemented', TRUE, 149),
                                                                                   ('', 'Subclass used overridden version', TRUE, 149),
                                                                                   ('', 'No missing implementation', FALSE, 149),
                                                                                   ('', 'Abstract rule enforced', FALSE, 149);

-- 🧩 problem_id = 150: Interface Declaration
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Interface declared', TRUE, 150),
                                                                                   ('', 'Method signatures defined', TRUE, 150),
                                                                                   ('', 'No constructor allowed', FALSE, 150),
                                                                                   ('', 'Constants accessed via name', FALSE, 150);

-- 🧩 problem_id = 151: Interface Implementation
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Implemented all methods', TRUE, 151),
                                                                                   ('', 'Interface object via reference', TRUE, 151),
                                                                                   ('', 'Polymorphism via interface', FALSE, 151),
                                                                                   ('', 'Default method accessed', FALSE, 151);

-- 🧩 problem_id = 152: Multiple Interface Implementation
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Implements A and B', TRUE, 152),
                                                                                   ('', 'Conflict resolved explicitly', TRUE, 152),
                                                                                   ('', 'All methods available', FALSE, 152),
                                                                                   ('', 'No ambiguity remains', FALSE, 152);

-- 🧩 problem_id = 153: Default Interface Method
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Default executed', TRUE, 153),
                                                                                   ('', 'Overridden default executed', TRUE, 153),
                                                                                   ('', 'Static method accessed', FALSE, 153),
                                                                                   ('', 'No collision found', FALSE, 153);

-- 🧩 problem_id = 154: Functional Interface
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Single abstract method confirmed', TRUE, 154),
                                                                                   ('', 'Lambda implemented interface', TRUE, 154),
                                                                                   ('', 'Multiple SAM not allowed', FALSE, 154),
                                                                                   ('', 'Annotation @FunctionalInterface validated', FALSE, 154);

-- 🧩 problem_id = 155: Interface Inheritance
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Child interface extends parent', TRUE, 155),
                                                                                   ('', 'All methods inherited', TRUE, 155),
                                                                                   ('', 'Additional method added', FALSE, 155),
                                                                                   ('', 'Conflict resolved', FALSE, 155);

-- 🧩 problem_id = 156: Abstract vs Interface Comparison
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Abstract can have constructor', TRUE, 156),
                                                                                   ('', 'Interface cannot have constructor', TRUE, 156),
                                                                                   ('', 'Both support abstraction', FALSE, 156),
                                                                                   ('', 'Interface supports multiple inheritance', FALSE, 156);

-- 🧩 problem_id = 157: Anonymous Class Example
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Anonymous object created', TRUE, 157),
                                                                                   ('', 'Overridden method called', TRUE, 157),
                                                                                   ('', 'No name assigned', FALSE, 157),
                                                                                   ('', 'Inline instantiation complete', FALSE, 157);

-- 🧩 problem_id = 158: Abstract Class Variable
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Reference of abstract type', TRUE, 158),
                                                                                   ('', 'Instance of concrete subclass', TRUE, 158),
                                                                                   ('', 'Runtime binding verified', FALSE, 158),
                                                                                   ('', 'Cannot new abstract class', FALSE, 158);

-- 🧩 problem_id = 159: Interface Constant Example
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Constant value accessed', TRUE, 159),
                                                                                   ('', 'Static final verified', TRUE, 159),
                                                                                   ('', 'Modification disallowed', FALSE, 159),
                                                                                   ('', 'Compile-time accessible', FALSE, 159);

-- 🧩 problem_id = 160: Abstract Constructor Call
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Superclass constructor called', TRUE, 160),
                                                                                   ('', 'Abstract class initialized', TRUE, 160),
                                                                                   ('', 'Chain completed successfully', FALSE, 160),
                                                                                   ('', 'Execution order validated', FALSE, 160);

-- 🧩 problem_id = 161: Interface Multiple Inheritance
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Methods combined', TRUE, 161),
                                                                                   ('', 'No diamond conflict', TRUE, 161),
                                                                                   ('', 'Overridden successfully', FALSE, 161),
                                                                                   ('', 'Default handled cleanly', FALSE, 161);

-- 🧩 problem_id = 162: Abstract Factory Pattern
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Created product via abstract factory', TRUE, 162),
                                                                                   ('', 'Concrete factory returned', TRUE, 162),
                                                                                   ('', 'Factory method overridden', FALSE, 162),
                                                                                   ('', 'Polymorphism applied', FALSE, 162);

-- 🧩 problem_id = 163: Template Method Pattern
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Base defines template', TRUE, 163),
                                                                                   ('', 'Child overrides steps', TRUE, 163),
                                                                                   ('', 'Flow maintained', FALSE, 163),
                                                                                   ('', 'Hook method executed', FALSE, 163);

-- 🧩 problem_id = 164: Interface Default Conflict
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Conflict resolved via override', TRUE, 164),
                                                                                   ('', 'Ambiguity avoided', TRUE, 164),
                                                                                   ('', 'Explicit call to Interface.super', FALSE, 164),
                                                                                   ('', 'Final override applied', FALSE, 164);

-- 🧩 problem_id = 165: Abstract Interface Mix
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Abstract implements interface', TRUE, 165),
                                                                                   ('', 'Partial implementation allowed', TRUE, 165),
                                                                                   ('', 'Subclass completed remaining methods', FALSE, 165),
                                                                                   ('', 'Hierarchy validated', FALSE, 165);

-- 🧩 problem_id = 166: Abstract Field and Method
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Abstract method invoked', TRUE, 166),
                                                                                   ('', 'Field inherited correctly', TRUE, 166),
                                                                                   ('', 'Override successful', FALSE, 166),
                                                                                   ('', 'No instantiation allowed', FALSE, 166);

-- 🧩 problem_id = 167: Interface Polymorphism Example
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'Implemented via multiple classes', TRUE, 167),
                                                                                   ('', 'Runtime binding confirmed', TRUE, 167),
                                                                                   ('', 'Dynamic dispatch works', FALSE, 167),
                                                                                   ('', 'Polymorphism achieved', FALSE, 167);

-- 🧩 problem_id = 168: Complete Abstraction Example
INSERT INTO problem_test_cases (input, expected_output, is_public, problem_id) VALUES
                                                                                   ('', 'All methods abstract', TRUE, 168),
                                                                                   ('', 'No implementation in base', TRUE, 168),
                                                                                   ('', 'Implemented in derived', FALSE, 168),
                                                                                   ('', 'Full abstraction achieved', FALSE, 168);
