package com.ignite.CBL.repository;

import com.ignite.CBL.entity.Topic;
import com.ignite.CBL.entity.User;
import com.ignite.CBL.entity.UserTopicEngagement;
import org.springframework.data.jpa.repository.JpaRepository;
import com.ignite.CBL.entity.UserTopicEngagementId;

import java.util.Optional;

public interface UserTopicEngagementRepository extends JpaRepository<UserTopicEngagement, UserTopicEngagementId> {
    
    Optional<UserTopicEngagement> findByUser_UserIdAndTopic_TopicId(String userId, Integer topicId);
    
    boolean existsByUser_UserIdAndTopic_TopicId(String userId, Integer topicId);
}
