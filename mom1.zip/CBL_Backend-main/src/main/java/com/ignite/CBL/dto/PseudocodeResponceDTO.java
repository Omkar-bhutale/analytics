package com.ignite.CBL.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class PseudocodeResponceDTO {
    private Integer pseudocodeSubmissionId;
    private String content;
    private Boolean isCorrect;
    private Integer problemId;
    private Integer version;
    private LocalDateTime submittedAt;
}
