package com.ignite.CBL.service;

import com.ignite.CBL.dto.TopicDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface TopicService {
    
    Optional<TopicDTO> findTopicById(Integer topicId);
    
    Optional<TopicDTO> findTopicByTitle(String title);
    
    List<TopicDTO> findAllByMainTopicId(Integer mainTopicId);
    
    Page<TopicDTO> findPaginatedByMainTopicId(Integer mainTopicId, Pageable pageable);
    
    TopicDTO createTopic(Integer mainTopicId, TopicDTO topicDTO);
    
    int createTopics(Integer mainTopicId, List<TopicDTO> topicDTOs);
    
    Optional<TopicDTO> updateTopic(Integer topicId, TopicDTO topicDTO);
    
    boolean deleteTopicById(Integer topicId);
    
    int deleteAllByMainTopicId(Integer mainTopicId);
    
    void deleteAll();
    
    boolean existsByTitle(String title);
}
