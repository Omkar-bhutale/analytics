package com.ignite.CBL.service.impl;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ignite.CBL.dto.*;
import com.ignite.CBL.entity.*;
import com.ignite.CBL.exception.ResourceNotFoundException;
import com.ignite.CBL.repository.*;
import com.ignite.CBL.service.AlgorithmSubmissionService;
import com.ignite.CBL.service.ProblemSubmissionService;
import com.ignite.CBL.service.PseudocodeSubmissionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProblemSubmissionServiceImpl implements ProblemSubmissionService {

    @Value("${user.id}")
    private String userId;

    private final ProblemRepository problemRepository;
    private final AlgorithmSubmissionService algorithmSubmissionService;
    private final PseudocodeSubmissionService pseudocodeSubmissionService;
    private final UserProblemEngagementRepository userProblemEngagementRepository;
    private final UserRepository userRepository;
    private final ProblemSubmissionRepository problemSubmissionRepository;
    private final UserProblemReportRepository userProblemReportRepository;

    @Override
    @Transactional
    public ProblemCodeResponceDTO getProblemToSolve(Integer problemId) {
        log.info("Getting problem to solve for problemId: {} and userId: {}", problemId, userId);
        
        // Verify algorithm submission is correct
        if (!algorithmSubmissionService.isAlgorithmCorrect(problemId)) {
            throw new IllegalStateException("Algorithm submission must be correct before solving the problem");
        }
        
        // Verify pseudocode submission is correct
        if (!pseudocodeSubmissionService.isPseudocodeCorrect(problemId)) {
            throw new IllegalStateException("Pseudocode submission must be correct before solving the problem");
        }

        Problem problem = problemRepository.findById(problemId)
                .orElseThrow(() -> new ResourceNotFoundException("Problem not found with id: " + problemId));
        
        // Fetch or create UserProblemEngagement
        UserProblemEngagement engagement = getOrCreateUserProblemEngagement(problemId, problem);
        
        // Convert Problem to ProblemDTO
        ProblemDTO problemDTO = convertToProblemDTO(problem);
        
        // Build response DTO
        ProblemCodeResponceDTO response = new ProblemCodeResponceDTO();
        response.setProblemDTO(problemDTO);
        response.setSavedCodes(engagement.getSavedCodes());
        response.setTotalSecondsSpent(engagement.getTotalSecondsSpent());
        
        log.info("Successfully retrieved problem to solve for problemId: {}", problemId);
        return response;
    }

    private ProblemDTO convertToProblemDTO(Problem problem) {
        return ProblemDTO.builder()
                .problemId(problem.getProblemId())
                .title(problem.getTitle())
                .description(problem.getDescription())
                .difficulty(problem.getDifficulty())
                .testCases(problem.getTestCases().stream()
                        .map(tc -> ProblemTestCaseDTO.builder()
                                .testCaseId(tc.getTestCaseId())
                                .input(tc.getInput())
                                .expectedOutput(tc.getExpectedOutput())
                                .isPublic(tc.getIsPublic())
                                .build())
                        .collect(Collectors.toSet()))
                .build();
    }

    private UserProblemEngagement getOrCreateUserProblemEngagement(Integer problemId, Problem problem) {
        UserProblemEngagement engagement = userProblemEngagementRepository
                .findById_UserIdAndId_ProblemId(userId, problemId)
                .orElse(null);
        
        if (engagement == null) {
            log.info("Creating new UserProblemEngagement for userId: {} and problemId: {}", userId, problemId);
            engagement = new UserProblemEngagement();
            
            UserProblemEngagementId engagementId = new UserProblemEngagementId();
            engagementId.setProblemId(problemId);
            engagementId.setUserId(userId);
            
            engagement.setId(engagementId);
            engagement.setProblem(problem);
            

            User user = userRepository.findByUserId(userId)
                    .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));
            engagement.setUser(user);
            
            engagement = userProblemEngagementRepository.save(engagement);
        }
        
        return engagement;
    }

    @Override
    @Transactional
    public void saveCodeAndTime(SaveCodeAndTimeRequest saveCodeAndTimeRequest) {
        log.info("Saving code and time for problemId: {} and userId: {}", saveCodeAndTimeRequest.getProblemId(), userId);
        
        UserProblemEngagement engagement = userProblemEngagementRepository
                .findById_UserIdAndId_ProblemId(userId, saveCodeAndTimeRequest.getProblemId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "UserProblemEngagement not found for problemId: " + saveCodeAndTimeRequest.getProblemId() + " and userId: " + userId));
        
        engagement.setSavedCodes(saveCodeAndTimeRequest.getSavedCodes());
        if(!engagement.getIsSolved())  engagement.setTotalSecondsSpent(saveCodeAndTimeRequest.getTotalSecondsSpent());
        
        userProblemEngagementRepository.save(engagement);
    }

    @Override
    @Transactional
    public boolean saveSubmission(ProblemSubmissionRequestDTO problemSubmissionRequestDTO) {
        log.info("Saving submission for problemId: {}, userId: {}, language: {}", 
                problemSubmissionRequestDTO.getProblemId(), userId, problemSubmissionRequestDTO.getLanguage());

        try {

            UserProblemReport userProblemReport = getOrCreateUserProblemReport(
                    problemSubmissionRequestDTO.getProblemId());

            log.info("UserProblemReport: {}", userProblemReport);
            UserProblemEngagement engagement = getOrCreateUserProblemEngagement(
                    problemSubmissionRequestDTO.getProblemId(),
                    problemRepository.findById(problemSubmissionRequestDTO.getProblemId())
                            .orElseThrow(() -> new ResourceNotFoundException("Problem not found"))
            );
            log.info("UserProblemEngagement: {}", engagement);


            ProblemSubmission submission = problemSubmissionRepository
                    .findByProblem_ProblemIdAndUser_UserIdAndLanguage(
                            problemSubmissionRequestDTO.getProblemId(),
                            userId,
                            problemSubmissionRequestDTO.getLanguage()
                    )
                    .orElse(new ProblemSubmission());
            log.info("ProblemSubmission: {}", submission);

            //user engage ment must saved first
            if(!engagement.getIsSolved()) engagement.setTotalSecondsSpent(engagement.getTotalSecondsSpent());
            if (Boolean.TRUE.equals(problemSubmissionRequestDTO.getIsCorrect())) {
                engagement.setIsSolved(true);
            }

            // Save the engagement
            engagement.setSavedCodes(problemSubmissionRequestDTO.getSavedCodes());
            userProblemEngagementRepository.save(engagement);

            if((submission.getIsSolved()!=null && submission.getIsSolved())  && !problemSubmissionRequestDTO.getIsCorrect() ) return false;
            submission.setProblem(problemRepository.findById(problemSubmissionRequestDTO.getProblemId())
                    .orElseThrow(() -> new ResourceNotFoundException("Problem not found")));
            submission.setUser(userRepository.findByUserId(userId)
                    .orElseThrow(() -> new ResourceNotFoundException("User not found")));

            submission.setLanguage(problemSubmissionRequestDTO.getLanguage());
            submission.setCode(problemSubmissionRequestDTO.getCode());
            submission.setTotalTestCases(problemSubmissionRequestDTO.getTotalTestCases() != null ?
                    problemSubmissionRequestDTO.getTotalTestCases() : 0);
            submission.setPassedTestCases(problemSubmissionRequestDTO.getTotalTestCasesPassed() != null ?
                    problemSubmissionRequestDTO.getTotalTestCasesPassed() : 0);
            submission.setInsights(problemSubmissionRequestDTO.getInsights());
            submission.setIsSolved(problemSubmissionRequestDTO.getIsCorrect());
            submission.setUserProblemReport(userProblemReport);

            // Save the submission
            problemSubmissionRepository.save(submission);


            Language language = problemSubmissionRequestDTO.getLanguage();
            if (!userProblemReport.getLanguagesUsed().contains(language)) {
                userProblemReport.getLanguagesUsed().add(language);
            }

            // Update engagement and user problem report if submission is correct
            if (Boolean.TRUE.equals(problemSubmissionRequestDTO.getIsCorrect())) {
                userProblemReport.setSolved(true);
            }
            userProblemReportRepository.save(userProblemReport);


            log.info("Successfully saved submission for problemId: {}", problemSubmissionRequestDTO.getProblemId());
            return true;

        } catch (Exception e) {
            log.error("Error saving submission: {}", e.getMessage(), e);
            throw e;
        }
    }
    
    private UserProblemReport getOrCreateUserProblemReport(Integer problemId) {
        return userProblemReportRepository.findByUser_UserIdAndProblem_ProblemId(userId, problemId)
                .orElseGet(() -> {
                    Problem problem = problemRepository.findById(problemId)
                            .orElseThrow(() -> new ResourceNotFoundException("Problem not found with id: " + problemId));
                    User user = userRepository.findByUserId(userId)
                            .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));
                            
                    UserProblemReport report = new UserProblemReport();
                    report.setProblem(problem);
                    report.setUser(user);
                    report.setTotalAttempts(0);
                    report.setSolved(false);

                    //TODO:This has to be removed
                    ObjectMapper mapper = new ObjectMapper();
                    ObjectNode body = mapper.createObjectNode();
                    body.put("msg", "Time complexity can be improved");
                    report.setInsight(body);

                    report.setLanguagesUsed(new java.util.HashSet<Language>());
                    
                    return userProblemReportRepository.save(report);
                });
    }
    @Override
    @Transactional(readOnly = true)
    public List<ProblemSubmissionResponceDTO> getAllSubmissions(Integer problemId) {
        log.info("Fetching all submissions for problemId: {} and userId: {}", problemId, userId);

        // Get all submissions for the current user and problem
        List<ProblemSubmission> submissions = problemSubmissionRepository.findByProblem_ProblemIdAndUser_UserId(problemId, userId);

        // Map each submission to DTO
        return submissions.stream()
                .map(submission -> ProblemSubmissionResponceDTO.builder()
                        .problemId(submission.getProblem().getProblemId())
                        .language(submission.getLanguage().name())
                        .code(submission.getCode())
                        .isCorrect(submission.getIsSolved())
                        .totalTestCasesPassed(submission.getPassedTestCases())
                        .totalTestCases(submission.getTotalTestCases())
                        .insights(submission.getInsights())
                        .build())
                .collect(Collectors.toList());
    }
}

