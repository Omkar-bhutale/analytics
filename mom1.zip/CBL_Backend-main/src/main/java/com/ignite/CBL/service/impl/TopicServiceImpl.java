package com.ignite.CBL.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.ignite.CBL.dto.TopicDTO;
import com.ignite.CBL.entity.MainTopic;
import com.ignite.CBL.entity.Topic;
import com.ignite.CBL.exception.ResourceNotFoundException;
import com.ignite.CBL.repository.MainTopicRepository;
import com.ignite.CBL.repository.TopicRepository;
import com.ignite.CBL.service.TopicService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class TopicServiceImpl implements TopicService {

    private final TopicRepository topicRepository;
    private final MainTopicRepository mainTopicRepository;
    private final ModelMapper modelMapper;

    @Override
    public Optional<TopicDTO> findTopicById(Integer topicId) {
        log.debug("Finding topic by id: {}", topicId);
        return topicRepository.findTopicDTOById(topicId);
    }

    @Override
    public Optional<TopicDTO> findTopicByTitle(String title) {
        log.debug("Finding topic by title: {}", title);
        return topicRepository.findTopicDTOByTitle(title);
    }

    @Override
    public List<TopicDTO> findAllByMainTopicId(Integer mainTopicId) {
        log.debug("Finding all topics for main topic id: {}", mainTopicId);
        if (!mainTopicRepository.existsById(mainTopicId)) {
            throw new ResourceNotFoundException("MainTopic not found with id: " + mainTopicId);
        }
        return topicRepository.findAllByMainTopicId(mainTopicId);
    }

    @Override
    public Page<TopicDTO> findPaginatedByMainTopicId(Integer mainTopicId, Pageable pageable) {
        log.debug("Finding paginated topics for main topic id: {}", mainTopicId);
        if (!mainTopicRepository.existsById(mainTopicId)) {
            throw new ResourceNotFoundException("MainTopic not found with id: " + mainTopicId);
        }
        return topicRepository.findPaginatedByMainTopicId(mainTopicId, pageable);
    }

    @Override
    @Transactional
    public TopicDTO createTopic(Integer mainTopicId, TopicDTO topicDTO) {
        log.debug("Creating new topic for main topic id: {}", mainTopicId);
        MainTopic mainTopic = mainTopicRepository.findById(mainTopicId)
                .orElseThrow(() -> new ResourceNotFoundException("MainTopic not found with id: " + mainTopicId));

        if (topicRepository.existsByTitle(topicDTO.getTitle())) {
            throw new IllegalArgumentException("Topic with title '" + topicDTO.getTitle() + "' already exists");
        }

        Topic topic = Topic.builder()
                .title(topicDTO.getTitle())
                .content(topicDTO.getContent())
                .mainTopic(mainTopic)
                .createdAt(LocalDateTime.now())
                .build();

        Topic savedTopic = topicRepository.save(topic);
        log.info("Created new topic with id: {}", savedTopic.getTopicId());
        return convertToDTO(savedTopic);
    }

    @Override
    @Transactional
    public int createTopics(Integer mainTopicId, List<TopicDTO> topicDTOs) {
        log.debug("Creating {} topics for main topic id: {}", topicDTOs.size(), mainTopicId);
        MainTopic mainTopic = mainTopicRepository.findById(mainTopicId)
                .orElseThrow(() -> new ResourceNotFoundException("MainTopic not found with id: " + mainTopicId));

        if (topicDTOs == null || topicDTOs.isEmpty()) {
            return 0;
        }

        List<Topic> topics = topicDTOs.stream()
                .filter(dto -> !topicRepository.existsByTitle(dto.getTitle()))
                .map(dto -> Topic.builder()
                        .title(dto.getTitle())
                        .content(dto.getContent())
                        .mainTopic(mainTopic)
                        .createdAt(LocalDateTime.now())
                        .build())
                .collect(Collectors.toList());

        if (!topics.isEmpty()) {
            topicRepository.saveAll(topics);
            log.info("Created {} new topics for main topic id: {}", topics.size(), mainTopicId);
        }

        return topics.size();
    }

    @Override
    @Transactional
    public Optional<TopicDTO> updateTopic(Integer topicId, TopicDTO topicDTO) {
        log.debug("Updating topic with id: {}", topicId);
        return topicRepository.findById(topicId)
                .map(existingTopic -> {
                    if (topicDTO.getTitle() != null && !topicDTO.getTitle().equals(existingTopic.getTitle())) {
                        if (topicRepository.existsByTitle(topicDTO.getTitle())) {
                            throw new IllegalArgumentException("Topic with title '" + topicDTO.getTitle() + "' already exists");
                        }
                        existingTopic.setTitle(topicDTO.getTitle());
                    }
                    
                    if (topicDTO.getContent() != null) {
                        existingTopic.setContent(topicDTO.getContent());
                    }
                    
                    Topic updatedTopic = topicRepository.save(existingTopic);
                    log.info("Updated topic with id: {}", topicId);
                    return convertToDTO(updatedTopic);
                });
    }

    @Override
    @Transactional
    public boolean deleteTopicById(Integer topicId) {
        log.debug("Deleting topic with id: {}", topicId);
        if (!topicRepository.existsById(topicId)) {
            return false;
        }
        topicRepository.deleteById(topicId);
        log.info("Deleted topic with id: {}", topicId);
        return true;
    }

    @Override
    @Transactional
    public int deleteAllByMainTopicId(Integer mainTopicId) {
        log.debug("Deleting all topics for main topic id: {}", mainTopicId);
        if (!mainTopicRepository.existsById(mainTopicId)) {
            log.error("MainTopic not found with id: {}", mainTopicId);
            throw new ResourceNotFoundException("MainTopic not found with id: " + mainTopicId);


        }
        return topicRepository.deleteAllByMainTopicId(mainTopicId);
    }

    @Override
    @Transactional
    public void deleteAll() {
        log.debug("Deleting all topics");
        topicRepository.deleteAll();
        log.info("Deleted all topics");
    }

    @Override
    public boolean existsByTitle(String title) {
        return topicRepository.existsByTitle(title);
    }

    private TopicDTO convertToDTO(Topic topic) {
        return modelMapper.map(topic, TopicDTO.class);
    }
}
