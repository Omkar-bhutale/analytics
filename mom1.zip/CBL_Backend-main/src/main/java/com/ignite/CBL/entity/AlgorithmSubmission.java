package com.ignite.CBL.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Table(name = "algorithm_submissions")
public class AlgorithmSubmission {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "algorithm_id")
    private Integer algorithmId;
    @Column(name = "content", nullable = false, columnDefinition = "text")
    private String content;

    @Version
    @Column(name = "version",nullable = false)
    private int version;

//    @Column(name = "feedback", columnDefinition = "text")
//    private String feedback;

    @Column(name = "submitted_at",nullable = false)
    private LocalDateTime submittedAt;
    @PrePersist
    private void prePersist() {
        submittedAt = LocalDateTime.now();
    }
    @PreUpdate
    private void preUpdate() {
        submittedAt = LocalDateTime.now();
    }

    @Column(name = "is_correct",nullable = false)
    private Boolean isCorrect = false;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id",nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "problem_id", nullable = false)
    @JsonBackReference("problem-algorithm")
    private Problem problem;


}
