package com.ignite.CBL.service;

import com.ignite.CBL.dto.*;
import com.ignite.CBL.entity.ProblemSubmission;

import java.util.List;

public interface ProblemSubmissionService {

    public ProblemCodeResponceDTO getProblemToSolve(Integer problemId);
    public void saveCodeAndTime(SaveCodeAndTimeRequest SaveCodeAndTimeRequest);
    public boolean saveSubmission(ProblemSubmissionRequestDTO problemSubmissionRequestDTO);


    public List<ProblemSubmissionResponceDTO> getAllSubmissions(Integer problemId);

}
