package com.ignite.CBL.dto;

import com.fasterxml.jackson.databind.JsonNode;
import com.ignite.CBL.entity.Language;
import com.ignite.CBL.entity.SavedCodes;
import lombok.Data;

@Data
public class ProblemSubmissionRequestDTO {
    private Integer problemId;
    private Language language;
    private String code;
    private Boolean isCorrect;
    private SavedCodes savedCodes;
    private Integer totalSecondsSpent;
    private Integer totalTestCasesPassed;
    private Integer totalTestCases;
    private JsonNode insights;

}
