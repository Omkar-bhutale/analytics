package com.ignite.CBL.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class PseudoCodeRequestDTO {
    private Integer problemId;
    private String content;
    private Boolean isCorrect;

}
