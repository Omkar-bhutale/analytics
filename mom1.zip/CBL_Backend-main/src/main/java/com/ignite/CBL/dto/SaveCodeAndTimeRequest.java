package com.ignite.CBL.dto;

import com.ignite.CBL.entity.SavedCodes;
import lombok.Data;

@Data
public class SaveCodeAndTimeRequest {
    private Integer problemId;
    private SavedCodes savedCodes;
    private Integer totalSecondsSpent;

}
