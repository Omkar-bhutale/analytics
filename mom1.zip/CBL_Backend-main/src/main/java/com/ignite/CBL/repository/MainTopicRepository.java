package com.ignite.CBL.repository;

import com.ignite.CBL.entity.MainTopic;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MainTopicRepository extends JpaRepository<MainTopic, Integer> {
}
