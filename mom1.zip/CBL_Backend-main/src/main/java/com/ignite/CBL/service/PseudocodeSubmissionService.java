package com.ignite.CBL.service;

import com.ignite.CBL.dto.PseudoCodeRequestDTO;
import com.ignite.CBL.dto.PseudocodeResponceDTO;

public interface PseudocodeSubmissionService {

    public PseudocodeResponceDTO saveOrUpdatePseudocode(PseudoCodeRequestDTO pseudoCodeRequestDTO);
    public PseudocodeResponceDTO getPseudocodeByProblemId(Integer problemId);
    public Boolean existByProblemId(Integer problemId);
    public Boolean isPseudocodeCorrect(Integer problemId);
}
