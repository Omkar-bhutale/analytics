package com.ignite.CBL.dto;

import lombok.Data;

@Data
public class AlgorithmRequestDTO {
    private Integer problemId;
    private String content;
    private Boolean isCorrect;
}
