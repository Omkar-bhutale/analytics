package com.ignite.CBL.service;

import com.ignite.CBL.dto.ProblemDTO;

import java.util.List;

public interface ProblemService {
    ProblemDTO saveProblem(Integer topicId,ProblemDTO problemDTO);
    List<ProblemDTO> saveProblemsByTopicId(Integer topicId, List<ProblemDTO> problemDTOs);
    void deleteProblemById(Integer problemId);
    int deleteProblemByTopicId(Integer topicId);
    ProblemDTO fetchProblemById(Integer problemId);
    List<ProblemDTO> fetchProblemsByTopicId(Integer topicId);
}
