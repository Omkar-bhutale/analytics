package com.ignite.CBL.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object for MCQ (Multiple Choice Question) entity.
 * Used for transferring MCQ data between layers and validating input.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MCQDTO {
    private Integer mcqId;
    
    @NotNull(message = "Content is required")
    private JsonNode content;
    
    private Integer topicId;
    
    // For create/update operations
    public MCQDTO(JsonNode content, Integer topicId) {
        this.content = content;
        this.topicId = topicId;
    }
}
