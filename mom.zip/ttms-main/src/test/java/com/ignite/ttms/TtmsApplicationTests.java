package com.ignite.ttms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TtmsApplicationTests {

    @Test
    void contextLoads() {
    }

}
