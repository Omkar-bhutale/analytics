package com.ignite.ttms.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "trains")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Train {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String trainNumber;

    @Column(nullable = false)
    private String trainName;

    @Column(nullable = false)
    private String originStation;

    @Column(nullable = false)
    private String destinationStation;

    @ElementCollection
    @CollectionTable(name = "train_intermediate_stops", joinColumns = @JoinColumn(name = "train_id"))
    @Column(name = "stop")
    private List<String> intermediateStops;

    @Column(nullable = false)
    private LocalDateTime departureTime;

    @Column(nullable = false)
    private LocalDateTime arrivalTime;

    @Column(nullable = false)
    private Integer sleeperSeats = 0;

    @Column(nullable = false)
    private Integer acSeats = 0;

    @Column(nullable = false)
    private Integer availableSleeperSeats = 0;

    @Column(nullable = false)
    private Integer availableAcSeats = 0;

    @Column(nullable = false)
    private Double sleeperFare = 0.0;

    @Column(nullable = false)
    private Double acFare = 0.0;
}
