package com.ignite.ttms.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TrainRequest {
    @NotBlank(message = "Train number is required")
    private String trainNumber;

    @NotBlank(message = "Train name is required")
    private String trainName;

    @NotBlank(message = "Origin station is required")
    private String originStation;

    @NotBlank(message = "Destination station is required")
    private String destinationStation;

    private List<String> intermediateStops;

    @NotNull(message = "Departure time is required")
    private LocalDateTime departureTime;

    @NotNull(message = "Arrival time is required")
    private LocalDateTime arrivalTime;

    @NotNull(message = "Sleeper seats count is required")
    private Integer sleeperSeats;

    @NotNull(message = "AC seats count is required")
    private Integer acSeats;

    @NotNull(message = "Sleeper fare is required")
    private Double sleeperFare;

    @NotNull(message = "AC fare is required")
    private Double acFare;
}
