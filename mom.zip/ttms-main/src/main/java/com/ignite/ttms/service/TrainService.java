package com.ignite.ttms.service;

import com.ignite.ttms.dto.TrainRequest;
import com.ignite.ttms.dto.TrainResponse;
import com.ignite.ttms.dto.TrainSearchRequest;
import com.ignite.ttms.entity.Booking;
import com.ignite.ttms.entity.Train;
import com.ignite.ttms.repository.BookingRepository;
import com.ignite.ttms.repository.TrainRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TrainService {
    private final TrainRepository trainRepository;
    private final BookingRepository bookingRepository;

    @Transactional
    public TrainResponse registerTrain(TrainRequest request) {
        // Validate unique train number
        if (trainRepository.existsByTrainNumber(request.getTrainNumber())) {
            throw new RuntimeException("Train number already exists");
        }

        Train train = new Train();
        train.setTrainNumber(request.getTrainNumber());
        train.setTrainName(request.getTrainName());
        train.setOriginStation(request.getOriginStation());
        train.setDestinationStation(request.getDestinationStation());
        train.setIntermediateStops(request.getIntermediateStops());
        train.setDepartureTime(request.getDepartureTime());
        train.setArrivalTime(request.getArrivalTime());
        train.setSleeperSeats(request.getSleeperSeats());
        train.setAcSeats(request.getAcSeats());
        train.setAvailableSleeperSeats(request.getSleeperSeats());
        train.setAvailableAcSeats(request.getAcSeats());
        train.setSleeperFare(request.getSleeperFare());
        train.setAcFare(request.getAcFare());

        Train savedTrain = trainRepository.save(train);
        return mapToResponse(savedTrain);
    }

    @Transactional
    public TrainResponse updateTrain(String trainNumber, TrainRequest request) {
        Train train = trainRepository.findByTrainNumber(trainNumber)
                .orElseThrow(() -> new RuntimeException("Train not found"));

        // Check for schedule conflict
        if (trainRepository.existsScheduleConflict(
                request.getOriginStation(),
                request.getDestinationStation(),
                request.getDepartureTime(),
                request.getArrivalTime(),
                train.getId())) {
            throw new RuntimeException("Schedule conflict: Another train has the same departure and arrival times for this route");
        }

        train.setTrainName(request.getTrainName());
        train.setOriginStation(request.getOriginStation());
        train.setDestinationStation(request.getDestinationStation());
        train.setIntermediateStops(request.getIntermediateStops());
        train.setDepartureTime(request.getDepartureTime());
        train.setArrivalTime(request.getArrivalTime());

        // Update seat counts maintaining the difference
        int sleeperDiff = train.getSleeperSeats() - train.getAvailableSleeperSeats();
        int acDiff = train.getAcSeats() - train.getAvailableAcSeats();

        train.setSleeperSeats(request.getSleeperSeats());
        train.setAcSeats(request.getAcSeats());
        train.setAvailableSleeperSeats(request.getSleeperSeats() - sleeperDiff);
        train.setAvailableAcSeats(request.getAcSeats() - acDiff);
        train.setSleeperFare(request.getSleeperFare());
        train.setAcFare(request.getAcFare());

        Train updatedTrain = trainRepository.save(train);
        return mapToResponse(updatedTrain);
    }

    @Transactional
    public void deleteTrain(String trainNumber) {
        Train train = trainRepository.findByTrainNumber(trainNumber)
                .orElseThrow(() -> new RuntimeException("Train not found"));

        // Cancel all associated bookings
        List<Booking> bookings = bookingRepository.findByTrain(train);
        for (Booking booking : bookings) {
            if (booking.getStatus() == Booking.BookingStatus.CONFIRMED) {
                booking.setStatus(Booking.BookingStatus.CANCELLED);
                booking.setCancellationDateTime(java.time.LocalDateTime.now());
            }
        }
        bookingRepository.saveAll(bookings);

        // Delete the train
        trainRepository.delete(train);
    }

    public TrainResponse getTrainByNumber(String trainNumber) {
        Train train = trainRepository.findByTrainNumber(trainNumber)
                .orElseThrow(() -> new RuntimeException("Train not found"));
        return mapToResponse(train);
    }

    public List<TrainResponse> searchTrains(TrainSearchRequest request) {
        LocalDate travelDate = request.getTravelDate();
        LocalDate today = LocalDate.now();
        LocalDate maxDate = today.plusMonths(3);

        if (travelDate != null && (travelDate.isBefore(today) || travelDate.isAfter(maxDate))) {
            throw new RuntimeException("Travel date must be within the next 3 months");
        }

        List<Train> trains = trainRepository.findByRoute(
                request.getOriginStation(),
                request.getDestinationStation()
        );

        return trains.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public List<TrainResponse> getAllTrains() {
        return trainRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    private TrainResponse mapToResponse(Train train) {
        TrainResponse response = new TrainResponse();
        response.setId(train.getId());
        response.setTrainNumber(train.getTrainNumber());
        response.setTrainName(train.getTrainName());
        response.setOriginStation(train.getOriginStation());
        response.setDestinationStation(train.getDestinationStation());
        response.setIntermediateStops(train.getIntermediateStops());
        response.setDepartureTime(train.getDepartureTime());
        response.setArrivalTime(train.getArrivalTime());
        response.setSleeperSeats(train.getSleeperSeats());
        response.setAcSeats(train.getAcSeats());
        response.setAvailableSleeperSeats(train.getAvailableSleeperSeats());
        response.setAvailableAcSeats(train.getAvailableAcSeats());
        response.setSleeperFare(train.getSleeperFare());
        response.setAcFare(train.getAcFare());
        return response;
    }
}

