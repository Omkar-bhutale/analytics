# 🎯 TTMS - Quick Reference Guide

## 🚀 Start Application (Easiest Way)

Simply double-click: **`start-application.bat`**

This will:
1. Start the backend on port 8080
2. Wait 10 seconds
3. Start the frontend on port 3000
4. Open both in separate terminal windows

---

## 📝 Manual Start Commands

### Backend Only
```bash
cd D:\TTMS
.\mvnw.cmd spring-boot:run
```

### Frontend Only
```bash
cd D:\TTMS\frontend
npm install   # First time only
npm start
```

---

## 🔗 Access URLs

| Service | URL | Description |
|---------|-----|-------------|
| Frontend | http://localhost:3000 | Main application |
| Backend API | http://localhost:8080/api | REST API |
| Swagger UI | http://localhost:8080/swagger-ui.html | API documentation |
| H2 Console | http://localhost:8080/h2-console | Database console |

---

## 🔑 Login Credentials

### Admin
- Username: `admin`
- Password: `admin123`

### Customer
- Register from: http://localhost:3000/register
- Then login with email and password

---

## 📦 Installation (First Time)

### 1. Backend Dependencies
```bash
cd D:\TTMS
.\mvnw.cmd clean install
```

### 2. Frontend Dependencies
```bash
cd D:\TTMS\frontend
npm install
```

---

## 🔄 Common Operations

### Rebuild Backend
```bash
cd D:\TTMS
.\mvnw.cmd clean package
```

### Rebuild Frontend
```bash
cd D:\TTMS\frontend
npm run build
```

### Run Tests (Backend)
```bash
cd D:\TTMS
.\mvnw.cmd test
```

---

## 🐛 Troubleshooting

### Port 8080 Already in Use
```bash
# Find and kill process
netstat -ano | findstr :8080
taskkill /PID <PID> /F
```

### Port 3000 Already in Use
```bash
# Frontend will ask to use different port
# Or kill the process manually
```

### Clear Frontend Cache
```bash
cd D:\TTMS\frontend
rmdir /s /q node_modules
del package-lock.json
npm install
```

### Reset H2 Database
Just restart the backend application - H2 is in-memory and resets automatically.

---

## 📤 Push to GitHub

Double-click: **`push-to-github.bat`**

Or manually:
```bash
cd D:\TTMS
git init
git add .
git commit -m "Initial commit: TTMS with JWT and React"
git branch -M main
git remote add origin https://github.com/Omkar-bhutale/ttms.git
git push -u origin main
```

---

## 🧪 Test APIs

### Using Swagger UI (Recommended)
1. Go to: http://localhost:8080/swagger-ui.html
2. Login via `/api/auth/customer/login` or `/api/auth/admin/login`
3. Copy the JWT token from response
4. Click "Authorize" button (🔒)
5. Enter: `Bearer <your-token>`
6. Test any endpoint

### Using cURL

**Customer Registration:**
```bash
curl -X POST http://localhost:8080/api/customers/register ^
  -H "Content-Type: application/json" ^
  -d "{\"name\":\"John Doe\",\"email\":\"john@example.com\",\"phoneNumber\":\"9876543210\",\"address\":\"123 Street\",\"password\":\"Password@123\"}"
```

**Customer Login:**
```bash
curl -X POST http://localhost:8080/api/auth/customer/login ^
  -H "Content-Type: application/json" ^
  -d "{\"username\":\"john@example.com\",\"password\":\"Password@123\"}"
```

**Admin Login:**
```bash
curl -X POST http://localhost:8080/api/auth/admin/login ^
  -H "Content-Type: application/json" ^
  -d "{\"username\":\"admin\",\"password\":\"admin123\"}"
```

---

## 📋 Password Requirements

Customer passwords must have:
- ✅ Minimum 8 characters
- ✅ At least 1 uppercase letter (A-Z)
- ✅ At least 1 lowercase letter (a-z)
- ✅ At least 1 digit (0-9)
- ✅ At least 1 special character (@#$%^&+=)

**Example:** `Password@123`

---

## 🎨 Frontend Pages

| Page | Route | Access |
|------|-------|--------|
| Home | `/` | Public |
| Login | `/login` | Public |
| Register | `/register` | Public |
| Search Trains | `/search-trains` | Public |
| My Bookings | `/my-bookings` | Customer |
| Profile | `/profile` | Customer |
| Manage Trains | `/admin/trains` | Admin |
| Manage Customers | `/admin/customers` | Admin |

---

## 🔧 Configuration Files

### Backend: `application.properties`
```properties
server.port=8080
spring.datasource.url=jdbc:h2:mem:ttmsdb
jwt.secret=404E635266556A586E3272357538782F413F4428472B4B6250645367566B5970
jwt.expiration=86400000
```

### Frontend: `.env` (if needed)
```
REACT_APP_API_URL=http://localhost:8080/api
```

---

## 📊 Database Access

**H2 Console:** http://localhost:8080/h2-console

**Settings:**
- JDBC URL: `jdbc:h2:mem:ttmsdb`
- Username: `sa`
- Password: (leave empty)
- Driver Class: `org.h2.Driver`

---

## 🌟 Key Features to Test

### As Customer:
1. ✅ Register account
2. ✅ Login
3. ✅ Search trains (Mumbai to Delhi)
4. ✅ Book ticket
5. ✅ View bookings
6. ✅ Cancel booking
7. ✅ Update profile

### As Admin:
1. ✅ Login
2. ✅ Add new train
3. ✅ Edit train details
4. ✅ Delete train
5. ✅ View all customers
6. ✅ Deactivate customer
7. ✅ Activate customer

---

## 📚 Documentation Files

- `README.md` - Main project overview
- `COMPLETE_SETUP_GUIDE.md` - Detailed setup guide
- `API_DOCUMENTATION.md` - API reference
- `CUSTOMER_REGISTRATION_API.md` - Customer API details
- `frontend/README.md` - Frontend documentation
- `QUICK_REFERENCE.md` - This file

---

## ⚡ Quick Tips

1. **Always start backend before frontend**
2. **Keep both terminals running**
3. **Check Swagger UI for API testing**
4. **Use Chrome DevTools for debugging**
5. **JWT token expires in 24 hours**
6. **H2 database resets on restart**

---

## 🆘 Getting Help

1. Check `COMPLETE_SETUP_GUIDE.md` for detailed instructions
2. Review Swagger UI for API details
3. Check browser console for frontend errors
4. Check terminal for backend errors
5. Verify both servers are running

---

## ✅ Deployment Checklist

- [ ] Backend compiles successfully
- [ ] Frontend builds without errors
- [ ] Can login as admin
- [ ] Can register customer
- [ ] Can search trains
- [ ] Can book tickets
- [ ] Can view bookings
- [ ] Can cancel bookings
- [ ] Admin can add trains
- [ ] Admin can manage customers

---

**🎉 Happy Coding!**

