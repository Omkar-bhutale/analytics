└── README.md
```

---

## 🧪 Testing the Application

### Test Customer Flow:

1. **Register:**
   - Go to `http://localhost:3000/register`
   - Fill form with valid data
   - Password must have: 8+ chars, uppercase, lowercase, digit, special char

2. **Login:**
   - Go to `http://localhost:3000/login`
   - Select "Customer" tab
   - Enter email and password

3. **Search Trains:**
   - Go to "Search Trains"
   - Enter origin and destination
   - Click Search

4. **Book Ticket:**
   - Click "Book Now" on a train
   - Select seat type and number of seats
   - Confirm booking

5. **View Bookings:**
   - Go to "My Bookings"
   - View all your bookings
   - Cancel if needed

### Test Admin Flow:

1. **Login as Admin:**
   - Go to `http://localhost:3000/login`
   - Select "Admin" tab
   - Username: `admin`, Password: `admin123`

2. **Manage Trains:**
   - Go to "Manage Trains"
   - Click "Add Train" tab
   - Fill in all train details
   - Submit to add train

3. **Manage Customers:**
   - Go to "Customers"
   - View all registered customers
   - Activate/Deactivate accounts

---

## 🚢 Building for Production

### Backend:
```bash
.\mvnw.cmd clean package
java -jar target/TTMS-0.0.1-SNAPSHOT.jar
```

### Frontend:
```bash
cd frontend
npm run build
```

The optimized build will be in `frontend/build/`

---

## 🐛 Troubleshooting

### Backend won't start:
- Check if port 8080 is available
- Verify Java 17+ is installed: `java -version`
- Check logs for errors

### Frontend won't start:
- Delete `node_modules` and `package-lock.json`
- Run `npm install` again
- Check if port 3000 is available

### API calls failing:
- Verify backend is running on port 8080
- Check browser console for CORS errors
- Verify JWT token is being sent

### Database issues:
- Restart the backend to reset H2 database
- Check application.properties for correct settings

---

## 📝 Password Requirements

**Customer Registration Password must have:**
- Minimum 8 characters
- At least 1 uppercase letter
- At least 1 lowercase letter
- At least 1 digit
- At least 1 special character (@#$%^&+=)

**Example valid password:** `Password@123`

---

## 🔗 Important URLs

- **Frontend:** http://localhost:3000
- **Backend API:** http://localhost:8080/api
- **Swagger UI:** http://localhost:8080/swagger-ui.html
- **H2 Console:** http://localhost:8080/h2-console

---

## 📚 Additional Documentation

- `API_DOCUMENTATION.md` - Complete API documentation
- `CUSTOMER_REGISTRATION_API.md` - Customer API details
- `frontend/README.md` - Frontend specific documentation

---

## 🎯 Next Steps

1. Start both backend and frontend
2. Access `http://localhost:3000`
3. Register a customer account
4. Login and explore features
5. Login as admin to manage trains
6. Test the complete booking flow

---

## 💡 Tips

- Keep both terminals (backend & frontend) running
- Use Chrome DevTools to debug frontend
- Check Swagger UI for API testing
- Use H2 Console to view database

---

## 🤝 Support

For issues or questions:
1. Check the troubleshooting section
2. Review the API documentation
3. Check browser console for errors
4. Verify both servers are running

---

## 📄 License

MIT License - Feel free to use and modify
# TTMS Complete Setup Guide

## Complete Train Ticket Management System with React Frontend and Spring Boot Backend

---

## 📋 Prerequisites

Before starting, ensure you have:
- **Java 17** or higher
- **Node.js 14+** and npm
- **Maven** (included via mvnw)
- **Git** (for version control)
- A modern web browser

---

## 🚀 Quick Start (Complete Setup)

### Step 1: Backend Setup

1. **Navigate to project root:**
```bash
cd D:\TTMS
```

2. **Clean and compile the backend:**
```bash
.\mvnw.cmd clean install
```

3. **Run the Spring Boot backend:**
```bash
.\mvnw.cmd spring-boot:run
```

The backend will start on `http://localhost:8080`

✅ **Verify backend is running:**
- Open browser: `http://localhost:8080/swagger-ui.html`
- You should see the Swagger API documentation

### Step 2: Frontend Setup

1. **Open a new terminal and navigate to frontend:**
```bash
cd D:\TTMS\frontend
```

2. **Install dependencies:**
```bash
npm install
```

3. **Start the React development server:**
```bash
npm start
```

The frontend will start on `http://localhost:3000` and open automatically in your browser.

---

## 🔑 Default Login Credentials

### Admin Login
- **Username:** admin
- **Password:** admin123

### Customer Login
- Register a new account from the registration page
- Then login with your email and password

---

## 📱 Application Features

### Customer Features
1. ✅ Register new account with validation
2. ✅ Login with JWT authentication
3. ✅ Search trains between stations
4. ✅ Book tickets (Sleeper/AC class)
5. ✅ View booking history with PNR
6. ✅ Cancel bookings
7. ✅ Update profile

### Admin Features
1. ✅ Login with admin credentials
2. ✅ Add new trains
3. ✅ Edit train details
4. ✅ Delete trains
5. ✅ View all customers
6. ✅ Activate/Deactivate customers

---

## 🛠️ Technology Stack

### Backend
- Spring Boot 3.5.7
- Spring Security with JWT
- Spring Data JPA
- H2 Database (in-memory)
- Swagger/OpenAPI 3.0
- Lombok
- Bean Validation

### Frontend
- React 18
- React Router v6
- Axios
- React Toastify
- Context API
- CSS3

---

## 📡 API Endpoints

### Authentication
- `POST /api/auth/customer/login` - Customer login
- `POST /api/auth/admin/login` - Admin login

### Customers
- `POST /api/customers/register` - Register customer
- `GET /api/customers/{id}` - Get customer profile
- `PUT /api/customers/{id}` - Update profile
- `DELETE /api/customers/{id}` - Deactivate account
- `GET /api/customers` - Get all customers (Admin)
- `PUT /api/customers/{id}/activate` - Activate customer (Admin)

### Trains
- `POST /api/trains/search` - Search trains
- `GET /api/trains` - Get all trains
- `POST /api/admin/trains` - Add train (Admin)
- `PUT /api/admin/trains/{id}` - Update train (Admin)
- `DELETE /api/admin/trains/{id}` - Delete train (Admin)

### Bookings
- `POST /api/bookings` - Create booking
- `GET /api/bookings/{id}` - Get booking details
- `GET /api/bookings/customer/{customerId}` - Get customer bookings
- `POST /api/bookings/cancel` - Cancel booking

---

## 🔐 JWT Authentication Flow

1. User logs in with credentials
2. Backend validates and returns JWT token
3. Frontend stores token in localStorage
4. Token is sent with every API request in Authorization header
5. Backend validates token and processes request

**Token Format:**
```
Authorization: Bearer <jwt-token>
```

---

## 🗄️ Database

The application uses **H2 in-memory database**:
- Data resets on application restart
- Access H2 Console: `http://localhost:8080/h2-console`
  - JDBC URL: `jdbc:h2:mem:ttmsdb`
  - Username: `sa`
  - Password: (leave empty)

---

## 📁 Project Structure

```
TTMS/
├── frontend/                    # React frontend
│   ├── public/
│   ├── src/
│   │   ├── components/         # Reusable components
│   │   ├── context/            # Context providers
│   │   ├── pages/              # Page components
│   │   ├── services/           # API services
│   │   ├── App.js
│   │   └── index.js
│   └── package.json
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/ignite/ttms/
│   │   │       ├── config/     # Configuration
│   │   │       ├── controller/ # REST controllers
│   │   │       ├── dto/        # Data Transfer Objects
│   │   │       ├── entity/     # JPA entities
│   │   │       ├── repository/ # Data repositories
│   │   │       ├── security/   # JWT security
│   │   │       └── service/    # Business logic
│   │   └── resources/
│   │       └── application.properties
│   └── test/
├── pom.xml

