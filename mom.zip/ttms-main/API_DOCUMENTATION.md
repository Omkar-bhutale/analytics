# Train Ticket Management System (TTMS) - REST API

## Overview
A complete REST API-based Train Ticket Management System built with Spring Boot, JPA, and H2 Database.

## Technology Stack
- Java 17
- Spring Boot 3.5.7
- Spring Data JPA
- H2 In-Memory Database
- Lombok
- Validation API

## Getting Started

### Prerequisites
- Java 17 or higher
- Maven

### Running the Application
```bash
mvnw clean install
mvnw spring-boot:run
```

The application will start on `http://localhost:8080`

### H2 Database Console
Access the H2 console at: `http://localhost:8080/h2-console`
- JDBC URL: `jdbc:h2:mem:ttmsdb`
- Username: `sa`
- Password: (leave empty)

### Default Admin Credentials
- Username: `admin`
- Password: `admin123`

## API Endpoints

### 1. Authentication APIs

#### Admin Login
```
POST /api/auth/admin/login
Content-Type: application/json

{
  "username": "admin",
  "password": "admin123"
}
```

#### Customer Login
```
POST /api/auth/customer/login
Content-Type: application/json

{
  "username": "customer@email.com",
  "password": "password123"
}
```

### 2. Customer APIs

#### Register Customer
```
POST /api/customers/register
Content-Type: application/json

{
  "name": "John Doe",
  "email": "john@example.com",
  "phoneNumber": "1234567890",
  "address": "123 Main St, City",
  "password": "password123"
}
```

#### Update Customer
```
PUT /api/customers/{customerId}
Content-Type: application/json

{
  "name": "John Doe Updated",
  "email": "john@example.com",
  "phoneNumber": "1234567890",
  "address": "456 New St, City",
  "password": "newpassword123"
}
```

#### Get Customer Details
```
GET /api/customers/{customerId}
```

#### Deactivate Customer Account
```
DELETE /api/customers/{customerId}
```

### 3. Train APIs (Public)

#### Search Trains
```
POST /api/trains/search
Content-Type: application/json

{
  "originStation": "Mumbai",
  "destinationStation": "Delhi",
  "travelDate": "2025-12-01"
}
```

#### Get All Trains
```
GET /api/trains
```

#### Get Train by Number
```
GET /api/trains/{trainNumber}
```

### 4. Admin Train Management APIs

#### Register Train
```
POST /api/admin/trains
Content-Type: application/json

{
  "trainNumber": "12345",
  "trainName": "Express Train",
  "originStation": "Mumbai",
  "destinationStation": "Delhi",
  "intermediateStops": ["Surat", "Vadodara", "Ahmedabad"],
  "departureTime": "2025-11-08T10:00:00",
  "arrivalTime": "2025-11-08T20:00:00",
  "sleeperSeats": 100,
  "acSeats": 50,
  "sleeperFare": 500.0,
  "acFare": 1000.0
}
```

#### Update Train
```
PUT /api/admin/trains/{trainNumber}
Content-Type: application/json

{
  "trainNumber": "12345",
  "trainName": "Super Express",
  "originStation": "Mumbai",
  "destinationStation": "Delhi",
  "intermediateStops": ["Surat", "Vadodara"],
  "departureTime": "2025-11-08T09:00:00",
  "arrivalTime": "2025-11-08T19:00:00",
  "sleeperSeats": 120,
  "acSeats": 60,
  "sleeperFare": 550.0,
  "acFare": 1100.0
}
```

#### Delete Train
```
DELETE /api/admin/trains/{trainNumber}
```

#### Get All Trains (Admin)
```
GET /api/admin/trains
```

### 5. Booking APIs

#### Book Ticket
```
POST /api/bookings
Content-Type: application/json

{
  "customerId": 1,
  "trainNumber": "12345",
  "originStation": "Mumbai",
  "destinationStation": "Delhi",
  "travelDate": "2025-12-01",
  "travelClass": "SLEEPER",
  "numberOfSeats": 2
}
```

**Travel Class Options:** `SLEEPER` or `AC`

#### Cancel Ticket
```
POST /api/bookings/cancel
Content-Type: application/json

{
  "ticketId": "TKT12AB34CD",
  "password": "password123",
  "customerId": 1
}
```

**Note:** Cancellation must be done at least 24 hours before departure.

#### Get Booking History
```
GET /api/bookings/customer/{customerId}
```

#### Get Booking by Ticket ID
```
GET /api/bookings/ticket/{ticketId}
```

## Business Rules

### Customer Registration
- Email must be unique
- Phone number must be exactly 10 digits
- Name should not contain numeric or special characters

### Train Management
- Train number must be unique
- Cannot have schedule conflicts (same route with same departure/arrival times)
- Deleting a train cancels all associated bookings

### Booking
- Maximum 6 seats can be booked in one session
- Travel date must be within the next 3 months
- Sufficient seats must be available
- Customer account must be active

### Cancellation
- Must be done at least 24 hours before departure
- Requires ticket ID, customer ID, and password verification
- Automatically releases seats back to the train

## Response Formats

### Success Response (Example)
```json
{
  "id": 1,
  "ticketId": "TKT12AB34CD",
  "customerName": "John Doe",
  "trainNumber": "12345",
  "trainName": "Express Train",
  "originStation": "Mumbai",
  "destinationStation": "Delhi",
  "travelDate": "2025-12-01",
  "travelClass": "SLEEPER",
  "numberOfSeats": 2,
  "totalFare": 1000.0,
  "status": "CONFIRMED",
  "bookingDateTime": "2025-11-07T14:30:00"
}
```

### Error Response (Example)
```json
{
  "timestamp": "2025-11-07T14:30:00",
  "status": 400,
  "error": "Error",
  "message": "Insufficient sleeper seats available"
}
```

### Validation Error Response (Example)
```json
{
  "timestamp": "2025-11-07T14:30:00",
  "status": 400,
  "error": "Validation Failed",
  "validationErrors": {
    "email": "Invalid email format",
    "phoneNumber": "Phone number must contain exactly 10 digits"
  }
}
```

## Testing with cURL

### Example: Register a Customer
```bash
curl -X POST http://localhost:8080/api/customers/register \
  -H "Content-Type: application/json" \
  -d "{\"name\":\"John Doe\",\"email\":\"john@example.com\",\"phoneNumber\":\"1234567890\",\"address\":\"123 Main St\",\"password\":\"pass123\"}"
```

### Example: Search Trains
```bash
curl -X POST http://localhost:8080/api/trains/search \
  -H "Content-Type: application/json" \
  -d "{\"originStation\":\"Mumbai\",\"destinationStation\":\"Delhi\"}"
```

### Example: Book a Ticket
```bash
curl -X POST http://localhost:8080/api/bookings \
  -H "Content-Type: application/json" \
  -d "{\"customerId\":1,\"trainNumber\":\"12345\",\"originStation\":\"Mumbai\",\"destinationStation\":\"Delhi\",\"travelDate\":\"2025-12-01\",\"travelClass\":\"SLEEPER\",\"numberOfSeats\":2}"
```

## Features Implemented

### Admin Features
- ✅ Register new trains with complete details
- ✅ Update train information
- ✅ Delete trains (with automatic booking cancellation)
- ✅ View all trains
- ✅ Login authentication

### Customer Features
- ✅ Register new account with validation
- ✅ Login authentication
- ✅ Update profile information
- ✅ Deactivate account
- ✅ Search trains by route
- ✅ Book tickets (max 6 seats per booking)
- ✅ View booking history
- ✅ Cancel tickets (24-hour rule)
- ✅ View ticket details

### System Features
- ✅ Seat availability management
- ✅ Automatic fare calculation
- ✅ Unique ticket ID generation
- ✅ Booking status tracking (CONFIRMED/CANCELLED)
- ✅ Data validation
- ✅ Exception handling
- ✅ Database persistence

## Project Structure
```
src/main/java/com/ignite/ttms/
├── config/
│   └── DataInitializer.java
├── controller/
│   ├── AdminTrainController.java
│   ├── AuthController.java
│   ├── BookingController.java
│   ├── CustomerController.java
│   └── TrainController.java
├── dto/
│   ├── BookingRequest.java
│   ├── BookingResponse.java
│   ├── CancellationRequest.java
│   ├── CustomerRequest.java
│   ├── CustomerResponse.java
│   ├── LoginRequest.java
│   ├── LoginResponse.java
│   ├── TrainRequest.java
│   ├── TrainResponse.java
│   └── TrainSearchRequest.java
├── entity/
│   ├── Admin.java
│   ├── Booking.java
│   ├── Customer.java
│   └── Train.java
├── exception/
│   ├── ErrorResponse.java
│   └── GlobalExceptionHandler.java
├── repository/
│   ├── AdminRepository.java
│   ├── BookingRepository.java
│   ├── CustomerRepository.java
│   └── TrainRepository.java
├── service/
│   ├── AuthService.java
│   ├── BookingService.java
│   ├── CustomerService.java
│   └── TrainService.java
└── TtmsApplication.java
```

## Notes
- The system uses H2 in-memory database for simplicity
- All passwords are stored in plain text (for demo purposes only)
- The system automatically creates a default admin user on startup
- Seat availability is managed automatically on booking and cancellation

