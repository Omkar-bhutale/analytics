import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Navbar = () => {
  const { user, logout, isAuthenticated, isAdmin, isCustomer } = useAuth();

  return (
    <nav className="navbar">
      <div className="container">
        <Link to="/" className="navbar-brand">TTMS</Link>
        <div className="navbar-menu">
          <Link to="/">Home</Link>
          <Link to="/search-trains">Search Trains</Link>

          {!isAuthenticated() ? (
            <>
              <Link to="/login">Login</Link>
              <Link to="/register">Register</Link>
            </>
          ) : (
            <>
              {isCustomer() && (
                <>
                  <Link to="/my-bookings">My Bookings</Link>
                  <Link to="/profile">Profile</Link>
                </>
              )}
              {isAdmin() && (
                <>
                  <Link to="/admin/trains">Manage Trains</Link>
                  <Link to="/admin/customers">Customers</Link>
                </>
              )}
              <span style={{ color: 'white' }}>Welcome, {user?.username || 'User'}</span>
              <button onClick={logout}>Logout</button>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

