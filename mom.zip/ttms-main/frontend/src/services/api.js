import axios from 'axios';

const API_BASE_URL = 'http://localhost:8080/api';

// Create axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add token to requests if available
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Handle response errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Authentication APIs
export const authAPI = {
  adminLogin: (credentials) => api.post('/auth/admin/login', credentials),
  customerLogin: (credentials) => api.post('/auth/customer/login', credentials),
};

// Customer APIs
export const customerAPI = {
  register: (data) => api.post('/customers/register', data),
  getProfile: (customerId) => api.get(`/customers/${customerId}`),
  updateProfile: (customerId, data) => api.put(`/customers/${customerId}`, data),
  deactivate: (customerId) => api.delete(`/customers/${customerId}`),
  getAll: () => api.get('/customers'),
  getByEmail: (email) => api.get(`/customers/email/${email}`),
  activate: (customerId) => api.put(`/customers/${customerId}/activate`),
};

// Train APIs
export const trainAPI = {
  search: (params) => api.post('/trains/search', params),
  getAll: () => api.get('/trains'),
  getById: (trainId) => api.get(`/trains/${trainId}`),
  create: (data) => api.post('/admin/trains', data),
  update: (trainId, data) => api.put(`/admin/trains/${trainId}`, data),
  delete: (trainId) => api.delete(`/admin/trains/${trainId}`),
};

// Booking APIs
export const bookingAPI = {
  create: (data) => api.post('/bookings', data),
  getById: (bookingId) => api.get(`/bookings/${bookingId}`),
  getByCustomer: (customerId) => api.get(`/bookings/customer/${customerId}`),
  cancel: (data) => api.post('/bookings/cancel', data),
};

export default api;

