import React, { useState } from 'react';
import { trainAPI, bookingAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';

const SearchTrains = () => {
  const [searchParams, setSearchParams] = useState({
    originStation: '',
    destinationStation: '',
  });
  const [trains, setTrains] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedTrain, setSelectedTrain] = useState(null);
  const [bookingData, setBookingData] = useState({
    seatType: 'SLEEPER',
    numberOfSeats: 1,
  });

  const { user, isAuthenticated } = useAuth();

  const handleSearchChange = (e) => {
    setSearchParams({
      ...searchParams,
      [e.target.name]: e.target.value,
    });
  };

  const handleSearch = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await trainAPI.search(searchParams);
      setTrains(response.data);

      if (response.data.length === 0) {
        toast.info('No trains found for the selected route');
      }
    } catch (error) {
      toast.error('Failed to search trains');
    } finally {
      setLoading(false);
    }
  };

  const openBookingModal = (train) => {
    if (!isAuthenticated()) {
      toast.error('Please login to book tickets');
      return;
    }
    setSelectedTrain(train);
    setBookingData({ seatType: 'SLEEPER', numberOfSeats: 1 });
  };

  const closeBookingModal = () => {
    setSelectedTrain(null);
  };

  const handleBookingChange = (e) => {
    setBookingData({
      ...bookingData,
      [e.target.name]: e.target.value,
    });
  };

  const calculatePrice = () => {
    if (!selectedTrain) return 0;
    const fare = bookingData.seatType === 'SLEEPER'
      ? selectedTrain.sleeperFare
      : selectedTrain.acFare;
    return fare * bookingData.numberOfSeats;
  };

  const handleBooking = async (e) => {
    e.preventDefault();

    try {
      const booking = {
        customerId: user.userId,
        trainId: selectedTrain.id,
        seatType: bookingData.seatType,
        numberOfSeats: parseInt(bookingData.numberOfSeats),
      };

      await bookingAPI.create(booking);
      toast.success('Booking successful!');
      closeBookingModal();
      handleSearch(e);
    } catch (error) {
      toast.error(error.response?.data?.message || 'Booking failed');
    }
  };

  return (
    <div className="page">
      <div className="container">
        <div className="card">
          <h2>Search Trains</h2>
          <form onSubmit={handleSearch}>
            <div className="form-row">
              <div className="form-group">
                <label>From</label>
                <input
                  type="text"
                  name="originStation"
                  value={searchParams.originStation}
                  onChange={handleSearchChange}
                  placeholder="Origin station"
                  required
                />
              </div>
              <div className="form-group">
                <label>To</label>
                <input
                  type="text"
                  name="destinationStation"
                  value={searchParams.destinationStation}
                  onChange={handleSearchChange}
                  placeholder="Destination station"
                  required
                />
              </div>
            </div>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? 'Searching...' : 'Search Trains'}
            </button>
          </form>
        </div>

        {loading ? (
          <div className="loading">
            <div className="spinner"></div>
            <p>Searching trains...</p>
          </div>
        ) : trains.length > 0 ? (
          <div>
            {trains.map((train) => (
              <div key={train.id} className="train-card">
                <div className="train-header">
                  <div>
                    <div className="train-number">{train.trainNumber}</div>
                    <div className="train-name">{train.trainName}</div>
                  </div>
                </div>

                <div className="train-route">
                  <span>{train.originStation}</span>
                  <span className="route-arrow">→</span>
                  <span>{train.destinationStation}</span>
                </div>

                {train.intermediateStops && train.intermediateStops.length > 0 && (
                  <div style={{
                    marginBottom: '1rem',
                    padding: '0.75rem',
                    background: '#f8f9fa',
                    borderRadius: '4px'
                  }}>
                    <div style={{ fontSize: '0.85rem', color: '#666', marginBottom: '0.5rem', fontWeight: '600' }}>
                      Stops at:
                    </div>
                    <ul style={{
                      margin: 0,
                      paddingLeft: '1.5rem',
                      listStyleType: 'circle'
                    }}>
                      {train.intermediateStops.map((stop, index) => (
                        <li
                          key={index}
                          style={{
                            fontSize: '0.95rem',
                            color: '#333',
                            marginBottom: '0.25rem'
                          }}
                        >
                          {stop}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                <div className="train-details">
                  <div className="detail-item">
                    <div className="detail-label">Departure</div>
                    <div className="detail-value">
                      {new Date(train.departureTime).toLocaleString()}
                    </div>
                  </div>
                  <div className="detail-item">
                    <div className="detail-label">Arrival</div>
                    <div className="detail-value">
                      {new Date(train.arrivalTime).toLocaleString()}
                    </div>
                  </div>
                </div>

                <div className="seat-info">
                  <div className="seat-type">
                    <h4>Sleeper</h4>
                    <p>Available: {train.availableSleeperSeats}</p>
                    <p>Fare: ₹{train.sleeperFare}</p>
                  </div>
                  <div className="seat-type">
                    <h4>AC</h4>
                    <p>Available: {train.availableAcSeats}</p>
                    <p>Fare: ₹{train.acFare}</p>
                  </div>
                </div>

                <button
                  className="btn btn-primary"
                  onClick={() => openBookingModal(train)}
                  disabled={train.availableSleeperSeats === 0 && train.availableAcSeats === 0}
                >
                  {train.availableSleeperSeats === 0 && train.availableAcSeats === 0
                    ? 'Sold Out'
                    : 'Book Now'}
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className="empty-state">
            <h3>No trains found</h3>
            <p>Try searching for trains between different stations</p>
          </div>
        )}

        {selectedTrain && (
          <div className="modal-overlay" onClick={closeBookingModal}>
            <div className="modal" onClick={(e) => e.stopPropagation()}>
              <span className="modal-close" onClick={closeBookingModal}>&times;</span>
              <h3>Book Ticket</h3>
              <p><strong>{selectedTrain.trainName}</strong> ({selectedTrain.trainNumber})</p>

              <form onSubmit={handleBooking}>
                <div className="form-group">
                  <label>Seat Type</label>
                  <select
                    name="seatType"
                    value={bookingData.seatType}
                    onChange={handleBookingChange}
                    required
                  >
                    <option value="SLEEPER" disabled={selectedTrain.availableSleeperSeats === 0}>
                      Sleeper (₹{selectedTrain.sleeperFare}) - {selectedTrain.availableSleeperSeats} available
                    </option>
                    <option value="AC" disabled={selectedTrain.availableAcSeats === 0}>
                      AC (₹{selectedTrain.acFare}) - {selectedTrain.availableAcSeats} available
                    </option>
                  </select>
                </div>

                <div className="form-group">
                  <label>Number of Seats</label>
                  <input
                    type="number"
                    name="numberOfSeats"
                    value={bookingData.numberOfSeats}
                    onChange={handleBookingChange}
                    min="1"
                    max={bookingData.seatType === 'SLEEPER'
                      ? selectedTrain.availableSleeperSeats
                      : selectedTrain.availableAcSeats}
                    required
                  />
                </div>

                <div style={{
                  padding: '1rem',
                  background: '#f8f9fa',
                  borderRadius: '4px',
                  marginBottom: '1rem'
                }}>
                  <strong>Total Price: ₹{calculatePrice()}</strong>
                </div>

                <button type="submit" className="btn btn-primary btn-block">
                  Confirm Booking
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SearchTrains;

