import React, { useState, useEffect } from 'react';
import { bookingAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';

const MyBookings = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    fetchBookings();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const fetchBookings = async () => {
    try {
      const response = await bookingAPI.getByCustomer(user.userId);
      setBookings(response.data);
    } catch (error) {
      toast.error('Failed to fetch bookings');
    } finally {
      setLoading(false);
    }
  };

  const handleCancelBooking = async (bookingId, customerId) => {
    if (!window.confirm('Are you sure you want to cancel this booking?')) {
      return;
    }

    try {
      await bookingAPI.cancel({ bookingId, customerId });
      toast.success('Booking cancelled successfully');
      fetchBookings();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to cancel booking');
    }
  };

  if (loading) {
    return (
      <div className="page">
        <div className="container">
          <div className="loading">
            <div className="spinner"></div>
            <p>Loading bookings...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="container">
        <h2>My Bookings</h2>

        {bookings.length > 0 ? (
          <div>
            {bookings.map((booking) => (
              <div key={booking.id} className="booking-card">
                <div className="booking-header">
                  <div>
                    <div className="booking-id">Booking #{booking.id}</div>
                    <div>PNR: {booking.pnrNumber}</div>
                  </div>
                  <span className={`status-badge status-${booking.status.toLowerCase()}`}>
                    {booking.status}
                  </span>
                </div>

                <div className="train-route">
                  <span><strong>Train:</strong> {booking.trainName} ({booking.trainNumber})</span>
                </div>

                <div className="train-details">
                  <div className="detail-item">
                    <div className="detail-label">Seat Type</div>
                    <div className="detail-value">{booking.seatType}</div>
                  </div>
                  <div className="detail-item">
                    <div className="detail-label">Number of Seats</div>
                    <div className="detail-value">{booking.numberOfSeats}</div>
                  </div>
                  <div className="detail-item">
                    <div className="detail-label">Total Fare</div>
                    <div className="detail-value">₹{booking.totalFare}</div>
                  </div>
                  <div className="detail-item">
                    <div className="detail-label">Booking Date</div>
                    <div className="detail-value">
                      {new Date(booking.bookingDate).toLocaleDateString()}
                    </div>
                  </div>
                </div>

                {booking.status === 'CONFIRMED' && (
                  <button
                    className="btn btn-danger"
                    onClick={() => handleCancelBooking(booking.id, user.userId)}
                  >
                    Cancel Booking
                  </button>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="empty-state">
            <h3>No bookings found</h3>
            <p>You haven't made any bookings yet</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default MyBookings;

