# Quick Start Guide - Train Ticket Management System

## How to Run the Application

1. **Build the project:**
   ```
   cd D:\TTMS
   .\mvnw.cmd clean package -DskipTests
   ```

2. **Run the application:**
   ```
   cd D:\TTMS
   .\mvnw.cmd spring-boot:run
   ```

3. **Access the application:**
   - API Base URL: `http://localhost:8080`
   - H2 Database Console: `http://localhost:8080/h2-console`

## Default Credentials
- **Admin Login:**
  - Username: `admin`
  - Password: `admin123`

## Quick Test Flow

### Step 1: Register a Customer
```bash
curl -X POST http://localhost:8080/api/customers/register -H "Content-Type: application/json" -d "{\"name\":\"John Doe\",\"email\":\"john@example.com\",\"phoneNumber\":\"1234567890\",\"address\":\"123 Main St\",\"password\":\"pass123\"}"
```

### Step 2: Admin Login
```bash
curl -X POST http://localhost:8080/api/auth/admin/login -H "Content-Type: application/json" -d "{\"username\":\"admin\",\"password\":\"admin123\"}"
```

### Step 3: Register a Train (Admin)
```bash
curl -X POST http://localhost:8080/api/admin/trains -H "Content-Type: application/json" -d "{\"trainNumber\":\"12345\",\"trainName\":\"Mumbai Express\",\"originStation\":\"Mumbai\",\"destinationStation\":\"Delhi\",\"intermediateStops\":[\"Surat\",\"Vadodara\"],\"departureTime\":\"2025-12-01T10:00:00\",\"arrivalTime\":\"2025-12-01T20:00:00\",\"sleeperSeats\":100,\"acSeats\":50,\"sleeperFare\":500.0,\"acFare\":1000.0}"
```

### Step 4: Search Trains
```bash
curl -X POST http://localhost:8080/api/trains/search -H "Content-Type: application/json" -d "{\"originStation\":\"Mumbai\",\"destinationStation\":\"Delhi\"}"
```

### Step 5: Book a Ticket
```bash
curl -X POST http://localhost:8080/api/bookings -H "Content-Type: application/json" -d "{\"customerId\":1,\"trainNumber\":\"12345\",\"originStation\":\"Mumbai\",\"destinationStation\":\"Delhi\",\"travelDate\":\"2025-12-01\",\"travelClass\":\"SLEEPER\",\"numberOfSeats\":2}"
```

### Step 6: View Booking History
```bash
curl -X GET http://localhost:8080/api/bookings/customer/1
```

## API Endpoints Summary

### Authentication
- `POST /api/auth/admin/login` - Admin login
- `POST /api/auth/customer/login` - Customer login

### Customer Management
- `POST /api/customers/register` - Register new customer
- `GET /api/customers/{id}` - Get customer details
- `PUT /api/customers/{id}` - Update customer
- `DELETE /api/customers/{id}` - Deactivate customer

### Train Management (Admin)
- `POST /api/admin/trains` - Register new train
- `GET /api/admin/trains` - Get all trains
- `GET /api/admin/trains/{trainNumber}` - Get train details
- `PUT /api/admin/trains/{trainNumber}` - Update train
- `DELETE /api/admin/trains/{trainNumber}` - Delete train

### Train Search (Public)
- `POST /api/trains/search` - Search trains by route
- `GET /api/trains` - Get all trains
- `GET /api/trains/{trainNumber}` - Get train by number

### Booking Management
- `POST /api/bookings` - Book a ticket
- `POST /api/bookings/cancel` - Cancel a ticket
- `GET /api/bookings/customer/{customerId}` - Get booking history
- `GET /api/bookings/ticket/{ticketId}` - Get booking by ticket ID

## Testing with Postman
Import the `TTMS_Postman_Collection.json` file into Postman for easy API testing.

## Database Access
- URL: `jdbc:h2:mem:ttmsdb`
- Username: `sa`
- Password: (leave empty)

## Project Features
✅ RESTful API architecture
✅ JPA/Hibernate for database operations
✅ Input validation
✅ Exception handling
✅ Automatic admin user creation
✅ Seat availability management
✅ Booking and cancellation system
✅ H2 in-memory database

## Troubleshooting
If you encounter any issues:
1. Make sure Java 17 is installed
2. Check if port 8080 is available
3. Review the console logs for errors
4. Verify database connections in H2 console

