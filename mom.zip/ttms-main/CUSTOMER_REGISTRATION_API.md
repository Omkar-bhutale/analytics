# TTMS API Documentation - Customer Registration & Management

## Base URL
```
http://localhost:8080
```

## Authentication
All protected endpoints require JWT token in the Authorization header:
```
Authorization: Bearer <your-jwt-token>
```

---

## Customer Registration & Authentication APIs

### 1. Register Customer (Public)
**Endpoint:** `POST /api/customers/register`

**Description:** Register a new customer account

**Request Body:**
```json
{
  "name": "John Doe",
  "email": "john.doe@example.com",
  "phoneNumber": "9876543210",
  "address": "123 Main Street, City, State",
  "password": "Password@123"
}
```

**Validation Rules:**
- **name**: Required, only alphabets and spaces allowed
- **email**: Required, must be valid email format
- **phoneNumber**: Required, must be exactly 10 digits
- **address**: Required
- **password**: Required, must be at least 8 characters with:
  - At least one uppercase letter
  - At least one lowercase letter
  - At least one digit
  - At least one special character (@#$%^&+=)

**Success Response (201 Created):**
```json
{
  "id": 1,
  "name": "John Doe",
  "email": "john.doe@example.com",
  "phoneNumber": "9876543210",
  "address": "123 Main Street, City, State",
  "isActive": true
}
```

**Error Response (400 Bad Request):**
```json
{
  "message": "Email already exists"
}
```

---

### 2. Customer Login (Public)
**Endpoint:** `POST /api/auth/customer/login`

**Description:** Authenticate customer and receive JWT token

**Request Body:**
```json
{
  "username": "john.doe@example.com",
  "password": "Password@123"
}
```

**Success Response (200 OK):**
```json
{
  "success": true,
  "message": "Login successful",
  "userId": 1,
  "role": "CUSTOMER",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Error Response (200 OK):**
```json
{
  "success": false,
  "message": "Please Enter Correct UserName and Password",
  "userId": null,
  "role": null,
  "token": null
}
```

---

### 3. Admin Login (Public)
**Endpoint:** `POST /api/auth/admin/login`

**Description:** Authenticate admin user and receive JWT token

**Default Admin Credentials:**
- Username: `admin`
- Password: `admin123`

**Request Body:**
```json
{
  "username": "admin",
  "password": "admin123"
}
```

**Success Response (200 OK):**
```json
{
  "success": true,
  "message": "Login successful",
  "userId": 1,
  "role": "ADMIN",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

---

## Customer Management APIs (Protected)

### 4. Get Customer Profile
**Endpoint:** `GET /api/customers/{customerId}`

**Description:** Retrieve customer information by ID

**Headers:**
```
Authorization: Bearer <jwt-token>
```

**Success Response (200 OK):**
```json
{
  "id": 1,
  "name": "John Doe",
  "email": "john.doe@example.com",
  "phoneNumber": "9876543210",
  "address": "123 Main Street, City, State",
  "isActive": true
}
```

---

### 5. Update Customer Profile
**Endpoint:** `PUT /api/customers/{customerId}`

**Description:** Update customer profile information

**Headers:**
```
Authorization: Bearer <jwt-token>
```

**Request Body:**
```json
{
  "name": "John Updated",
  "email": "john.updated@example.com",
  "phoneNumber": "9876543211",
  "address": "456 New Street, City, State",
  "password": "NewPassword@123"
}
```

**Note:** Password is optional. Leave empty to keep current password.

**Success Response (200 OK):**
```json
{
  "id": 1,
  "name": "John Updated",
  "email": "john.updated@example.com",
  "phoneNumber": "9876543211",
  "address": "456 New Street, City, State",
  "isActive": true
}
```

---

### 6. Deactivate Customer Account
**Endpoint:** `DELETE /api/customers/{customerId}`

**Description:** Deactivate customer account

**Headers:**
```
Authorization: Bearer <jwt-token>
```

**Success Response (200 OK):**
```
Customer account deactivated successfully
```

---

### 7. Get All Customers (Admin Only)
**Endpoint:** `GET /api/customers`

**Description:** Retrieve all customers (Admin only)

**Headers:**
```
Authorization: Bearer <admin-jwt-token>
```

**Success Response (200 OK):**
```json
[
  {
    "id": 1,
    "name": "John Doe",
    "email": "john.doe@example.com",
    "phoneNumber": "9876543210",
    "address": "123 Main Street, City, State",
    "isActive": true
  },
  {
    "id": 2,
    "name": "Jane Smith",
    "email": "jane.smith@example.com",
    "phoneNumber": "9876543211",
    "address": "789 Oak Avenue, City, State",
    "isActive": true
  }
]
```

---

### 8. Get Customer by Email
**Endpoint:** `GET /api/customers/email/{email}`

**Description:** Retrieve customer information by email

**Headers:**
```
Authorization: Bearer <jwt-token>
```

**Example:** `GET /api/customers/email/john.doe@example.com`

**Success Response (200 OK):**
```json
{
  "id": 1,
  "name": "John Doe",
  "email": "john.doe@example.com",
  "phoneNumber": "9876543210",
  "address": "123 Main Street, City, State",
  "isActive": true
}
```

---

### 9. Activate Customer Account (Admin Only)
**Endpoint:** `PUT /api/customers/{customerId}/activate`

**Description:** Activate a deactivated customer account

**Headers:**
```
Authorization: Bearer <admin-jwt-token>
```

**Success Response (200 OK):**
```
Customer account activated successfully
```

---

## Usage Flow

### For New Customer Registration:
1. **Register** using `POST /api/customers/register`
2. **Login** using `POST /api/auth/customer/login` to get JWT token
3. Use the JWT token for all subsequent requests

### For Admin:
1. **Login** using `POST /api/auth/admin/login` with default credentials
2. Use the JWT token for all admin operations
3. Manage customers using admin endpoints

---

## Error Codes

| Status Code | Description |
|-------------|-------------|
| 200 | Success |
| 201 | Created Successfully |
| 400 | Bad Request (Validation Error) |
| 401 | Unauthorized (Invalid Token) |
| 403 | Forbidden (Insufficient Permissions) |
| 404 | Not Found |
| 500 | Internal Server Error |

---

## Testing with cURL

### Register Customer:
```bash
curl -X POST http://localhost:8080/api/customers/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "John Doe",
    "email": "john.doe@example.com",
    "phoneNumber": "9876543210",
    "address": "123 Main Street",
    "password": "Password@123"
  }'
```

### Customer Login:
```bash
curl -X POST http://localhost:8080/api/auth/customer/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "john.doe@example.com",
    "password": "Password@123"
  }'
```

### Get Customer Profile (with JWT):
```bash
curl -X GET http://localhost:8080/api/customers/1 \
  -H "Authorization: Bearer YOUR_JWT_TOKEN_HERE"
```

---

## Swagger UI
Access interactive API documentation at:
```
http://localhost:8080/swagger-ui.html
```

You can test all APIs directly from the Swagger UI interface. Click the "Authorize" button and enter your JWT token to test protected endpoints.

