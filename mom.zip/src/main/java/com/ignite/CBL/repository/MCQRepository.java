package com.ignite.CBL.repository;

import com.ignite.CBL.dto.MCQDTO;
import com.ignite.CBL.entity.MCQ;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface MCQRepository extends JpaRepository<MCQ, Integer> {

    @Query("SELECT new com.ignite.CBL.dto.MCQDTO(m.mcqId, m.content) FROM MCQ m WHERE m.topic.topicId = :topicId")
    List<MCQDTO> findAllByTopicId(@Param("topicId") Integer topicId);

    @Query("DELETE FROM MCQ m WHERE m.topic.topicId = :topicId")
    @Modifying
    @Transactional
    int deleteAllMCQByTopicId(Integer topicTopicId);

    


}
