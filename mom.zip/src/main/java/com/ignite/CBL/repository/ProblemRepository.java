package com.ignite.CBL.repository;

import com.ignite.CBL.entity.Problem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface ProblemRepository extends JpaRepository<Problem, Integer> {
    List<Problem> findByTopic_TopicId(Integer topicTopicId);

    @Modifying
    @Transactional
    @Query("DELETE FROM Problem p WHERE p.topic.topicId = :topicId")
    int deleteByTopic_TopicId(@Param("topicId") Integer topicId);
}
