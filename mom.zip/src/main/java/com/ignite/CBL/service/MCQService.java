package com.ignite.CBL.service;

import com.ignite.CBL.dto.MCQDTO;

import java.util.List;

public interface MCQService {
    List<MCQDTO> findAllMCQByTopicId(Integer topicId);
    MCQDTO addMCQ(Integer topicId, MCQDTO mcqDTO);
    Integer addMCQs(Integer topicId, List<MCQDTO> mcqDTOs);
    void deleteAllMCQByTopicId(Integer topicId);
    void deleteMCQById(Integer mcqId);
    void deleteAllMCQ();

}
