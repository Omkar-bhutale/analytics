package com.ignite.CBL.service.impl;

import com.ignite.CBL.dto.TopicDTO;
import com.ignite.CBL.entity.MainTopic;
import com.ignite.CBL.entity.Topic;
import com.ignite.CBL.repository.MainTopicRepository;
import com.ignite.CBL.repository.TopicRepository;
import com.ignite.CBL.service.TopicService;
import jakarta.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TopicServiceImpl implements TopicService {

    private final TopicRepository topicRepository;
    private final MainTopicRepository mainTopicRepository;
    private final ModelMapper modelMapper = new ModelMapper();

    public TopicServiceImpl(TopicRepository topicRepository, MainTopicRepository mainTopicRepository) {
        this.topicRepository = topicRepository;
        this.mainTopicRepository = mainTopicRepository;
    }



    @Override
    public TopicDTO findByTopicId(Integer topicId) {
        return topicRepository.findByTopicId(topicId);
    }

    @Override
    public TopicDTO findByTitle(String title) {
        return topicRepository.findByTitle(title);
    }
    @Override
    public List<TopicDTO> findAllByMainTopicId(Integer mainTopicId) {
        return topicRepository.findAllByMainTopicId(mainTopicId);
    }

    @Override
    public TopicDTO addTopic(Integer mainTopicId, TopicDTO topicDTO) {
        MainTopic mainTopic = mainTopicRepository.findById(mainTopicId)
                .orElseThrow(() -> new RuntimeException("MainTopic not found"));

        Topic topic = Topic.builder()
                .title(topicDTO.getTitle())
                .content(topicDTO.getContent())
                .mainTopic(mainTopic).createdAt(LocalDateTime.now())
                .build();

        Topic savedTopic = topicRepository.save(topic);
        return modelMapper.map(savedTopic, TopicDTO.class);
    }

    @Override
    public Integer addTopics(Integer mainTopicId, List<TopicDTO> topicDTOs) {
        MainTopic mainTopic = mainTopicRepository.findById(mainTopicId)
                .orElseThrow(() -> new RuntimeException("MainTopic not found"));

        for (TopicDTO topicDTO : topicDTOs) {
            Topic topic = Topic.builder()
                    .title(topicDTO.getTitle())
                    .content(topicDTO.getContent())
                    .mainTopic(mainTopic)
                    .build();
            topicRepository.save(topic);
        }
        return topicDTOs.size();
    }

    @Override
    @Transactional
    public void deleteTopicById(Integer topicId) {
        topicRepository.deleteById(topicId);
    }

    @Override
    @Transactional
    public void deleteAllByMainTopicId(Integer mainTopicId) {
        topicRepository.deleteAllByMainTopic_MainTopicId(mainTopicId);
    }

    @Override
    @Transactional
    public void deleteAll() {
        topicRepository.deleteAll();
    }

}
