package com.ignite.CBL.controller;

import com.ignite.CBL.dto.ProblemDTO;
import com.ignite.CBL.service.ProblemService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/sme/problems")
@Tag(name = "Problem Management", description = "APIs for managing problems in the CBL system")
public class ProblemSMEController {

    private final ProblemService problemService;

    public ProblemSMEController(ProblemService problemService) {
        this.problemService = problemService;
    }

    @Operation(
            summary = "Create a new problem",
            description = "Creates a new problem for a specific topic"
    )
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Problem created successfully", 
                    content = @Content(schema = @Schema(implementation = ProblemDTO.class))),
            @ApiResponse(responseCode = "400", description = "Invalid input"),
            @ApiResponse(responseCode = "404", description = "Topic not found")
    })
    @PostMapping(
            value = "/topic/{topicId}",
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<ProblemDTO> createProblem(
            @Parameter(description = "ID of the topic to add the problem to", required = true)
            @PathVariable Integer topicId,
            
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Problem object that needs to be added",
                    required = true,
                    content = @Content(schema = @Schema(implementation = ProblemDTO.class))
            )
            @RequestBody ProblemDTO problemDTO) {
        ProblemDTO createdProblem = problemService.saveProblem(topicId, problemDTO);
        return new ResponseEntity<>(createdProblem, HttpStatus.CREATED);
    }

    @Operation(
            summary = "Create multiple problems",
            description = "Creates multiple problems for a specific topic in a single request"
    )
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Problems created successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid input"),
            @ApiResponse(responseCode = "404", description = "Topic not found")
    })
    @PostMapping(
            value = "/topic/{topicId}/batch",
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<List<ProblemDTO>> createProblems(
            @Parameter(description = "ID of the topic to add the problems to", required = true)
            @PathVariable Integer topicId,
            
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "List of problem objects that need to be added",
                    required = true,
                    content = @Content(schema = @Schema(implementation = ProblemDTO.class))
            )
            @RequestBody List<ProblemDTO> problemDTOs) {
        List<ProblemDTO> createdProblems = problemService.saveProblemsByTopicId(topicId, problemDTOs);
        return new ResponseEntity<>(createdProblems, HttpStatus.CREATED);
    }

    @Operation(
            summary = "Get problem by ID",
            description = "Retrieves a problem by its unique identifier"
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Problem found", 
                    content = @Content(schema = @Schema(implementation = ProblemDTO.class))),
            @ApiResponse(responseCode = "404", description = "Problem not found")
    })
    @GetMapping(
            value = "/{problemId}",
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<ProblemDTO> getProblemById(
            @Parameter(description = "ID of the problem to be retrieved", required = true)
            @PathVariable Integer problemId) {
        ProblemDTO problem = problemService.fetchProblemById(problemId);
        return ResponseEntity.ok(problem);
    }

    @Operation(
            summary = "Get all problems by topic",
            description = "Retrieves all problems for a specific topic"
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Problems retrieved successfully"),
            @ApiResponse(responseCode = "404", description = "Topic not found")
    })
    @GetMapping(
            value = "/topic/{topicId}",
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<List<ProblemDTO>> getProblemsByTopicId(
            @Parameter(description = "ID of the topic whose problems need to be retrieved", required = true)
            @PathVariable Integer topicId) {
        List<ProblemDTO> problems = problemService.fetchProblemsByTopicId(topicId);
        return ResponseEntity.ok(problems);
    }

    @Operation(
            summary = "Delete a problem",
            description = "Deletes a problem by its unique identifier"
    )
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Problem deleted successfully"),
            @ApiResponse(responseCode = "404", description = "Problem not found")
    })
    @DeleteMapping(
            value = "/{problemId}",
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<Void> deleteProblem(
            @Parameter(description = "ID of the problem to be deleted", required = true)
            @PathVariable Integer problemId) {
        problemService.deleteProblemById(problemId);
        return ResponseEntity.noContent().build();
    }

    @Operation(
            summary = "Delete all problems by topic",
            description = "Deletes all problems for a specific topic and returns the count of deleted problems"
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Problems deleted successfully"),
            @ApiResponse(responseCode = "404", description = "Topic not found")
    })
    @DeleteMapping(
            value = "/topic/{topicId}",
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<Integer> deleteProblemsByTopicId(
            @Parameter(description = "ID of the topic whose problems need to be deleted", required = true)
            @PathVariable Integer topicId) {
        int deletedCount = problemService.deleteProblemByTopicId(topicId);
        return ResponseEntity.ok(deletedCount);
    }
}
