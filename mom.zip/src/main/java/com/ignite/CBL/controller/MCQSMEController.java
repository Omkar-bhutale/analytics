package com.ignite.CBL.controller;

import com.ignite.CBL.dto.MCQDTO;
import com.ignite.CBL.service.MCQService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/mcq")
public class MCQSMEController {

    private MCQService mcqService;

    public MCQSMEController(MCQService mcqService) {
        this.mcqService = mcqService;
    }

    @GetMapping("/topic/{topicId}")
    public List<MCQDTO> findAllMCQByTopicId(@PathVariable Integer topicId) {
        return mcqService.findAllMCQByTopicId(topicId);
    }

    @PostMapping("add/{topicId}")
    public ResponseEntity<MCQDTO> addMCQ(@PathVariable Integer topicId, @RequestBody MCQDTO mcqDTO) {
        return ResponseEntity.ok(mcqService.addMCQ(topicId, mcqDTO));
    }

    @PostMapping("addMultiple/{topicId}")
    public ResponseEntity<Integer> addMCQs(@PathVariable Integer topicId, @RequestBody List<MCQDTO> mcqDTOs) {
        return ResponseEntity.ok(mcqService.addMCQs(topicId, mcqDTOs));
    }

    @DeleteMapping("delete-all-mcq-by-topic/{topicId}")
    public ResponseEntity<Void> deleteAllMCQByTopicId(@PathVariable Integer topicId) {
        mcqService.deleteAllMCQByTopicId(topicId);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("delete-mcq/{mcqId}")
    public ResponseEntity<Void> deleteMCQById(@PathVariable Integer mcqId) {
        mcqService.deleteMCQById(mcqId);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("delete-all-mcq")
    public ResponseEntity<Void> deleteAllMCQ() {
        mcqService.deleteAllMCQ();
        return ResponseEntity.ok().build();
    }


}
