package com.ignite.CBL.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.Type;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "problems")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Problem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "problem_id")
    private Integer problemId;

    @Column(name = "title",columnDefinition = "TEXT")
    private String title;


    @Column(name = "description",nullable = false,columnDefinition = "TEXT")

    private String description;

    @Enumerated(EnumType.STRING)
    @Column(name = "difficulty",nullable = false)
    private Difficulty difficulty;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "topic_id",nullable = false)
    private Topic topic;

    @OneToMany(mappedBy = "problem", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("problem-testcases")
    private Set<ProblemTestCase> testCases = new HashSet<>();

    @OneToMany(mappedBy = "problem", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("problem-algorithm")
    private Set<AlgorithmSubmission> algorithmSubmissions = new HashSet<>();

    @OneToMany(mappedBy = "problem", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("problem-submissions")
    private Set<ProblemSubmission> problemSubmissions = new HashSet<>();
    
    @OneToMany(mappedBy = "problem", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("problem-pseudocode")
    private Set<PseudocodeSubmission> pseudocodeSubmissions = new HashSet<>();
    
    @OneToMany(mappedBy = "problem", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("problem-reports")
    private Set<UserProblemReport> userProblemReports = new HashSet<>();

    @OneToMany(mappedBy = "problem", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("problem-engagements")
    private Set<UserProblemEngagement> userProblemEngagements = new HashSet<>();

    public void addTestCase(ProblemTestCase testCase){
        this.testCases.add(testCase);
        testCase.setProblem(this);
    }

    public void removeTestCase(ProblemTestCase testCase){
        this.testCases.remove(testCase);
        testCase.setProblem(null);
    }




}
