// This file is the new entry point for the Compiler component.
// It imports the main component from the modular structure.
import Compiler from './Compiler/index.jsx';

export default Compiler;

