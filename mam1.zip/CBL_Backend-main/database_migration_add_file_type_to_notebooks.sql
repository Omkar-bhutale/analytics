-- Migration script to add file_type column to notebooks table
-- This supports both PDF and IPYNB file types

-- Step 1: Add the file_type column (nullable initially)
ALTER TABLE notebooks ADD COLUMN file_type VARCHAR(10);

-- Step 2: Update existing records (assuming they are all .ipynb files)
-- You can modify this based on the actual file extensions in your file_path column
UPDATE notebooks
SET file_type = CASE
    WHEN file_path LIKE '%.ipynb' THEN 'IPYNB'
    WHEN file_path LIKE '%.pdf' THEN 'PDF'
    ELSE 'IPYNB'  -- Default for existing records
END;

-- Step 3: Make the column NOT NULL after populating existing data
ALTER TABLE notebooks ALTER COLUMN file_type SET NOT NULL;

-- Optional: Add a check constraint to ensure only valid file types
ALTER TABLE notebooks ADD CONSTRAINT chk_notebook_file_type
CHECK (file_type IN ('PDF', 'IPYNB'));

