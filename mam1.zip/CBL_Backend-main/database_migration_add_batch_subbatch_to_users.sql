-- Migration script to add batch and sub_batch columns to users table
-- Date: 2025-11-05

-- Add batch column
ALTER TABLE users
ADD COLUMN IF NOT EXISTS batch VARCHAR(10);

-- Add sub_batch column
ALTER TABLE users
ADD COLUMN IF NOT EXISTS sub_batch VARCHAR(10);

-- Add index for better query performance (optional but recommended)
CREATE INDEX IF NOT EXISTS idx_users_batch ON users(batch);
CREATE INDEX IF NOT EXISTS idx_users_sub_batch ON users(sub_batch);
CREATE INDEX IF NOT EXISTS idx_users_batch_subbatch ON users(batch, sub_batch);

-- Verify the changes
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_name = 'users'
  AND column_name IN ('batch', 'sub_batch');

