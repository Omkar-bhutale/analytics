-- ============================================================================
-- CBL Backend - MCQs Insertion Script
-- Generated: October 27, 2025
-- Description: Inserts 10 MCQs for each subtopic with proper JSON format
-- ============================================================================

-- MCQs for Topic 1: Primitive Data Types (topic_id: 1)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (1, '{
  "question": "Which of the following is NOT a primitive data type in Java?",
  "options": [
    "A) int",
    "B) float",
    "C) string",
    "D) boolean"
  ],
  "correct_answer": "C) string",
  "explanation": "String is a class in Java, not a primitive data type. Primitives are byte, short, int, long, float, double, char, boolean."
}'),
                                         (1, '{
  "question": "What is the default value of a boolean variable in Java?",
  "options": [
    "A) true",
    "B) false",
    "C) null",
    "D) 0"
  ],
  "correct_answer": "B) false",
  "explanation": "In Java, boolean variables are initialized to false by default."
}'),
                                         (1, '{
  "question": "Which data type would you use for storing a single character in Python?",
  "options": [
    "A) char",
    "B) string",
    "C) character",
    "D) chr"
  ],
  "correct_answer": "B) string",
  "explanation": "Python does not have a separate char type. Single characters are represented as strings of length 1."
}'),
                                         (1, '{
  "question": "What is the size of int data type in Java?",
  "options": [
    "A) 16 bits",
    "B) 32 bits",
    "C) 64 bits",
    "D) Depends on platform"
  ],
  "correct_answer": "B) 32 bits",
  "explanation": "In Java, int is always 32 bits regardless of the platform, ensuring portability."
}'),
                                         (1, '{
  "question": "Which of these is a valid way to declare a variable in JavaScript?",
  "options": [
    "A) var x = 10;",
    "B) let x = 10;",
    "C) const x = 10;",
    "D) All of the above"
  ],
  "correct_answer": "D) All of the above",
  "explanation": "JavaScript supports var, let, and const for variable declaration, each with different scoping rules."
}'),
                                         (1, '{
  "question": "What is the output of: print(type(5.0)) in Python?",
  "options": [
    "A) <class ''int''>",
    "B) <class ''float''>",
    "C) <class ''double''>",
    "D) <class ''number''>"
  ],
  "correct_answer": "B) <class ''float''>",
  "explanation": "In Python, numbers with decimal points are float type, even if the decimal part is zero."
}'),
                                         (1, '{
  "question": "Which TypeScript type would you use for a variable that can be number or string?",
  "options": [
    "A) any",
    "B) object",
    "C) union",
    "D) mixed"
  ],
  "correct_answer": "C) union",
  "explanation": "TypeScript union types allow a variable to hold values of multiple types, e.g., let value: number | string;"
}'),
                                         (1, '{
  "question": "What is the range of byte data type in Java?",
  "options": [
    "A) 0 to 255",
    "B) -128 to 127",
    "C) -256 to 255",
    "D) 0 to 65535"
  ],
  "correct_answer": "B) -128 to 127",
  "explanation": "Java byte is an 8-bit signed two''s complement integer with range -128 to 127."
}'),
                                         (1, '{
  "question": "Which keyword is used to declare a constant in JavaScript?",
  "options": [
    "A) constant",
    "B) final",
    "C) const",
    "D) let"
  ],
  "correct_answer": "C) const",
  "explanation": "The const keyword is used to declare constants in JavaScript. The value cannot be reassigned."
}'),
                                         (1, '{
  "question": "What is the default value of an int variable in Java?",
  "options": [
    "A) 0",
    "B) 1",
    "C) null",
    "D) undefined"
  ],
  "correct_answer": "A) 0",
  "explanation": "In Java, primitive int variables are initialized to 0 by default when declared as instance variables."
}');

-- MCQs for Topic 2: Operators and Expressions (topic_id: 2)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (2, '{
  "question": "What is the result of 10 + ''5'' in JavaScript?",
  "options": [
    "A) 15",
    "B) ''105''",
    "C) Error",
    "D) NaN"
  ],
  "correct_answer": "B) ''105''",
  "explanation": "JavaScript performs type coercion and converts the number to string when using + operator with string and number."
}'),
                                         (2, '{
  "question": "Which operator has the highest precedence in Java?",
  "options": [
    "A) *",
    "B) ++",
    "C) =",
    "D) &&"
  ],
  "correct_answer": "B) ++",
  "explanation": "The increment/decrement operators have higher precedence than arithmetic, relational, and assignment operators."
}'),
                                         (2, '{
  "question": "What is the output of: print(2 ** 3 ** 2) in Python?",
  "options": [
    "A) 64",
    "B) 512",
    "C) 72",
    "D) Error"
  ],
  "correct_answer": "B) 512",
  "explanation": "Exponentiation operator (**) is right-associative in Python, so 2 ** 3 ** 2 = 2 ** (3 ** 2) = 2 ** 9 = 512."
}'),
                                         (2, '{
  "question": "Which operator is used for integer division in Python?",
  "options": [
    "A) /",
    "B) //",
    "C) div",
    "D) %"
  ],
  "correct_answer": "B) //",
  "explanation": "The // operator performs floor division (integer division) in Python, returning the quotient without remainder."
}'),
                                         (2, '{
  "question": "What does the === operator do in JavaScript?",
  "options": [
    "A) Assignment",
    "B) Loose equality",
    "C) Strict equality",
    "D) Type conversion"
  ],
  "correct_answer": "C) Strict equality",
  "explanation": "The === operator checks strict equality without type coercion, comparing both value and type."
}'),
                                         (2, '{
  "question": "Which of these is a ternary operator?",
  "options": [
    "A) ? :",
    "B) &&",
    "C) ||",
    "D) ??"
  ],
  "correct_answer": "A) ? :",
  "explanation": "The ? : is the ternary operator that takes three operands: condition ? expr1 : expr2"
}'),
                                         (2, '{
  "question": "What is the result of 10 / 3 in Java?",
  "options": [
    "A) 3",
    "B) 3.333...",
    "C) 3.0",
    "D) 3.3"
  ],
  "correct_answer": "B) 3.333...",
  "explanation": "In Java, division of two integers results in integer division, but here one operand is int and result is promoted to double."
}'),
                                         (2, '{
  "question": "Which operator is used for nullish coalescing in JavaScript?",
  "options": [
    "A) ||",
    "B) ??",
    "C) &&",
    "D) ?:"
  ],
  "correct_answer": "B) ??",
  "explanation": "The ?? operator returns the right-hand operand when the left-hand operand is null or undefined."
}'),
                                         (2, '{
  "question": "What is the output of: ''hello'' * 3 in Python?",
  "options": [
    "A) ''hellohellohello''",
    "B) ''hello3''",
    "C) Error",
    "D) 0"
  ],
  "correct_answer": "C) Error",
  "explanation": "Python does not support string multiplication with *. Use ''hello'' * 3 for repetition (which gives ''hellohellohello'')."
}'),
                                         (2, '{
  "question": "Which operator has the lowest precedence?",
  "options": [
    "A) =",
    "B) +",
    "C) *",
    "D) &&"
  ],
  "correct_answer": "A) =",
  "explanation": "Assignment operators have the lowest precedence among common operators in most programming languages."
}');

-- Continue with MCQs for remaining topics...
-- Topic 3: Type Conversion and Casting (topic_id: 3)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (3, '{
  "question": "What is implicit type conversion also known as?",
  "options": [
    "A) Casting",
    "B) Coercion",
    "C) Parsing",
    "D) Transformation"
  ],
  "correct_answer": "B) Coercion",
  "explanation": "Implicit type conversion is called coercion, where the language automatically converts types without programmer intervention."
}'),
                                         (3, '{
  "question": "Which method converts a string to integer in Python?",
  "options": [
    "A) int()",
    "B) integer()",
    "C) parse_int()",
    "D) to_int()"
  ],
  "correct_answer": "A) int()",
  "explanation": "The int() function in Python converts a string or number to an integer."
}'),
                                         (3, '{
  "question": "What is type casting in Java?",
  "options": [
    "A) Automatic type conversion",
    "B) Explicit type conversion",
    "C) Type inference",
    "D) Dynamic typing"
  ],
  "correct_answer": "B) Explicit type conversion",
  "explanation": "Type casting in Java is explicit conversion where programmer specifies the target type using (type) syntax."
}'),
                                         (3, '{
  "question": "What happens when you add a number and string in JavaScript?",
  "options": [
    "A) Error",
    "B) String concatenation",
    "C) Number addition",
    "D) NaN"
  ],
  "explanation": "JavaScript converts the number to string and performs string concatenation when using + operator with string and number."
}'),
                                         (3, '{
  "question": "Which is the correct way to cast double to int in Java?",
  "options": [
    "A) int x = (int) 5.7;",
    "B) int x = int(5.7);",
    "C) int x = 5.7.toInt();",
    "D) int x = convert(5.7);"
  ],
  "correct_answer": "A) int x = (int) 5.7;",
  "explanation": "Java uses (type) syntax for explicit casting. (int) 5.7 will truncate to 5."
}'),
                                         (3, '{
  "question": "What is the result of Number(''hello'') in JavaScript?",
  "options": [
    "A) 0",
    "B) NaN",
    "C) Error",
    "D) ''hello''"
  ],
  "correct_answer": "B) NaN",
  "explanation": "Number() function returns NaN when the string cannot be parsed as a valid number."
}'),
                                         (3, '{
  "question": "Which function converts any value to string in Python?",
  "options": [
    "A) string()",
    "B) str()",
    "C) toString()",
    "D) convert()"
  ],
  "correct_answer": "B) str()",
  "explanation": "The str() function in Python converts any object to its string representation."
}'),
                                         (3, '{
  "question": "What is widening conversion in Java?",
  "options": [
    "A) byte → int",
    "B) int → byte",
    "C) double → int",
    "D) long → int"
  ],
  "correct_answer": "A) byte → int",
  "explanation": "Widening conversion happens when converting from smaller to larger data types, which is safe and implicit."
}'),
                                         (3, '{
  "question": "How do you convert string to number in TypeScript?",
  "options": [
    "A) parseInt()",
    "B) Number()",
    "C) + operator",
    "D) All of the above"
  ],
  "correct_answer": "D) All of the above",
  "explanation": "TypeScript supports all JavaScript methods for string to number conversion: parseInt(), Number(), and unary + operator."
}'),
                                         (3, '{
  "question": "What is narrowing conversion?",
  "options": [
    "A) Safe automatic conversion",
    "B) Conversion with potential data loss",
    "C) String to number conversion",
    "D) Boolean conversion"
  ],
  "correct_answer": "B) Conversion with potential data loss",
  "explanation": "Narrowing conversion happens when converting from larger to smaller data types, which may lose precision and requires explicit casting."
}');

-- ============================================================================
-- CBL Backend - MCQs Insertion Script (Continued)
-- ============================================================================

-- MCQs for Topic 4: Variables and Scope (topic_id: 4)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (4, '{
  "question": "What is the scope of a variable declared with ''var'' in JavaScript?",
  "options": [
    "A) Block scope",
    "B) Function scope",
    "C) Global scope",
    "D) Module scope"
  ],
  "correct_answer": "B) Function scope",
  "explanation": "Variables declared with ''var'' have function scope or global scope if declared outside functions."
}'),
                                         (4, '{
  "question": "Which keyword is used to declare a constant in Java?",
  "options": [
    "A) const",
    "B) final",
    "C) constant",
    "D) static"
  ],
  "correct_answer": "B) final",
  "explanation": "The ''final'' keyword is used to declare constants in Java."
}'),
                                         (4, '{
  "question": "What is the difference between ''let'' and ''var'' in JavaScript?",
  "options": [
    "A) let has block scope, var has function scope",
    "B) var has block scope, let has function scope",
    "C) Both have same scope",
    "D) let is hoisted, var is not"
  ],
  "correct_answer": "A) let has block scope, var has function scope",
  "explanation": "''let'' variables are block-scoped while ''var'' variables are function-scoped."
}'),
                                         (4, '{
  "question": "What is a global variable in Python?",
  "options": [
    "A) Variable declared inside a function",
    "B) Variable declared with ''global'' keyword",
    "C) Variable declared at module level",
    "D) Both B and C"
  ],
  "correct_answer": "D) Both B and C",
  "explanation": "Global variables are declared at module level or explicitly declared with ''global'' keyword inside functions."
}'),
                                         (4, '{
  "question": "What is variable shadowing?",
  "options": [
    "A) When a variable is declared but not used",
    "B) When a local variable has same name as global variable",
    "C) When a variable is undefined",
    "D) When a variable is constant"
  ],
  "correct_answer": "B) When a local variable has same name as global variable",
  "explanation": "Variable shadowing occurs when a local variable has the same name as a variable in outer scope, hiding the outer variable."
}'),
                                         (4, '{
  "question": "Which variable has the longest lifetime in Java?",
  "options": [
    "A) Local variable",
    "B) Instance variable",
    "C) Class variable",
    "D) Parameter"
  ],
  "correct_answer": "C) Class variable",
  "explanation": "Class variables (static) exist for the lifetime of the program, while instance variables exist as long as the object."
}'),
                                         (4, '{
  "question": "What is the purpose of ''nonlocal'' keyword in Python?",
  "options": [
    "A) Declare global variables",
    "B) Declare constants",
    "C) Access variables from enclosing scope",
    "D) Import modules"
  ],
  "correct_answer": "C) Access variables from enclosing scope",
  "explanation": "The ''nonlocal'' keyword is used to work with variables in the nearest enclosing scope that is not global."
}'),
                                         (4, '{
  "question": "What is hoisting in JavaScript?",
  "options": [
    "A) Variable declaration moved to top of scope",
    "B) Variable initialization moved to top",
    "C) Both declaration and initialization moved",
    "D) Variable deletion"
  ],
  "correct_answer": "A) Variable declaration moved to top of scope",
  "explanation": "Hoisting moves variable and function declarations to the top of their containing scope during compilation."
}'),
                                         (4, '{
  "question": "Which type of variable is shared among all instances of a class?",
  "options": [
    "A) Instance variable",
    "B) Local variable",
    "C) Class variable",
    "D) Parameter"
  ],
  "correct_answer": "C) Class variable",
  "explanation": "Class variables (static) are shared among all instances of a class, while instance variables are unique to each object."
}'),
                                         (4, '{
  "question": "What is the default value of an uninitialized local variable in Java?",
  "options": [
    "A) 0",
    "B) null",
    "C) undefined",
    "D) No default value"
  ],
  "correct_answer": "D) No default value",
  "explanation": "Local variables in Java are not automatically initialized and must be explicitly assigned before use."
}');

-- MCQs for Topic 5: If-Else Statements (topic_id: 5)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (5, '{
  "question": "What is the purpose of ''elif'' in Python?",
  "options": [
    "A) Else if",
    "B) Else for if",
    "C) Else in function",
    "D) End if"
  ],
  "correct_answer": "A) Else if",
  "explanation": "''elif'' in Python is equivalent to ''else if'' in other languages, used for multiple conditional branches."
}'),
                                         (5, '{
  "question": "Which of these is a valid if statement in Java?",
  "options": [
    "A) if x > 5 {}",
    "B) if (x > 5) {}",
    "C) if [x > 5] {}",
    "D) if {x > 5} {}"
  ],
  "correct_answer": "B) if (x > 5) {}",
  "explanation": "Java requires parentheses around the condition in if statements."
}'),
                                         (5, '{
  "question": "What is short-circuit evaluation in conditional statements?",
  "options": [
    "A) Evaluating both sides always",
    "B) Stopping evaluation when result is known",
    "C) Using short variable names",
    "D) Fast execution"
  ],
  "correct_answer": "B) Stopping evaluation when result is known",
  "explanation": "Short-circuit evaluation stops evaluating expressions as soon as the final result can be determined."
}'),
                                         (5, '{
  "question": "Which operator has higher precedence in conditions?",
  "options": [
    "A) &&",
    "B) ||",
    "C) !",
    "D) =="
  ],
  "correct_answer": "C) !",
  "explanation": "The logical NOT operator (!) has higher precedence than && and || in most languages."
}'),
                                         (5, '{
  "question": "What is the purpose of ''switch'' statement?",
  "options": [
    "A) Replace multiple if-else statements",
    "B) Create loops",
    "C) Define functions",
    "D) Handle exceptions"
  ],
  "correct_answer": "A) Replace multiple if-else statements",
  "explanation": "Switch statements provide a cleaner way to handle multiple possible values for a variable compared to if-else chains."
}'),
                                         (5, '{
  "question": "What happens if no ''break'' is used in a switch case in Java?",
  "options": [
    "A) Error",
    "B) Fall-through to next case",
    "C) Default case executed",
    "D) Nothing"
  ],
  "correct_answer": "B) Fall-through to next case",
  "explanation": "Without ''break'', execution will continue to the next case statement (fall-through)."
}'),
                                         (5, '{
  "question": "Which data types can be used in switch statements in Java?",
  "options": [
    "A) Only integers",
    "B) Integers and strings",
    "C) Any primitive type",
    "D) byte, short, char, int, String, enum"
  ],
  "correct_answer": "D) byte, short, char, int, String, enum",
  "explanation": "Java switch supports byte, short, char, int, their wrapper classes, String, and enum types."
}'),
                                         (5, '{
  "question": "What is the ternary operator syntax?",
  "options": [
    "A) condition ? value1 : value2",
    "B) condition : value1 ? value2",
    "C) value1 ? value2 : condition",
    "D) condition ? value1 ? value2"
  ],
  "correct_answer": "A) condition ? value1 : value2",
  "explanation": "The ternary operator has syntax: condition ? expression_if_true : expression_if_false"
}'),
                                         (5, '{
  "question": "What is the purpose of ''else'' clause?",
  "options": [
    "A) Execute when if condition is true",
    "B) Execute when all conditions are false",
    "C) Define default case",
    "D) Handle errors"
  ],
  "correct_answer": "B) Execute when all conditions are false",
  "explanation": "The ''else'' clause executes when all preceding if and else if conditions are false."
}'),
                                         (5, '{
  "question": "Which is true about Python indentation in conditionals?",
  "options": [
    "A) Optional",
    "B) Required for code blocks",
    "C) Uses braces",
    "D) Uses parentheses"
  ],
  "correct_answer": "B) Required for code blocks",
  "explanation": "Python uses indentation to define code blocks, making it mandatory for if-else statements."
}');

-- MCQs for Topic 6: Switch Statements (topic_id: 6)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (6, '{
  "question": "What is the new switch expression in Java 14+?",
  "options": [
    "A) Uses -> arrow syntax",
    "B) Can return values",
    "C) No fall-through",
    "D) All of the above"
  ],
  "correct_answer": "D) All of the above",
  "explanation": "Java 14+ switch expressions use -> syntax, can return values, and don''t have fall-through behavior."
}'),
                                         (6, '{
  "question": "Which Python version introduced match-case?",
  "options": [
    "A) Python 2.7",
    "B) Python 3.6",
    "C) Python 3.10",
    "D) Python 3.8"
  ],
  "correct_answer": "C) Python 3.10",
  "explanation": "The match-case statement (structural pattern matching) was introduced in Python 3.10."
}'),
                                         (6, '{
  "question": "What is the purpose of ''default'' case in switch?",
  "options": [
    "A) First case to execute",
    "B) Case when no other matches",
    "C) Required case",
    "D) Error handler"
  ],
  "correct_answer": "B) Case when no other matches",
  "explanation": "The default case executes when no other case values match the switch expression."
}'),
                                         (6, '{
  "question": "Can switch statements use floating-point numbers in Java?",
  "options": [
    "A) Yes",
    "B) No",
    "C) Only float",
    "D) Only double"
  ],
  "correct_answer": "B) No",
  "explanation": "Java switch does not support floating-point numbers (float, double) as case values."
}'),
                                         (6, '{
  "question": "What is pattern matching in switch?",
  "options": [
    "A) Matching exact values",
    "B) Matching types and extracting data",
    "C) Using regex patterns",
    "D) String comparison"
  ],
  "correct_answer": "B) Matching types and extracting data",
  "explanation": "Pattern matching allows switching on types and extracting data from objects, available in modern Java and Python."
}'),
                                         (6, '{
  "question": "Which is NOT a advantage of switch over if-else?",
  "options": [
    "A) Better readability",
    "B) Faster execution",
    "C) More flexible conditions",
    "D) Compiler optimization"
  ],
  "correct_answer": "C) More flexible conditions",
  "explanation": "Switch is less flexible than if-else as it can only test equality, not complex conditions."
}'),
                                         (6, '{
  "question": "What does ''yield'' do in Java switch expressions?",
  "options": [
    "A) Break from switch",
    "B) Return a value",
    "C) Continue to next case",
    "D) Throw exception"
  ],
  "correct_answer": "B) Return a value",
  "explanation": "In Java switch expressions, ''yield'' is used to return a value from a case branch."
}'),
                                         (6, '{
  "question": "Can JavaScript switch use strict comparison?",
  "options": [
    "A) Yes, always",
    "B) No, never",
    "C) Only with === operator",
    "D) Only in strict mode"
  ],
  "correct_answer": "A) Yes, always",
  "explanation": "JavaScript switch statements always use strict comparison (===) for matching cases."
}'),
                                         (6, '{
  "question": "What is the purpose of ''case _'' in Python match?",
  "options": [
    "A) Match underscore character",
    "B) Default case",
    "C) Match any value",
    "D) Both B and C"
  ],
  "correct_answer": "D) Both B and C",
  "explanation": "In Python match, ''case _'' acts as a wildcard that matches any value and serves as the default case."
}'),
                                         (6, '{
  "question": "Which language does NOT have traditional switch statement?",
  "options": [
    "A) Java",
    "B) Python (before 3.10)",
    "C) JavaScript",
    "D) C++"
  ],
  "correct_answer": "B) Python (before 3.10)",
  "explanation": "Python did not have a traditional switch statement until match-case was introduced in version 3.10."
}');

-- MCQs for Topic 7: For Loops (topic_id: 7)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (7, '{
  "question": "What is the range of values in for i in range(5) in Python?",
  "options": [
    "A) 0 to 4",
    "B) 1 to 5",
    "C) 0 to 5",
    "D) 1 to 4"
  ],
  "correct_answer": "A) 0 to 4",
  "explanation": "range(5) generates numbers from 0 to 4 (5 is exclusive)."
}'),
                                         (7, '{
  "question": "Which loop is guaranteed to execute at least once?",
  "options": [
    "A) for loop",
    "B) while loop",
    "C) do-while loop",
    "D) for-each loop"
  ],
  "correct_answer": "C) do-while loop",
  "explanation": "do-while loop checks condition after execution, so it always runs at least once."
}'),
                                         (7, '{
  "question": "What is enhanced for loop in Java?",
  "options": [
    "A) for-each loop",
    "B) for-in loop",
    "C) for-of loop",
    "D) while loop"
  ],
  "correct_answer": "A) for-each loop",
  "explanation": "Enhanced for loop (for-each) iterates over arrays and collections without index management."
}'),
                                         (7, '{
  "question": "What does ''break'' statement do in loops?",
  "options": [
    "A) Skip current iteration",
    "B) Exit the loop completely",
    "C) Continue to next iteration",
    "D) Restart the loop"
  ],
  "correct_answer": "B) Exit the loop completely",
  "explanation": "''break'' immediately terminates the loop and continues with code after the loop."
}'),
                                         (7, '{
  "question": "What is the purpose of ''continue'' statement?",
  "options": [
    "A) Exit program",
    "B) Skip to next iteration",
    "C) Break out of loop",
    "D) Restart loop"
  ],
  "correct_answer": "B) Skip to next iteration",
  "explanation": "''continue'' skips the remaining code in current iteration and moves to next iteration."
}'),
                                         (7, '{
  "question": "Which loop is best for iterating over array elements?",
  "options": [
    "A) while loop",
    "B) do-while loop",
    "C) for loop with index",
    "D) All can be used"
  ],
  "correct_answer": "D) All can be used",
  "explanation": "All loop types can iterate over arrays, but for-each is often preferred for simplicity."
}'),
                                         (7, '{
  "question": "What is an infinite loop?",
  "options": [
    "A) Loop that never ends",
    "B) Very fast loop",
    "C) Loop with many iterations",
    "D) Recursive loop"
  ],
  "correct_answer": "A) Loop that never ends",
  "explanation": "An infinite loop has a condition that always evaluates to true and never terminates."
}'),
                                         (7, '{
  "question": "What does range(1, 10, 2) generate in Python?",
  "options": [
    "A) 1, 3, 5, 7, 9",
    "B) 1, 2, 3, ..., 9",
    "C) 2, 4, 6, 8, 10",
    "D) 1, 2, 3, ..., 10"
  ],
  "correct_answer": "A) 1, 3, 5, 7, 9",
  "explanation": "range(start, stop, step) generates numbers from start to stop-1 with given step size."
}'),
                                         (7, '{
  "question": "Which loop is not available in Python?",
  "options": [
    "A) for loop",
    "B) while loop",
    "C) do-while loop",
    "D) nested loops"
  ],
  "correct_answer": "C) do-while loop",
  "explanation": "Python does not have a built-in do-while loop construct."
}'),
                                         (7, '{
  "question": "What is nested loop?",
  "options": [
    "A) Loop inside another loop",
    "B) Infinite loop",
    "C) Recursive function",
    "D) Parallel loop"
  ],
  "correct_answer": "A) Loop inside another loop",
  "explanation": "A nested loop is a loop placed inside another loop, commonly used for multi-dimensional data."
}');

-- MCQs for Topic 8: While and Do-While Loops (topic_id: 8)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (8, '{
  "question": "What is the main difference between while and do-while loops?",
  "options": [
    "A) Syntax",
    "B) do-while executes at least once",
    "C) while is faster",
    "D) do-while uses different condition"
  ],
  "correct_answer": "B) do-while executes at least once",
  "explanation": "do-while checks condition after execution, guaranteeing at least one iteration."
}'),
                                         (8, '{
  "question": "When should you use while loop over for loop?",
  "options": [
    "A) When number of iterations is known",
    "B) When number of iterations is unknown",
    "C) For array iteration",
    "D) For fixed count iterations"
  ],
  "correct_answer": "B) When number of iterations is unknown",
  "explanation": "while loops are ideal when the number of iterations depends on a condition that may change during execution."
}'),
                                         (8, '{
  "question": "What is a common use case for do-while loop?",
  "options": [
    "A) Menu-driven programs",
    "B) Array iteration",
    "C) Fixed count loops",
    "D) Infinite loops"
  ],
  "correct_answer": "A) Menu-driven programs",
  "explanation": "do-while is often used in menu systems where you want to show the menu at least once."
}'),
                                         (8, '{
  "question": "How do you simulate do-while in Python?",
  "options": [
    "A) Use while True with break",
    "B) Use for loop with condition",
    "C) Python has built-in do-while",
    "D) Use if statement"
  ],
  "correct_answer": "A) Use while True with break",
  "explanation": "Python simulates do-while using while True with a break condition at the end."
}'),
                                         (8, '{
  "question": "What is loop control variable?",
  "options": [
    "A) Variable that controls loop execution",
    "B) Variable inside loop body",
    "C) Constant value",
    "D) Loop counter"
  ],
  "correct_answer": "A) Variable that controls loop execution",
  "explanation": "Loop control variable is modified within the loop and tested in the condition to determine when to stop."
}'),
                                         (8, '{
  "question": "What is an off-by-one error in loops?",
  "options": [
    "A) Loop runs one more or less time than intended",
    "B) Infinite loop",
    "C) Syntax error",
    "D) Memory error"
  ],
  "correct_answer": "A) Loop runs one more or less time than intended",
  "explanation": "Off-by-one error occurs when loop boundaries are incorrect, causing one extra or missing iteration."
}'),
                                         (8, '{
  "question": "Which loop is more readable for simple iterations?",
  "options": [
    "A) while loop",
    "B) do-while loop",
    "C) for loop",
    "D) All are equal"
  ],
  "correct_answer": "C) for loop",
  "explanation": "for loops are often more readable when iterating a known number of times as all loop control is in one line."
}'),
                                         (8, '{
  "question": "What is the risk of modifying loop variable inside while loop?",
  "options": [
    "A) Infinite loop",
    "B) Compiler error",
    "C) Better performance",
    "D) No risk"
  ],
  "correct_answer": "A) Infinite loop",
  "explanation": "Modifying loop variable incorrectly can cause the loop to run indefinitely or terminate prematurely."
}'),
                                         (8, '{
  "question": "How to avoid infinite loops?",
  "options": [
    "A) Ensure condition eventually becomes false",
    "B) Use break statements",
    "C) Both A and B",
    "D) Use only for loops"
  ],
  "correct_answer": "C) Both A and B",
  "explanation": "Ensure loop condition can become false and use break statements as safety measures."
}'),
                                         (8, '{
  "question": "What is tail recursion?",
  "options": [
    "A) Recursive call as last operation",
    "B) Infinite recursion",
    "C) Loop optimization",
    "D) Function calling itself"
  ],
  "correct_answer": "A) Recursive call as last operation",
  "explanation": "Tail recursion occurs when the recursive call is the last operation in the function, allowing compiler optimization."
}');

-- Continue with remaining topics following the same pattern...
-- Topics 9-28 would continue here with 10 MCQs each...

-- MCQs for Topic 9: Function Declaration and Invocation (topic_id: 9)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (9, '{
  "question": "What is a function signature?",
  "options": [
    "A) Function name and return type",
    "B) Function name and parameters",
    "C) Function body",
    "D) Function documentation"
  ],
  "correct_answer": "B) Function name and parameters",
  "explanation": "Function signature includes function name and parameter types (and return type in some languages)."
}'),
                                         (9, '{
  "question": "What is method overloading?",
  "options": [
    "A) Multiple methods with same name but different parameters",
    "B) Method that is too long",
    "C) Recursive method",
    "D) Static method"
  ],
  "correct_answer": "A) Multiple methods with same name but different parameters",
  "explanation": "Method overloading allows multiple methods with same name but different parameter lists in the same class."
}'),
                                         (9, '{
  "question": "What is the purpose of ''void'' return type?",
  "options": [
    "A) Function returns nothing",
    "B) Function returns any type",
    "C) Function returns null",
    "D) Function returns object"
  ],
  "correct_answer": "A) Function returns nothing",
  "explanation": "void indicates that a function does not return any value."
}'),
                                         (9, '{
  "question": "What are first-class functions?",
  "options": [
    "A) Functions that can be treated as variables",
    "B) Most important functions",
    "C) Built-in functions",
    "D) Main function"
  ],
  "correct_answer": "A) Functions that can be treated as variables",
  "explanation": "First-class functions can be assigned to variables, passed as arguments, and returned from other functions."
}'),
                                         (9, '{
  "question": "What is IIFE in JavaScript?",
  "options": [
    "A) Immediately Invoked Function Expression",
    "B) Internal Function Execution",
    "C) Instant Function Call",
    "D) Inline Function"
  ],
  "correct_answer": "A) Immediately Invoked Function Expression",
  "explanation": "IIFE is a function that is defined and called immediately, often used to create private scope."
}'),
                                         (9, '{
  "question": "What is the ''main'' method in Java?",
  "options": [
    "A) Program entry point",
    "B) Any method",
    "C) Constructor",
    "D) Static block"
  ],
  "correct_answer": "A) Program entry point",
  "explanation": "The main method is the entry point of a Java application where execution begins."
}'),
                                         (9, '{
  "question": "What are lambda functions?",
  "options": [
    "A) Anonymous functions",
    "B) Named functions",
    "C) Recursive functions",
    "D) Static functions"
  ],
  "correct_answer": "A) Anonymous functions",
  "explanation": "Lambda functions are anonymous functions defined without a name, often used for short operations."
}'),
                                         (9, '{
  "question": "What is function currying?",
  "options": [
    "A) Converting multi-argument function to sequence of single-argument functions",
    "B) Function optimization",
    "C) Function documentation",
    "D) Function testing"
  ],
  "correct_answer": "A) Converting multi-argument function to sequence of single-argument functions",
  "explanation": "Currying transforms a function with multiple arguments into a sequence of functions each with single argument."
}'),
                                         (9, '{
  "question": "What is the ''this'' keyword in methods?",
  "options": [
    "A) Refers to current object instance",
    "B) Refers to parent class",
    "C) Refers to static context",
    "D) Refers to global object"
  ],
  "correct_answer": "A) Refers to current object instance",
  "explanation": "''this'' refers to the current object instance in most object-oriented languages."
}'),
                                         (9, '{
  "question": "What are pure functions?",
  "options": [
    "A) Functions with no side effects",
    "B) Functions that always return same output for same input",
    "C) Both A and B",
    "D) Functions with global variables"
  ],
  "correct_answer": "C) Both A and B",
  "explanation": "Pure functions have no side effects and always return the same output for the same input."
}');
-- MCQs for Topic 10: Parameters and Return Values (topic_id: 10)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (10, '{
  "question": "What are default parameters?",
  "options": [
    "A) Parameters with predefined values",
    "B) Required parameters",
    "C) Output parameters",
    "D) Constant parameters"
  ],
  "correct_answer": "A) Parameters with predefined values",
  "explanation": "Default parameters have predefined values that are used when no argument is provided."
}'),
                                         (10, '{
  "question": "What is pass-by-value in Java?",
  "options": [
    "A) Copy of value is passed",
    "B) Reference is passed",
    "C) Variable itself is passed",
    "D) Memory address is passed"
  ],
  "correct_answer": "A) Copy of value is passed",
  "explanation": "Java always passes primitive types by value (copy) and object references by value."
}'),
                                         (10, '{
  "question": "What are variadic functions?",
  "options": [
    "A) Functions that accept variable number of arguments",
    "B) Functions with fixed parameters",
    "C) Recursive functions",
    "D) Async functions"
  ],
  "correct_answer": "A) Functions that accept variable number of arguments",
  "explanation": "Variadic functions can accept any number of arguments, like printf in C or *args in Python."
}'),
                                         (10, '{
  "question": "What is the ''void'' keyword used for?",
  "options": [
    "A) Indicate no return value",
    "B) Indicate any return type",
    "C) Indicate null return",
    "D) Indicate empty parameters"
  ],
  "correct_answer": "A) Indicate no return value",
  "explanation": "void specifies that a function does not return any value."
}'),
                                         (10, '{
  "question": "What are named parameters?",
  "options": [
    "A) Parameters specified by name",
    "B) Required parameters",
    "C) Default parameters",
    "D) Output parameters"
  ],
  "correct_answer": "A) Parameters specified by name",
  "explanation": "Named parameters allow arguments to be passed by parameter name rather than position."
}'),
                                         (10, '{
  "question": "What is return type inference?",
  "options": [
    "A) Compiler deduces return type",
    "B) Explicit return type declaration",
    "C) No return type",
    "D) Multiple return types"
  ],
  "correct_answer": "A) Compiler deduces return type",
  "explanation": "Type inference allows the compiler to automatically determine the return type based on the returned value."
}'),
                                         (10, '{
  "question": "What are out parameters?",
  "options": [
    "A) Parameters used to return additional values",
    "B) Input parameters",
    "C) Optional parameters",
    "D) Constant parameters"
  ],
  "correct_answer": "A) Parameters used to return additional values",
  "explanation": "Out parameters are used to return multiple values from a function."
}'),
                                         (10, '{
  "question": "What is method chaining?",
  "options": [
    "A) Calling multiple methods in sequence",
    "B) Method overloading",
    "C) Method overriding",
    "D) Recursive methods"
  ],
  "correct_answer": "A) Calling multiple methods in sequence",
  "explanation": "Method chaining allows calling multiple methods on the same object in a single statement."
}'),
                                         (10, '{
  "question": "What are optional parameters?",
  "options": [
    "A) Parameters that can be omitted",
    "B) Required parameters",
    "C) Output parameters",
    "D) Reference parameters"
  ],
  "correct_answer": "A) Parameters that can be omitted",
  "explanation": "Optional parameters have default values and can be skipped when calling the function."
}'),
                                         (10, '{
  "question": "What is the difference between return and print?",
  "options": [
    "A) return gives value to caller, print displays output",
    "B) Both are same",
    "C) print returns value, return displays output",
    "D) return is for loops, print for functions"
  ],
  "correct_answer": "A) return gives value to caller, print displays output",
  "explanation": "return passes a value back to the caller, while print sends output to the console."
}');

-- MCQs for Topic 11: Function Scope and Closures (topic_id: 11)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (11, '{
  "question": "What is a closure?",
  "options": [
    "A) Function with access to its outer scope",
    "B) Anonymous function",
    "C) Recursive function",
    "D) Static function"
  ],
  "correct_answer": "A) Function with access to its outer scope",
  "explanation": "A closure is a function that retains access to variables from its outer (enclosing) scope even after the outer function has finished execution."
}'),
                                         (11, '{
  "question": "What is lexical scoping?",
  "options": [
    "A) Scope determined by code structure",
    "B) Scope determined at runtime",
    "C) Global scope only",
    "D) Function scope only"
  ],
  "correct_answer": "A) Scope determined by code structure",
  "explanation": "Lexical scoping means variable scope is determined by the physical structure of the code (nesting of functions)."
}'),
                                         (11, '{
  "question": "What is the LEGB rule in Python?",
  "options": [
    "A) Local, Enclosing, Global, Built-in",
    "B) Loop, Execute, Global, Built-in",
    "C) Local, External, Global, Base",
    "D) Lexical, External, Global, Built-in"
  ],
  "correct_answer": "A) Local, Enclosing, Global, Built-in",
  "explanation": "LEGB describes Python''s scope resolution order: Local → Enclosing → Global → Built-in."
}'),
                                         (11, '{
  "question": "What is variable hoisting?",
  "options": [
    "A) Declaration moved to top of scope",
    "B) Variable deletion",
    "C) Variable initialization",
    "D) Variable assignment"
  ],
  "correct_answer": "A) Declaration moved to top of scope",
  "explanation": "Hoisting moves variable and function declarations to the top of their scope during compilation."
}'),
                                         (11, '{
  "question": "What is a callback function?",
  "options": [
    "A) Function passed as argument to another function",
    "B) Recursive function",
    "C) Function that calls itself",
    "D) Async function"
  ],
  "correct_answer": "A) Function passed as argument to another function",
  "explanation": "A callback function is passed as an argument to another function and executed later."
}'),
                                         (11, '{
  "question": "What is the ''global'' keyword used for in Python?",
  "options": [
    "A) Access global variables",
    "B) Create local variables",
    "C) Import modules",
    "D) Define constants"
  ],
  "correct_answer": "A) Access global variables",
  "explanation": "The global keyword allows modifying global variables from within a function."
}'),
                                         (11, '{
  "question": "What is function composition?",
  "options": [
    "A) Combining multiple functions",
    "B) Function overloading",
    "C) Function overriding",
    "D) Function declaration"
  ],
  "correct_answer": "A) Combining multiple functions",
  "explanation": "Function composition combines simple functions to build more complex ones (f(g(x)))."
}'),
                                         (11, '{
  "question": "What is the difference between var and let in JavaScript?",
  "options": [
    "A) var is function-scoped, let is block-scoped",
    "B) let is function-scoped, var is block-scoped",
    "C) Both are same",
    "D) var is newer than let"
  ],
  "correct_answer": "A) var is function-scoped, let is block-scoped",
  "explanation": "var declarations are function-scoped while let declarations are block-scoped."
}'),
                                         (11, '{
  "question": "What is the purpose of IIFE?",
  "options": [
    "A) Create private scope",
    "B) Improve performance",
    "C) Make functions public",
    "D) Export modules"
  ],
  "correct_answer": "A) Create private scope",
  "explanation": "Immediately Invoked Function Expressions create a private scope to avoid polluting global namespace."
}'),
                                         (11, '{
  "question": "What are higher-order functions?",
  "options": [
    "A) Functions that take other functions as arguments",
    "B) Functions with high complexity",
    "C) Built-in functions",
    "D) Main functions"
  ],
  "correct_answer": "A) Functions that take other functions as arguments",
  "explanation": "Higher-order functions either take functions as parameters or return functions as results."
}');

-- MCQs for Topic 12: Recursion and Higher-Order Functions (topic_id: 12)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (12, '{
  "question": "What is recursion?",
  "options": [
    "A) Function calling itself",
    "B) Function calling other functions",
    "C) Infinite loop",
    "D) Method overloading"
  ],
  "correct_answer": "A) Function calling itself",
  "explanation": "Recursion occurs when a function calls itself directly or indirectly to solve a problem."
}'),
                                         (12, '{
  "question": "What is the base case in recursion?",
  "options": [
    "A) Condition that stops recursion",
    "B) First function call",
    "C) Last function call",
    "D) Recursive call"
  ],
  "correct_answer": "A) Condition that stops recursion",
  "explanation": "The base case provides the terminating condition that prevents infinite recursion."
}'),
                                         (12, '{
  "question": "What is tail recursion?",
  "options": [
    "A) Recursive call as last operation",
    "B) First recursive call",
    "C) Multiple recursive calls",
    "D) No recursive calls"
  ],
  "correct_answer": "A) Recursive call as last operation",
  "explanation": "Tail recursion occurs when the recursive call is the last operation in the function."
}'),
                                         (12, '{
  "question": "What are map, filter, and reduce?",
  "options": [
    "A) Higher-order functions",
    "B) Data structures",
    "C) Loop types",
    "D) Algorithm types"
  ],
  "correct_answer": "A) Higher-order functions",
  "explanation": "map, filter, and reduce are higher-order functions for processing collections."
}'),
                                         (12, '{
  "question": "What is memoization?",
  "options": [
    "A) Caching function results",
    "B) Function documentation",
    "C) Function optimization",
    "D) Memory allocation"
  ],
  "correct_answer": "A) Caching function results",
  "explanation": "Memoization stores results of expensive function calls to avoid redundant calculations."
}'),
                                         (12, '{
  "question": "What is the main risk of recursion?",
  "options": [
    "A) Stack overflow",
    "B) Memory leak",
    "C) Slow execution",
    "D) Syntax errors"
  ],
  "correct_answer": "A) Stack overflow",
  "explanation": "Deep recursion can cause stack overflow due to too many function calls on the call stack."
}'),
                                         (12, '{
  "question": "What is a recursive data structure?",
  "options": [
    "A) Structure that contains itself",
    "B) Array structure",
    "C) Simple variables",
    "D) Primitive types"
  ],
  "correct_answer": "A) Structure that contains itself",
  "explanation": "Recursive data structures contain references to instances of the same type, like trees and linked lists."
}'),
                                         (12, '{
  "question": "What is the difference between recursion and iteration?",
  "options": [
    "A) Recursion uses function calls, iteration uses loops",
    "B) Iteration uses function calls, recursion uses loops",
    "C) Both are same",
    "D) Recursion is faster"
  ],
  "correct_answer": "A) Recursion uses function calls, iteration uses loops",
  "explanation": "Recursion solves problems by function calls, while iteration uses looping constructs."
}'),
                                         (12, '{
  "question": "What are pure functions in functional programming?",
  "options": [
    "A) No side effects, same input = same output",
    "B) Functions with side effects",
    "C) Impure functions",
    "D) Main functions"
  ],
  "correct_answer": "A) No side effects, same input = same output",
  "explanation": "Pure functions don''t modify external state and always return the same output for the same input."
}'),
                                         (12, '{
  "question": "What is function currying?",
  "options": [
    "A) Transform multi-arg function to single-arg functions",
    "B) Function optimization",
    "C) Function documentation",
    "D) Function testing"
  ],
  "correct_answer": "A) Transform multi-arg function to single-arg functions",
  "explanation": "Currying converts a function with multiple arguments into a sequence of functions with single arguments."
}');

-- MCQs for Topic 13: Lists and Arrays (topic_id: 13)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (13, '{
  "question": "What is the main difference between array and list?",
  "options": [
    "A) Array fixed size, list dynamic size",
    "B) List fixed size, array dynamic size",
    "C) Both are same",
    "D) Array is in Python, list in Java"
  ],
  "correct_answer": "A) Array fixed size, list dynamic size",
  "explanation": "Arrays typically have fixed size while lists can grow and shrink dynamically."
}'),
                                         (13, '{
  "question": "What is zero-based indexing?",
  "options": [
    "A) First element at index 0",
    "B) First element at index 1",
    "C) No indexing",
    "D) Negative indexing"
  ],
  "correct_answer": "A) First element at index 0",
  "explanation": "Zero-based indexing means the first element is at position 0, common in most programming languages."
}'),
                                         (13, '{
  "question": "What is array out of bounds error?",
  "options": [
    "A) Accessing invalid index",
    "B) Array too large",
    "C) Array too small",
    "D) Memory error"
  ],
  "correct_answer": "A) Accessing invalid index",
  "explanation": "This error occurs when trying to access an array element with an index outside valid range."
}'),
                                         (13, '{
  "question": "What are multidimensional arrays?",
  "options": [
    "A) Arrays with multiple dimensions",
    "B) Single dimension arrays",
    "C) Dynamic arrays",
    "D) Sorted arrays"
  ],
  "correct_answer": "A) Arrays with multiple dimensions",
  "explanation": "Multidimensional arrays have rows and columns, like matrices (2D) or cubes (3D)."
}'),
                                         (13, '{
  "question": "What is list comprehension in Python?",
  "options": [
    "A) Concise way to create lists",
    "B) List documentation",
    "C) List sorting",
    "D) List iteration"
  ],
  "correct_answer": "A) Concise way to create lists",
  "explanation": "List comprehension provides a compact way to create lists based on existing lists with conditions."
}'),
                                         (13, '{
  "question": "What is the time complexity of array access?",
  "options": [
    "A) O(1)",
    "B) O(n)",
    "C) O(log n)",
    "D) O(n²)"
  ],
  "correct_answer": "A) O(1)",
  "explanation": "Array access by index is constant time O(1) due to direct memory addressing."
}'),
                                         (13, '{
  "question": "What are dynamic arrays?",
  "options": [
    "A) Arrays that resize automatically",
    "B) Fixed size arrays",
    "C) Static arrays",
    "D) Read-only arrays"
  ],
  "correct_answer": "A) Arrays that resize automatically",
  "explanation": "Dynamic arrays automatically grow when needed and shrink when possible."
}'),
                                         (13, '{
  "question": "What is the difference between ArrayList and array in Java?",
  "options": [
    "A) ArrayList dynamic, array fixed size",
    "B) Array dynamic, ArrayList fixed size",
    "C) Both are same",
    "D) ArrayList is primitive"
  ],
  "correct_answer": "A) ArrayList dynamic, array fixed size",
  "explanation": "ArrayList is a resizable array implementation while basic arrays have fixed size."
}'),
                                         (13, '{
  "question": "What is negative indexing in Python?",
  "options": [
    "A) Access elements from end",
    "B) Invalid indexing",
    "C) Zero indexing",
    "D) Positive indexing"
  ],
  "correct_answer": "A) Access elements from end",
  "explanation": "Negative indices in Python count backwards from the end (-1 is last element)."
}'),
                                         (13, '{
  "question": "What are jagged arrays?",
  "options": [
    "A) Arrays with different row lengths",
    "B) Regular arrays",
    "C) Sorted arrays",
    "D) Single dimension arrays"
  ],
  "correct_answer": "A) Arrays with different row lengths",
  "explanation": "Jagged arrays are arrays of arrays where each sub-array can have different lengths."
}');

-- Continue with topics 14-18...
-- MCQs for Topic 14: Sets and Unique Collections (topic_id: 14)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (14, '{
  "question": "What is the main characteristic of a set?",
  "options": [
    "A) Contains unique elements",
    "B) Maintains insertion order",
    "C) Allows duplicates",
    "D) Indexed access"
  ],
  "correct_answer": "A) Contains unique elements",
  "explanation": "Sets automatically eliminate duplicate elements and only store unique values."
}'),
                                         (14, '{
  "question": "What are the main set operations?",
  "options": [
    "A) Union, intersection, difference",
    "B) Add, remove, get",
    "C) Sort, reverse, shuffle",
    "D) Map, filter, reduce"
  ],
  "correct_answer": "A) Union, intersection, difference",
  "explanation": "Basic set operations include union (combine), intersection (common), and difference (unique to first)."
}'),
                                         (14, '{
  "question": "What is a HashSet?",
  "options": [
    "A) Set implementation using hash table",
    "B) Sorted set",
    "C) Linked set",
    "D) Array-based set"
  ],
  "correct_answer": "A) Set implementation using hash table",
  "explanation": "HashSet uses hashing for fast operations but doesn''t maintain order."
}'),
                                         (14, '{
  "question": "What is a TreeSet?",
  "options": [
    "A) Sorted set implementation",
    "B) Hash-based set",
    "C) Linked set",
    "D) Unsorted set"
  ],
  "correct_answer": "A) Sorted set implementation",
  "explanation": "TreeSet maintains elements in sorted order using a tree structure."
}'),
                                         (14, '{
  "question": "What is set comprehension in Python?",
  "options": [
    "A) Concise way to create sets",
    "B) Set documentation",
    "C) Set sorting",
    "D) Set iteration"
  ],
  "correct_answer": "A) Concise way to create sets",
  "explanation": "Set comprehension provides compact syntax for creating sets from iterables."
}'),
                                         (14, '{
  "question": "What is the time complexity of set membership test?",
  "options": [
    "A) O(1) average case",
    "B) O(n)",
    "C) O(log n)",
    "D) O(n²)"
  ],
  "correct_answer": "A) O(1) average case",
  "explanation": "Hash-based sets provide O(1) average case for membership testing (contains operation)."
}'),
                                         (14, '{
  "question": "What is a frozen set?",
  "options": [
    "A) Immutable set",
    "B) Mutable set",
    "C) Sorted set",
    "D) Empty set"
  ],
  "correct_answer": "A) Immutable set",
  "explanation": "Frozen sets are immutable versions of sets that cannot be modified after creation."
}'),
                                         (14, '{
  "question": "What is the difference between set and list?",
  "options": [
    "A) Set unique, list allows duplicates",
    "B) List unique, set allows duplicates",
    "C) Both are same",
    "D) Set ordered, list unordered"
  ],
  "correct_answer": "A) Set unique, list allows duplicates",
  "explanation": "Sets enforce uniqueness while lists allow duplicate elements and maintain order."
}'),
                                         (14, '{
  "question": "What is symmetric difference?",
  "options": [
    "A) Elements in either set but not both",
    "B) Common elements",
    "C) All elements combined",
    "D) Elements only in first set"
  ],
  "correct_answer": "A) Elements in either set but not both",
  "explanation": "Symmetric difference returns elements that are in either set but not in their intersection."
}'),
                                         (14, '{
  "question": "What are the main uses of sets?",
  "options": [
    "A) Remove duplicates, membership testing",
    "B) Sorting elements",
    "C) Maintaining order",
    "D) Indexed access"
  ],
  "correct_answer": "A) Remove duplicates, membership testing",
  "explanation": "Sets are primarily used for eliminating duplicates and fast membership checking."
}');

-- MCQs for Topic 15: Maps and Dictionaries (topic_id: 15)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (15, '{
  "question": "What is a dictionary/map?",
  "options": [
    "A) Key-value pair collection",
    "B) Ordered collection",
    "C) Unique value collection",
    "D) Indexed collection"
  ],
  "correct_answer": "A) Key-value pair collection",
  "explanation": "Dictionaries store data as key-value pairs where each key maps to a value."
}'),
                                         (15, '{
  "question": "What are the characteristics of dictionary keys?",
  "options": [
    "A) Must be unique and immutable",
    "B) Can be duplicate and mutable",
    "C) Must be numbers only",
    "D) Can be any type"
  ],
  "correct_answer": "A) Must be unique and immutable",
  "explanation": "Dictionary keys must be unique and typically immutable (strings, numbers, tuples)."
}'),
                                         (15, '{
  "question": "What is a HashMap?",
  "options": [
    "A) Hash table based map",
    "B) Sorted map",
    "C) Linked map",
    "D) Array-based map"
  ],
  "correct_answer": "A) Hash table based map",
  "explanation": "HashMap uses hashing for fast key lookups but doesn''t maintain order."
}'),
                                         (15, '{
  "question": "What is a TreeMap?",
  "options": [
    "A) Sorted map implementation",
    "B) Hash-based map",
    "C) Linked map",
    "D) Unsorted map"
  ],
  "correct_answer": "A) Sorted map implementation",
  "explanation": "TreeMap maintains keys in sorted order using a tree structure."
}'),
                                         (15, '{
  "question": "What is dictionary comprehension in Python?",
  "options": [
    "A) Concise way to create dictionaries",
    "B) Dictionary documentation",
    "C) Dictionary sorting",
    "D) Dictionary iteration"
  ],
  "correct_answer": "A) Concise way to create dictionaries",
  "explanation": "Dictionary comprehension provides compact syntax for creating dictionaries from iterables."
}'),
                                         (15, '{
  "question": "What is the time complexity of dictionary lookups?",
  "options": [
    "A) O(1) average case",
    "B) O(n)",
    "C) O(log n)",
    "D) O(n²)"
  ],
  "correct_answer": "A) O(1) average case",
  "explanation": "Hash-based dictionaries provide O(1) average case for get and put operations."
}'),
                                         (15, '{
  "question": "What is the difference between Map and Object in JavaScript?",
  "options": [
    "A) Map preserves insertion order, any keys",
    "B) Object preserves order, Map doesn''t",
    "C) Both are same",
    "D) Map only for strings"
  ],
  "correct_answer": "A) Map preserves insertion order, any keys",
  "explanation": "Map maintains insertion order and allows any data type as keys, while Object doesn''t guarantee order."
}'),
                                         (15, '{
  "question": "What are default dictionaries?",
  "options": [
    "A) Dictionaries with default values",
    "B) Empty dictionaries",
    "C) Sorted dictionaries",
    "D) Immutable dictionaries"
  ],
  "correct_answer": "A) Dictionaries with default values",
  "explanation": "Default dictionaries provide default values for missing keys to avoid KeyError."
}'),
                                         (15, '{
  "question": "What is dictionary merging?",
  "options": [
    "A) Combining multiple dictionaries",
    "B) Sorting dictionaries",
    "C) Filtering dictionaries",
    "D) Copying dictionaries"
  ],
  "correct_answer": "A) Combining multiple dictionaries",
  "explanation": "Dictionary merging combines key-value pairs from multiple dictionaries into one."
}'),
                                         (15, '{
  "question": "What are ordered dictionaries?",
  "options": [
    "A) Dictionaries that maintain insertion order",
    "B) Sorted dictionaries",
    "C) Hash dictionaries",
    "D) Default dictionaries"
  ],
  "correct_answer": "A) Dictionaries that maintain insertion order",
  "explanation": "Ordered dictionaries remember the order in which items were inserted."
}');

-- MCQs for Topic 16: Collection Operations and Iteration (topic_id: 16)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (16, '{
  "question": "What are the main collection operations?",
  "options": [
    "A) Filter, map, reduce",
    "B) Add, remove, contains",
    "C) Sort, reverse, shuffle",
    "D) All of the above"
  ],
  "correct_answer": "D) All of the above",
  "explanation": "Collection operations include functional operations (filter/map/reduce) and basic CRUD operations."
}'),
                                         (16, '{
  "question": "What is the purpose of filter()?",
  "options": [
    "A) Select elements matching condition",
    "B) Transform elements",
    "C) Combine elements",
    "D) Sort elements"
  ],
  "correct_answer": "A) Select elements matching condition",
  "explanation": "filter() creates a new collection with elements that satisfy a given condition."
}'),
                                         (16, '{
  "question": "What does map() do?",
  "options": [
    "A) Transform each element",
    "B) Filter elements",
    "C) Sort elements",
    "D) Combine elements"
  ],
  "correct_answer": "A) Transform each element",
  "explanation": "map() applies a function to each element and returns a new collection with transformed values."
}'),
                                         (16, '{
  "question": "What is reduce() used for?",
  "options": [
    "A) Combine elements into single value",
    "B) Filter elements",
    "C) Transform elements",
    "D) Sort elements"
  ],
  "correct_answer": "A) Combine elements into single value",
  "explanation": "reduce() accumulates values by applying a function repeatedly to combine elements into a single result."
}'),
                                         (16, '{
  "question": "What are iterators?",
  "options": [
    "A) Objects for traversing collections",
    "B) Collection types",
    "C) Data structures",
    "D) Algorithms"
  ],
  "correct_answer": "A) Objects for traversing collections",
  "explanation": "Iterators provide a way to access elements of a collection sequentially without exposing its underlying structure."
}'),
                                         (16, '{
  "question": "What is the difference between iterator and iterable?",
  "options": [
    "A) Iterable can create iterator",
    "B) Iterator can create iterable",
    "C) Both are same",
    "D) Iterator is collection"
  ],
  "correct_answer": "A) Iterable can create iterator",
  "explanation": "Iterable is an object that can return an iterator, while iterator is the object used for traversal."
}'),
                                         (16, '{
  "question": "What are generator expressions?",
  "options": [
    "A) Lazy evaluation of sequences",
    "B) Fast execution",
    "C) Memory intensive",
    "D) Eager evaluation"
  ],
  "correct_answer": "A) Lazy evaluation of sequences",
  "explanation": "Generator expressions create iterators that generate values on-the-fly, saving memory."
}'),
                                         (16, '{
  "question": "What is the purpose of sorted()?",
  "options": [
    "A) Return new sorted collection",
    "B) Sort in-place",
    "C) Filter elements",
    "D) Transform elements"
  ],
  "correct_answer": "A) Return new sorted collection",
  "explanation": "sorted() returns a new sorted list from the elements of any iterable, leaving original unchanged."
}'),
                                         (16, '{
  "question": "What are collection streams?",
  "options": [
    "A) Functional-style operations on collections",
    "B) Data streams",
    "C) File streams",
    "D) Network streams"
  ],
  "correct_answer": "A) Functional-style operations on collections",
  "explanation": "Streams enable functional programming operations (map, filter, reduce) on collections with lazy evaluation."
}'),
                                         (16, '{
  "question": "What is parallel stream processing?",
  "options": [
    "A) Process collection elements concurrently",
    "B) Sequential processing",
    "C) Single-threaded processing",
    "D) Manual processing"
  ],
  "correct_answer": "A) Process collection elements concurrently",
  "explanation": "Parallel streams split collection processing across multiple threads for better performance on multi-core systems."
}');

-- MCQs for Topic 17: Class Declaration and Object Creation (topic_id: 17)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (17, '{
  "question": "What is a class?",
  "options": [
    "A) Blueprint for creating objects",
    "B) Instance of object",
    "C) Method collection",
    "D) Variable container"
  ],
  "correct_answer": "A) Blueprint for creating objects",
  "explanation": "A class defines the properties and behaviors that objects of that type will have."
}'),
                                         (17, '{
  "question": "What is an object?",
  "options": [
    "A) Instance of a class",
    "B) Blueprint",
    "C) Method",
    "D) Variable"
  ],
  "correct_answer": "A) Instance of a class",
  "explanation": "An object is a concrete instance created from a class blueprint."
}'),
                                         (17, '{
  "question": "What is instantiation?",
  "options": [
    "A) Process of creating objects",
    "B) Method definition",
    "C) Class declaration",
    "D) Variable assignment"
  ],
  "correct_answer": "A) Process of creating objects",
  "explanation": "Instantiation is the process of creating an object instance from a class using the ''new'' keyword."
}'),
                                         (17, '{
  "question": "What are instance variables?",
  "options": [
    "A) Variables unique to each object",
    "B) Shared variables",
    "C) Local variables",
    "D) Global variables"
  ],
  "correct_answer": "A) Variables unique to each object",
  "explanation": "Instance variables store data that is unique to each object instance."
}'),
                                         (17, '{
  "question": "What are class variables?",
  "options": [
    "A) Variables shared by all instances",
    "B) Instance-specific variables",
    "C) Local variables",
    "D) Temporary variables"
  ],
  "correct_answer": "A) Variables shared by all instances",
  "explanation": "Class variables (static) are shared across all instances of a class."
}'),
                                         (17, '{
  "question": "What is the ''new'' keyword used for?",
  "options": [
    "A) Create new object instance",
    "B) Define new class",
    "C) Create new variable",
    "D) Import new module"
  ],
  "correct_answer": "A) Create new object instance",
  "explanation": "The ''new'' keyword allocates memory and creates a new object instance from a class."
}'),
                                         (17, '{
  "question": "What is the difference between class and object?",
  "options": [
    "A) Class is blueprint, object is instance",
    "B) Object is blueprint, class is instance",
    "C) Both are same",
    "D) Class is runtime, object is compile time"
  ],
  "correct_answer": "A) Class is blueprint, object is instance",
  "explanation": "Class defines structure and behavior, while object is a concrete entity with actual data."
}'),
                                         (17, '{
  "question": "What are access modifiers?",
  "options": [
    "A) Control visibility of class members",
    "B) Method parameters",
    "C) Return types",
    "D) Variable types"
  ],
  "correct_answer": "A) Control visibility of class members",
  "explanation": "Access modifiers (public, private, protected) control which parts of code can access class members."
}'),
                                         (17, '{
  "question": "What is the purpose of ''this'' keyword?",
  "options": [
    "A) Refer to current object instance",
    "B) Refer to parent class",
    "C) Refer to child class",
    "D) Refer to static context"
  ],
  "correct_answer": "A) Refer to current object instance",
  "explanation": "''this'' refers to the current object instance within instance methods and constructors."
}'),
                                         (17, '{
  "question": "What are getters and setters?",
  "options": [
    "A) Methods to access private fields",
    "B) Constructor methods",
    "C) Static methods",
    "D) Main methods"
  ],
  "correct_answer": "A) Methods to access private fields",
  "explanation": "Getters and setters provide controlled access to private instance variables (encapsulation)."
}');

-- MCQs for Topic 18: Constructors and Initialization (topic_id: 18)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (18, '{
  "question": "What is a constructor?",
  "options": [
    "A) Special method for object initialization",
    "B) Regular method",
    "C) Static method",
    "D) Main method"
  ],
  "correct_answer": "A) Special method for object initialization",
  "explanation": "Constructors are special methods called when objects are created to initialize instance variables."
}'),
                                         (18, '{
  "question": "What is constructor overloading?",
  "options": [
    "A) Multiple constructors with different parameters",
    "B) Single constructor",
    "C) Constructor with same parameters",
    "D) No constructor"
  ],
  "correct_answer": "A) Multiple constructors with different parameters",
  "explanation": "Constructor overloading allows a class to have multiple constructors with different parameter lists."
}'),
                                         (18, '{
  "question": "What is the default constructor?",
  "options": [
    "A) No-argument constructor",
    "B) Constructor with parameters",
    "C) Private constructor",
    "D) Static constructor"
  ],
  "correct_answer": "A) No-argument constructor",
  "explanation": "Default constructor takes no arguments and is provided automatically if no constructors are defined."
}'),
                                         (18, '{
  "question": "What is constructor chaining?",
  "options": [
    "A) Calling one constructor from another",
    "B) Multiple objects creation",
    "C) Constructor overloading",
    "D) Constructor overriding"
  ],
  "correct_answer": "A) Calling one constructor from another",
  "explanation": "Constructor chaining occurs when one constructor calls another constructor in the same class or parent class."
}'),
                                         (18, '{
  "question": "What is the purpose of ''super()'' in constructors?",
  "options": [
    "A) Call parent class constructor",
    "B) Call same class constructor",
    "C) Call child class constructor",
    "D) Call static method"
  ],
  "correct_answer": "A) Call parent class constructor",
  "explanation": "super() calls the parent class constructor, typically as the first statement in child class constructor."
}'),
                                         (18, '{
  "question": "What are copy constructors?",
  "options": [
    "A) Create object from existing object",
    "B) Create empty object",
    "C) Create multiple objects",
    "D) Create static objects"
  ],
  "correct_answer": "A) Create object from existing object",
  "explanation": "Copy constructors create a new object as a copy of an existing object of the same class."
}'),
                                         (18, '{
  "question": "What is static initialization block?",
  "options": [
    "A) Code that runs when class is loaded",
    "B) Constructor code",
    "C) Method code",
    "D) Variable declaration"
  ],
  "correct_answer": "A) Code that runs when class is loaded",
  "explanation": "Static initialization blocks execute when the class is first loaded, before any objects are created."
}'),
                                         (18, '{
  "question": "What is instance initialization block?",
  "options": [
    "A) Code that runs before every constructor",
    "B) Static code",
    "C) Method code",
    "D) Class code"
  ],
  "correct_answer": "A) Code that runs before every constructor",
  "explanation": "Instance initialization blocks execute before constructors when objects are created."
}'),
                                         (18, '{
  "question": "What is the order of initialization?",
  "options": [
    "A) Static → instance → constructor",
    "B) Constructor → instance → static",
    "C) Instance → static → constructor",
    "D) Static → constructor → instance"
  ],
  "correct_answer": "A) Static → instance → constructor",
  "explanation": "Static blocks run first, then instance blocks, then constructors when creating objects."
}'),
                                         (18, '{
  "question": "What are private constructors used for?",
  "options": [
    "A) Prevent instantiation, singleton pattern",
    "B) Public instantiation",
    "C) Multiple instantiation",
    "D) Fast instantiation"
  ],
  "correct_answer": "A) Prevent instantiation, singleton pattern",
  "explanation": "Private constructors prevent external instantiation and are used in singleton pattern and utility classes."
}');
-- MCQs for Topic 19: Encapsulation and Access Modifiers (topic_id: 19)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (19, '{
  "question": "What is encapsulation?",
  "options": [
    "A) Bundling data with methods",
    "B) Hiding implementation details",
    "C) Both A and B",
    "D) Inheriting from parent class"
  ],
  "correct_answer": "C) Both A and B",
  "explanation": "Encapsulation bundles data with methods that operate on that data and hides internal implementation details."
}'),
                                         (19, '{
  "question": "What is the purpose of access modifiers?",
  "options": [
    "A) Control visibility of class members",
    "B) Improve performance",
    "C) Add security",
    "D) All of the above"
  ],
  "correct_answer": "A) Control visibility of class members",
  "explanation": "Access modifiers control which parts of code can access class members (public, private, protected)."
}'),
                                         (19, '{
  "question": "What does ''private'' access modifier do?",
  "options": [
    "A) Access only within same class",
    "B) Access from anywhere",
    "C) Access within package",
    "D) Access by subclasses"
  ],
  "correct_answer": "A) Access only within same class",
  "explanation": "Private members are accessible only within the same class where they are declared."
}'),
                                         (19, '{
  "question": "What is the difference between private and protected?",
  "options": [
    "A) Protected allows subclass access",
    "B) Private allows subclass access",
    "C) Both are same",
    "D) Protected is more restrictive"
  ],
  "correct_answer": "A) Protected allows subclass access",
  "explanation": "Protected members are accessible within same package and by subclasses, while private is class-only."
}'),
                                         (19, '{
  "question": "What are getters and setters?",
  "options": [
    "A) Methods to access private fields",
    "B) Constructor methods",
    "C) Static methods",
    "D) Utility methods"
  ],
  "correct_answer": "A) Methods to access private fields",
  "explanation": "Getters (accessors) and setters (mutators) provide controlled access to private instance variables."
}'),
                                         (19, '{
  "question": "What is data hiding?",
  "options": [
    "A) Making fields private",
    "B) Making methods public",
    "C) Using global variables",
    "D) Using static variables"
  ],
  "correct_answer": "A) Making fields private",
  "explanation": "Data hiding involves making instance variables private and providing public methods to access them."
}'),
                                         (19, '{
  "question": "What is the benefit of encapsulation?",
  "options": [
    "A) Maintainability and flexibility",
    "B) Faster execution",
    "C) Smaller code size",
    "D) Easier debugging"
  ],
  "correct_answer": "A) Maintainability and flexibility",
  "explanation": "Encapsulation makes code more maintainable and flexible by hiding implementation details."
}'),
                                         (19, '{
  "question": "What are JavaBeans naming conventions?",
  "options": [
    "A) getXxx(), setXxx() for accessors",
    "B) get_xxx(), set_xxx()",
    "C) get(), set()",
    "D) retrieveXxx(), updateXxx()"
  ],
  "correct_answer": "A) getXxx(), setXxx() for accessors",
  "explanation": "JavaBeans convention uses getProperty() and setProperty() for accessor methods."
}'),
                                         (19, '{
  "question": "What is package-private access?",
  "options": [
    "A) Default access within package",
    "B) Public access",
    "C) Private access",
    "D) Protected access"
  ],
  "correct_answer": "A) Default access within package",
  "explanation": "Package-private (default) access allows members to be accessed only by classes in the same package."
}'),
                                         (19, '{
  "question": "Why use private constructors?",
  "options": [
    "A) Prevent object creation",
    "B) Allow multiple instances",
    "C) Improve performance",
    "D) Reduce memory usage"
  ],
  "correct_answer": "A) Prevent object creation",
  "explanation": "Private constructors prevent instantiation of a class, useful for utility classes and singletons."
}');

-- MCQs for Topic 20: Methods and Instance Variables (topic_id: 20)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (20, '{
  "question": "What are instance methods?",
  "options": [
    "A) Methods that operate on instance data",
    "B) Static methods",
    "C) Class methods",
    "D) Utility methods"
  ],
  "correct_answer": "A) Methods that operate on instance data",
  "explanation": "Instance methods belong to objects and can access instance variables using ''this''."
}'),
                                         (20, '{
  "question": "What is method signature?",
  "options": [
    "A) Method name and parameters",
    "B) Return type only",
    "C) Method body",
    "D) Access modifier"
  ],
  "correct_answer": "A) Method name and parameters",
  "explanation": "Method signature includes method name and parameter types (not return type or exceptions)."
}'),
                                         (20, '{
  "question": "What is method overloading?",
  "options": [
    "A) Same name, different parameters",
    "B) Different name, same parameters",
    "C) Same name, same parameters",
    "D) Different name, different parameters"
  ],
  "correct_answer": "A) Same name, different parameters",
  "explanation": "Method overloading allows multiple methods with same name but different parameter lists."
}'),
                                         (20, '{
  "question": "What are static methods?",
  "options": [
    "A) Methods that belong to class",
    "B) Methods that belong to objects",
    "C) Instance methods",
    "D) Constructor methods"
  ],
  "correct_answer": "A) Methods that belong to class",
  "explanation": "Static methods belong to the class rather than objects and can be called without instantiation."
}'),
                                         (20, '{
  "question": "What is the ''this'' keyword used for?",
  "options": [
    "A) Refer to current object",
    "B) Refer to parent object",
    "C) Refer to child object",
    "D) Refer to static context"
  ],
  "correct_answer": "A) Refer to current object",
  "explanation": "''this'' refers to the current object instance within instance methods and constructors."
}'),
                                         (20, '{
  "question": "What are void methods?",
  "options": [
    "A) Methods that don''t return value",
    "B) Methods that return value",
    "C) Constructor methods",
    "D) Static methods"
  ],
  "correct_answer": "A) Methods that don''t return value",
  "explanation": "Void methods perform actions but don''t return any value to the caller."
}'),
                                         (20, '{
  "question": "What is method chaining?",
  "options": [
    "A) Calling multiple methods in sequence",
    "B) Method overloading",
    "C) Method overriding",
    "D) Recursive methods"
  ],
  "correct_answer": "A) Calling multiple methods in sequence",
  "explanation": "Method chaining allows calling multiple methods on the same object in a single statement."
}'),
                                         (20, '{
  "question": "What are accessor methods?",
  "options": [
    "A) Getters that return field values",
    "B) Setters that modify fields",
    "C) Constructor methods",
    "D) Static methods"
  ],
  "correct_answer": "A) Getters that return field values",
  "explanation": "Accessor methods (getters) return the value of private fields without modifying them."
}'),
                                         (20, '{
  "question": "What are mutator methods?",
  "options": [
    "A) Setters that modify field values",
    "B) Getters that return values",
    "C) Constructor methods",
    "D) Utility methods"
  ],
  "correct_answer": "A) Setters that modify field values",
  "explanation": "Mutator methods (setters) modify the value of private fields with validation if needed."
}'),
                                         (20, '{
  "question": "What is the difference between instance and static methods?",
  "options": [
    "A) Instance methods need object, static don''t",
    "B) Static methods need object, instance don''t",
    "C) Both need objects",
    "D) Neither needs objects"
  ],
  "correct_answer": "A) Instance methods need object, static don''t",
  "explanation": "Instance methods require object instantiation, while static methods can be called using class name."
}');

-- MCQs for Topic 21: Try-Catch-Finally Blocks (topic_id: 21)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (21, '{
  "question": "What is exception handling?",
  "options": [
    "A) Managing runtime errors gracefully",
    "B) Preventing all errors",
    "C) Ignoring errors",
    "D) Logging only"
  ],
  "correct_answer": "A) Managing runtime errors gracefully",
  "explanation": "Exception handling allows programs to deal with unexpected situations without crashing."
}'),
                                         (21, '{
  "question": "What is the purpose of try block?",
  "options": [
    "A) Code that might throw exceptions",
    "B) Code that handles exceptions",
    "C) Code that always executes",
    "D) Code that never executes"
  ],
  "correct_answer": "A) Code that might throw exceptions",
  "explanation": "The try block contains code that might generate exceptions during execution."
}'),
                                         (21, '{
  "question": "What does catch block do?",
  "options": [
    "A) Handles specific exceptions",
    "B) Throws exceptions",
    "C) Prevents exceptions",
    "D) Ignores exceptions"
  ],
  "correct_answer": "A) Handles specific exceptions",
  "explanation": "Catch blocks handle specific types of exceptions thrown in the try block."
}'),
                                         (21, '{
  "question": "What is the purpose of finally block?",
  "options": [
    "A) Code that always executes",
    "B) Code that handles exceptions",
    "C) Code that might throw exceptions",
    "D) Code that never executes"
  ],
  "correct_answer": "A) Code that always executes",
  "explanation": "Finally block always executes regardless of whether an exception occurred or was caught."
}'),
                                         (21, '{
  "question": "What is exception propagation?",
  "options": [
    "A) Exception moving up call stack",
    "B) Exception catching",
    "C) Exception ignoring",
    "D) Exception logging"
  ],
  "correct_answer": "A) Exception moving up call stack",
  "explanation": "Exception propagation occurs when an exception is not caught and moves up through method calls."
}'),
                                         (21, '{
  "question": "What are checked exceptions?",
  "options": [
    "A) Exceptions checked at compile time",
    "B) Runtime exceptions",
    "C) Errors",
    "D) All exceptions"
  ],
  "correct_answer": "A) Exceptions checked at compile time",
  "explanation": "Checked exceptions must be declared in method signature or handled, enforced at compile time."
}'),
                                         (21, '{
  "question": "What are unchecked exceptions?",
  "options": [
    "A) Runtime exceptions",
    "B) Checked exceptions",
    "C) Compile-time exceptions",
    "D) All exceptions"
  ],
  "correct_answer": "A) Runtime exceptions",
  "explanation": "Unchecked exceptions (RuntimeException and its subclasses) are not checked at compile time."
}'),
                                         (21, '{
  "question": "What is the difference between throw and throws?",
  "options": [
    "A) throw used in code, throws in declaration",
    "B) throws used in code, throw in declaration",
    "C) Both are same",
    "D) Both used in declaration"
  ],
  "correct_answer": "A) throw used in code, throws in declaration",
  "explanation": "throw is used to throw an exception in code, while throws declares exceptions in method signature."
}'),
                                         (21, '{
  "question": "What is multiple catch blocks?",
  "options": [
    "A) Handling different exception types",
    "B) Handling same exception multiple times",
    "C) Ignoring exceptions",
    "D) Throwing multiple exceptions"
  ],
  "correct_answer": "A) Handling different exception types",
  "explanation": "Multiple catch blocks allow handling different types of exceptions with specific handling for each."
}'),
                                         (21, '{
  "question": "What is try-with-resources?",
  "options": [
    "A) Automatic resource management",
    "B) Manual resource management",
    "C) Exception throwing",
    "D) Resource creation"
  ],
  "correct_answer": "A) Automatic resource management",
  "explanation": "Try-with-resources automatically closes resources like files and database connections."
}');

-- MCQs for Topic 22: Exception Types and Hierarchy (topic_id: 22)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (22, '{
  "question": "What is the root class of exception hierarchy?",
  "options": [
    "A) Throwable",
    "B) Exception",
    "C) Error",
    "D) RuntimeException"
  ],
  "correct_answer": "A) Throwable",
  "explanation": "Throwable is the root class of all exception and error types in Java."
}'),
                                         (22, '{
  "question": "What is the difference between Exception and Error?",
  "options": [
    "A) Exception recoverable, Error usually not",
    "B) Error recoverable, Exception not",
    "C) Both are same",
    "D) Both unrecoverable"
  ],
  "correct_answer": "A) Exception recoverable, Error usually not",
  "explanation": "Exceptions are conditions that can be recovered from, while Errors indicate serious system problems."
}'),
                                         (22, '{
  "question": "What are runtime exceptions?",
  "options": [
    "A) Unchecked exceptions",
    "B) Checked exceptions",
    "C) Compile-time exceptions",
    "D) All exceptions"
  ],
  "correct_answer": "A) Unchecked exceptions",
  "explanation": "Runtime exceptions (unchecked) don''t need to be declared or caught at compile time."
}'),
                                         (22, '{
  "question": "What is NullPointerException?",
  "options": [
    "A) Accessing null object reference",
    "B) Array index out of bounds",
    "C) Division by zero",
    "D) File not found"
  ],
  "correct_answer": "A) Accessing null object reference",
  "explanation": "NullPointerException occurs when trying to use an object reference that points to null."
}'),
                                         (22, '{
  "question": "What is ArrayIndexOutOfBoundsException?",
  "options": [
    "A) Invalid array index access",
    "B) Null array access",
    "C) Array size zero",
    "D) Array creation error"
  ],
  "correct_answer": "A) Invalid array index access",
  "explanation": "This exception occurs when accessing an array with an index that is negative or too large."
}'),
                                         (22, '{
  "question": "What is IOException?",
  "options": [
    "A) Input/output operation failure",
    "B) Arithmetic error",
    "C) Memory error",
    "D) Network error"
  ],
  "correct_answer": "A) Input/output operation failure",
  "explanation": "IOException indicates failures in input/output operations like file reading/writing."
}'),
                                         (22, '{
  "question": "What is ClassCastException?",
  "options": [
    "A) Invalid type casting",
    "B) Class not found",
    "C) Method not found",
    "D) Field not found"
  ],
  "correct_answer": "A) Invalid type casting",
  "explanation": "ClassCastException occurs when trying to cast an object to a type it doesn''t inherit from."
}'),
                                         (22, '{
  "question": "What is IllegalArgumentException?",
  "options": [
    "A) Invalid method argument",
    "B) Invalid return value",
    "C) Invalid class name",
    "D) Invalid package"
  ],
  "correct_answer": "A) Invalid method argument",
  "explanation": "IllegalArgumentException indicates that a method received an illegal or inappropriate argument."
}'),
                                         (22, '{
  "question": "What is the exception hierarchy order?",
  "options": [
    "A) Throwable → Exception → RuntimeException",
    "B) Exception → Throwable → RuntimeException",
    "C) RuntimeException → Exception → Throwable",
    "D) Throwable → RuntimeException → Exception"
  ],
  "correct_answer": "A) Throwable → Exception → RuntimeException",
  "explanation": "The hierarchy is: Throwable (root) → Exception (checked) → RuntimeException (unchecked)."
}'),
                                         (22, '{
  "question": "What are custom exceptions?",
  "options": [
    "A) User-defined exception classes",
    "B) Built-in exceptions",
    "C) Runtime exceptions",
    "D) System errors"
  ],
  "correct_answer": "A) User-defined exception classes",
  "explanation": "Custom exceptions are user-created exception classes that extend Exception or RuntimeException."
}');

-- MCQs for Topic 23: Throwing and Creating Custom Exceptions (topic_id: 23)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (23, '{
  "question": "How to create custom exception?",
  "options": [
    "A) Extend Exception or RuntimeException",
    "B) Implement Throwable",
    "C) Extend Error",
    "D) Implement Serializable"
  ],
  "correct_answer": "A) Extend Exception or RuntimeException",
  "explanation": "Custom exceptions are created by extending either Exception (checked) or RuntimeException (unchecked)."
}'),
                                         (23, '{
  "question": "What is the purpose of custom exceptions?",
  "options": [
    "A) Application-specific error handling",
    "B) Better performance",
    "C) Smaller code",
    "D) Faster execution"
  ],
  "correct_answer": "A) Application-specific error handling",
  "explanation": "Custom exceptions represent application-specific error conditions with meaningful names and additional data."
}'),
                                         (23, '{
  "question": "How to throw an exception?",
  "options": [
    "A) throw new ExceptionType()",
    "B) throws new ExceptionType()",
    "C) throw ExceptionType()",
    "D) throws ExceptionType()"
  ],
  "correct_answer": "A) throw new ExceptionType()",
  "explanation": "Use ''throw'' keyword followed by ''new'' and exception constructor to throw an exception."
}'),
                                         (23, '{
  "question": "What is exception chaining?",
  "options": [
    "A) Wrapping one exception in another",
    "B) Multiple exceptions",
    "C) Exception inheritance",
    "D) Exception hierarchy"
  ],
  "correct_answer": "A) Wrapping one exception in another",
  "explanation": "Exception chaining preserves the original exception when throwing a new one, maintaining the cause."
}'),
                                         (23, '{
  "question": "What is the purpose of getCause() method?",
  "options": [
    "A) Get original exception in chaining",
    "B) Get exception message",
    "C) Get stack trace",
    "D) Get exception type"
  ],
  "correct_answer": "A) Get original exception in chaining",
  "explanation": "getCause() returns the original exception that caused the current exception in chained exceptions."
}'),
                                         (23, '{
  "question": "When to use checked vs unchecked custom exceptions?",
  "options": [
    "A) Checked for recoverable, unchecked for programming errors",
    "B) Unchecked for recoverable, checked for programming errors",
    "C) Always use checked",
    "D) Always use unchecked"
  ],
  "correct_answer": "A) Checked for recoverable, unchecked for programming errors",
  "explanation": "Use checked exceptions for recoverable conditions and unchecked for programming errors that shouldn''t be caught."
}'),
                                         (23, '{
  "question": "What is the advantage of custom exceptions?",
  "options": [
    "A) Better error categorization and handling",
    "B) Faster execution",
    "C) Smaller memory footprint",
    "D) Automatic handling"
  ],
  "correct_answer": "A) Better error categorization and handling",
  "explanation": "Custom exceptions provide meaningful names and can carry additional error information."
}'),
                                         (23, '{
  "question": "How to add custom data to exceptions?",
  "options": [
    "A) Add fields and constructor parameters",
    "B) Use global variables",
    "C) Use static fields",
    "D) Use system properties"
  ],
  "correct_answer": "A) Add fields and constructor parameters",
  "explanation": "Add instance variables and constructor parameters to custom exception classes to carry additional data."
}'),
                                         (23, '{
  "question": "What is best practice for exception messages?",
  "options": [
    "A) Clear, descriptive, and actionable",
    "B) Short and cryptic",
    "C) Technical details only",
    "D) No messages"
  ],
  "correct_answer": "A) Clear, descriptive, and actionable",
  "explanation": "Exception messages should clearly describe what went wrong and ideally suggest how to fix it."
}'),
                                         (23, '{
  "question": "What is exception wrapping?",
  "options": [
    "A) Converting one exception type to another",
    "B) Ignoring exceptions",
    "C) Logging exceptions",
    "D) Preventing exceptions"
  ],
  "correct_answer": "A) Converting one exception type to another",
  "explanation": "Exception wrapping converts low-level exceptions to higher-level application-specific exceptions."
}');

-- MCQs for Topic 24: Best Practices and Error Recovery (topic_id: 24)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (24, '{
  "question": "What is defensive programming?",
  "options": [
    "A) Writing code to handle unexpected inputs",
    "B) Ignoring errors",
    "C) Using only try-catch",
    "D) Avoiding exceptions"
  ],
  "correct_answer": "A) Writing code to handle unexpected inputs",
  "explanation": "Defensive programming involves validating inputs and handling edge cases to prevent errors."
}'),
                                         (24, '{
  "question": "What is fail-fast principle?",
  "options": [
    "A) Fail immediately on invalid state",
    "B) Ignore errors",
    "C) Continue despite errors",
    "D) Log and continue"
  ],
  "correct_answer": "A) Fail immediately on invalid state",
  "explanation": "Fail-fast detects problems early and fails immediately rather than continuing with invalid state."
}'),
                                         (24, '{
  "question": "What is graceful degradation?",
  "options": [
    "A) System continues with reduced functionality",
    "B) System stops completely",
    "C) System ignores errors",
    "D) System restarts"
  ],
  "correct_answer": "A) System continues with reduced functionality",
  "explanation": "Graceful degradation allows systems to continue operating with limited functionality when errors occur."
}'),
                                         (24, '{
  "question": "What is circuit breaker pattern?",
  "options": [
    "A) Prevent cascading failures",
    "B) Improve performance",
    "C) Reduce memory usage",
    "D) Enhance security"
  ],
  "correct_answer": "A) Prevent cascading failures",
  "explanation": "Circuit breaker pattern stops calls to failing services to prevent system-wide failures."
}'),
                                         (24, '{
  "question": "What is retry pattern?",
  "options": [
    "A) Retry failed operations",
    "B) Ignore failures",
    "C) Log failures only",
    "D) Stop on first failure"
  ],
  "correct_answer": "A) Retry failed operations",
  "explanation": "Retry pattern automatically retries failed operations, often with exponential backoff."
}'),
                                         (24, '{
  "question": "What is the purpose of finally block?",
  "options": [
    "A) Cleanup resources",
    "B) Handle exceptions",
    "C) Throw exceptions",
    "D) Prevent exceptions"
  ],
  "correct_answer": "A) Cleanup resources",
  "explanation": "Finally block is used for cleanup operations like closing files, database connections, etc."
}'),
                                         (24, '{
  "question": "What is exception swallowing?",
  "options": [
    "A) Catching and ignoring exceptions",
    "B) Throwing exceptions",
    "C) Logging exceptions",
    "D) Preventing exceptions"
  ],
  "correct_answer": "A) Catching and ignoring exceptions",
  "explanation": "Exception swallowing occurs when exceptions are caught but not handled properly, hiding problems."
}'),
                                         (24, '{
  "question": "What is the best practice for exception logging?",
  "options": [
    "A) Log with context and stack trace",
    "B) Don''t log exceptions",
    "C) Log only message",
    "D) Log to console only"
  ],
  "correct_answer": "A) Log with context and stack trace",
  "explanation": "Always log exceptions with sufficient context and stack trace for debugging."
}'),
                                         (24, '{
  "question": "What is the rule for catching exceptions?",
  "options": [
    "A) Catch specific exceptions first",
    "B) Catch general exceptions first",
    "C) Catch all exceptions together",
    "D) Don''t catch exceptions"
  ],
  "correct_answer": "A) Catch specific exceptions first",
  "explanation": "Catch more specific exception types before more general ones in multiple catch blocks."
}'),
                                         (24, '{
  "question": "What is error recovery strategy?",
  "options": [
    "A) Plan for handling failures",
    "B) Ignoring errors",
    "C) Preventing all errors",
    "D) Logging only"
  ],
  "correct_answer": "A) Plan for handling failures",
  "explanation": "Error recovery strategy defines how system recovers from different types of failures."
}');

-- MCQs for Topic 25: Inheritance and Base Classes (topic_id: 25)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (25, '{
  "question": "What is inheritance?",
  "options": [
    "A) Child class inherits from parent class",
    "B) Parent class inherits from child",
    "C) Classes inherit from themselves",
    "D) No inheritance"
  ],
  "correct_answer": "A) Child class inherits from parent class",
  "explanation": "Inheritance allows a child class to inherit fields and methods from a parent class."
}'),
                                         (25, '{
  "question": "What is the ''extends'' keyword used for?",
  "options": [
    "A) Establish inheritance relationship",
    "B) Implement interface",
    "C) Import package",
    "D) Create object"
  ],
  "correct_answer": "A) Establish inheritance relationship",
  "explanation": "The ''extends'' keyword is used to create a child class that inherits from a parent class."
}'),
                                         (25, '{
  "question": "What is method overriding?",
  "options": [
    "A) Redefining parent method in child",
    "B) Creating new method",
    "C) Hiding method",
    "D) Deleting method"
  ],
  "correct_answer": "A) Redefining parent method in child",
  "explanation": "Method overriding allows a child class to provide a specific implementation of a method already defined in parent."
}'),
                                         (25, '{
  "question": "What is the ''super'' keyword?",
  "options": [
    "A) Refer to parent class",
    "B) Refer to child class",
    "C) Refer to current class",
    "D) Refer to interface"
  ],
  "correct_answer": "A) Refer to parent class",
  "explanation": "''super'' refers to the parent class and is used to access parent methods, constructors, and fields."
}'),
                                         (25, '{
  "question": "What is the purpose of @Override annotation?",
  "options": [
    "A) Indicate method overriding",
    "B) Improve performance",
    "C) Force compilation",
    "D) Create new method"
  ],
  "correct_answer": "A) Indicate method overriding",
  "explanation": "@Override annotation indicates that a method is intended to override a parent method, enabling compile-time checks."
}'),
                                         (25, '{
  "question": "What is single inheritance?",
  "options": [
    "A) Class inherits from one parent",
    "B) Class inherits from multiple parents",
    "C) No inheritance",
    "D) Multiple levels inheritance"
  ],
  "correct_answer": "A) Class inherits from one parent",
  "explanation": "Single inheritance means a class can inherit from only one parent class (Java, C#)."
}'),
                                         (25, '{
  "question": "What is multiple inheritance?",
  "options": [
    "A) Class inherits from multiple parents",
    "B) Class inherits from one parent",
    "C) No inheritance",
    "D) Single level inheritance"
  ],
  "correct_answer": "A) Class inherits from multiple parents",
  "explanation": "Multiple inheritance allows a class to inherit from multiple parent classes (C++, Python)."
}'),
                                         (25, '{
  "question": "What is the ''final'' keyword for classes?",
  "options": [
    "A) Prevent inheritance",
    "B) Allow inheritance",
    "C) Force inheritance",
    "D) Enable polymorphism"
  ],
  "correct_answer": "A) Prevent inheritance",
  "explanation": "A final class cannot be extended (inherited from) by other classes."
}'),
                                         (25, '{
  "question": "What is the inheritance hierarchy?",
  "options": [
    "A) Tree-like structure of classes",
    "B) Flat structure",
    "C) Circular structure",
    "D) No structure"
  ],
  "correct_answer": "A) Tree-like structure of classes",
  "explanation": "Inheritance hierarchy forms a tree-like structure with Object class at the root."
}'),
                                         (25, '{
  "question": "What is the benefit of inheritance?",
  "options": [
    "A) Code reuse and polymorphism",
    "B) Faster execution",
    "C) Smaller memory",
    "D) Simpler syntax"
  ],
  "correct_answer": "A) Code reuse and polymorphism",
  "explanation": "Inheritance promotes code reuse and enables polymorphism through method overriding."
}');

-- MCQs for Topic 26: Method Overriding and Super Keyword (topic_id: 26)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (26, '{
  "question": "What are the rules for method overriding?",
  "options": [
    "A) Same signature, compatible return type",
    "B) Different signature",
    "C) Same name only",
    "D) Any method can override"
  ],
  "correct_answer": "A) Same signature, compatible return type",
  "explanation": "Overriding method must have same signature and compatible return type as parent method."
}'),
                                         (26, '{
  "question": "What is covariant return type?",
  "options": [
    "A) Child class return type in overriding",
    "B) Parent class return type",
    "C) Same return type only",
    "D) No return type"
  ],
  "correct_answer": "A) Child class return type in overriding",
  "explanation": "Covariant return type allows overriding method to return a subtype of parent method''s return type."
}'),
                                         (26, '{
  "question": "What is the purpose of super.method()?",
  "options": [
    "A) Call parent class method",
    "B) Call child class method",
    "C) Call current method",
    "D) Call static method"
  ],
  "correct_answer": "A) Call parent class method",
  "explanation": "super.method() calls the parent class version of an overridden method from the child class."
}'),
                                         (26, '{
  "question": "What is method hiding?",
  "options": [
    "A) Static method with same name as parent",
    "B) Instance method overriding",
    "C) Private method",
    "D) Abstract method"
  ],
  "correct_answer": "A) Static method with same name as parent",
  "explanation": "Method hiding occurs when child class defines a static method with same signature as parent static method."
}'),
                                         (26, '{
  "question": "What is the difference between overriding and overloading?",
  "options": [
    "A) Overriding same signature, overloading different",
    "B) Overloading same signature, overriding different",
    "C) Both same",
    "D) Both different"
  ],
  "correct_answer": "A) Overriding same signature, overloading different",
  "explanation": "Overriding has same method signature, overloading has same method name but different parameters."
}'),
                                         (26, '{
  "question": "Can private methods be overridden?",
  "options": [
    "A) No, they are not inherited",
    "B) Yes, always",
    "C) Only in same package",
    "D) Only by child classes"
  ],
  "correct_answer": "A) No, they are not inherited",
  "explanation": "Private methods are not inherited by child classes, so they cannot be overridden."
}'),
                                         (26, '{
  "question": "What is the ''final'' keyword for methods?",
  "options": [
    "A) Prevent method overriding",
    "B) Allow overriding",
    "C) Force overriding",
    "D) Enable polymorphism"
  ],
  "correct_answer": "A) Prevent method overriding",
  "explanation": "A final method cannot be overridden by child classes."
}'),
                                         (26, '{
  "question": "What is dynamic method dispatch?",
  "options": [
    "A) Runtime determination of method to call",
    "B) Compile-time method binding",
    "C) Static method calling",
    "D) Method overloading"
  ],
  "correct_answer": "A) Runtime determination of method to call",
  "explanation": "Dynamic method dispatch determines at runtime which overridden method to call based on actual object type."
}'),
                                         (26, '{
  "question": "What is super() constructor call?",
  "options": [
    "A) Call parent class constructor",
    "B) Call child class constructor",
    "C) Call current constructor",
    "D) Call static constructor"
  ],
  "correct_answer": "A) Call parent class constructor",
  "explanation": "super() calls the parent class constructor, typically as the first statement in child constructor."
}'),
                                         (26, '{
  "question": "What is the rules for constructor overriding?",
  "options": [
    "A) Constructors cannot be overridden",
    "B) Constructors can be overridden",
    "C) Only default constructors",
    "D) Only parameterized constructors"
  ],
  "correct_answer": "A) Constructors cannot be overridden",
  "explanation": "Constructors are not inherited and therefore cannot be overridden, only overloaded."
}');

-- MCQs for Topic 27: Polymorphism and Dynamic Binding (topic_id: 27)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (27, '{
  "question": "What is polymorphism?",
  "options": [
    "A) One interface, multiple implementations",
    "B) One implementation, multiple interfaces",
    "C) Single implementation",
    "D) No interface"
  ],
  "correct_answer": "A) One interface, multiple implementations",
  "explanation": "Polymorphism allows objects of different types to be treated as objects of a common super type."
}'),
                                         (27, '{
  "question": "What is compile-time polymorphism?",
  "options": [
    "A) Method overloading",
    "B) Method overriding",
    "C) Dynamic binding",
    "D) Runtime polymorphism"
  ],
  "correct_answer": "A) Method overloading",
  "explanation": "Compile-time polymorphism (static binding) is achieved through method overloading, resolved at compile time."
}'),
                                         (27, '{
  "question": "What is runtime polymorphism?",
  "options": [
    "A) Method overriding",
    "B) Method overloading",
    "C) Static methods",
    "D) Constructor overloading"
  ],
  "correct_answer": "A) Method overriding",
  "explanation": "Runtime polymorphism (dynamic binding) is achieved through method overriding, resolved at runtime."
}'),
                                         (27, '{
  "question": "What is dynamic method dispatch?",
  "options": [
    "A) Runtime determination of method to call",
    "B) Compile-time method resolution",
    "C) Static method calling",
    "D) Method declaration"
  ],
  "correct_answer": "A) Runtime determination of method to call",
  "explanation": "Dynamic method dispatch determines which overridden method to execute based on actual object type at runtime."
}'),
                                         (27, '{
  "question": "What is the ''instanceof'' operator used for?",
  "options": [
    "A) Check object type at runtime",
    "B) Create objects",
    "C) Compare objects",
    "D) Cast objects"
  ],
  "correct_answer": "A) Check object type at runtime",
  "explanation": "instanceof operator checks if an object is an instance of a specific class or interface at runtime."
}'),
                                         (27, '{
  "question": "What is upcasting?",
  "options": [
    "A) Treating child as parent type",
    "B) Treating parent as child type",
    "C) Same type casting",
    "D) No casting"
  ],
  "correct_answer": "A) Treating child as parent type",
  "explanation": "Upcasting is treating a child object as its parent type, which is always safe and implicit."
}'),
                                         (27, '{
  "question": "What is downcasting?",
  "options": [
    "A) Treating parent as child type",
    "B) Treating child as parent type",
    "C) Same type casting",
    "D) No casting"
  ],
  "correct_answer": "A) Treating parent as child type",
  "explanation": "Downcasting is treating a parent object as child type, which requires explicit casting and runtime check."
}'),
                                         (27, '{
  "question": "What is the benefit of polymorphism?",
  "options": [
    "A) Code flexibility and extensibility",
    "B) Faster execution",
    "C) Smaller code size",
    "D) Simpler syntax"
  ],
  "correct_answer": "A) Code flexibility and extensibility",
  "explanation": "Polymorphism makes code more flexible and extensible by allowing new types to be added easily."
}'),
                                         (27, '{
  "question": "What is interface polymorphism?",
  "options": [
    "A) Using interface references for different implementations",
    "B) Using class references",
    "C) Using abstract classes only",
    "D) Using final classes"
  ],
  "correct_answer": "A) Using interface references for different implementations",
  "explanation": "Interface polymorphism allows different classes implementing the same interface to be used interchangeably."
}'),
                                         (27, '{
  "question": "What is the Liskov Substitution Principle?",
  "options": [
    "A) Subtypes must be substitutable for base types",
    "B) Base types must be substitutable for subtypes",
    "C) No substitution allowed",
    "D) Only same types substitutable"
  ],
  "correct_answer": "A) Subtypes must be substitutable for base types",
  "explanation": "LSP states that objects of a superclass should be replaceable with objects of its subclasses without breaking the program."
}');

-- MCQs for Topic 28: Abstract Classes and Interfaces (topic_id: 28)
INSERT INTO mcqs (topic_id, content) VALUES
                                         (28, '{
  "question": "What is an abstract class?",
  "options": [
    "A) Class that cannot be instantiated",
    "B) Class with all methods implemented",
    "C) Final class",
    "D) Static class"
  ],
  "correct_answer": "A) Class that cannot be instantiated",
  "explanation": "Abstract classes cannot be instantiated and may contain abstract methods that must be implemented by subclasses."
}'),
                                         (28, '{
  "question": "What is an abstract method?",
  "options": [
    "A) Method without implementation",
    "B) Method with implementation",
    "C) Static method",
    "D) Final method"
  ],
  "correct_answer": "A) Method without implementation",
  "explanation": "Abstract methods are declared without implementation and must be implemented by concrete subclasses."
}'),
                                         (28, '{
  "question": "What is an interface?",
  "options": [
    "A) Contract of methods to implement",
    "B) Class with implementations",
    "C) Abstract class",
    "D) Final class"
  ],
  "correct_answer": "A) Contract of methods to implement",
  "explanation": "Interface defines a contract of methods that implementing classes must provide."
}'),
                                         (28, '{
  "question": "What is the difference between abstract class and interface?",
  "options": [
    "A) Abstract class can have implementation, interface cannot",
    "B) Interface can have implementation, abstract class cannot",
    "C) Both are same",
    "D) Neither can have implementation"
  ],
  "correct_answer": "A) Abstract class can have implementation, interface cannot",
  "explanation": "Abstract classes can have both abstract and concrete methods, while interfaces traditionally only have abstract methods."
}'),
                                         (28, '{
  "question": "What are default methods in interfaces?",
  "options": [
    "A) Methods with implementation in interface",
    "B) Abstract methods",
    "C) Static methods",
    "D) Private methods"
  ],
  "correct_answer": "A) Methods with implementation in interface",
  "explanation": "Default methods provide implementation in interfaces, allowing backward compatibility."
}'),
                                         (28, '{
  "question": "What is multiple inheritance through interfaces?",
  "options": [
    "A) Class implementing multiple interfaces",
    "B) Class extending multiple classes",
    "C) Interface extending class",
    "D) Class implementing one interface"
  ],
  "correct_answer": "A) Class implementing multiple interfaces",
  "explanation": "A class can implement multiple interfaces, achieving multiple inheritance of type."
}'),
                                         (28, '{
  "question": "What is the ''implements'' keyword used for?",
  "options": [
    "A) Implement interface",
    "B) Extend class",
    "C) Create object",
    "D) Import package"
  ],
  "correct_answer": "A) Implement interface",
  "explanation": "The ''implements'' keyword is used by a class to implement one or more interfaces."
}'),
                                         (28, '{
  "question": "What are marker interfaces?",
  "options": [
    "A) Interfaces with no methods",
    "B) Interfaces with many methods",
    "C) Abstract classes",
    "D) Final classes"
  ],
  "correct_answer": "A) Interfaces with no methods",
  "explanation": "Marker interfaces are empty interfaces used to mark classes with special behavior (Serializable, Cloneable)."
}'),
                                         (28, '{
  "question": "What is functional interface?",
  "options": [
    "A) Interface with one abstract method",
    "B) Interface with multiple methods",
    "C) Abstract class",
    "D) Class with lambda"
  ],
  "correct_answer": "A) Interface with one abstract method",
  "explanation": "Functional interfaces have exactly one abstract method and can be implemented using lambda expressions."
}'),
                                         (28, '{
  "question": "What is the purpose of abstract classes?",
  "options": [
    "A) Provide common base with partial implementation",
    "B) Force complete implementation",
    "C) Prevent inheritance",
    "D) Enable multiple inheritance"
  ],
  "correct_answer": "A) Provide common base with partial implementation",
  "explanation": "Abstract classes provide a common base with some implementation while forcing subclasses to implement specific methods."
}');

-- Final Verification Query
SELECT 'Total MCQs Created: ' || COUNT(*) as final_summary FROM mcqs;
SELECT topic_id, COUNT(*) as mcq_count
FROM mcqs
GROUP BY topic_id
ORDER BY topic_id;

-- ============================================================================
-- End of Complete MCQs Script for All 28 Topics
-- ============================================================================
-- Final Verification Query
SELECT 'Total MCQs: ' || COUNT(*) as summary FROM mcqs;

-- ============================================================================
-- End of Complete MCQs Script
-- ============================================================================