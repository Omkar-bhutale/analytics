# LearningPage Component Structure

This folder contains the modularized Learning Page components, split from the original `LearningPage_NEW.jsx` file.

## File Structure

```
LearningPage/
├── index.jsx                       # Main LearningPage component (entry point)
├── axiosConfig.js                  # Axios configuration with interceptors
├── constants.js                    # Constants (questionMap, PERSISTENT_KEYS, etc.)
├── usePersistentTopicTimers.js     # Custom hook for timer management
├── TopicTimer.jsx                  # Timer display component
├── Sidebar.jsx                     # Sidebar navigation component
├── SessionContentsModal.jsx        # Modal for session contents/notebooks
├── DataTypesTabs.jsx              # Language tabs and content display
└── README.md                       # This file
```

## Component Descriptions

### `index.jsx`
Main component that orchestrates the Learning Page. Handles:
- Data fetching from backend
- State management for selected topic/subtopic/language
- Navigation and routing
- Integration of all child components

### `axiosConfig.js`
Configures axios with:
- Base URL from environment variables
- Request interceptor for adding authentication token
- Error handling

### `constants.js`
Defines shared constants:
- `questionMap`: Maps languages to quiz question types
- `PERSISTENT_KEYS`: Keys to persist in localStorage
- `ALL_LANGUAGES`: List of supported languages

### `usePersistentTopicTimers.js`
Custom React hook that manages:
- Timer state for each topic-language combination
- Completion tracking (quizzes, subtopics, main topics)
- Time synchronization with backend
- localStorage persistence
- Event listeners for visibility changes and page unload

### `TopicTimer.jsx`
Displays the time spent on current topic in HH:MM:SS format.

### `Sidebar.jsx`
Sidebar navigation component with:
- Collapsible topic list
- Subtopic navigation
- Completion indicators (checkmarks)
- Active topic/subtopic highlighting

### `SessionContentsModal.jsx`
Modal dialog for viewing and downloading:
- Jupyter notebooks
- PDF resources
- Other session materials

### `DataTypesTabs.jsx`
Content display component featuring:
- Language tabs (Java, Python, JavaScript, TypeScript)
- Code examples and explanations
- Quiz navigation
- "Code Here" button for problems
- "Mark as Complete" functionality
- Language visit tracking

## Usage

Import the main component in your routing file:

```javascript
import LearningPage from './LearningPage';

// In your routes
<Route path="/learning" element={<LearningPage onLogout={handleLogout} />} />
```

## Key Features

1. **Time Tracking**: Automatic tracking of time spent per topic and language
2. **Progress Tracking**: Tracks completion of subtopics, languages, and quizzes
3. **Persistence**: All progress saved to localStorage and synced with backend
4. **Multi-language Support**: Switch between Java, Python, JavaScript, TypeScript
5. **Offline Resilience**: Uses `keepalive` fetch for reliable data syncing
6. **Session Materials**: Download notebooks and resources per topic

## Data Flow

1. Main component fetches topics/subtopics from backend
2. Timer hook initializes from backend + localStorage
3. User navigates topics/subtopics via Sidebar
4. DataTypesTabs displays content and tracks language visits
5. Timer syncs time spent to backend periodically
6. Completion states update both localStorage and backend

## State Management

- **Local State**: UI-specific state (modal open/close, loading states)
- **Custom Hook State**: Timers and completion tracking
- **localStorage**: Persistence of user progress
- **Backend**: Source of truth for time and completion data

## Dependencies

- React & React Router
- axios
- react-hot-toast
- js-cookie
- react-icons (FaCode, TbBulb, TbCheck, etc.)

