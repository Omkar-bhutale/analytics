import React, { useState, useEffect } from "react";
import axios from "./axiosConfig";
import { BASE_URL } from "./axiosConfig";
import { TbX, TbNotebook, TbDownload } from "react-icons/tb";
import toast from "react-hot-toast";

export function SessionContentsModal({ isOpen, onClose, selectedTopic, fetchedData }) {
    const [notebooks, setNotebooks] = useState([]);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (!isOpen || !selectedTopic) return;

        const fetchNotebooks = async () => {
            setLoading(true);
            try {
                const topicData = fetchedData.find(t => t.mainTopicName === selectedTopic);
                if (!topicData?.mainTopicId) {
                    toast.error("Topic ID not found");
                    return;
                }

                const response = await axios.get(`${BASE_URL}/user/notebooks/${topicData.mainTopicId}`);
                setNotebooks(response.data || []);
            } catch (error) {
                console.error("Error fetching notebooks:", error);
                toast.error("Failed to fetch session contents");
                setNotebooks([]);
            } finally {
                setLoading(false);
            }
        };

        fetchNotebooks();
    }, [isOpen, selectedTopic, fetchedData]);

    const handleDownload = async (notebookId, title, fileType) => {
        try {
            toast.loading(`Downloading ${title}...`, { id: `download-${notebookId}` });

            const response = await axios.get(`${BASE_URL}/user/notebooks/download/${notebookId}`, {
                responseType: 'blob',
            });

            let fileName = title;
            const contentDisposition = response.headers['content-disposition'];
            if (contentDisposition) {
                const fileNameMatch = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/);
                if (fileNameMatch && fileNameMatch[1]) {
                    fileName = fileNameMatch[1].replace(/['"]/g, '');
                }
            } else {
                const extension = fileType === 'PDF' ? '.pdf' : '.ipynb';
                if (!fileName.toLowerCase().endsWith(extension)) {
                    fileName += extension;
                }
            }

            const blob = new Blob([response.data], {
                type: response.headers['content-type'] || 'application/octet-stream'
            });
            const url = window.URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', fileName);
            document.body.appendChild(link);
            link.click();

            link.remove();
            window.URL.revokeObjectURL(url);

            toast.success(`Downloaded ${fileName}`, { id: `download-${notebookId}` });
        } catch (error) {
            console.error("Error downloading notebook:", error);
            toast.error("Failed to download notebook", { id: `download-${notebookId}` });
        }
    };

    if (!isOpen) return null;

    return (
        <div
            style={{
                position: "fixed",
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                backgroundColor: "rgba(0, 0, 0, 0.5)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                zIndex: 1000,
            }}
            onClick={onClose}
        >
            <div
                style={{
                    backgroundColor: "#fff",
                    borderRadius: "12px",
                    padding: "24px",
                    minWidth: "500px",
                    maxWidth: "700px",
                    maxHeight: "80vh",
                    overflowY: "auto",
                    boxShadow: "0 10px 40px rgba(0, 0, 0, 0.2)",
                }}
                onClick={(e) => e.stopPropagation()}
            >
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
                    <h2 style={{ margin: 0, color: "#09122C", fontSize: "24px", fontWeight: "bold" }}>
                        Session Contents - {selectedTopic}
                    </h2>
                    <button
                        onClick={onClose}
                        style={{
                            background: "none",
                            border: "none",
                            cursor: "pointer",
                            fontSize: "24px",
                            color: "#666",
                        }}
                    >
                        <TbX />
                    </button>
                </div>

                {loading ? (
                    <div style={{ textAlign: "center", padding: "40px", color: "#666" }}>
                        Loading notebooks...
                    </div>
                ) : notebooks.length === 0 ? (
                    <div style={{ textAlign: "center", padding: "40px", color: "#666" }}>
                        No notebooks available for this topic yet.
                    </div>
                ) : (
                    <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                        {notebooks.map((notebook) => (
                            <div
                                key={notebook.notebookId}
                                style={{
                                    display: "flex",
                                    justifyContent: "space-between",
                                    alignItems: "center",
                                    padding: "16px",
                                    backgroundColor: "#f6f7fb",
                                    borderRadius: "8px",
                                    border: "1px solid #e0e0e0",
                                }}
                            >
                                <div style={{ flex: 1 }}>
                                    <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "4px" }}>
                                        <TbNotebook style={{ color: "#DD6B20", fontSize: "20px" }} />
                                        <h4 style={{ margin: 0, color: "#09122C", fontSize: "16px" }}>
                                            {notebook.title}
                                        </h4>
                                    </div>
                                    <div style={{ display: "flex", gap: "12px", fontSize: "13px", color: "#666" }}>
                                        <span style={{
                                            backgroundColor: "#DD6B20",
                                            color: "#fff",
                                            padding: "2px 8px",
                                            borderRadius: "4px",
                                            fontSize: "12px"
                                        }}>
                                            {notebook.language}
                                        </span>
                                        <span style={{
                                            backgroundColor: "#09122C",
                                            color: "#fff",
                                            padding: "2px 8px",
                                            borderRadius: "4px",
                                            fontSize: "12px"
                                        }}>
                                            {notebook.fileType}
                                        </span>
                                    </div>
                                </div>
                                <button
                                    onClick={() => handleDownload(notebook.notebookId, notebook.title, notebook.fileType)}
                                    style={{
                                        backgroundColor: "#09122C",
                                        color: "#fff",
                                        border: "none",
                                        borderRadius: "6px",
                                        padding: "10px 16px",
                                        cursor: "pointer",
                                        display: "flex",
                                        alignItems: "center",
                                        gap: "6px",
                                        fontSize: "14px",
                                        fontWeight: "500",
                                        transition: "background-color 0.2s",
                                    }}
                                    onMouseEnter={(e) => e.target.style.backgroundColor = "#1a2444"}
                                    onMouseLeave={(e) => e.target.style.backgroundColor = "#09122C"}
                                >
                                    <TbDownload style={{ fontSize: "18px" }} />
                                    Download
                                </button>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}

