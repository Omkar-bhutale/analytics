import { useState, useEffect, useRef, useCallback } from "react";
import { PERSISTENT_KEYS } from "./constants";
import toast from "react-hot-toast";
import * as learningApi from "./learningApi";

export function usePersistentTopicTimers(selectedTopic, selectedSubtopic, selectedLanguage, fetchedData) {
    // Timer state: { 'topic::language': seconds, ... }
    const [timers, setTimers] = useState({});
    const timersInitialized = useRef(false);

    // ✅ Initialize timers from backend data as the source of truth
    useEffect(() => {
        const initializeTimers = async () => {
            if (fetchedData.length > 0 && !timersInitialized.current) {
                const initialTimers = {};
                const savedTimers = JSON.parse(localStorage.getItem("topicTimers") || "{}");

                // Fetch timer data for each main topic
                for (const topic of fetchedData) {
                    try {
                        const timerData = await learningApi.getMainTopicTimer(topic.mainTopicId);
                        const mainTopicName = topic.mainTopicName;

                        // Store timer data with topic::language key
                        if (timerData.javaSeconds) initialTimers[`${mainTopicName}::Java`] = timerData.javaSeconds;
                        if (timerData.pythonSeconds) initialTimers[`${mainTopicName}::Python`] = timerData.pythonSeconds;
                        if (timerData.javascriptSeconds) initialTimers[`${mainTopicName}::JavaScript`] = timerData.javascriptSeconds;
                        if (timerData.typescriptSeconds) initialTimers[`${mainTopicName}::TypeScript`] = timerData.typescriptSeconds;
                    } catch (error) {
                        console.error(`Failed to fetch timer for topic ${topic.mainTopicId}:`, error);
                    }
                }

                // Merge with localStorage, giving precedence to backend data
                const finalTimers = { ...savedTimers, ...initialTimers };

                setTimers(finalTimers);
                // ✅ CRITICAL FIX: Initialize lastSyncTimeRef with the same values
                // This prevents sending the full cumulative time on the first sync.
                lastSyncTimeRef.current = { ...lastSyncTimeRef.current, ...finalTimers };
                timersInitialized.current = true;
                console.log("✅ Timers initialized from backend and localStorage:", finalTimers);
            }
        };

        initializeTimers();
    }, [fetchedData]);

    // Helper to load ALL completion keys
    const loadAllCompletedItems = () => {
        const saved = localStorage.getItem("completedQuizzes");
        return saved ? JSON.parse(saved) : [];
    }

    // Completion state: Tracks ALL completion keys
    const [completedItems, setCompletedItems] = useState(loadAllCompletedItems);

    const intervalRef = useRef(null);
    const lastSyncTimeRef = useRef({}); // Track last sync time for each topic::language

    //  REVISED TIMER KEY: Now scoped to TOPIC::LANGUAGE (Accumulates time across all subtopics)
    const currentTimerKey = selectedTopic && selectedLanguage
        ? `${selectedTopic}::${selectedLanguage}`
        : null;

    const isPersistentKey = (key) => {
        return PERSISTENT_KEYS.some(suffix => key.endsWith(suffix));
    };

    //  Save timers and ALL relevant completed items
    useEffect(() => {
        localStorage.setItem("topicTimers", JSON.stringify(timers));
    }, [timers]);

    useEffect(() => {
        // Filter to only save keys that end with a recognised persistent suffix
        const keysToSave = completedItems.filter(isPersistentKey);
        localStorage.setItem("completedQuizzes", JSON.stringify(keysToSave));
    }, [completedItems]);

    //  CRITICAL FIX: Listen for both storage event (other tabs) and custom event (same tab)
    useEffect(() => {
        const updateFromStorage = () => {
            const savedItems = loadAllCompletedItems();
            setCompletedItems(savedItems);
            const savedTimers = localStorage.getItem("topicTimers");
            if (savedTimers) setTimers(JSON.parse(savedTimers));
        };

        // Listener for storage changes from other tabs
        window.addEventListener("storage", updateFromStorage);

        // Listener for custom event dispatched by McqPage in the same tab/window
        window.addEventListener("completedQuizzesUpdated", updateFromStorage);

        return () => {
            window.removeEventListener("storage", updateFromStorage);
            window.removeEventListener("completedQuizzesUpdated", updateFromStorage);
        };
    }, [setCompletedItems]);

    const isLanguageCompletedForTopic = completedItems.includes(currentTimerKey);

    //  Timer logic: run only for the currently active language and if not completed
    useEffect(() => {
        clearInterval(intervalRef.current);
        if (!currentTimerKey) return;

        //  REVISED: Use Topic-level completion check
        if (isLanguageCompletedForTopic) return; // Stop timer if the current language for the topic is completed

        // Start the timer
        intervalRef.current = setInterval(() => {
            setTimers(prev => ({
                ...prev,
                [currentTimerKey]: (prev[currentTimerKey] || 0) + 1,
            }));
        }, 1000);

        return () => clearInterval(intervalRef.current);

    }, [currentTimerKey, isLanguageCompletedForTopic]);

    // Helper to find the topicId for the current subtopic
    const findTopicId = useCallback((topic, subtopic) => {
        const topicData = fetchedData.find(t => t.mainTopicName === topic);
        const subtopicData = topicData?.subTopics?.find(s => s.title === subtopic);
        // The topicId in the subTopics array (like 12 in the image) is what the API uses
        return subtopicData?.topicId;
    }, [fetchedData]);

    //  ✅ Sync time ONLY on navigation events (language/subtopic/main topic switch or page close)
    // No periodic background sync (per requirement #7)

    // Sync on visibility change (page hide/close)
    useEffect(() => {
        const syncFinalTime = async () => {
            if (!currentTimerKey || !selectedSubtopic) return;

            const [topic, language] = currentTimerKey.split('::');
            const currentTime = timers[currentTimerKey] || 0;
            const lastSyncTime = lastSyncTimeRef.current[currentTimerKey] || 0;
            const timeSinceLastSync = currentTime - lastSyncTime;

            if (timeSinceLastSync > 0) {
                const currentSubtopicId = findTopicId(topic, selectedSubtopic);

                if (currentSubtopicId) {
                    try {
                        const response = await learningApi.sendTimeDelta(
                            currentSubtopicId,
                            language,
                            timeSinceLastSync
                        );

                        if (response.success) {
                            console.log(`✅ Final sync on page hide: Subtopic ${currentSubtopicId} (${selectedSubtopic}) in ${language} - ${timeSinceLastSync}s`);
                            lastSyncTimeRef.current[currentTimerKey] = currentTime;
                        }
                    } catch (error) {
                        console.error(`❌ Failed to sync on page hide`, error);
                    }
                }
            }
        };

        const handleVisibilityChange = () => {
            if (document.visibilityState === 'hidden') {
                syncFinalTime();
            }
        };

        window.addEventListener('visibilitychange', handleVisibilityChange);
        window.addEventListener('pagehide', syncFinalTime);

        return () => {
            window.removeEventListener('visibilitychange', handleVisibilityChange);
            window.removeEventListener('pagehide', syncFinalTime);
            // Final sync on cleanup
            syncFinalTime();
        };
    }, [currentTimerKey, selectedSubtopic, findTopicId, timers]);

    // ✅ NEW: Send final time on page unload (refresh/close) or tab switch
    useEffect(() => {
        const syncFinalTime = () => {
            // This logic is now inside the main sync effect's cleanup.
            // We can trigger it from here if needed, but let's consolidate.
        };

        const handleVisibilityChange = () => {
            if (document.visibilityState === 'hidden') {
                // The main sync effect already handles this.
                // We can trigger its sync function if we extract it.
            }
        };

        window.addEventListener('visibilitychange', handleVisibilityChange);
        // 'pagehide' is more reliable than 'beforeunload' for this purpose.
        window.addEventListener('pagehide', syncFinalTime);

        return () => {
            window.removeEventListener('visibilitychange', handleVisibilityChange);
            window.removeEventListener('pagehide', syncFinalTime);
        };
    }, [currentTimerKey, selectedSubtopic, findTopicId, timers]);

    const prevSubtopicRef = useRef(selectedSubtopic);

    useEffect(() => {
        // Check if the subtopic has actually changed
        if (prevSubtopicRef.current !== selectedSubtopic) {
            const prevSubtopic = prevSubtopicRef.current;
            const prevTimerKey = currentTimerKey; // This is based on the *current* topic/language

            if (prevTimerKey && prevSubtopic) {
                const [topic, language] = prevTimerKey.split('::');
                const currentTime = timers[prevTimerKey] || 0;
                const lastSyncTime = lastSyncTimeRef.current[prevTimerKey] || 0;
                const timeToSync = currentTime - lastSyncTime;

                if (timeToSync > 0) {
                    const subtopicId = findTopicId(topic, prevSubtopic);
                    if (subtopicId) {
                        // Use new delta API
                        learningApi.sendTimeDelta(subtopicId, language, timeToSync)
                            .then((response) => {
                                if (response.success) {
                                    console.log(`✅ Subtopic Switch Sync: Sent ${timeToSync}s for Subtopic ${subtopicId} (${prevSubtopic}), New Total: ${response.newTotal}s`);
                                    lastSyncTimeRef.current[prevTimerKey] = currentTime;
                                }
                            })
                            .catch(err => {
                                console.error(`❌ Subtopic Switch Sync failed for Subtopic ${subtopicId}`, err);
                            });
                    }
                }
            }

            // After syncing, update the ref to the new current subtopic
            prevSubtopicRef.current = selectedSubtopic;
        }
    }, [selectedSubtopic, currentTimerKey, findTopicId, timers]);

    // ✅ Sync time on language switch (Requirement #6)
    const prevLanguageRef = useRef(selectedLanguage);

    useEffect(() => {
        // Check if the language has actually changed
        if (prevLanguageRef.current !== selectedLanguage && prevLanguageRef.current !== null) {
            const prevLanguage = prevLanguageRef.current;
            const prevTimerKey = selectedTopic ? `${selectedTopic}::${prevLanguage}` : null;

            if (prevTimerKey && selectedSubtopic) {
                const currentTime = timers[prevTimerKey] || 0;
                const lastSyncTime = lastSyncTimeRef.current[prevTimerKey] || 0;
                const timeToSync = currentTime - lastSyncTime;

                if (timeToSync > 0) {
                    const subtopicId = findTopicId(selectedTopic, selectedSubtopic);
                    if (subtopicId) {
                        // Use new delta API
                        learningApi.sendTimeDelta(subtopicId, prevLanguage, timeToSync)
                            .then((response) => {
                                if (response.success) {
                                    console.log(`✅ Language Switch Sync: Sent ${timeToSync}s for language ${prevLanguage}, New Total: ${response.newTotal}s`);
                                    lastSyncTimeRef.current[prevTimerKey] = currentTime;
                                }
                            })
                            .catch(err => {
                                console.error(`❌ Language Switch Sync failed for ${prevLanguage}`, err);
                            });
                    }
                }
            }

            // After syncing, update the ref to the new current language
            prevLanguageRef.current = selectedLanguage;
        } else if (prevLanguageRef.current === null) {
            // Initialize on first render
            prevLanguageRef.current = selectedLanguage;
        }
    }, [selectedLanguage, selectedTopic, selectedSubtopic, findTopicId, timers]);

    //  Send final time when language is marked complete
    useEffect(() => {
        const newlyCompletedKeys = completedItems.filter(key =>
            key.split('::').length === 2 && // Topic::Language (2 parts)
            PERSISTENT_KEYS.some(suffix => key.endsWith(suffix))
        );

        newlyCompletedKeys.forEach(key => {
            const [topic, language] = key.split('::');
            const topicData = fetchedData.find(t => t.mainTopicName === topic);
            const subtopics = topicData?.subTopics || [];
            const totalTime = timers[key] || 0;
            const lastSyncTime = lastSyncTimeRef.current[key] || 0;
            const remainingTime = totalTime - lastSyncTime;

            // Only send if there's unsent time
            if (remainingTime > 0 && subtopics.length > 0) {
                const timePerSubtopic = Math.floor(remainingTime / subtopics.length);

                subtopics.forEach(async (subtopic) => {
                    const topicId = subtopic.topicId;

                    try {
                        const response = await learningApi.sendTimeDelta(
                            topicId,
                            language,
                            timePerSubtopic
                        );

                        if (response.success) {
                            console.log(`✅ Final time tracked: Topic ${topicId} (${language}) - ${timePerSubtopic}s, New Total: ${response.newTotal}s`);
                            lastSyncTimeRef.current[key] = totalTime;
                        }
                    } catch (error) {
                        console.error(`❌ Failed to update final engagement for Topic ${topicId} (${language})`, error);
                    }
                });
            }
        });

    }, [completedItems, timers, fetchedData]);

    const checkSubtopicAndTopicCompletion = useCallback((topic, subtopic, updatedItems) => {
        const allLangsCompleteForTopic = ['Java', 'Python', 'JavaScript', 'TypeScript'].every(
            lang => updatedItems.includes(`${topic}::${lang}`)
        );
        const isQuizPassedForSubtopic = updatedItems.includes(`${topic}::${subtopic}::passed`);

        //  Step 1: Mark subtopic complete only after explicit quiz + all langs complete
        if (allLangsCompleteForTopic && isQuizPassedForSubtopic) {
            const subtopicCompleteKey = `${topic}::${subtopic}::subtopic_complete`;
            if (!updatedItems.includes(subtopicCompleteKey)) {
                updatedItems.push(subtopicCompleteKey);
            }
        }

        //  Step 2: Mark main topic complete only when all subtopics are done
        const topicData = fetchedData.find(t => t.mainTopicName === topic);
        const allSubtopicsComplete = topicData?.subTopics.every(sub => {
            const subKey = `${topic}::${sub.title}::subtopic_complete`;
            return updatedItems.includes(subKey);
        });

        if (allSubtopicsComplete) {
            const mainTopicCompleteKey = `${topic}::main_topic_complete`;
            if (!updatedItems.includes(mainTopicCompleteKey)) {
                updatedItems.push(mainTopicCompleteKey);
            }
        }

        return updatedItems;
    }, [fetchedData]);

    // Function to mark a language as complete and check for subtopic/topic completion
    const markLanguageComplete = useCallback((topic, subtopic, language) => {
        //  REVISED LANGUAGE KEY: Now at Topic level: 'Topic::Language'
        const languageKey = `${topic}::${language}`;

        setCompletedItems(prevItems => {
            if (prevItems.includes(languageKey)) {
                return prevItems;
            }

            let updatedItems = [...prevItems, languageKey];
            const topicData = fetchedData.find(t => t.mainTopicName === topic);

            topicData?.subTopics.forEach(sub => {
                updatedItems = checkSubtopicAndTopicCompletion(topic, sub.title, updatedItems);
            });

            // Note: Backend validation and marking complete is now handled in DataTypesTabs.jsx
            // via learningApi.getMarkCompleteStatus() and learningApi.markTopicComplete()
            console.log(`✅ Language marked complete locally: ${topic}::${language}`);

            return updatedItems;
        });
    }, [checkSubtopicAndTopicCompletion, fetchedData]);

    // Function to mark a quiz as passed and check for subtopic/topic completion
    const markQuizPassed = useCallback((topic, subtopic, language) => {
        const quizKey = `${topic}::${subtopic}::passed`;
        setCompletedItems(prevItems => {
            // CRITICAL CHECK: Don't re-run logic if already passed
            if (prevItems.includes(quizKey)) {
                return prevItems;
            }
            const newItems = [...prevItems, quizKey];

            // ✅ UPDATED: Send MCQ visited status to backend using new API
            const topicData = fetchedData.find(t => t.mainTopicName === topic);
            const subtopicData = topicData?.subTopics?.find(s => s.title === subtopic);
            if (subtopicData?.topicId && language) {
                learningApi.markMcqVisited(subtopicData.topicId, language)
                    .then(response => {
                        if (response.success) {
                            console.log(`✅ MCQ marked as visited for topic ${subtopicData.topicId} in ${language}`, response);
                            toast.success(`${language} MCQ completed for ${subtopic}!`);
                        }
                    })
                    .catch(error => {
                        console.error(`❌ Failed to mark MCQ as visited for topic ${subtopicData.topicId}`, error);
                        toast.error(`Failed to save MCQ completion for ${language}`);
                    });
            }

            // Check completion for the specific subtopic where the quiz was passed
            return checkSubtopicAndTopicCompletion(topic, subtopic, newItems);
        });
    }, [checkSubtopicAndTopicCompletion, fetchedData]);

    return {
        timers,
        completedItems,
        setCompletedItems,
        markLanguageComplete,
        markQuizPassed,
    };
}

