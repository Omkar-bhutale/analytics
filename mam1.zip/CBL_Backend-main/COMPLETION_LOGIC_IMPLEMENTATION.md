# ✅ Topic & Main Topic Completion Logic - Implementation Guide

**Date:** November 10, 2025  
**File Updated:** `LearningPage_NEW.jsx`  
**Status:** ✅ COMPLETE

---

## 🎯 Requirements Overview

Based on the backend validation requirements, the completion logic follows these rules:

### **To Mark a Language as Complete for a Main Topic:**

The backend validates **3 conditions** before allowing completion:

1. ✅ **All Subtopics Visited** in that language
   - Each subtopic must have `{language}Visited = true`
   - Automatically set when user spends **≥ 3 minutes (180 seconds)** on subtopic

2. ✅ **All MCQs Completed** in that language
   - Each subtopic must have `{language}McqVisited = true`
   - Set when user completes MCQ quiz for that subtopic in that language

3. ✅ **Code Problem Attempted** in that language
   - Either: User spent **≥ 2 minutes (120 seconds)** on code problem
   - Or: User successfully solved the code problem

---

## 📊 Implementation Details

### **1. Subtopic Visited (Auto-Tracked by Timer)**

**How it works:**
- Timer tracks time spent on each subtopic + language combination
- Backend automatically sets `{language}Visited = true` when cumulative time ≥ 180 seconds
- No explicit API call needed - happens during time sync

**Example:**
```javascript
// User views Arrays in Java for 3 minutes
// Timer sends time every 30 seconds:

PUT /user/topic-engagement/language
{
  "topicId": 1,           // Arrays subtopic
  "language": "JAVA",
  "timeSpentSeconds": 30  // Delta
}

// Backend logic:
engagement.javaTimeSeconds += 30;
if (engagement.javaTimeSeconds >= 180) {
    engagement.javaVisited = true;  // ✅ Auto-set!
}
```

**Frontend Display:**
```javascript
// Check if subtopic is visited in current language
const langKey = selectedLanguage.toLowerCase() + 'Visited';
const isVisited = subtopicEngagement[langKey] || false;

// Show indicator: ✅ Visited or 🔄 In Progress
```

---

### **2. MCQ Completed (Language-Specific)**

**How it works:**
- When user completes MCQ quiz, frontend sends language parameter
- Backend sets language-specific MCQ flag
- Each language tracked independently

**Updated Implementation:**
```javascript
// ✅ UPDATED: markQuizPassed now includes language parameter
const markQuizPassed = useCallback((topic, subtopic, language) => {
    const topicData = fetchedData.find(t => t.mainTopicName === topic);
    const subtopicData = topicData?.subTopics?.find(s => s.title === subtopic);
    
    if (subtopicData?.topicId && language) {
        // Send MCQ completion WITH language parameter
        axios.put(
            `${BASE_URL}/user/topic-engagement/${subtopicData.topicId}/mcq-visited`,
            null,
            { params: { language: language.toUpperCase() } }
        )
        .then(response => {
            console.log(`✅ MCQ marked as visited for ${subtopic} in ${language}`);
            toast.success(`${language} MCQ completed for ${subtopic}!`);
        })
        .catch(error => {
            console.error(`❌ Failed to mark MCQ as visited`, error);
            toast.error(`Failed to save MCQ completion for ${language}`);
        });
    }
}, [fetchedData]);
```

**API Call:**
```http
PUT /user/topic-engagement/1/mcq-visited?language=JAVA
Authorization: Bearer <token>
```

**Backend Updates:**
```java
// Backend sets language-specific flag
switch (language.toUpperCase()) {
    case "JAVA" -> engagement.setJavaMcqVisited(true);
    case "PYTHON" -> engagement.setPythonMcqVisited(true);
    case "JAVASCRIPT" -> engagement.setJavascriptMcqVisited(true);
    case "TYPESCRIPT" -> engagement.setTypescriptMcqVisited(true);
}
```

**Database Result:**
```sql
-- user_topic_engagement table for Arrays subtopic
java_mcq_visited = true       -- ✅ Set when Java MCQ completed
python_mcq_visited = false    -- ❌ Not completed yet
javascript_mcq_visited = false
typescript_mcq_visited = false
```

---

### **3. Code Problem Attempted**

**How it works:**
- User must either spend ≥ 2 minutes OR solve the problem
- Tracked in `user_problem_engagement` table
- Backend validates this during completion check

**Conditions:**
```java
// Backend validation logic
boolean codeAttempted = 
    engagement.getJavaTimeSeconds() >= 120 ||  // 2 minutes
    engagement.getJavaCompleted();              // Problem solved
```

**No frontend changes needed** - backend validates automatically.

---

## 🔄 Complete Flow Example

### **Scenario: User wants to mark Java complete for Data Structures**

#### **Step 1: User completes all requirements**

```
Data Structures has 3 subtopics: Arrays, Linked Lists, Stacks

For Java to be complete:
✅ Arrays → Java: Visited (3+ min), MCQ completed
✅ Linked Lists → Java: Visited (3+ min), MCQ completed  
✅ Stacks → Java: Visited (3+ min), MCQ completed
✅ Code Problem: Attempted (2+ min) or Solved
```

#### **Step 2: User clicks "Mark as Complete" button**

```javascript
const handleMarkComplete = () => {
    if (!isLangCompletedForTopic && canMarkLanguageComplete) {
        // Call backend validation API
        markLanguageComplete(selectedTopic, selectedSubtopic, selectedLanguage);
    }
};
```

#### **Step 3: Frontend calls validation API**

```javascript
const markLanguageComplete = useCallback((topic, subtopic, language) => {
    const topicData = fetchedData.find(t => t.mainTopicName === topic);
    
    if (topicData?.mainTopicId) {
        // ✅ Call backend validation API
        axios.put(
            `${BASE_URL}/user/user-main-topic-engagement/${topicData.mainTopicId}/validate-completion`,
            null,
            { params: { language: language.toUpperCase() } }
        )
        .then(response => {
            if (response.data?.success) {
                toast.success(response.data.message || `${language} completed successfully!`);
                // Refresh engagement data to show completion badge
            }
        })
        .catch(error => {
            // Show specific error message
            const errorMessage = error.response?.data?.message ||
                `Could not mark ${language} as complete. Please ensure you have:\n` +
                `1. Visited all subtopics in ${language}\n` +
                `2. Completed all MCQs in ${language}\n` +
                `3. Spent at least 2 minutes or solved the Code Here problem`;
            
            toast.error(errorMessage);
        });
    }
}, [fetchedData]);
```

#### **Step 4: Backend validates all conditions**

```java
@Transactional
public CompletionValidationResponse validateAndMarkCompletion(
    Integer mainTopicId, 
    String language
) {
    // Get all subtopics for this main topic
    List<Topic> subtopics = topicRepository.findByMainTopicId(mainTopicId);
    
    // Check 1: All subtopics visited in this language?
    boolean allVisited = subtopics.stream().allMatch(subtopic -> {
        UserTopicEngagement eng = getEngagement(userId, subtopic.getId());
        return switch(language) {
            case "JAVA" -> eng.getJavaVisited();
            case "PYTHON" -> eng.getPythonVisited();
            case "JAVASCRIPT" -> eng.getJavascriptVisited();
            case "TYPESCRIPT" -> eng.getTypescriptVisited();
        };
    });
    
    if (!allVisited) {
        return CompletionValidationResponse.failure(
            "Not all subtopics visited in " + language
        );
    }
    
    // Check 2: All MCQs completed in this language?
    boolean allMcqsCompleted = subtopics.stream().allMatch(subtopic -> {
        UserTopicEngagement eng = getEngagement(userId, subtopic.getId());
        return switch(language) {
            case "JAVA" -> eng.getJavaMcqVisited();
            case "PYTHON" -> eng.getPythonMcqVisited();
            case "JAVASCRIPT" -> eng.getJavascriptMcqVisited();
            case "TYPESCRIPT" -> eng.getTypescriptMcqVisited();
        };
    });
    
    if (!allMcqsCompleted) {
        return CompletionValidationResponse.failure(
            "Not all MCQs completed in " + language
        );
    }
    
    // Check 3: Code problem attempted?
    UserProblemEngagement problemEng = getProblemEngagement(userId, mainTopicId);
    boolean codeAttempted = switch(language) {
        case "JAVA" -> problemEng.getJavaTimeSeconds() >= 120 || 
                       problemEng.getJavaCompleted();
        case "PYTHON" -> problemEng.getPythonTimeSeconds() >= 120 || 
                         problemEng.getPythonCompleted();
        // ... other languages
    };
    
    if (!codeAttempted) {
        return CompletionValidationResponse.failure(
            "Code problem not attempted in " + language
        );
    }
    
    // ✅ All checks passed - mark as complete!
    UserMainTopicEngagement mainEng = getMainTopicEngagement(userId, mainTopicId);
    switch(language) {
        case "JAVA" -> mainEng.setJavaCompleted(true);
        case "PYTHON" -> mainEng.setPythonCompleted(true);
        case "JAVASCRIPT" -> mainEng.setJavascriptCompleted(true);
        case "TYPESCRIPT" -> mainEng.setTypescriptCompleted(true);
    }
    
    mainEngagementRepository.save(mainEng);
    
    return CompletionValidationResponse.success(
        language + " marked as complete for " + mainTopicName
    );
}
```

#### **Step 5: Frontend shows result**

**Success:**
```javascript
// Toast notification: "✅ Java completed successfully for Data Structures!"
// Completion badge appears on language tab
// User can now mark next language (Python)
```

**Failure:**
```javascript
// Toast notification with specific error:
// "❌ Not all MCQs completed in Java"
// or
// "❌ Not all subtopics visited in Java"
// or
// "❌ Code problem not attempted in Java"
```

---

## 🎨 UI/UX Considerations

### **Mark as Complete Button States**

```javascript
// Button should be:
// 1. DISABLED if language already completed
// 2. DISABLED if not all subtopics visited (frontend check)
// 3. ENABLED only when user has visited all subtopics

const isLangCompleted = completedItems.includes(`${topic}::${language}`);
const allSubtopicsVisited = topicData?.subTopics.every(sub => {
    // Check if user spent 3+ minutes on this subtopic in this language
    return visitedLanguages.includes(`${topic}::${sub.title}::${language}::visited`);
});

<button
    onClick={handleMarkComplete}
    disabled={isLangCompleted || !allSubtopicsVisited}
    style={{
        cursor: (isLangCompleted || !allSubtopicsVisited) ? "not-allowed" : "pointer",
        background: isLangCompleted ? "#4ADE80" : 
                   (!allSubtopicsVisited ? "#9CA3AF" : "#09122C"),
        opacity: (!allSubtopicsVisited && !isLangCompleted) ? 0.6 : 1
    }}
>
    {isLangCompleted ? `Completed (${language})` : "Mark as Complete"}
</button>
```

### **Completion Indicators**

**Language Tab:**
```javascript
// Show checkmark on language tab if completed
{isLangCompleted && (
    <TbCheck style={{ color: "#4ADE80", marginLeft: 5, fontSize: "20px" }} />
)}
```

**Main Topic Sidebar:**
```javascript
// Show checkmark on main topic if ALL languages completed
const allLanguagesCompleted = 
    completedItems.includes(`${topic}::Java`) &&
    completedItems.includes(`${topic}::Python`) &&
    completedItems.includes(`${topic}::JavaScript`) &&
    completedItems.includes(`${topic}::TypeScript`);

{allLanguagesCompleted && (
    <TbCheck style={{ color: "#4ADE80", marginRight: 5, fontSize: "20px" }} />
)}
```

---

## 📋 Validation Checklist

### **Before User Can Mark Language Complete:**

| Requirement | How to Check | Auto or Manual |
|-------------|--------------|----------------|
| All subtopics visited (3+ min each) | Backend checks `{lang}Visited` flags | ✅ Auto (timer) |
| All MCQs completed | Backend checks `{lang}McqVisited` flags | 👤 Manual (user takes quiz) |
| Code problem attempted (2+ min) | Backend checks problem engagement | 👤 Manual (user codes) |

### **Frontend Responsibilities:**

- ✅ Send time updates every 30 seconds (auto-marks visited at 3 min)
- ✅ Send MCQ completion with language parameter
- ✅ Call validation API when user clicks "Mark as Complete"
- ✅ Display appropriate error messages if validation fails
- ✅ Show completion badges when successful

### **Backend Responsibilities:**

- ✅ Validate all 3 conditions before marking complete
- ✅ Return specific error messages for failed validations
- ✅ Set language-specific completion flag only when all conditions met
- ✅ Track visited status automatically based on time spent

---

## 🧪 Testing Scenarios

### **Test 1: Happy Path - All Requirements Met**

```
1. User visits all 3 subtopics in Java (3+ min each)
   ✅ Arrays: 4 min → javaVisited = true
   ✅ Linked Lists: 5 min → javaVisited = true
   ✅ Stacks: 3 min → javaVisited = true

2. User completes all MCQs in Java
   ✅ Arrays MCQ → javaMcqVisited = true
   ✅ Linked Lists MCQ → javaMcqVisited = true
   ✅ Stacks MCQ → javaMcqVisited = true

3. User attempts code problem in Java (2+ min)
   ✅ Code problem: 3 min → javaTimeSeconds = 180

4. User clicks "Mark as Complete" for Java
   ✅ Backend validates all conditions
   ✅ Sets javaCompleted = true
   ✅ Returns success message
   ✅ Frontend shows completion badge
```

### **Test 2: Missing MCQ**

```
1. User visits all subtopics ✅
2. User completes only 2 out of 3 MCQs ❌
3. User attempts code problem ✅
4. User clicks "Mark as Complete"
   ❌ Backend returns error: "Not all MCQs completed in Java"
   ❌ Frontend shows error toast
   ❌ Completion NOT marked
```

### **Test 3: Insufficient Time on Subtopic**

```
1. User visits Arrays (4 min) ✅
2. User visits Linked Lists (2 min) ❌ (< 3 min)
3. User visits Stacks (5 min) ✅
4. User clicks "Mark as Complete"
   ❌ Backend returns error: "Not all subtopics visited in Java"
   ❌ Frontend shows error toast
```

### **Test 4: Independent Language Tracking**

```
1. User completes all requirements for Java ✅
2. User marks Java as complete ✅
3. User switches to Python
   ❌ Python NOT automatically complete
   🔄 User must complete all requirements for Python separately
4. User completes all requirements for Python ✅
5. User marks Python as complete ✅
   ✅ Both Java and Python now completed independently
```

---

## 🔧 Code Changes Summary

### **1. MCQ Completion - Added Language Parameter**

**Before:**
```javascript
markQuizPassed(mainTopic, subtopic);
```

**After:**
```javascript
markQuizPassed(mainTopic, subtopic, selectedLanguage);
```

### **2. MCQ API Call - Include Language**

**Before:**
```javascript
axios.put(`${BASE_URL}/user/topic-engagement/${topicId}/mcq-visited`)
```

**After:**
```javascript
axios.put(
    `${BASE_URL}/user/topic-engagement/${topicId}/mcq-visited`,
    null,
    { params: { language: language.toUpperCase() } }
)
```

### **3. Validation API Call - Already Correct**

```javascript
axios.put(
    `${BASE_URL}/user/user-main-topic-engagement/${mainTopicId}/validate-completion`,
    null,
    { params: { language: language.toUpperCase() } }
)
```

---

## ✅ Final Checklist

- [x] Timer auto-marks subtopics as visited after 3 minutes
- [x] MCQ completion sends language parameter to backend
- [x] Mark as complete calls backend validation API
- [x] Backend validates all 3 conditions
- [x] Error messages displayed to user if validation fails
- [x] Success message and badge shown when complete
- [x] Each language tracked independently
- [x] Axios interceptor includes token automatically

---

**Status:** ✅ **IMPLEMENTATION COMPLETE**  
**Ready for Testing:** ✅ **YES**  
**Backend Integration:** ✅ **FULLY INTEGRATED**

