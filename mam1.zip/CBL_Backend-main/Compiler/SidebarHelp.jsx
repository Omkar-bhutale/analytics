import React, { useState } from 'react';
import { toast } from 'sonner';
import { TfiUnlock, TfiLock } from "react-icons/tfi";
import { IoCloseSharp } from "react-icons/io5";

// Generate random math problems
const generateMathProblem = () => {
    const operations = ['+', '-', '*'];
    const operation = operations[Math.floor(Math.random() * operations.length)];
    let num1, num2, answer;

    switch (operation) {
        case '+':
            num1 = Math.floor(Math.random() * 50) + 1;
            num2 = Math.floor(Math.random() * 50) + 1;
            answer = num1 + num2;
            break;
        case '-':
            num1 = Math.floor(Math.random() * 50) + 25;
            num2 = Math.floor(Math.random() * 25) + 1;
            answer = num1 - num2;
            break;
        case '*':
            num1 = Math.floor(Math.random() * 12) + 1;
            num2 = Math.floor(Math.random() * 12) + 1;
            answer = num1 * num2;
            break;
        default:
            num1 = 2;
            num2 = 2;
            answer = 4;
    }

    return {
        question: `What is ${num1} ${operation} ${num2}?`,
        answer: answer
    };
};

// Sidebar Help Component
const SidebarHelp = ({ hint, syntax, sol, onClose }) => {
    const { Condition } = syntax?.[0] || { Condition: [] };

    const [syntaxLock, setSyntaxLock] = useState(true);
    const [selected, setSelected] = useState('hint');
    const [solLock, setSolLock] = useState(true);
    const [mathProblem, setMathProblem] = useState(null);
    const [userAnswer, setUserAnswer] = useState('');
    const [showMathChallenge, setShowMathChallenge] = useState(false);
    const [pendingSection, setPendingSection] = useState(null);

    const handleSectionClick = (section) => {
        if (section === 'hint') {
            setSelected('hint');
            setShowMathChallenge(false);
            return;
        }

        if ((section === 'syntax' && syntaxLock) || (section === 'solution' && solLock)) {
            const problem = generateMathProblem();
            setMathProblem(problem);
            setPendingSection(section);
            setShowMathChallenge(true);
            setUserAnswer('');
        } else {
            setSelected(section);
            setShowMathChallenge(false);
        }
    };

    const handleMathSubmit = () => {
        const answer = parseInt(userAnswer);
        if (answer === mathProblem.answer) {
            setShowMathChallenge(false);
            if (pendingSection === 'syntax') {
                setSyntaxLock(false);
                setSelected('syntax');
            } else if (pendingSection === 'solution') {
                const confirmResult = window.confirm('If you see the full solution before solving, your score will not get added');
                if (confirmResult) {
                    setSolLock(false);
                    setSelected('solution');
                } else {
                    setShowMathChallenge(false);
                    return;
                }
            }
            setPendingSection(null);
            toast.success('Correct! Access granted.');
        } else {
            toast.error('Incorrect answer. Try again!');
            setUserAnswer('');
        }
    };

    const handleKeyPress = (e) => {
        if (e.key === 'Enter') {
            handleMathSubmit();
        }
    };

    return (
        <div className="sidebar-help-content">
            <div className="help-header">
                <button className="close-help-btn" onClick={onClose}>
                    <IoCloseSharp />
                </button>
            </div>
            <hr className="help-divider" />
            <nav className="help-navigation-tabs">
                <span
                    className={`help-nav-tab ${selected === 'hint' ? 'selected' : ''}`}
                    onClick={() => handleSectionClick('hint')}
                >
                    <b>Hint</b>
                    <TfiUnlock className="unlock-icon" />
                </span>

                <span
                    className={`help-nav-tab ${selected === 'syntax' ? 'selected' : ''}`}
                    onClick={() => handleSectionClick('syntax')}
                >
                    <b>Syntax</b>
                    {syntaxLock ? <TfiLock className="lock-icon" /> : <TfiUnlock className="unlock-icon" />}
                </span>

                <span
                    className={`help-nav-tab ${selected === 'solution' ? 'selected' : ''}`}
                    onClick={() => handleSectionClick('solution')}
                >
                    <b>Full Solution</b>
                    {solLock ? <TfiLock className="lock-icon" /> : <TfiUnlock className="unlock-icon" />}
                </span>
            </nav>

            <hr className="help-divider" />

            <div className="help-content-area">
                {showMathChallenge ? (
                    <div className="math-challenge-container">
                        <h3>Solve this problem to unlock:</h3>
                        <div className="math-question-display">{mathProblem?.question}</div>
                        <input
                            type="number"
                            value={userAnswer}
                            onChange={(e) => setUserAnswer(e.target.value)}
                            placeholder="Enter your answer"
                            className="math-answer-input"
                            onKeyPress={handleKeyPress}
                            autoFocus
                        />
                        <div className="math-action-buttons">
                            <button onClick={handleMathSubmit} className="math-submit-button">
                                Submit
                            </button>
                            <button
                                onClick={() => setShowMathChallenge(false)}
                                className="math-cancel-button"
                            >
                                Cancel
                            </button>
                        </div>
                    </div>
                ) : (
                    <>
                        {selected === 'hint' && (
                            <div className="help-section">
                                <h4>Hint:</h4>
                                <pre className="help-code-block"><code>{hint}</code></pre>
                            </div>
                        )}
                        {selected === 'syntax' && !syntaxLock && (
                            <div className="help-section">
                                <h4>Syntax Breakdown:</h4>
                                {Condition?.map((item, index) => (
                                    <pre key={index} className="help-code-block"><code>{item}</code></pre>
                                ))}
                            </div>
                        )}
                        {selected === 'solution' && !solLock && (
                            <div className="help-section">
                                <h4>Full Solution:</h4>
                                <pre className="help-code-block"><code>{sol}</code></pre>
                            </div>
                        )}
                    </>
                )}
            </div>
        </div>
    );
};

export default SidebarHelp;

