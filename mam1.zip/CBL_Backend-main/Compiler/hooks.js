import React, { useEffect, useCallback, useRef } from 'react';
import axios from 'axios';
import { toast } from 'sonner';

// Custom hook for fetching all compiler data
export const useCompilerData = ({
    questionId,
    setQuestion,
    setInput,
    setJavaCode,
    setPythonCode,
    setJavaScriptCode,
    setTypeScriptCode,
    setJavaSavedCode,
    setPythonSavedCode,
    setJavaScriptSavedCode,
    setTypeScriptSavedCode,
    setCode,
    setJavaTime,
    setPythonTime,
    setJavascriptTime,
    setTypescriptTime,
    setCurrentTime,
    setLastSavedJavaTime,
    setLastSavedPythonTime,
    setLastSavedJavascriptTime,
    setLastSavedTypescriptTime,
    setAlgorithm,
    setAlgorithmTime,
    setLastSavedAlgorithmTime,
    setPseudoCode,
    setPseudocodeTime,
    setLastSavedPseudocodeTime,
    setAlgorithmValidated,
    setPseudoValidated,
    setJavaCompleted,
    setPythonCompleted,
    setJavaScriptCompleted,
    setTypeScriptCompleted,
    setCurrentEditor,
    setDataLoaded
}) => {
    useEffect(() => {
        const fetchAllData = async () => {
            try {
                setDataLoaded(false);
                console.log("📥 Fetching all data from backend...");

                // Fetch question and saved codes
                const problemResponse = await axios.get(
                    `${import.meta.env.VITE_API_BASE_URL}/user/problem-submissions/${questionId}`
                );

                const data = problemResponse.data;
                const foundQuestion = data.problemDTO;

                if (foundQuestion) {
                    setQuestion(foundQuestion);
                    if (foundQuestion.testCases && foundQuestion.testCases.length > 0) {
                        setInput(foundQuestion.testCases[0].input || "");
                    }
                }

                // Load saved codes
                if (data.savedCodes) {
                    setJavaCode(data.savedCodes.java || "// Write your Java code here\npublic class Main {\n    public static void main(String[] args) {\n        \n    }\n}");
                    setPythonCode(data.savedCodes.python || "# Write your Python code here\n");
                    setJavaScriptCode(data.savedCodes.javascript || "// Write your JavaScript code here\n");
                    setTypeScriptCode(data.savedCodes.typescript || "// Write your TypeScript code here\n");

                    setJavaSavedCode(data.savedCodes.java || "// Write your Java code here\npublic class Main {\n    public static void main(String[] args) {\n        \n    }\n}");
                    setPythonSavedCode(data.savedCodes.python || "# Write your Python code here\n");
                    setJavaScriptSavedCode(data.savedCodes.javascript || "// Write your JavaScript code here\n");
                    setTypeScriptSavedCode(data.savedCodes.typescript || "// Write your TypeScript code here\n");

                    setCode(data.savedCodes.java || "// Write your Java code here\npublic class Main {\n    public static void main(String[] args) {\n        \n    }\n}");
                }

                // Load time spent for each language
                const javaTimeFromDB = data.javaTimeSeconds || 0;
                const pythonTimeFromDB = data.pythonTimeSeconds || 0;
                const jsTimeFromDB = data.javascriptTimeSeconds || 0;
                const tsTimeFromDB = data.typescriptTimeSeconds || 0;

                setJavaTime(javaTimeFromDB);
                setPythonTime(pythonTimeFromDB);
                setJavascriptTime(jsTimeFromDB);
                setTypescriptTime(tsTimeFromDB);
                setCurrentTime(javaTimeFromDB);

                setLastSavedJavaTime(javaTimeFromDB);
                setLastSavedPythonTime(pythonTimeFromDB);
                setLastSavedJavascriptTime(jsTimeFromDB);
                setLastSavedTypescriptTime(tsTimeFromDB);

                console.log("✅ Time loaded from DB:", { javaTimeFromDB, pythonTimeFromDB, jsTimeFromDB, tsTimeFromDB });

                // Fetch algorithm
                try {
                    const algoResponse = await axios.get(
                        `${import.meta.env.VITE_API_BASE_URL}/user/algorithm-submissions/problem/${questionId}`
                    );
                    if (algoResponse.data && algoResponse.data.content) {
                        setAlgorithm(algoResponse.data.content);
                        const algoTimeFromDB = algoResponse.data.totalSecondSpent || 0;
                        setAlgorithmTime(algoTimeFromDB);
                        setLastSavedAlgorithmTime(algoTimeFromDB);
                        console.log("✅ Algorithm loaded, time:", algoTimeFromDB);
                    }
                } catch (err) {
                    console.log("No algorithm found, using default");
                    setAlgorithm("// Write algorithm first");
                    setAlgorithmTime(0);
                    setLastSavedAlgorithmTime(0);
                }

                // Fetch pseudocode
                try {
                    const pseudoResponse = await axios.get(
                        `${import.meta.env.VITE_API_BASE_URL}/user/pseudocode-submissions/problem/${questionId}`
                    );
                    if (pseudoResponse.data && pseudoResponse.data.content) {
                        setPseudoCode(pseudoResponse.data.content);
                        const pseudoTimeFromDB = pseudoResponse.data.totalSecondSpent || 0;
                        setPseudocodeTime(pseudoTimeFromDB);
                        setLastSavedPseudocodeTime(pseudoTimeFromDB);
                        console.log("✅ Pseudocode loaded, time:", pseudoTimeFromDB);
                    }
                } catch (err) {
                    console.log("No pseudocode found, using default");
                    setPseudoCode("// Write pseudo code first");
                    setPseudocodeTime(0);
                    setLastSavedPseudocodeTime(0);
                }

                // Check validation status
                let algoValidResponse = null;
                let pseudoValidResponse = null;

                try {
                    algoValidResponse = await axios.get(
                        `${import.meta.env.VITE_API_BASE_URL}/user/algorithm-submissions/problem/${questionId}/is-correct`
                    );
                    const isAlgoCorrect = algoValidResponse.data === true;
                    setAlgorithmValidated(isAlgoCorrect);
                    console.log("✅ Algorithm validation status:", isAlgoCorrect);
                } catch (err) {
                    setAlgorithmValidated(false);
                    console.log("Algorithm not validated yet");
                }

                try {
                    pseudoValidResponse = await axios.get(
                        `${import.meta.env.VITE_API_BASE_URL}/user/pseudocode-submissions/problem/${questionId}/is-correct`
                    );
                    const isPseudoCorrect = pseudoValidResponse.data === true;
                    setPseudoValidated(isPseudoCorrect);
                    console.log("✅ Pseudocode validation status:", isPseudoCorrect);
                } catch (err) {
                    setPseudoValidated(false);
                    console.log("Pseudocode not validated yet");
                }

                // Fetch completion status
                try {
                    const submissionsResponse = await axios.get(
                        `${import.meta.env.VITE_API_BASE_URL}/user/problem-submissions/${questionId}/submissions`
                    );
                    submissionsResponse.data.forEach(element => {
                        if (element.isCorrect === true) {
                            if (element.language === 'JAVA') setJavaCompleted(true);
                            else if (element.language === 'PYTHON') setPythonCompleted(true);
                            else if (element.language === 'JAVASCRIPT') setJavaScriptCompleted(true);
                            else if (element.language === 'TYPESCRIPT') setTypeScriptCompleted(true);
                        }
                    });
                } catch (err) {
                    console.log("Error fetching submissions:", err);
                }

                // Determine current editor based on validation status
                let editor = 'algorithm';
                if (algoValidResponse?.data === true) {
                    if (pseudoValidResponse?.data === true) {
                        editor = 'code';
                    } else {
                        editor = 'pseudocode';
                    }
                }
                setCurrentEditor(editor);
                console.log("✅ Current editor set to:", editor);

                setDataLoaded(true);
                console.log("✅ All data loaded successfully");

            } catch (error) {
                console.error("❌ Error fetching data:", error);
                toast.error("Failed to load problem data");
                setDataLoaded(true);
            }
        };

        fetchAllData();
    }, [questionId]);
};

// Custom hook for timer management
export const useCompilerTimer = ({
    dataLoaded,
    currentEditor,
    language,
    setAlgorithmTime,
    setPseudocodeTime,
    setJavaTime,
    setPythonTime,
    setJavascriptTime,
    setTypescriptTime,
    setCurrentTime,
    timerIntervalRef
}) => {
    useEffect(() => {
        if (!dataLoaded) return;

        timerIntervalRef.current = setInterval(() => {
            if (currentEditor === 'algorithm') {
                setAlgorithmTime(prev => {
                    const newTime = prev + 1;
                    setCurrentTime(newTime);
                    return newTime;
                });
            } else if (currentEditor === 'pseudocode') {
                setPseudocodeTime(prev => {
                    const newTime = prev + 1;
                    setCurrentTime(newTime);
                    return newTime;
                });
            } else if (currentEditor === 'code') {
                if (language === 'java') {
                    setJavaTime(prev => {
                        const newTime = prev + 1;
                        setCurrentTime(newTime);
                        return newTime;
                    });
                } else if (language === 'python') {
                    setPythonTime(prev => {
                        const newTime = prev + 1;
                        setCurrentTime(newTime);
                        return newTime;
                    });
                } else if (language === 'javascript') {
                    setJavascriptTime(prev => {
                        const newTime = prev + 1;
                        setCurrentTime(newTime);
                        return newTime;
                    });
                } else if (language === 'typescript') {
                    setTypescriptTime(prev => {
                        const newTime = prev + 1;
                        setCurrentTime(newTime);
                        return newTime;
                    });
                }
            }
        }, 1000);

        return () => {
            if (timerIntervalRef.current) {
                clearInterval(timerIntervalRef.current);
            }
        };
    }, [dataLoaded, currentEditor, language]);
};

// Custom hook for auto-save functionality
export const useCompilerAutoSave = ({
    dataLoaded,
    currentEditor,
    algorithm,
    pseudoCode,
    javaCode,
    pythonCode,
    javaScriptCode,
    typeScriptCode,
    javaTime,
    pythonTime,
    javascriptTime,
    typescriptTime,
    algorithmTime,
    pseudocodeTime,
    lastSavedJavaTime,
    lastSavedPythonTime,
    lastSavedJavascriptTime,
    lastSavedTypescriptTime,
    lastSavedAlgorithmTime,
    lastSavedPseudocodeTime,
    algorithmValidated,
    pseudoValidated,
    questionId,
    setLastSavedAlgorithmTime,
    setLastSavedPseudocodeTime,
    setLastSavedJavaTime,
    setLastSavedPythonTime,
    setLastSavedJavascriptTime,
    setLastSavedTypescriptTime,
    autoSaveIntervalRef
}) => {
    const latestRef = useRef(null);

    // Keep a snapshot of the latest state used for saving
    useEffect(() => {
        latestRef.current = {
            dataLoaded,
            currentEditor,
            algorithm,
            pseudoCode,
            javaCode,
            pythonCode,
            javaScriptCode,
            typeScriptCode,
            javaTime,
            pythonTime,
            javascriptTime,
            typescriptTime,
            algorithmTime,
            pseudocodeTime,
            lastSavedJavaTime,
            lastSavedPythonTime,
            lastSavedJavascriptTime,
            lastSavedTypescriptTime,
            lastSavedAlgorithmTime,
            lastSavedPseudocodeTime,
            algorithmValidated,
            pseudoValidated,
            questionId
        };
    }, [
        dataLoaded,
        currentEditor,
        algorithm,
        pseudoCode,
        javaCode,
        pythonCode,
        javaScriptCode,
        typeScriptCode,
        javaTime,
        pythonTime,
        javascriptTime,
        typescriptTime,
        algorithmTime,
        pseudocodeTime,
        lastSavedJavaTime,
        lastSavedPythonTime,
        lastSavedJavascriptTime,
        lastSavedTypescriptTime,
        lastSavedAlgorithmTime,
        lastSavedPseudocodeTime,
        algorithmValidated,
        pseudoValidated,
        questionId
    ]);

    const saveToDatabase = useCallback(async () => {
        const snap = latestRef.current;
        if (!snap || !snap.dataLoaded) {
            return;
        }

        try {
            const {
                currentEditor,
                algorithm,
                pseudoCode,
                javaCode,
                pythonCode,
                javaScriptCode,
                typeScriptCode,
                javaTime,
                pythonTime,
                javascriptTime,
                typescriptTime,
                algorithmTime,
                pseudocodeTime,
                lastSavedJavaTime,
                lastSavedPythonTime,
                lastSavedJavascriptTime,
                lastSavedTypescriptTime,
                lastSavedAlgorithmTime,
                lastSavedPseudocodeTime,
                algorithmValidated,
                pseudoValidated,
                questionId
            } = snap;

            if (currentEditor === 'algorithm') {
                const timeDelta = algorithmTime - lastSavedAlgorithmTime;
                if (timeDelta > 0 || algorithm !== "// Write algorithm first") {
                    const algoData = {
                        problemId: parseInt(questionId),
                        content: algorithm,
                        isCorrect: algorithmValidated,
                        totalSecondSpent: timeDelta
                    };

                    await axios.post(
                        `${import.meta.env.VITE_API_BASE_URL}/user/algorithm-submissions`,
                        algoData,
                        { headers: { 'Content-Type': 'application/json' } }
                    );
                    setLastSavedAlgorithmTime(algorithmTime);
                }
            } else if (currentEditor === 'pseudocode') {
                const timeDelta = pseudocodeTime - lastSavedPseudocodeTime;
                if (timeDelta > 0 || pseudoCode !== "// Write pseudo code first") {
                    const pseudoData = {
                        problemId: parseInt(questionId),
                        content: pseudoCode,
                        isCorrect: pseudoValidated,
                        totalSecondSpent: timeDelta
                    };

                    await axios.post(
                        `${import.meta.env.VITE_API_BASE_URL}/user/pseudocode-submissions`,
                        pseudoData,
                        { headers: { 'Content-Type': 'application/json' } }
                    );
                    setLastSavedPseudocodeTime(pseudocodeTime);
                }
            } else if (currentEditor === 'code') {
                const javaDelta = javaTime - lastSavedJavaTime;
                const pythonDelta = pythonTime - lastSavedPythonTime;
                const jsDelta = javascriptTime - lastSavedJavascriptTime;
                const tsDelta = typescriptTime - lastSavedTypescriptTime;

                if (javaDelta > 0 || pythonDelta > 0 || jsDelta > 0 || tsDelta > 0) {
                    const codeData = {
                        problemId: parseInt(questionId),
                        savedCodes: {
                            java: javaCode,
                            python: pythonCode,
                            javascript: javaScriptCode,
                            typescript: typeScriptCode
                        },
                        javaTimeSeconds: javaDelta,
                        pythonTimeSeconds: pythonDelta,
                        javascriptTimeSeconds: jsDelta,
                        typescriptTimeSeconds: tsDelta
                    };

                    await axios.put(
                        `${import.meta.env.VITE_API_BASE_URL}/user/problem-submissions/save-code`,
                        codeData,
                        { headers: { 'Content-Type': 'application/json' } }
                    );

                    setLastSavedJavaTime(javaTime);
                    setLastSavedPythonTime(pythonTime);
                    setLastSavedJavascriptTime(javascriptTime);
                    setLastSavedTypescriptTime(typescriptTime);
                }
            }
        } catch (error) {
            console.error('Auto-save error:', error);
        }
    }, [
        setLastSavedAlgorithmTime,
        setLastSavedPseudocodeTime,
        setLastSavedJavaTime,
        setLastSavedPythonTime,
        setLastSavedJavascriptTime,
        setLastSavedTypescriptTime
    ]);

    useEffect(() => {
        if (!dataLoaded) return;

        autoSaveIntervalRef.current = setInterval(() => {
            saveToDatabase();
        }, 15000);

        return () => {
            if (autoSaveIntervalRef.current) {
                clearInterval(autoSaveIntervalRef.current);
            }
        };
    }, [dataLoaded, saveToDatabase, autoSaveIntervalRef]);

    return { saveToDatabase };
}
