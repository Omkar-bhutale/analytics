import React from 'react';

// Full Screen Overlay Loader Component
const FullScreenLoader = ({
    isVisible,
    message = "Processing...",
    subMessage = "Please wait while we process your request",
    loaderType = "spinner" // spinner, pulse, dots, wave, enhanced
}) => {
    if (!isVisible) return null;

    const renderLoader = () => {
        switch (loaderType) {
            case 'pulse':
                return <div className="pulse-loader"></div>;
            case 'dots':
                return (
                    <div className="dots-loader">
                        <div></div>
                        <div></div>
                        <div></div>
                    </div>
                );
            case 'wave':
                return (
                    <div className="wave-loader">
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                    </div>
                );
            case 'enhanced':
                return <div className="spinner-enhanced"></div>;
            default:
                return <div className="spinner"></div>;
        }
    };

    return (
        <div className="loader-overlay">
            <div className="loader-container">
                {renderLoader()}
                <h3 className="loader-text">{message}</h3>
                {subMessage && <p className="loader-subtext">{subMessage}</p>}
                <div className="loader-progress"></div>
            </div>
        </div>
    );
};

export default FullScreenLoader;

