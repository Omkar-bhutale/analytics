import React, { useState, useEffect } from "react";
import Editor from "@monaco-editor/react";
import axios from 'axios';
import '../Styles/Compiler.css';
import Navbar from "../Navbar";
import { useParams, Link, useLocation } from "react-router-dom";
import { Toaster, toast } from 'sonner';
import { TbBulb } from "react-icons/tb";
import FullScreenLoader from "./FullScreenLoader";
import SidebarHelp from "./SidebarHelp";
import {
    useCompilerData,
    useCompilerTimer,
    useCompilerAutoSave
} from "./hooks";
import {
    formatTime,
    checkAlgorithmAPI,
    checkPseudocodeAPI,
    checkCodeAPI,
    runCodeAPI,
    submitCodeAPI
} from "./utils";

const Compiler = ({ onLogout }) => {
    const { questionId } = useParams();
    const location = useLocation();

    // State Management
    const [pythonCode, setPythonCode] = useState("");
    const [javaCode, setJavaCode] = useState("");
    const [javaScriptCode, setJavaScriptCode] = useState("");
    const [typeScriptCode, setTypeScriptCode] = useState("");
    const [code, setCode] = useState("// Write your code here \n public class Main { \n}");
    const [pseudoCode, setPseudoCode] = useState("// Write pseudo code first");
    const [language, setLanguage] = useState("java");
    const [input, setInput] = useState("");
    const [output, setOutput] = useState(null);
    const [loading, setLoading] = useState(false);
    const [checkLoading, setCheckLoading] = useState(false);
    const [checkCodeLoading, setCheckCodeLoading] = useState(false);
    const [algorithmLoading, setAlgorithmLoading] = useState(false);
    const [question, setQuestion] = useState(null);
    const [javaCompleted, setJavaCompleted] = useState(false);
    const [pythonCompleted, setPythonCompleted] = useState(false);
    const [javaScriptCompleted, setJavaScriptCompleted] = useState(false);
    const [typeScriptCompleted, setTypeScriptCompleted] = useState(false);
    const [showHelp, setShowHelp] = useState(false);
    const [algorithm, setAlgorithm] = useState("// Write algorithm first");
    const [feedback, setFeedback] = useState("");
    const [passedCount, setPassedCount] = useState(0);
    const [showPopup, setShowPopup] = useState(false);
    const [currentEditor, setCurrentEditor] = useState('algorithm');

    // Timer state - per language tracking (in seconds)
    const [javaTime, setJavaTime] = useState(0);
    const [pythonTime, setPythonTime] = useState(0);
    const [javascriptTime, setJavascriptTime] = useState(0);
    const [typescriptTime, setTypescriptTime] = useState(0);
    const [algorithmTime, setAlgorithmTime] = useState(0);
    const [pseudocodeTime, setPseudocodeTime] = useState(0);
    const [currentTime, setCurrentTime] = useState(0);

    // Track last saved time to send only deltas to backend
    const [lastSavedJavaTime, setLastSavedJavaTime] = useState(0);
    const [lastSavedPythonTime, setLastSavedPythonTime] = useState(0);
    const [lastSavedJavascriptTime, setLastSavedJavascriptTime] = useState(0);
    const [lastSavedTypescriptTime, setLastSavedTypescriptTime] = useState(0);
    const [lastSavedAlgorithmTime, setLastSavedAlgorithmTime] = useState(0);
    const [lastSavedPseudocodeTime, setLastSavedPseudocodeTime] = useState(0);

    // Resizer states
    const [leftWidth, setLeftWidth] = useState(30);
    const [bottomHeight, setBottomHeight] = useState(30);
    const [isResizing, setIsResizing] = useState(null);

    // Validation states
    const [algorithmValidated, setAlgorithmValidated] = useState(false);
    const [pseudoValidated, setPseudoValidated] = useState(false);
    const [dataLoaded, setDataLoaded] = useState(false);
    const [savedWithoutChange, setSavedWithoutChange] = useState(true);
    const [javaSavedCode, setJavaSavedCode] = useState("");
    const [pythonSavedCode, setPythonSavedCode] = useState("");
    const [javaScriptSavedCode, setJavaScriptSavedCode] = useState("");
    const [typeScriptSavedCode, setTypeScriptSavedCode] = useState("");

    // Auto-save interval ref
    const autoSaveIntervalRef = React.useRef(null);
    const timerIntervalRef = React.useRef(null);

    // Use custom hooks
    useCompilerData({
        questionId,
        setQuestion,
        setInput,
        setJavaCode,
        setPythonCode,
        setJavaScriptCode,
        setTypeScriptCode,
        setJavaSavedCode,
        setPythonSavedCode,
        setJavaScriptSavedCode,
        setTypeScriptSavedCode,
        setCode,
        setJavaTime,
        setPythonTime,
        setJavascriptTime,
        setTypescriptTime,
        setCurrentTime,
        setLastSavedJavaTime,
        setLastSavedPythonTime,
        setLastSavedJavascriptTime,
        setLastSavedTypescriptTime,
        setAlgorithm,
        setAlgorithmTime,
        setLastSavedAlgorithmTime,
        setPseudoCode,
        setPseudocodeTime,
        setLastSavedPseudocodeTime,
        setAlgorithmValidated,
        setPseudoValidated,
        setJavaCompleted,
        setPythonCompleted,
        setJavaScriptCompleted,
        setTypeScriptCompleted,
        setCurrentEditor,
        setDataLoaded
    });

    useCompilerTimer({
        dataLoaded,
        currentEditor,
        language,
        setAlgorithmTime,
        setPseudocodeTime,
        setJavaTime,
        setPythonTime,
        setJavascriptTime,
        setTypescriptTime,
        setCurrentTime,
        timerIntervalRef
    });

    const { saveToDatabase } = useCompilerAutoSave({
        dataLoaded,
        currentEditor,
        algorithm,
        pseudoCode,
        javaCode,
        pythonCode,
        javaScriptCode,
        typeScriptCode,
        javaTime,
        pythonTime,
        javascriptTime,
        typescriptTime,
        algorithmTime,
        pseudocodeTime,
        lastSavedJavaTime,
        lastSavedPythonTime,
        lastSavedJavascriptTime,
        lastSavedTypescriptTime,
        lastSavedAlgorithmTime,
        lastSavedPseudocodeTime,
        algorithmValidated,
        pseudoValidated,
        questionId,
        setLastSavedAlgorithmTime,
        setLastSavedPseudocodeTime,
        setLastSavedJavaTime,
        setLastSavedPythonTime,
        setLastSavedJavascriptTime,
        setLastSavedTypescriptTime,
        autoSaveIntervalRef
    });

    // ==================== SAVE ON LANGUAGE SWITCH ====================
    useEffect(() => {
        if (!dataLoaded) return;

        const saveAndSwitch = async () => {
            await saveToDatabase();

            // Update current code based on language
            if (language === 'java') {
                setCode(javaCode);
                setCurrentTime(javaTime);
            } else if (language === 'python') {
                setCode(pythonCode);
                setCurrentTime(pythonTime);
            } else if (language === 'javascript') {
                setCode(javaScriptCode);
                setCurrentTime(javascriptTime);
            } else if (language === 'typescript') {
                setCode(typeScriptCode);
                setCurrentTime(typescriptTime);
            }
        };

        saveAndSwitch();
    }, [language, dataLoaded, saveToDatabase, javaCode, pythonCode, javaScriptCode, typeScriptCode, javaTime, pythonTime, javascriptTime, typescriptTime, setCode, setCurrentTime]);

    // ==================== SAVE ON TAB/WINDOW CLOSE ====================
    useEffect(() => {
        const handleBeforeUnload = async (event) => {
            event.preventDefault();
            await saveToDatabase();
            event.returnValue = "";
        };

        const handleVisibilityChange = async () => {
            if (document.hidden) {
                await saveToDatabase();
            }
        };

        window.addEventListener("beforeunload", handleBeforeUnload);
        document.addEventListener("visibilitychange", handleVisibilityChange);

        return () => {
            window.removeEventListener("beforeunload", handleBeforeUnload);
            document.removeEventListener("visibilitychange", handleVisibilityChange);
            saveToDatabase();
        };
    }, [saveToDatabase]);

    // ==================== HANDLER FUNCTIONS ====================
    const checkAlgorithm = async () => {
        if (!question) {
            setFeedback("Question not loaded yet. Please wait.");
            return;
        }

        if (!algorithm.trim() || algorithm.trim() === "// Write algorithm first") {
            setFeedback("Please write some algorithm first.");
            return;
        }

        setAlgorithmLoading(true);

        try {
            const result = await checkAlgorithmAPI(question.description, algorithm);

            if (result.valid) {
                setAlgorithmValidated(true);

                const timeDelta = algorithmTime - lastSavedAlgorithmTime;
                const algoData = {
                    problemId: parseInt(questionId),
                    content: algorithm,
                    isCorrect: true,
                    totalSecondSpent: timeDelta
                };

                await axios.post(
                    `${import.meta.env.VITE_API_BASE_URL}/user/algorithm-submissions`,
                    algoData,
                    { headers: { 'Content-Type': 'application/json' } }
                );

                setLastSavedAlgorithmTime(algorithmTime);
                setCurrentEditor('pseudocode');
                setFeedback("✅ Your algorithm is correct! Now write pseudocode.");
                toast.success("Algorithm validated successfully!");
            } else {
                setFeedback(`❌ ${result.feedback || "Algorithm validation failed. Try again."}`);
            }
        } catch (error) {
            console.error("Algorithm validation error:", error);
            setFeedback("⚠️ Error checking algorithm. Please try again.");
        } finally {
            setAlgorithmLoading(false);
        }
    };

    const checkCode = async () => {
        if (!question) {
            setFeedback("Question not loaded yet. Please wait.");
            return;
        }

        if (!pseudoCode.trim() || pseudoCode.trim() === "// Write pseudo code first") {
            setFeedback("Please write some pseudocode first.");
            return;
        }

        setCheckLoading(true);

        try {
            const result = await checkPseudocodeAPI(question.description, pseudoCode);

            if (result.valid) {
                setPseudoValidated(true);

                const timeDelta = pseudocodeTime - lastSavedPseudocodeTime;
                const pseudoData = {
                    problemId: parseInt(questionId),
                    content: pseudoCode,
                    isCorrect: true,
                    totalSecondSpent: timeDelta
                };

                await axios.post(
                    `${import.meta.env.VITE_API_BASE_URL}/user/pseudocode-submissions`,
                    pseudoData,
                    { headers: { 'Content-Type': 'application/json' } }
                );

                setLastSavedPseudocodeTime(pseudocodeTime);
                setCurrentEditor('code');
                setFeedback("✅ Your pseudocode is correct! Now you can solve the question.");
                toast.success("Pseudocode validated successfully!");
            } else {
                setFeedback(`❌ ${result.feedback || "Pseudocode validation failed. Try again."}`);
            }
        } catch (error) {
            console.error("Pseudocode validation error:", error);
            setFeedback("⚠️ Error checking pseudocode. Please try again.");
        } finally {
            setCheckLoading(false);
        }
    };

    const CodeEditor = async () => {
        if (!question) {
            setFeedback("Question not loaded yet. Please wait.");
            return;
        }

        if (!code.trim()) {
            setFeedback("Please write some code first.");
            return;
        }

        setCheckCodeLoading(true);

        try {
            const result = await checkCodeAPI(question.description, code, language);

            if (result.valid) {
                setFeedback("✅ Your code looks good. Running...");
            } else {
                setFeedback(`❌ ${result.feedback}`);
            }
        } catch (error) {
            setFeedback("⚠️ Error checking code. Please try again.");
        } finally {
            setCheckCodeLoading(false);
        }
    };

    // Mouse event handlers for resizing
    const handleMouseDown = (type) => (e) => {
        setIsResizing(type);
        e.preventDefault();
    };

    const handleMouseMove = (e) => {
        if (!isResizing) return;

        if (isResizing === 'horizontal') {
            const newWidth = (e.clientX / window.innerWidth) * 100;
            if (newWidth > 20 && newWidth < 60) {
                setLeftWidth(newWidth);
            }
        } else if (isResizing === 'vertical') {
            const rect = document.querySelector('.editor-section')?.getBoundingClientRect();
            if (rect) {
                const newHeight = ((e.clientY - rect.top) / rect.height) * 100;
                if (newHeight > 20 && newHeight < 80) {
                    setBottomHeight(100 - newHeight);
                }
            }
        }
    };

    const handleMouseUp = () => {
        setIsResizing(null);
    };

    const setcodesnippet = (lang) => {
        if (lang === "java") setCode(javaSavedCode || "// Write your Java code here\npublic class Main {\n    public static void main(String[] args) {\n        \n    }\n}");
        else if (lang === "python") setCode(pythonSavedCode || "# Write your Python code here\n")
        else if (lang === "javascript") setCode(javaScriptSavedCode || "// Write your JavaScript code here\n")
        else setCode(typeScriptSavedCode || "// Write your TypeScript code here\n")
    }

    // Resizing Effect
    useEffect(() => {
        if (isResizing) {
            document.addEventListener('mousemove', handleMouseMove);
            document.addEventListener('mouseup', handleMouseUp);
            return () => {
                document.removeEventListener('mousemove', handleMouseMove);
                document.removeEventListener('mouseup', handleMouseUp);
            };
        }
    }, [isResizing]);

    // Editor Change Handlers
    const handleEditorChange1 = (value) => {
        setSavedWithoutChange(false)
        if (language === 'java') {
            setJavaCode(value || javaSavedCode);
        }
        else if (language === 'python') {
            setPythonCode(value || pythonSavedCode);
        }
        else if (language === 'javascript') {
            setJavaScriptCode(value || javaScriptSavedCode);
        }
        else if (language === 'typescript') {
            setTypeScriptCode(value || typeScriptSavedCode);
        }
        setCode(value || code);
    }
    const handleEditorChange2 = (value) => setPseudoCode(value || "");
    const handleEditorChange3 = (value) => setAlgorithm(value || "");

    // Language Change Handler
    const handleLanguageChange = (e) => {
        const lang = e.target.value;
        setLanguage(lang);
        setcodesnippet(lang);
    };

    // Input Change Handler
    const handleInputChange = (e) => setInput(e.target.value);

    // Save Code Function
    const saveCode = async () => {
        if (currentEditor === 'code') {
            try {
                const javaDelta = javaTime - lastSavedJavaTime;
                const pythonDelta = pythonTime - lastSavedPythonTime;
                const jsDelta = javascriptTime - lastSavedJavascriptTime;
                const tsDelta = typescriptTime - lastSavedTypescriptTime;

                const responseDataCode = {
                    "problemId": parseInt(questionId),
                    "savedCodes": {
                        "java": javaCode,
                        "python": pythonCode,
                        "javascript": javaScriptCode,
                        "typescript": typeScriptCode
                    },
                    "javaTimeSeconds": javaDelta,
                    "pythonTimeSeconds": pythonDelta,
                    "javascriptTimeSeconds": jsDelta,
                    "typescriptTimeSeconds": tsDelta
                }

                await axios.put(
                    `${import.meta.env.VITE_API_BASE_URL}/user/problem-submissions/save-code`,
                    responseDataCode,
                    { headers: { 'Content-Type': 'application/json' } }
                );

                setLastSavedJavaTime(javaTime);
                setLastSavedPythonTime(pythonTime);
                setLastSavedJavascriptTime(javascriptTime);
                setLastSavedTypescriptTime(typescriptTime);

                if (!savedWithoutChange) {
                    toast.success("Code and time saved successfully");
                } else {
                    toast.success("Time saved successfully");
                }
                setSavedWithoutChange(true);
            } catch (err) {
                console.error("Save error:", err);
                toast.error("Code saving failed");
            }
        }
        else if (currentEditor === 'algorithm') {
            try {
                const timeDelta = algorithmTime - lastSavedAlgorithmTime;

                const responseDataAlgorithm = {
                    "problemId": parseInt(questionId),
                    "content": algorithm,
                    "isCorrect": algorithmValidated,
                    "totalSecondSpent": timeDelta
                }

                await axios.post(
                    `${import.meta.env.VITE_API_BASE_URL}/user/algorithm-submissions`,
                    responseDataAlgorithm,
                    { headers: { 'Content-Type': 'application/json' } }
                );
// Main Compiler Component
                setLastSavedAlgorithmTime(algorithmTime);
                toast.success("Algorithm Saved Successfully");
            } catch (err) {
                console.error(err);
                toast.error("Algorithm saving failed");
            }
        }
        else if (currentEditor === 'pseudocode') {
            try {
                const timeDelta = pseudocodeTime - lastSavedPseudocodeTime;

                const responseDataPseudocode = {
                    "problemId": parseInt(questionId),
                    "content": pseudoCode,
                    "isCorrect": pseudoValidated,
                    "totalSecondSpent": timeDelta
                }

                await axios.post(
                    `${import.meta.env.VITE_API_BASE_URL}/user/pseudocode-submissions`,
                    responseDataPseudocode,
                    { headers: { 'Content-Type': 'application/json' } }
                );

                setLastSavedPseudocodeTime(pseudocodeTime);
                toast.success("Pseudocode Saved Successfully");
            } catch (err) {
                console.error(err);
                toast.error("Pseudocode saving failed");
            }
        }
    };

    const runCode = async () => {
        if (!code.trim()) {
            toast.error("Please write some code first.");
            return;
        }

        setLoading(true);
        setOutput("Running...");

        try {
            const result = await runCodeAPI(language, code, input.replace(" ", "\n"));
            setOutput(result.output || "No output received");
        } catch (error) {
            console.error("Run error:", error);
            setOutput(error.response?.data?.error || "Compilation/Runtime Error");
        } finally {
            setLoading(false);
        }
    };

    const submitCode = async () => {
        if (!question || !question.testCases) {
            toast.error("No test cases available for this question.");
            return;
        }

        if (!code.trim()) {
            toast.error("Please write some code first.");
            return;
        }

        setLoading(true);

        try {
            const result = await submitCodeAPI({
                question,
                code,
                language,
                questionId,
                javaCode,
                pythonCode,
                javaScriptCode,
                typeScriptCode,
                javaTime,
                pythonTime,
                javascriptTime,
                typescriptTime,
                lastSavedJavaTime,
                lastSavedPythonTime,
                lastSavedJavascriptTime,
                lastSavedTypescriptTime
            });

            setPassedCount(result.passedCount);
            setOutput(result.output);

            if (result.allPassed) {
                toast.success(`All ${question.testCases.length} test cases passed!`);

                if (language === "python") setPythonCompleted(true);
                if (language === "java") setJavaCompleted(true);
                if (language === "javascript") setJavaScriptCompleted(true);
                if (language === "typescript") setTypeScriptCompleted(true);
            } else {
                toast.error(`${result.passedCount}/${question.testCases.length} test cases passed.`);
            }

            // Update last saved times
            if (language === 'java') setLastSavedJavaTime(javaTime);
            else if (language === 'python') setLastSavedPythonTime(pythonTime);
            else if (language === 'javascript') setLastSavedJavascriptTime(javascriptTime);
            else if (language === 'typescript') setLastSavedTypescriptTime(typescriptTime);

        } catch (error) {
            console.error("❌ Submit error:", error);
            toast.error(`Error submitting code: ${error.message}`);
        } finally {
            setLoading(false);
        }
    };

    // ==================== FETCH COMPLETION STATUS ====================
    useEffect(() => {
        const fetchCompletionStatus = async () => {
            try {
                const response = await axios.get(
                    `${import.meta.env.VITE_API_BASE_URL}/user/problem-submissions/${questionId}/submissions`
                );
                response.data.forEach(element => {
                    if (element.isCorrect === true) {
                        if (element.language === 'JAVA') setJavaCompleted(true);
                        else if (element.language === 'PYTHON') setPythonCompleted(true);
                        else if (element.language === 'JAVASCRIPT') setJavaScriptCompleted(true);
                        else if (element.language === 'TYPESCRIPT') setTypeScriptCompleted(true);
                    }
                });
            } catch (err) {
                console.error("❌ Error fetching completion status:", err);
            }
        };

        fetchCompletionStatus();
    }, [questionId, location.key]);

    return (
        <div className="compiler-container">
            <Toaster richColors position="top-center" />
            <Navbar onLogout={onLogout} />

            {/* Full Screen Overlay Loaders */}
            <FullScreenLoader
                isVisible={checkLoading}
                message="Validating Pseudocode"
                subMessage="AI is analyzing your pseudocode logic..."
                loaderType="enhanced"
            />
            <FullScreenLoader
                isVisible={checkCodeLoading}
                message="Validating Code"
                subMessage="AI is analyzing your code logic..."
                loaderType="enhanced"
            />
            <FullScreenLoader
                isVisible={algorithmLoading}
                message="Validating Algorithm"
                subMessage="AI is analyzing your algorithm logic..."
                loaderType="enhanced"
            />
            <FullScreenLoader
                isVisible={loading}
                message="Processing Code"
                subMessage="Running your code against test cases..."
                loaderType="wave"
            />

            <main className="compiler-content">
                {/* Left Section - Problem Description */}
                <div className="description-section" style={{ width: `${leftWidth}%` }}>
                    {showHelp ? (
                        <SidebarHelp
                            hint={question?.hint}
                            syntax={question?.syntax_breakdown}
                            sol={question?.solution}
                            onClose={() => setShowHelp(false)}
                        />
                    ) : (
                        question && (
                            <div className="description">
                                <Link to="/questions" state={{ selectedTopic: location.state?.selectedTopic, selectedSubTopic: location.state?.selectedSubTopic }}>
                                    <button className="comp-back-button">&larr;Back</button>
                                </Link>
                                <h2>{question.title}</h2>

                                <h3>Problem Statement:</h3>
                                <div className="comp-desc">{question.description}</div>

                                <h3>Difficulty:</h3>
                                <pre style={{ fontSize: "18px" }}>{question.difficulty}</pre>

                                {question.testCases && question.testCases.some(tc => tc.isPublic) ? (
                                    <>
                                        <h3>Sample Test Cases:</h3>
                                        {question.testCases
                                            .filter(tc => tc.isPublic)
                                            .map((tc, index) => (
                                                <div key={tc.testCaseId} className="testcase-block">
                                                    <h4>Test Case {index + 1}</h4>
                                                    <strong>Input:</strong>
                                                    <pre style={{ fontSize: "16px" }}>{tc.input}</pre>
                                                    <strong>Expected Output:</strong>
                                                    <pre style={{ fontSize: "16px" }}>{tc.expectedOutput}</pre>
                                                </div>
                                            ))}
                                    </>
                                ) : (
                                    <p>No public test cases available.</p>
                                )}
                            </div>
                        )
                    )}
                </div>

                {/* Horizontal Resizer */}
                <div className="horizontal-resizer" onMouseDown={handleMouseDown('horizontal')} />

                {/* Right Section - Editors and Output */}
                <div className="editor-section" style={{ width: `${100 - leftWidth}%` }}>
                    {/* Toolbar */}
                    <div className="editor-toolbar">
                        {currentEditor === 'code' && (
                            <>
                                <label htmlFor="language-switcher" className="language-label">Choose Language:</label>
                                <select id="language-switcher" className="language-switcher" value={language} onChange={handleLanguageChange}>
                                    <option value="java">{"Java "}{javaCompleted ? "✔" : ""}</option>
                                    <option value="python">{"Python "}{pythonCompleted ? "✔" : ""}</option>
                                    <option value="javascript">{"JavaScript "}{javaScriptCompleted ? "✔" : ""}</option>
                                    <option value="typescript">{"TypeScript "}{typeScriptCompleted ? "✔" : ""}</option>
                                </select>
                            </>
                        )}
                        <div className="timer-span">{formatTime(currentTime)}</div>

                        <div className="editor-buttons">
                            <button className="action-button" onClick={() => setShowHelp(true)}>
                                <TbBulb />
                            </button>
                            <button className="action-button" onClick={saveCode}>Save</button>

                            {currentEditor === 'algorithm' && (
                                <button
                                    className="action-button"
                                    onClick={checkAlgorithm}
                                    disabled={algorithmLoading}
                                    style={{
                                        opacity: algorithmLoading ? 0.7 : 1,
                                        cursor: algorithmLoading ? 'not-allowed' : 'pointer'
                                    }}
                                >
                                    Validate Algorithm
                                </button>
                            )}

                            {currentEditor === 'pseudocode' && (
                                <button
                                    className="action-button"
                                    onClick={checkCode}
                                    disabled={checkLoading}
                                    style={{
                                        opacity: checkLoading ? 0.7 : 1,
                                        cursor: checkLoading ? 'not-allowed' : 'pointer'
                                    }}
                                >
                                    Validate
                                </button>
                            )}

                            {currentEditor === 'code' && (
                                <>
                                    <button className="action-button" onClick={CodeEditor} disabled={checkLoading}>
                                        CheckCode
                                    </button>
                                    <button className="action-button" onClick={runCode} disabled={loading}>
                                        Run
                                    </button>
                                    <button className="action-button" onClick={submitCode} disabled={loading}>
                                        Submit
                                    </button>
                                    <button className="action-button" onClick={() => setShowPopup(true)}>
                                        Show Feedback
                                    </button>
                                    {showPopup && (
                                        <div
                                            style={{
                                                position: "fixed",
                                                top: 0,
                                                left: 0,
                                                width: "100vw",
                                                height: "100vh",
                                                backgroundColor: "rgba(0,0,0,0.5)",
                                                display: "flex",
                                                justifyContent: "center",
                                                alignItems: "center",
                                                zIndex: 1000,
                                            }}
                                            onClick={() => setShowPopup(false)}
                                        >
                                            <div
                                                style={{
                                                    backgroundColor: "#fff",
                                                    padding: "20px",
                                                    borderRadius: "10px",
                                                    width: "350px",
                                                    textAlign: "center",
                                                    boxShadow: "0 4px 8px rgba(0,0,0,0.2)",
                                                }}
                                                onClick={(e) => e.stopPropagation()}
                                            >
                                                {passedCount > 0 ? (
                                                    <p style={{ color: "green", fontWeight: "bold" }}>
                                                        ✅ You passed {passedCount} test case{passedCount > 1 ? "s" : ""}!
                                                    </p>
                                                ) : (
                                                    <p style={{ color: "red", fontWeight: "bold" }}>
                                                        ❌ 0 test cases passed.
                                                    </p>
                                                )}
                                                <p style={{ marginTop: "10px", color: "#555" }}>
                                                    Feedback: "Your code looks clean, but optimize your loops.
                                                    need to improve in using the loops and condition update"
                                                </p>
                                                <button
                                                    onClick={() => setShowPopup(false)}
                                                    style={{
                                                        marginTop: "15px",
                                                        padding: "6px 12px",
                                                        backgroundColor: "#FBB034",
                                                        color: "#fff",
                                                        border: "none",
                                                        borderRadius: "4px",
                                                        cursor: "pointer",
                                                    }}
                                                >Close</button>
                                            </div>
                                        </div>
                                    )}
                                </>
                            )}
                        </div>
                    </div>

                    {/* Editors Container */}
                    <div style={{ display: "flex", height: `${100 - bottomHeight}%` }}>
                        {currentEditor === 'algorithm' && (
                            <div className="editor-container" style={{ width: "100%" }}>
                                <div style={{ padding: "8px", background: "#1e1e1e", color: "#fff", fontSize: "16px", borderBottom: "1px solid #333", fontWeight: 700 }}>
                                    Algorithm Editor
                                </div>
                                <Editor
                                    height="calc(100% - 32px)"
                                    language="text"
                                    value={algorithm}
                                    theme="vs-dark"
                                    onChange={handleEditorChange3}
                                    options={{
                                        minimap: { enabled: false },
                                        fontSize: 14,
                                        wordWrap: "on",
                                        lineNumbers: "on",
                                    }}
                                />
                            </div>
                        )}
                        {currentEditor === 'pseudocode' && (
                            <div className="editor-container" style={{ width: "100%" }}>
                                <div style={{ padding: "8px", background: "#1e1e1e", color: "#fff", fontSize: "16px", borderBottom: "1px solid #333", fontWeight: 700 }}>
                                    Pseudocode Editor
                                </div>
                                <Editor
                                    height="calc(100% - 32px)"
                                    language="text"
                                    value={pseudoCode}
                                    theme="vs-dark"
                                    onChange={handleEditorChange2}
                                    options={{
                                        minimap: { enabled: false },
                                        fontSize: 14,
                                        wordWrap: "on",
                                        lineNumbers: "on",
                                    }}
                                />
                            </div>
                        )}
                        {currentEditor === 'code' && (
                            <div className="editor-container" style={{ width: "100%" }}>
                                <div style={{ padding: "8px", background: "#1e1e1e", color: "#fff", fontSize: "16px", borderBottom: "1px solid #333", fontWeight: 700 }}>
                                    {language === "java" ? "Java" : (language === 'python') ? 'Python' : (language === 'javascript') ? "JavaScript" : "TypeScript"} Code Editor
                                </div>
                                <Editor
                                    height="calc(100% - 32px)"
                                    options={{
                                        readOnly: false,
                                        minimap: { enabled: false },
                                        fontSize: 14,
                                        wordWrap: "on",
                                        lineNumbers: "on",
                                    }}
                                    language={language}
                                    value={code}
                                    theme="vs-dark"
                                    onChange={handleEditorChange1}
                                />
                            </div>
                        )}
                    </div>

                    {/* Vertical Resizer */}
                    <div
                        className="vertical-resizer"
                        onMouseDown={handleMouseDown('vertical')}
                        style={{ cursor: 'ns-resize' }}
                    />

                    {feedback && (
                        <div
                            style={{
                                height: "100vh",
                                width: "100vw",
                                backdropFilter: "blur(4px)",
                                backgroundColor: "rgba(0,0,0,0.5)",
                                position: "fixed",
                                top: 0,
                                left: 0,
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                                zIndex: 1000,
                            }}
                        >
                            <div
                                style={{
                                    position: "relative",
                                    width: "350px",
                                    backgroundColor: "#f8f9fa",
                                    padding: "20px 15px 60px 15px",
                                    borderRadius: "12px",
                                    textAlign: "center",
                                    boxShadow: "0 4px 12px rgba(0,0,0,0.2)",
                                    color: feedback.startsWith("✅") ? "green" : "red",
                                }}
                            >
                                <h2 style={{ marginBottom: "15px" }}>
                                    {currentEditor === "algorithm" ? "Algorithm Validation" :
                                     currentEditor === "pseudocode" ? "Pseudocode Validation" : "Code Validation"}
                                </h2>
                                <p style={{ fontSize: "16px" }}>{feedback}</p>
                                <button
                                    onClick={() => setFeedback("")}
                                    style={{
                                        position: "absolute",
                                        bottom: "15px",
                                        left: "50%",
                                        transform: "translateX(-50%)",
                                        padding: "10px 20px",
                                        backgroundColor: "#dc3545",
                                        color: "#fff",
                                        border: "none",
                                        borderRadius: "6px",
                                        cursor: "pointer",
                                        fontWeight: "bold",
                                    }}
                                >
                                    Close
                                </button>
                            </div>
                        </div>
                    )}

                    {/* Input/Output Container */}
                    <div className="input-output-container" style={{ height: `${bottomHeight}%` }}>
                        <div className="input-output-section">
                            <h3>Input</h3>
                            <textarea
                                className="input-textarea"
                                value={input}
                                onChange={handleInputChange}
                                placeholder="Enter input here"
                                style={{
                                    width: "100%",
                                    height: "calc(100% - 40px)",
                                    resize: "none",
                                    fontFamily: "monospace"
                                }}
                            />
                        </div>

                        <div className="input-output-section">
                            <h3>Output</h3>
                            <textarea
                                className="output-textarea"
                                value={output || ""}
                                readOnly
                                placeholder="Output will appear here after running the code"
                                style={{
                                    width: "100%",
                                    height: "calc(100% - 40px)",
                                    resize: "none",
                                    fontFamily: "monospace",
                                    backgroundColor: "#f8f9fa"
                                }}
                            />
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default Compiler;
