import axios from 'axios';

// Format Time Function
export const formatTime = (seconds) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs.toString().padStart(2, "0")}:${mins
        .toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
};

// Check Algorithm API
export const checkAlgorithmAPI = async (questionDescription, algorithm) => {
    const response = await axios.post(`${import.meta.env.VITE_AI_URL}/check-algorithm`, {
        question: questionDescription,
        algorithm: JSON.stringify(algorithm)
    });
    return response.data;
};

// Check Pseudocode API
export const checkPseudocodeAPI = async (questionDescription, pseudoCode) => {
    const response = await axios.post(`${import.meta.env.VITE_AI_URL}/check-pseudocode`, {
        question: questionDescription,
        pseudocode: JSON.stringify(pseudoCode)
    });
    return response.data;
};

// Check Code API
export const checkCodeAPI = async (questionDescription, code, language) => {
    const response = await axios.post(
        `${import.meta.env.VITE_AI_URL}/check-code`,
        { question: questionDescription, code: JSON.stringify(code), language }
    );
    return response.data;
};

// Run Code API
export const runCodeAPI = async (language, code, input) => {
    const response = await axios.post(`${import.meta.env.VITE_CODE_EXECUTOR_URL || "http://172.20.201.87:5010"}/api/v1/run`, {
        language,
        source: code,
        input
    });
    return response.data;
};

// Submit Code API
export const submitCodeAPI = async ({
    question,
    code,
    language,
    questionId,
    javaCode,
    pythonCode,
    javaScriptCode,
    typeScriptCode,
    javaTime,
    pythonTime,
    javascriptTime,
    typescriptTime,
    lastSavedJavaTime,
    lastSavedPythonTime,
    lastSavedJavascriptTime,
    lastSavedTypescriptTime
}) => {
    const testCases = question.testCases || [];
    let allPassed = true;
    let results = [];
    let localPassedCount = 0;

    const runTestCases = async (lang) => {
        for (let i = 0; i < testCases.length; i++) {
            const test = testCases[i];
            const userInput = test.input.replace(" ", "\n");

            try {
                const response = await axios.post(`${import.meta.env.VITE_CODE_EXECUTOR_URL || "http://172.20.201.87:5010"}/api/v1/run`, {
                    language: lang,
                    source: code,
                    input: userInput,
                });

                const actualOutput = response.data.output?.trim() || "";
                const expectedOutput = test.expectedOutput?.trim() || "";

                if (actualOutput === expectedOutput) {
                    localPassedCount++;
                    results.push(`Test Case ${i + 1}: PASSED`);
                } else {
                    allPassed = false;
                    results.push(`Test case ${i + 1}: Expected: ${expectedOutput} But Got: ${actualOutput}`);
                }
            } catch (error) {
                allPassed = false;
                results.push(`Test Case ${i + 1}: ERROR (${error.message || "Runtime/Compilation Error"})`);
            }
        }
    };

    if (["java", "python", "javascript", "typescript"].includes(language)) {
        await runTestCases(language);
    } else {
        throw new Error(`Language ${language} not supported.`);
    }

    // Calculate time delta
    let languageTimeSpent = 0;
    if (language === 'java') {
        languageTimeSpent = javaTime - lastSavedJavaTime;
    } else if (language === 'python') {
        languageTimeSpent = pythonTime - lastSavedPythonTime;
    } else if (language === 'javascript') {
        languageTimeSpent = javascriptTime - lastSavedJavascriptTime;
    } else if (language === 'typescript') {
        languageTimeSpent = typescriptTime - lastSavedTypescriptTime;
    }

    console.log("📤 Submitting - language time delta:", languageTimeSpent, "for", language);

    // Save current work to database
    const codeData = {
        problemId: parseInt(questionId),
        savedCodes: {
            java: javaCode,
            python: pythonCode,
            javascript: javaScriptCode,
            typescript: typeScriptCode
        },
        javaTimeSeconds: language === 'java' ? languageTimeSpent : 0,
        pythonTimeSeconds: language === 'python' ? languageTimeSpent : 0,
        javascriptTimeSeconds: language === 'javascript' ? languageTimeSpent : 0,
        typescriptTimeSeconds: language === 'typescript' ? languageTimeSpent : 0
    };

    await axios.put(
        `${import.meta.env.VITE_API_BASE_URL}/user/problem-submissions/save-code`,
        codeData,
        { headers: { 'Content-Type': 'application/json' } }
    );

    // Submit the solution
    const responseDataCodeSubmission = {
        problemId: parseInt(questionId),
        language: language.toUpperCase(),
        code: code,
        isCorrect: allPassed,
        savedCodes: {
            java: javaCode,
            python: pythonCode,
            javascript: javaScriptCode,
            typescript: typeScriptCode,
        },
        totalSecondsSpent: languageTimeSpent,
        totalTestCasesPassed: localPassedCount,
        totalTestCases: testCases.length,
        insights: {},
    };

    await axios.put(
        `${import.meta.env.VITE_API_BASE_URL}/user/problem-submissions/submission`,
        responseDataCodeSubmission,
        { headers: { "Content-Type": "application/json" } }
    );

    return {
        allPassed,
        passedCount: localPassedCount,
        output: results.join("\n")
    };
};

