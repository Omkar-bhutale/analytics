# Compiler Page – Timer, Auto-Save, and Submission Logic

This document explains how **time tracking**, **saved code**, and **submissions** work for the `Compiler` page.

It is based on the current implementation in:

- `Compiler/index.jsx`
- `Compiler/hooks.js`
- `Compiler/utils.js`

---

## 1. Time Tracking

Time is tracked **per editor** and **per language**.

### 1.1 State variables (in `Compiler/index.jsx`)

- Algorithm & pseudocode:
  - `algorithmTime` – total seconds spent in the **Algorithm** editor.
  - `pseudocodeTime` – total seconds spent in the **Pseudocode** editor.

- Code (per language):
  - `javaTime` – total seconds spent coding in **Java**.
  - `pythonTime` – total seconds spent coding in **Python**.
  - `javascriptTime` – total seconds spent coding in **JavaScript**.
  - `typescriptTime` – total seconds spent coding in **TypeScript**.

- General:
  - `currentTime` – the value currently shown on the timer UI.
  - `currentEditor` – one of `'algorithm' | 'pseudocode' | 'code'`.
  - `language` – one of `'java' | 'python' | 'javascript' | 'typescript'` when `currentEditor === 'code'`.

### 1.2 Initial time loading (`useCompilerData` in `hooks.js`)

On page load, `useCompilerData`:

1. Calls `GET /user/problem-submissions/{questionId}` and reads:
   - `javaTimeSeconds` → `javaTime` and `lastSavedJavaTime`.
   - `pythonTimeSeconds` → `pythonTime` and `lastSavedPythonTime`.
   - `javascriptTimeSeconds` → `javascriptTime` and `lastSavedJavascriptTime`.
   - `typescriptTimeSeconds` → `typescriptTime` and `lastSavedTypescriptTime`.

2. Calls:
   - `GET /user/algorithm-submissions/problem/{questionId}` → sets `algorithm`, `algorithmTime`, `lastSavedAlgorithmTime`.
   - `GET /user/pseudocode-submissions/problem/{questionId}` → sets `pseudoCode`, `pseudocodeTime`, `lastSavedPseudocodeTime`.

3. Sets `currentTime` initially to the Java time from DB (`javaTimeSeconds`).

4. Determines `currentEditor` based on validation flags:
   - If algorithm is correct and pseudocode is correct → `currentEditor = 'code'`.
   - If algorithm is correct but pseudocode is not → `currentEditor = 'pseudocode'`.
   - Else → `currentEditor = 'algorithm'`.

### 1.3 Timer ticking (`useCompilerTimer` in `hooks.js`)

`useCompilerTimer` sets up a `setInterval` that fires **every 1 second** whenever `dataLoaded` is true.

On each tick:

- If `currentEditor === 'algorithm'`:
  - `algorithmTime += 1` and `currentTime = algorithmTime`.

- If `currentEditor === 'pseudocode'`:
  - `pseudocodeTime += 1` and `currentTime = pseudocodeTime`.

- If `currentEditor === 'code'`:
  - If `language === 'java'`:
    - `javaTime += 1` and `currentTime = javaTime`.
  - If `language === 'python'`:
    - `pythonTime += 1` and `currentTime = pythonTime`.
  - If `language === 'javascript'`:
    - `javascriptTime += 1` and `currentTime = javascriptTime`.
  - If `language === 'typescript'`:
    - `typescriptTime += 1` and `currentTime = typescriptTime`.

Only **one** timer is active at a time for the current editor / language.

### 1.4 Language switching behavior

When the user changes the language in the dropdown while `currentEditor === 'code'`:

- `useEffect` in `index.jsx` runs:
  - First calls `saveToDatabase()` (see auto-save below) to flush pending deltas.
  - Then updates `code` and `currentTime` to match the selected language:
    - `language === 'java'` → `code = javaCode`, `currentTime = javaTime`.
    - `language === 'python'` → `code = pythonCode`, `currentTime = pythonTime`.
    - `language === 'javascript'` → `code = javaScriptCode`, `currentTime = javascriptTime`.
    - `language === 'typescript'` → `code = typeScriptCode`, `currentTime = typescriptTime`.

This ensures the timer always reflects the **total time spent in the currently selected language**.

---

## 2. Auto-Save Logic

Auto-save is handled by the custom hook `useCompilerAutoSave` in `hooks.js`.

### 2.1 State involved

For calculating **increments (deltas)** since the last save, we track:

- Last saved times:
  - `lastSavedJavaTime`
  - `lastSavedPythonTime`
  - `lastSavedJavascriptTime`
  - `lastSavedTypescriptTime`
  - `lastSavedAlgorithmTime`
  - `lastSavedPseudocodeTime`

- Current times:
  - `javaTime`, `pythonTime`, `javascriptTime`, `typescriptTime`
  - `algorithmTime`, `pseudocodeTime`

These are kept in sync by `useCompilerData`, `useCompilerTimer`, and the various save functions.

### 2.2 Snapshot ref pattern (`latestRef`)

`useCompilerAutoSave` uses a `latestRef` to hold a snapshot of all relevant state:

```js
const latestRef = useRef(null);

useEffect(() => {
  latestRef.current = {
    dataLoaded,
    currentEditor,
    algorithm,
    pseudoCode,
    javaCode,
    pythonCode,
    javaScriptCode,
    typeScriptCode,
    javaTime,
    pythonTime,
    javascriptTime,
    typescriptTime,
    algorithmTime,
    pseudocodeTime,
    lastSavedJavaTime,
    lastSavedPythonTime,
    lastSavedJavascriptTime,
    lastSavedTypescriptTime,
    lastSavedAlgorithmTime,
    lastSavedPseudocodeTime,
    algorithmValidated,
    pseudoValidated,
    questionId
  };
}, [/* all relevant dependencies */]);
```

This allows the auto-save callback to always see the **latest** values without being re-created every second.

### 2.3 Auto-save callback (`saveToDatabase`)

`saveToDatabase` reads from `latestRef.current` and sends **only deltas** to the backend:

#### Algorithm editor

Criteria to save:

- `currentEditor === 'algorithm'`, and
- Either:
  - `algorithmTime > lastSavedAlgorithmTime` (time increased), or
  - `algorithm` content changed from the default (`"// Write algorithm first"`).

Data sent:

- Endpoint:
  - `POST /user/algorithm-submissions`
- Body:
  - `problemId`: `parseInt(questionId)`
  - `content`: `algorithm`
  - `isCorrect`: `algorithmValidated`
  - `totalSecondSpent`: `algorithmTime - lastSavedAlgorithmTime`

Updates in state:

- `lastSavedAlgorithmTime = algorithmTime`.

#### Pseudocode editor

Criteria to save:

- `currentEditor === 'pseudocode'`, and
- Either:
  - `pseudocodeTime > lastSavedPseudocodeTime`, or
  - `pseudoCode` content changed from the default (`"// Write pseudo code first"`).

Data sent:

- Endpoint:
  - `POST /user/pseudocode-submissions`
- Body:
  - `problemId`: `parseInt(questionId)`
  - `content`: `pseudoCode`
  - `isCorrect`: `pseudoValidated`
  - `totalSecondSpent`: `pseudocodeTime - lastSavedPseudocodeTime`

Updates in state:

- `lastSavedPseudocodeTime = pseudocodeTime`.

#### Code editor (languages)

Criteria to save:

- `currentEditor === 'code'`, and
- At least one of the per-language time deltas is positive:
  - `javaDelta = javaTime - lastSavedJavaTime`
  - `pythonDelta = pythonTime - lastSavedPythonTime`
  - `jsDelta = javascriptTime - lastSavedJavascriptTime`
  - `tsDelta = typescriptTime - lastSavedTypescriptTime`

Data sent:

- Endpoint:
  - `PUT /user/problem-submissions/save-code`
- Body:
  - `problemId`: `parseInt(questionId)`
  - `savedCodes`:
    - `java: javaCode`
    - `python: pythonCode`
    - `javascript: javaScriptCode`
    - `typescript: typeScriptCode`
  - `javaTimeSeconds`: `javaDelta`
  - `pythonTimeSeconds`: `pythonDelta`
  - `javascriptTimeSeconds`: `jsDelta`
  - `typescriptTimeSeconds`: `tsDelta`

Updates in state:

- `lastSavedJavaTime = javaTime`
- `lastSavedPythonTime = pythonTime`
- `lastSavedJavascriptTime = javascriptTime`
- `lastSavedTypescriptTime = typescriptTime`

### 2.4 Auto-save interval

`useCompilerAutoSave` sets up a single interval once data is loaded:

- Triggered when: `dataLoaded === true`.
- Interval: **15,000 ms (15 seconds)**.
- Callback: `saveToDatabase()`.
- Cleanup: clears the interval on unmount or when `dataLoaded` becomes false.

This ensures auto-save runs **every 15 seconds**, not every 1–2 seconds.

### 2.5 Manual saves and page unload

In addition to auto-save:

- **Manual Save button** (`saveCode` in `index.jsx`):
  - For `code` editor, computes per-language deltas and calls the same `save-code` endpoint.
  - For `algorithm` and `pseudocode`, posts content with deltas and updates `lastSaved...Time`.

- **Language switch** and **tab close / visibility change** call `saveToDatabase()` to avoid losing work.

---

## 3. Submission Saving Logic

Actual **submissions** (as opposed to just saving work) are handled in `Compiler/utils.js` by `submitCodeAPI`, and called from `submitCode` in `index.jsx`.

### 3.1 Submission criteria

- Question must have test cases: `question && question.testCases`.
- There must be non-empty code: `code.trim() !== ""`.

### 3.2 What happens on submit

1. **Run all test cases** using the external code executor:

   - Endpoint:
     - `POST {VITE_CODE_EXECUTOR_URL || http://172.20.201.87:5010}/api/v1/run`
   - For each test case:
     - `language`: current language (java/python/javascript/typescript).
     - `source`: `code`.
     - `input`: `test.input` with spaces replaced by newlines (`replace(" ", "\n")`).
   - Collect results in `results` array:
     - If output matches → `Test Case X: PASSED` and `localPassedCount++`.
     - Else → `Test case X: Expected: ... But Got: ...` and `allPassed = false`.

2. **Compute time delta for the language**:

   ```js
   let languageTimeSpent = 0;
   if (language === 'java') {
     languageTimeSpent = javaTime - lastSavedJavaTime;
   } else if (language === 'python') {
     languageTimeSpent = pythonTime - lastSavedPythonTime;
   } else if (language === 'javascript') {
     languageTimeSpent = javascriptTime - lastSavedJavascriptTime;
   } else if (language === 'typescript') {
     languageTimeSpent = typescriptTime - lastSavedTypescriptTime;
   }
   ```

3. **Save current work snapshot with time delta**:

   - Endpoint:
     - `PUT /user/problem-submissions/save-code`
   - Body:

     ```js
     {
       problemId: parseInt(questionId),
       savedCodes: {
         java: javaCode,
         python: pythonCode,
         javascript: javaScriptCode,
         typescript: typeScriptCode
       },
       javaTimeSeconds: language === 'java' ? languageTimeSpent : 0,
       pythonTimeSeconds: language === 'python' ? languageTimeSpent : 0,
       javascriptTimeSeconds: language === 'javascript' ? languageTimeSpent : 0,
       typescriptTimeSeconds: language === 'typescript' ? languageTimeSpent : 0
     }
     ```

4. **Submit the final result**:

   - Endpoint:
     - `PUT /user/problem-submissions/submission`
   - Body:

     ```js
     {
       problemId: parseInt(questionId),
       language: language.toUpperCase(),
       code: code,
       isCorrect: allPassed,
       savedCodes: {
         java: javaCode,
         python: pythonCode,
         javascript: javaScriptCode,
         typescript: typeScriptCode
       },
       totalSecondsSpent: languageTimeSpent,
       totalTestCasesPassed: localPassedCount,
       totalTestCases: testCases.length,
       insights: {}
     }
     ```

5. **Update frontend state**:

   - `output` shows joined `results` lines.
   - `passedCount` is set to `localPassedCount`.
   - If `allPassed`:
     - Marks the corresponding language as completed in state (`javaCompleted`, `pythonCompleted`, etc.).
   - Updates `lastSavedJavaTime` / `lastSavedPythonTime` / etc. for the submitted language.

---

## 4. Summary of Criteria

### Time tracking

- 1-second interval increments **one** of:
  - `algorithmTime`, `pseudocodeTime`, or one of the language times.
- `currentTime` always mirrors the active editor/language time.

### Auto-save

- **Runs every 15 seconds** when `dataLoaded` is true.
- Saves **only deltas** (time since last save) to backend.
- Separate paths for algorithm, pseudocode, and code.

### Manual save

- Same delta logic as auto-save, but triggered by user action (Save button).

### Submissions

- Only run when there is code and test cases.
- Run all test cases and record pass/fail.
- Save current work snapshot with language-specific time delta.
- Record a submission with:
  - Success flag (`isCorrect`),
  - Time delta (`totalSecondsSpent`),
  - Test case stats.

