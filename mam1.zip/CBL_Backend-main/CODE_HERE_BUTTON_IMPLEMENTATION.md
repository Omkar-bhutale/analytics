# 🔧 Code Here Button - Dynamic Main Topic Problem Fetching

**Date:** November 10, 2025  
**Feature:** Dynamic API call to fetch main topic problem based on selected topic  
**Status:** ✅ IMPLEMENTED

---

## 📋 Overview

Updated the "Code Here" button in `LearningPage_NEW.jsx` to dynamically fetch the main topic problem using the selected topic's `mainTopicId` instead of a hardcoded value.

---

## 🎯 Requirements

**API Endpoint:**
```
GET /user/problem-submissions/main-topic
Query Parameter: mainTopicId (Integer)
```

**Backend Controller:**
```java
@GetMapping("/main-topic")
public ProblemCodeResponceDTO getMainTopicProblem(
    @Parameter(description = "ID of the main topic") 
    @RequestParam Integer mainTopicId
) {
    return problemSubmissionService.getMainTopicProblem(mainTopicId);
}
```

**Expected Response:**
```json
{
    "problemDTO": {
        "problemId": 123,
        "title": "Problem Title",
        "description": "Problem Description",
        // ... other fields
    }
}
```

---

## ✅ Implementation

### **Before (Hardcoded):**

```javascript
const handleTopicwiseQuestionFetch = async () => {
    try {
        const response = await axios.get(
            "http://10.23.252.193:8081/user/problem-submissions/main-topic?mainTopicId=2"
            // ❌ Hardcoded mainTopicId=2
        );

        if (response.data && response.data.problemDTO) {
            const fetchedProblemId = response.data.problemDTO.problemId;
            setQuestionId(fetchedProblemId);
            console.log("Fetched Problem ID:", fetchedProblemId);
        } else {
            console.error("Invalid API response structure:", response.data);
        }
    } catch (error) {
        console.error("Error fetching question:", error);
    }
};
```

**Problems:**
- ❌ Always fetches problem for mainTopicId=2 (hardcoded)
- ❌ Doesn't work for other topics (Arrays, Linked Lists, etc.)
- ❌ Uses hardcoded IP address instead of BASE_URL
- ❌ No user feedback (toasts)
- ❌ No validation

---

### **After (Dynamic):**

```javascript
const handleTopicwiseQuestionFetch = async () => {
    try {
        // ✅ Get the mainTopicId from the current selected topic
        if (!topicData?.mainTopicId) {
            toast.error("Main Topic ID not found");
            console.error("Main Topic ID not found for:", selectedTopic);
            return;
        }

        // ✅ Use BASE_URL and dynamic mainTopicId
        const response = await axios.get(
            `${BASE_URL}/user/problem-submissions/main-topic`,
            {
                params: { mainTopicId: topicData.mainTopicId }
            }
        );

        if (response.data && response.data.problemDTO) {
            const fetchedProblemId = response.data.problemDTO.problemId;
            setQuestionId(fetchedProblemId);
            console.log(`✅ Fetched Problem ID for ${selectedTopic} (mainTopicId: ${topicData.mainTopicId}):`, fetchedProblemId);
            toast.success("Problem loaded successfully!");
        } else {
            console.error("Invalid API response structure:", response.data);
            toast.error("Failed to load problem");
        }
    } catch (error) {
        console.error("Error fetching main topic problem:", error);
        toast.error("Failed to fetch problem. Please try again.");
    }
};
```

**Improvements:**
- ✅ Dynamically fetches problem based on selected topic
- ✅ Validates mainTopicId exists before API call
- ✅ Uses `BASE_URL` environment variable
- ✅ User-friendly toast notifications
- ✅ Better error handling and logging
- ✅ Works for all topics (Arrays, Linked Lists, Trees, etc.)

---

## 🔄 Data Flow

### **1. User Selects Topic**
```
User clicks on "Arrays" in sidebar
→ selectedTopic = "Arrays"
→ topicData = fetchedData.find(t => t.mainTopicName === "Arrays")
→ topicData.mainTopicId = 1 (example)
```

### **2. User Navigates to Last Subtopic**
```
User views all subtopics and reaches the last one
→ isLastSubtopic = true
→ "Code Here" button becomes visible
```

### **3. User Clicks "Code Here"**
```
handleTopicwiseQuestionFetch() is called
→ Validates topicData.mainTopicId exists
→ Sends GET request: /user/problem-submissions/main-topic?mainTopicId=1
→ Backend returns problem for "Arrays" topic
→ Sets questionId from response
→ Navigates to /compiler/{questionId}
```

### **4. Navigation to Compiler**
```javascript
<Link
    to={`/compiler/${questionId}`}
    state={{
        selectedTopic: selectedTopic,        // "Arrays"
        selectedSubTopic: selectedSubtopic,  // Last subtopic
        subtopics: topicData?.subTopics?.map(s => s.title) || []
    }}
>
```

---

## 📊 Example Scenarios

### **Scenario 1: Arrays Topic**
```
Selected Topic: "Arrays"
mainTopicId: 1
API Call: GET /user/problem-submissions/main-topic?mainTopicId=1
Response: { problemDTO: { problemId: 101, title: "Array Manipulation" } }
Navigate to: /compiler/101
```

### **Scenario 2: Linked Lists Topic**
```
Selected Topic: "Linked Lists"
mainTopicId: 2
API Call: GET /user/problem-submissions/main-topic?mainTopicId=2
Response: { problemDTO: { problemId: 202, title: "Reverse Linked List" } }
Navigate to: /compiler/202
```

### **Scenario 3: Trees Topic**
```
Selected Topic: "Trees"
mainTopicId: 3
API Call: GET /user/problem-submissions/main-topic?mainTopicId=3
Response: { problemDTO: { problemId: 303, title: "Tree Traversal" } }
Navigate to: /compiler/303
```

---

## 🎨 UI/UX

### **Button Visibility**
- ✅ Only visible on the **last subtopic** of each topic
- ✅ Positioned between "Take Quiz" and "Mark as Complete" buttons

### **Button Styling**
```javascript
{
    padding: "6px 14px",
    fontSize: "14px",
    borderRadius: "6px",
    cursor: "pointer",
    background: "#09122C",  // Dark blue
    color: "#fff",
    border: "none",
    display: "flex",
    alignItems: "center",
}
```

### **User Feedback**
- ✅ **Success:** "Problem loaded successfully!" (green toast)
- ❌ **Error:** "Failed to fetch problem. Please try again." (red toast)
- ❌ **Validation:** "Main Topic ID not found" (red toast)

---

## 🧪 Testing Guide

### **Test 1: Verify Dynamic mainTopicId**
1. Open Learning Page
2. Select different topics (Arrays, Linked Lists, Trees)
3. Navigate to last subtopic
4. Click "Code Here"
5. Check console logs:
   ```
   ✅ Fetched Problem ID for Arrays (mainTopicId: 1): 101
   ✅ Fetched Problem ID for Linked Lists (mainTopicId: 2): 202
   ```

### **Test 2: Verify API Call**
1. Open DevTools → Network tab
2. Click "Code Here"
3. Check request:
   ```
   GET /user/problem-submissions/main-topic?mainTopicId=1
   Headers:
     Authorization: Bearer <token>
   ```

### **Test 3: Verify Navigation**
1. Click "Code Here"
2. Should navigate to `/compiler/{problemId}`
3. Compiler page should receive state:
   ```javascript
   {
       selectedTopic: "Arrays",
       selectedSubTopic: "Last Subtopic Name",
       subtopics: ["Subtopic 1", "Subtopic 2", ...]
   }
   ```

### **Test 4: Error Handling**
1. **No mainTopicId:** Should show "Main Topic ID not found"
2. **API Error:** Should show "Failed to fetch problem. Please try again."
3. **Invalid Response:** Should show "Failed to load problem"

---

## 🔗 Related Code Sections

### **1. topicData Definition**
```javascript
const topicData = fetchedData.find(t => t.mainTopicName === selectedTopic);
```

### **2. Button Visibility Logic**
```javascript
const subtopicIndex = topicData?.subTopics.findIndex(s => s.title === selectedSubtopic);
const isLastSubtopic = subtopicIndex === (topicData?.subTopics.length - 1);
```

### **3. Button Render**
```javascript
{isLastSubtopic && (
    <Link
        to={`/compiler/${questionId}`}
        state={{
            selectedTopic: selectedTopic,
            selectedSubTopic: selectedSubtopic,
            subtopics: topicData?.subTopics?.map(s => s.title) || []
        }}
    >
        <button onClick={handleTopicwiseQuestionFetch}>
            <FaCode style={{ marginRight: "10px" }} />
            Code here
        </button>
    </Link>
)}
```

---

## 📝 Data Structure

### **fetchedData Structure:**
```javascript
[
    {
        mainTopicId: 1,
        mainTopicName: "Arrays",
        subTopics: [
            {
                topicId: 10,
                title: "Introduction to Arrays",
                content: { ... }
            },
            {
                topicId: 11,
                title: "Array Operations",
                content: { ... }
            }
        ]
    },
    {
        mainTopicId: 2,
        mainTopicName: "Linked Lists",
        subTopics: [ ... ]
    }
]
```

### **API Response Structure:**
```javascript
{
    problemDTO: {
        problemId: 101,
        title: "Array Manipulation",
        description: "Solve this array problem...",
        difficulty: "MEDIUM",
        // ... other fields
    }
}
```

---

## 🎯 Key Benefits

1. **Dynamic:** Works for all topics automatically
2. **Maintainable:** Uses BASE_URL environment variable
3. **User-Friendly:** Toast notifications for feedback
4. **Robust:** Proper error handling and validation
5. **Scalable:** Easy to add new topics without code changes
6. **Consistent:** Uses same axios interceptor for authentication

---

## ✅ Completion Checklist

- [x] Import Cookies library
- [x] Update axios interceptor to use Cookies
- [x] Update fetch cleanup to use Cookies
- [x] Make handleTopicwiseQuestionFetch dynamic
- [x] Add validation for mainTopicId
- [x] Use BASE_URL instead of hardcoded IP
- [x] Add toast notifications
- [x] Improve error handling
- [x] Add detailed logging
- [x] Test with different topics

---

**Status:** ✅ **FULLY IMPLEMENTED**  
**Impact:** Code Here button now works dynamically for all topics  
**User Experience:** Improved with toast notifications and better error handling  
**Maintainability:** Uses environment variables and follows best practices

