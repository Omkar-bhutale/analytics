-- ============================================================================
-- CBL Backend - Topics Data Insertion Script
-- Generated: October 27, 2025
-- Description: Inserts detailed topics data with proper JSON content structure
-- ============================================================================

-- Main Topic 1: Data Types & Operators - Topics
INSERT INTO topics (main_topic_id, title, content, creator_id, created_at, created_using) VALUES
                                                                                              (1, 'Primitive Data Types', '{
    "explaination": "Basic data types provided by programming languages that store simple values directly in memory",
    "language_details": [
        {
            "syntax": "byte, short, int, long, float, double, char, boolean",
            "example": "int age = 25;\ndouble salary = 50000.50;\nchar grade = ''A'';\nboolean isActive = true;",
            "language": "Java"
        },
        {
            "syntax": "int, float, str, bool, None",
            "example": "age = 25\nsalary = 50000.50\ngrade = ''A''\nis_active = True",
            "language": "Python"
        },
        {
            "syntax": "Number, String, Boolean, undefined, null, BigInt",
            "example": "let age = 25;\nlet salary = 50000.50;\nlet grade = ''A'';\nlet isActive = true;",
            "language": "JavaScript"
        },
        {
            "syntax": "number, string, boolean, undefined, null, bigint",
            "example": "let age: number = 25;\nlet salary: number = 50000.50;\nlet grade: string = ''A'';\nlet isActive: boolean = true;",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "Java has more specific numeric types (byte, short, int, long) while Python and JavaScript/TypeScript have more simplified type systems. Java requires explicit type declaration while others use type inference."
}', 'learnin', CURRENT_TIMESTAMP, 'SME'),

                                                                                              (1, 'Operators and Expressions', '{
    "explaination": "Symbols that perform operations on operands and form expressions for computations",
    "language_details": [
        {
            "syntax": "Arithmetic: + - * / % ++ --\nRelational: == != > < >= <=\nLogical: && || !",
            "example": "int result = 10 + 5 * 2;\nboolean isValid = (age >= 18) && (score > 60);",
            "language": "Java"
        },
        {
            "syntax": "Arithmetic: + - * / % ** //\nRelational: == != > < >= <=\nLogical: and or not",
            "example": "result = 10 + 5 * 2\nis_valid = (age >= 18) and (score > 60)",
            "language": "Python"
        },
        {
            "syntax": "Arithmetic: + - * / % ** ++ --\nRelational: == != > < >= <=\nLogical: && || !",
            "example": "let result = 10 + 5 * 2;\nlet isValid = (age >= 18) && (score > 60);",
            "language": "JavaScript"
        },
        {
            "syntax": "Arithmetic: + - * / % ** ++ --\nRelational: == != > < >= <=\nLogical: && || !",
            "example": "let result: number = 10 + 5 * 2;\nlet isValid: boolean = (age >= 18) && (score > 60);",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "Python uses ''and/or/not'' keywords instead of symbols. JavaScript/TypeScript have similar syntax to Java but with type differences."
}', 'learnin', CURRENT_TIMESTAMP, 'LLM'),

                                                                                              (1, 'Type Conversion and Casting', '{
    "explaination": "Process of converting one data type to another, either implicitly or explicitly",
    "language_details": [
        {
            "syntax": "Implicit: automatic\nExplicit: (type) variable",
            "example": "double d = 10; // implicit\nint i = (int) 10.5; // explicit",
            "language": "Java"
        },
        {
            "syntax": "Implicit: automatic\nExplicit: int(), float(), str(), bool()",
            "example": "x = 10 + 5.5 # implicit\nx = int(10.5) # explicit",
            "language": "Python"
        },
        {
            "syntax": "Implicit: automatic\nExplicit: Number(), String(), Boolean()",
            "example": "let str = ''5'';\nlet num = Number(str); // explicit",
            "language": "JavaScript"
        },
        {
            "syntax": "Implicit: automatic\nExplicit: as type or <type>",
            "example": "let str: string = ''5'';\nlet num: number = Number(str); // explicit",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "Java has strict type casting with (type) syntax. Python uses constructor functions. JavaScript has loose typing with conversion functions."
}', 'learnin', CURRENT_TIMESTAMP, 'SME'),

                                                                                              (1, 'Variables and Scope', '{
    "explaination": "Understanding variable declaration, initialization, and scope in different programming languages",
    "language_details": [
        {
            "syntax": "type variableName = value;\nScope: local, instance, class, method",
            "example": "int count = 0;\nstatic final int MAX_SIZE = 100;",
            "language": "Java"
        },
        {
            "syntax": "variable_name = value\nScope: local, global, nonlocal",
            "example": "count = 0\nMAX_SIZE = 100 # convention for constants",
            "language": "Python"
        },
        {
            "syntax": "var, let, const variableName = value\nScope: global, function, block",
            "example": "let count = 0;\nconst MAX_SIZE = 100;",
            "language": "JavaScript"
        },
        {
            "syntax": "let, const variableName: type = value\nScope: global, function, block",
            "example": "let count: number = 0;\nconst MAX_SIZE: number = 100;",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "Java requires explicit type declaration. Python uses dynamic typing. JavaScript has var/let/const with different scoping rules. TypeScript adds static typing to JavaScript."
}', 'learnin', CURRENT_TIMESTAMP, 'LLM');

-- Main Topic 2: Conditionals & Loops - Topics
INSERT INTO topics (main_topic_id, title, content, creator_id, created_at, created_using) VALUES
                                                                                              (2, 'If-Else Statements', '{
    "explaination": "Conditional statements that execute different code blocks based on boolean conditions",
    "language_details": [
        {
            "syntax": "if (condition) { } else if (condition) { } else { }",
            "example": "if (score >= 90) {\n    grade = ''A'';\n} else if (score >= 80) {\n    grade = ''B'';\n} else {\n    grade = ''C'';\n}",
            "language": "Java"
        },
        {
            "syntax": "if condition:\nelif condition:\nelse:",
            "example": "if score >= 90:\n    grade = ''A''\nelif score >= 80:\n    grade = ''B''\nelse:\n    grade = ''C''",
            "language": "Python"
        },
        {
            "syntax": "if (condition) { } else if (condition) { } else { }",
            "example": "if (score >= 90) {\n    grade = ''A'';\n} else if (score >= 80) {\n    grade = ''B'';\n} else {\n    grade = ''C'';\n}",
            "language": "JavaScript"
        },
        {
            "syntax": "if (condition) { } else if (condition) { } else { }",
            "example": "if (score >= 90) {\n    grade = ''A'';\n} else if (score >= 80) {\n    grade = ''B'';\n} else {\n    grade = ''C'';\n}",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "Python uses elif instead of else if and requires colons and indentation. Java/JavaScript/TypeScript use similar syntax with braces."
}', 'learnin', CURRENT_TIMESTAMP, 'SME'),

                                                                                              (2, 'Switch Statements', '{
    "explaination": "Multi-way branching statement that selects one of many code blocks to execute",
    "language_details": [
        {
            "syntax": "switch (expression) { case value: break; default: }",
            "example": "switch (day) {\n    case 1: dayName = ''Monday''; break;\n    case 2: dayName = ''Tuesday''; break;\n    default: dayName = ''Unknown'';\n}",
            "language": "Java"
        },
        {
            "syntax": "match expression:\n    case pattern:\n    case _:",
            "example": "match day:\n    case 1: day_name = ''Monday''\n    case 2: day_name = ''Tuesday''\n    case _: day_name = ''Unknown''",
            "language": "Python"
        },
        {
            "syntax": "switch (expression) { case value: break; default: }",
            "example": "switch (day) {\n    case 1: dayName = ''Monday''; break;\n    case 2: dayName = ''Tuesday''; break;\n    default: dayName = ''Unknown'';\n}",
            "language": "JavaScript"
        },
        {
            "syntax": "switch (expression) { case value: break; default: }",
            "example": "switch (day) {\n    case 1: dayName = ''Monday''; break;\n    case 2: dayName = ''Tuesday''; break;\n    default: dayName = ''Unknown'';\n}",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "Python uses match-case (introduced in 3.10) while others use traditional switch. Java requires break to prevent fallthrough."
}', 'learnin', CURRENT_TIMESTAMP, 'LLM'),

                                                                                              (2, 'For Loops', '{
    "explaination": "Iteration construct that repeats a block of code a specific number of times",
    "language_details": [
        {
            "syntax": "for (init; condition; increment) { }",
            "example": "for (int i = 0; i < 5; i++) {\n    System.out.println(i);\n}",
            "language": "Java"
        },
        {
            "syntax": "for item in sequence:\nfor i in range(start, stop, step):",
            "example": "for i in range(5):\n    print(i)\n\nfor item in [1,2,3]:\n    print(item)",
            "language": "Python"
        },
        {
            "syntax": "for (init; condition; increment) { }\nfor (item of array) { }",
            "example": "for (let i = 0; i < 5; i++) {\n    console.log(i);\n}\n\nfor (let item of array) {\n    console.log(item);\n}",
            "language": "JavaScript"
        },
        {
            "syntax": "for (init; condition; increment) { }\nfor (item of array) { }",
            "example": "for (let i: number = 0; i < 5; i++) {\n    console.log(i);\n}\n\nfor (let item of array) {\n    console.log(item);\n}",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "Python uses range() and direct iteration. Java uses traditional C-style for loops. JavaScript/TypeScript support both traditional and for-of loops."
}', 'learnin', CURRENT_TIMESTAMP, 'SME'),

                                                                                              (2, 'While and Do-While Loops', '{
    "explaination": "Loops that execute based on a condition, with do-while guaranteeing at least one execution",
    "language_details": [
        {
            "syntax": "while (condition) { }\ndo { } while (condition);",
            "example": "int i = 0;\nwhile (i < 5) {\n    System.out.println(i);\n    i++;\n}\n\ndo {\n    System.out.println(i);\n    i++;\n} while (i < 5);",
            "language": "Java"
        },
        {
            "syntax": "while condition:\n# No built-in do-while",
            "example": "i = 0\nwhile i < 5:\n    print(i)\n    i += 1",
            "language": "Python"
        },
        {
            "syntax": "while (condition) { }\ndo { } while (condition);",
            "example": "let i = 0;\nwhile (i < 5) {\n    console.log(i);\n    i++;\n}\n\ndo {\n    console.log(i);\n    i++;\n} while (i < 5);",
            "language": "JavaScript"
        },
        {
            "syntax": "while (condition) { }\ndo { } while (condition);",
            "example": "let i: number = 0;\nwhile (i < 5) {\n    console.log(i);\n    i++;\n}\n\ndo {\n    console.log(i);\n    i++;\n} while (i < 5);",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "Python doesn''t have a built-in do-while loop. Java/JavaScript/TypeScript have identical syntax for while and do-while loops."
}', 'learnin', CURRENT_TIMESTAMP, 'LLM');

-- Main Topic 3: Functions - Topics
INSERT INTO topics (main_topic_id, title, content, creator_id, created_at, created_using) VALUES
                                                                                              (3, 'Function Declaration and Invocation', '{
    "explaination": "How to define functions and call them with arguments in different programming languages",
    "language_details": [
        {
            "syntax": "returnType methodName(parameters) { }\nmethodName(arguments);",
            "example": "public int add(int a, int b) {\n    return a + b;\n}\nint result = add(5, 3);",
            "language": "Java"
        },
        {
            "syntax": "def function_name(parameters):\nfunction_name(arguments)",
            "example": "def add(a, b):\n    return a + b\nresult = add(5, 3)",
            "language": "Python"
        },
        {
            "syntax": "function name(parameters) { }\nname(arguments);",
            "example": "function add(a, b) {\n    return a + b;\n}\nlet result = add(5, 3);",
            "language": "JavaScript"
        },
        {
            "syntax": "function name(parameters): returnType { }\nname(arguments);",
            "example": "function add(a: number, b: number): number {\n    return a + b;\n}\nlet result = add(5, 3);",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "Java requires explicit return types and access modifiers. Python uses def keyword. JavaScript uses function keyword. TypeScript adds type annotations."
}', 'learnin', CURRENT_TIMESTAMP, 'SME'),

                                                                                              (3, 'Parameters and Return Values', '{
    "explaination": "Handling function inputs (parameters) and outputs (return values) across languages",
    "language_details": [
        {
            "syntax": "Type name, ...\nreturn value;",
            "example": "public String greet(String name, int age) {\n    return \"Hello \" + name + \", age: \" + age;\n}",
            "language": "Java"
        },
        {
            "syntax": "name, name=default, *args, **kwargs\nreturn value",
            "example": "def greet(name, age=0):\n    return f\"Hello {name}, age: {age}\"",
            "language": "Python"
        },
        {
            "syntax": "name, name=default, ...rest\nreturn value",
            "example": "function greet(name, age = 0) {\n    return `Hello ${name}, age: ${age}`;\n}",
            "language": "JavaScript"
        },
        {
            "syntax": "name: type, name: type = default, ...rest: type[]\nreturn value",
            "example": "function greet(name: string, age: number = 0): string {\n    return `Hello ${name}, age: ${age}`;\n}",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "Python and JavaScript support default parameters directly. Java requires method overloading for default-like behavior. TypeScript adds type safety to JavaScript parameters."
}', 'learnin', CURRENT_TIMESTAMP, 'LLM'),

                                                                                              (3, 'Function Scope and Closures', '{
    "explaination": "Understanding variable visibility and closure behavior in function execution contexts",
    "language_details": [
        {
            "syntax": "Local scope, method parameters, instance variables, class variables",
            "example": "public class Example {\n    private int instanceVar = 10;\n    \n    public void method(int param) {\n        int localVar = 20;\n        // can access instanceVar, param, localVar\n    }\n}",
            "language": "Java"
        },
        {
            "syntax": "Local, Enclosing, Global, Built-in (LEGB rule)",
            "example": "x = \"global\"\n\ndef outer():\n    x = \"enclosing\"\n    def inner():\n        x = \"local\"\n        return x\n    return inner()",
            "language": "Python"
        },
        {
            "syntax": "Function scope, Block scope (let/const), Global scope",
            "example": "let globalVar = \"global\";\n\nfunction outer() {\n    let outerVar = \"outer\";\n    function inner() {\n        let innerVar = \"inner\";\n        return outerVar; // closure\n    }\n    return inner;\n}",
            "language": "JavaScript"
        },
        {
            "syntax": "Function scope, Block scope (let/const), Global scope",
            "example": "let globalVar: string = \"global\";\n\nfunction outer(): () => string {\n    let outerVar: string = \"outer\";\n    function inner(): string {\n        let innerVar: string = \"inner\";\n        return outerVar; // closure\n    }\n    return inner;\n}",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "Java has class-based scoping. Python follows LEGB rule. JavaScript has function-based scoping with closures. TypeScript adds types but same scoping rules as JavaScript."
}', 'learnin', CURRENT_TIMESTAMP, 'SME'),

                                                                                              (3, 'Recursion and Higher-Order Functions', '{
    "explaination": "Functions that call themselves (recursion) and functions that operate on other functions",
    "language_details": [
        {
            "syntax": "Direct recursion, method references",
            "example": "public int factorial(int n) {\n    if (n <= 1) return 1;\n    return n * factorial(n - 1);\n}",
            "language": "Java"
        },
        {
            "syntax": "Direct recursion, lambda functions, map/filter/reduce",
            "example": "def factorial(n):\n    if n <= 1:\n        return 1\n    return n * factorial(n - 1)\n\nsquares = list(map(lambda x: x**2, [1,2,3]))",
            "language": "Python"
        },
        {
            "syntax": "Direct recursion, arrow functions, map/filter/reduce",
            "example": "function factorial(n) {\n    if (n <= 1) return 1;\n    return n * factorial(n - 1);\n}\n\nconst squares = [1,2,3].map(x => x * x);",
            "language": "JavaScript"
        },
        {
            "syntax": "Direct recursion, arrow functions, map/filter/reduce",
            "example": "function factorial(n: number): number {\n    if (n <= 1) return 1;\n    return n * factorial(n - 1);\n}\n\nconst squares: number[] = [1,2,3].map((x: number) => x * x);",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "All languages support recursion. Python and JavaScript have more functional programming features built-in. Java requires functional interfaces for higher-order functions."
}', 'learnin', CURRENT_TIMESTAMP, 'LLM');

-- Main Topic 4: Sets & Collections - Topics
INSERT INTO topics (main_topic_id, title, content, creator_id, created_at, created_using) VALUES
                                                                                              (4, 'Lists and Arrays', '{
    "explaination": "Ordered collections that store elements in sequence and allow indexed access",
    "language_details": [
        {
            "syntax": "ArrayList<Type>, Arrays.asList(), List<Type>",
            "example": "List<String> names = new ArrayList<>();\nnames.add(\"Alice\");\nnames.add(\"Bob\");\nString first = names.get(0);",
            "language": "Java"
        },
        {
            "syntax": "list = [], list()",
            "example": "names = [\"Alice\", \"Bob\"]\nnames.append(\"Charlie\")\nfirst = names[0]",
            "language": "Python"
        },
        {
            "syntax": "let arr = [], new Array()",
            "example": "let names = [\"Alice\", \"Bob\"];\nnames.push(\"Charlie\");\nlet first = names[0];",
            "language": "JavaScript"
        },
        {
            "syntax": "let arr: Type[] = [], Array<Type>",
            "example": "let names: string[] = [\"Alice\", \"Bob\"];\nnames.push(\"Charlie\");\nlet first: string = names[0];",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "Java uses generic List interfaces. Python has built-in lists. JavaScript arrays are dynamic. TypeScript adds type annotations to arrays."
}', 'learnin', CURRENT_TIMESTAMP, 'SME'),

                                                                                              (4, 'Sets and Unique Collections', '{
    "explaination": "Unordered collections that store unique elements and support set operations",
    "language_details": [
        {
            "syntax": "HashSet<Type>, TreeSet<Type>",
            "example": "Set<Integer> numbers = new HashSet<>();\nnumbers.add(1);\nnumbers.add(2);\nnumbers.add(1); // duplicate ignored",
            "language": "Java"
        },
        {
            "syntax": "set = {value1, value2}, set()",
            "example": "numbers = {1, 2, 3}\nnumbers.add(4)\nnumbers.add(1) # duplicate ignored",
            "language": "Python"
        },
        {
            "syntax": "let set = new Set()",
            "example": "let numbers = new Set([1, 2, 3]);\nnumbers.add(4);\nnumbers.add(1); // duplicate ignored",
            "language": "JavaScript"
        },
        {
            "syntax": "let set: Set<Type> = new Set()",
            "example": "let numbers: Set<number> = new Set([1, 2, 3]);\nnumbers.add(4);\nnumbers.add(1); // duplicate ignored",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "Java has multiple Set implementations. Python has built-in sets. JavaScript/TypeScript use Set object. All enforce uniqueness but have different iteration orders."
}', 'learnin', CURRENT_TIMESTAMP, 'LLM'),

                                                                                              (4, 'Maps and Dictionaries', '{
    "explaination": "Key-value pair collections that allow efficient lookup by unique keys",
    "language_details": [
        {
            "syntax": "HashMap<Key,Value>, TreeMap<Key,Value>",
            "example": "Map<String, Integer> ages = new HashMap<>();\nages.put(\"Alice\", 25);\nages.put(\"Bob\", 30);\nint aliceAge = ages.get(\"Alice\");",
            "language": "Java"
        },
        {
            "syntax": "dict = {key: value}, dict()",
            "example": "ages = {\"Alice\": 25, \"Bob\": 30}\nages[\"Charlie\"] = 28\nalice_age = ages[\"Alice\"]",
            "language": "Python"
        },
        {
            "syntax": "let map = new Map(), let obj = {}",
            "example": "let ages = new Map([\n    [\"Alice\", 25],\n    [\"Bob\", 30]\n]);\nages.set(\"Charlie\", 28);\nlet aliceAge = ages.get(\"Alice\");",
            "language": "JavaScript"
        },
        {
            "syntax": "let map: Map<Key,Value> = new Map()",
            "example": "let ages: Map<string, number> = new Map([\n    [\"Alice\", 25],\n    [\"Bob\", 30]\n]);\nages.set(\"Charlie\", 28);\nlet aliceAge: number = ages.get(\"Alice\")!;",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "Java uses Map interface with implementations. Python has built-in dictionaries. JavaScript has Map objects and plain objects. TypeScript adds type safety to Maps."
}', 'learnin', CURRENT_TIMESTAMP, 'SME'),

                                                                                              (4, 'Collection Operations and Iteration', '{
    "explaination": "Common operations on collections including filtering, mapping, and reducing elements",
    "language_details": [
        {
            "syntax": "stream().filter().map().collect()",
            "example": "List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);\nList<Integer> evens = numbers.stream()\n    .filter(n -> n % 2 == 0)\n    .collect(Collectors.toList());",
            "language": "Java"
        },
        {
            "syntax": "filter(), map(), reduce(), list comprehensions",
            "example": "numbers = [1, 2, 3, 4, 5]\nevens = [n for n in numbers if n % 2 == 0]\nsquares = list(map(lambda x: x**2, numbers))",
            "language": "Python"
        },
        {
            "syntax": "filter(), map(), reduce(), forEach()",
            "example": "let numbers = [1, 2, 3, 4, 5];\nlet evens = numbers.filter(n => n % 2 === 0);\nlet squares = numbers.map(n => n * n);",
            "language": "JavaScript"
        },
        {
            "syntax": "filter(), map(), reduce(), forEach()",
            "example": "let numbers: number[] = [1, 2, 3, 4, 5];\nlet evens: number[] = numbers.filter(n => n % 2 === 0);\nlet squares: number[] = numbers.map(n => n * n);",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "Java uses Stream API. Python has built-in functions and list comprehensions. JavaScript/TypeScript have array methods. All support functional operations but with different syntax."
}', 'learnin', CURRENT_TIMESTAMP, 'LLM');

-- Main Topic 5: Classes and Objects - Topics
INSERT INTO topics (main_topic_id, title, content, creator_id, created_at, created_using) VALUES
                                                                                              (5, 'Class Declaration and Object Creation', '{
    "explaination": "Fundamental concepts of defining classes and creating object instances in object-oriented programming",
    "language_details": [
        {
            "syntax": "class ClassName { fields methods constructors }",
            "example": "public class Person {\n    private String name;\n    private int age;\n    \n    public Person(String name, int age) {\n        this.name = name;\n        this.age = age;\n    }\n}\n\nPerson person = new Person(\"Alice\", 25);",
            "language": "Java"
        },
        {
            "syntax": "class ClassName:\n    def __init__(self, parameters):",
            "example": "class Person:\n    def __init__(self, name, age):\n        self.name = name\n        self.age = age\n\nperson = Person(\"Alice\", 25)",
            "language": "Python"
        },
        {
            "syntax": "class ClassName { constructor() { } methods() { } }",
            "example": "class Person {\n    constructor(name, age) {\n        this.name = name;\n        this.age = age;\n    }\n}\n\nlet person = new Person(\"Alice\", 25);",
            "language": "JavaScript"
        },
        {
            "syntax": "class ClassName { constructor() { } methods() { } }",
            "example": "class Person {\n    name: string;\n    age: number;\n    \n    constructor(name: string, age: number) {\n        this.name = name;\n        this.age = age;\n    }\n}\n\nlet person = new Person(\"Alice\", 25);",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "Java requires explicit access modifiers and types. Python uses __init__ as constructor. JavaScript uses constructor method. TypeScript adds type annotations to class properties."
}', 'learnin', CURRENT_TIMESTAMP, 'SME'),

                                                                                              (5, 'Constructors and Initialization', '{
    "explaination": "Special methods called when objects are created to initialize instance variables",
    "language_details": [
        {
            "syntax": "public ClassName(parameters) { }",
            "example": "public class Car {\n    private String model;\n    private int year;\n    \n    public Car(String model, int year) {\n        this.model = model;\n        this.year = year;\n    }\n    \n    // Default constructor\n    public Car() {\n        this.model = \"Unknown\";\n        this.year = 2023;\n    }\n}",
            "language": "Java"
        },
        {
            "syntax": "def __init__(self, parameters):",
            "example": "class Car:\n    def __init__(self, model=\"Unknown\", year=2023):\n        self.model = model\n        self.year = year\n\ncar1 = Car(\"Toyota\", 2022)\ncar2 = Car()  # Uses default values",
            "language": "Python"
        },
        {
            "syntax": "constructor(parameters) { }",
            "example": "class Car {\n    constructor(model = \"Unknown\", year = 2023) {\n        this.model = model;\n        this.year = year;\n    }\n}\n\nlet car1 = new Car(\"Toyota\", 2022);\nlet car2 = new Car();  // Uses default values",
            "language": "JavaScript"
        },
        {
            "syntax": "constructor(parameters) { }",
            "example": "class Car {\n    model: string;\n    year: number;\n    \n    constructor(model: string = \"Unknown\", year: number = 2023) {\n        this.model = model;\n        this.year = year;\n    }\n}\n\nlet car1 = new Car(\"Toyota\", 2022);\nlet car2 = new Car();  // Uses default values",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "Java supports constructor overloading. Python and JavaScript/TypeScript use default parameters. Python requires explicit 'self' parameter."
}', 'learnin', CURRENT_TIMESTAMP, 'LLM'),

                                                                                              (5, 'Encapsulation and Access Modifiers', '{
    "explaination": "Controlling access to class members using access modifiers to enforce data hiding",
    "language_details": [
        {
            "syntax": "private, protected, public, package-private",
            "example": "public class BankAccount {\n    private double balance;\n    \n    public BankAccount(double initialBalance) {\n        this.balance = initialBalance;\n    }\n    \n    public double getBalance() {\n        return balance;\n    }\n    \n    public void deposit(double amount) {\n        if (amount > 0) {\n            balance += amount;\n        }\n    }\n}",
            "language": "Java"
        },
        {
            "syntax": "Convention: _name (protected), __name (private)",
            "example": "class BankAccount:\n    def __init__(self, initial_balance):\n        self.__balance = initial_balance  # Private\n    \n    def get_balance(self):\n        return self.__balance\n    \n    def deposit(self, amount):\n        if amount > 0:\n            self.__balance += amount",
            "language": "Python"
        },
        {
            "syntax": "# private fields with # prefix (ES2022)",
            "example": "class BankAccount {\n    #balance;  // Private field\n    \n    constructor(initialBalance) {\n        this.#balance = initialBalance;\n    }\n    \n    getBalance() {\n        return this.#balance;\n    }\n    \n    deposit(amount) {\n        if (amount > 0) {\n            this.#balance += amount;\n        }\n    }\n}",
            "language": "JavaScript"
        },
        {
            "syntax": "private, protected, public, readonly",
            "example": "class BankAccount {\n    private balance: number;\n    \n    constructor(initialBalance: number) {\n        this.balance = initialBalance;\n    }\n    \n    public getBalance(): number {\n        return this.balance;\n    }\n    \n    public deposit(amount: number): void {\n        if (amount > 0) {\n            this.balance += amount;\n        }\n    }\n}",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "Java has built-in access modifiers. Python uses naming conventions. JavaScript uses # for private fields. TypeScript has access modifiers similar to Java."
}', 'learnin', CURRENT_TIMESTAMP, 'SME'),

                                                                                              (5, 'Methods and Instance Variables', '{
    "explaination": "Defining behavior through methods and storing state through instance variables in classes",
    "language_details": [
        {
            "syntax": "accessModifier returnType methodName(parameters) { }",
            "example": "public class Calculator {\n    private double result;\n    \n    public void add(double value) {\n        this.result += value;\n    }\n    \n    public void subtract(double value) {\n        this.result -= value;\n    }\n    \n    public double getResult() {\n        return this.result;\n    }\n    \n    public void reset() {\n        this.result = 0;\n    }\n}",
            "language": "Java"
        },
        {
            "syntax": "def method_name(self, parameters):",
            "example": "class Calculator:\n    def __init__(self):\n        self.result = 0\n    \n    def add(self, value):\n        self.result += value\n    \n    def subtract(self, value):\n        self.result -= value\n    \n    def get_result(self):\n        return self.result\n    \n    def reset(self):\n        self.result = 0",
            "language": "Python"
        },
        {
            "syntax": "methodName(parameters) { }",
            "example": "class Calculator {\n    constructor() {\n        this.result = 0;\n    }\n    \n    add(value) {\n        this.result += value;\n    }\n    \n    subtract(value) {\n        this.result -= value;\n    }\n    \n    getResult() {\n        return this.result;\n    }\n    \n    reset() {\n        this.result = 0;\n    }\n}",
            "language": "JavaScript"
        },
        {
            "syntax": "methodName(parameters): returnType { }",
            "example": "class Calculator {\n    private result: number = 0;\n    \n    add(value: number): void {\n        this.result += value;\n    }\n    \n    subtract(value: number): void {\n        this.result -= value;\n    }\n    \n    getResult(): number {\n        return this.result;\n    }\n    \n    reset(): void {\n        this.result = 0;\n    }\n}",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "Java requires explicit return types and access modifiers. Python methods require 'self' parameter. JavaScript methods are defined without 'function' keyword. TypeScript adds type annotations."
}', 'learnin', CURRENT_TIMESTAMP, 'LLM');
-- Main Topic 6: Exception Handling - Topics
INSERT INTO topics (main_topic_id, title, content, creator_id, created_at, created_using) VALUES
                                                                                              (6, 'Try-Catch-Finally Blocks', '{
    "explaination": "Structured error handling using try-catch blocks to gracefully handle runtime exceptions",
    "language_details": [
        {
            "syntax": "try { } catch (ExceptionType e) { } finally { }",
            "example": "try {\n    int result = 10 / 0;\n    System.out.println(\"Result: \" + result);\n} catch (ArithmeticException e) {\n    System.out.println(\"Error: \" + e.getMessage());\n} finally {\n    System.out.println(\"This always executes\");\n}",
            "language": "Java"
        },
        {
            "syntax": "try:\nexcept ExceptionType as e:\nfinally:",
            "example": "try:\n    result = 10 / 0\n    print(f\"Result: {result}\")\nexcept ZeroDivisionError as e:\n    print(f\"Error: {e}\")\nfinally:\n    print(\"This always executes\")",
            "language": "Python"
        },
        {
            "syntax": "try { } catch (error) { } finally { }",
            "example": "try {\n    let result = 10 / 0;\n    console.log(`Result: ${result}`);\n} catch (error) {\n    console.log(`Error: ${error.message}`);\n} finally {\n    console.log(\"This always executes\");\n}",
            "language": "JavaScript"
        },
        {
            "syntax": "try { } catch (error) { } finally { }",
            "example": "try {\n    let result: number = 10 / 0;\n    console.log(`Result: ${result}`);\n} catch (error: any) {\n    console.log(`Error: ${error.message}`);\n} finally {\n    console.log(\"This always executes\");\n}",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "Java has checked and unchecked exceptions. Python uses except blocks. JavaScript/TypeScript have single catch block for all errors. All support finally for cleanup code."
}', 'learnin', CURRENT_TIMESTAMP, 'SME'),

                                                                                              (6, 'Exception Types and Hierarchy', '{
    "explaination": "Understanding different types of exceptions and their inheritance hierarchy",
    "language_details": [
        {
            "syntax": "Throwable → Exception → RuntimeException, IOException, etc.",
            "example": "try {\n    FileReader file = new FileReader(\"nonexistent.txt\");\n} catch (FileNotFoundException e) {\n    System.out.println(\"File not found: \" + e.getMessage());\n} catch (IOException e) {\n    System.out.println(\"IO Error: \" + e.getMessage());\n} catch (Exception e) {\n    System.out.println(\"General error: \" + e.getMessage());\n}",
            "language": "Java"
        },
        {
            "syntax": "BaseException → SystemExit, KeyboardInterrupt, Exception → ValueError, TypeError, etc.",
            "example": "try:\n    number = int(\"not_a_number\")\nexcept ValueError as e:\n    print(f\"Value error: {e}\")\nexcept TypeError as e:\n    print(f\"Type error: {e}\")\nexcept Exception as e:\n    print(f\"General error: {e}\")",
            "language": "Python"
        },
        {
            "syntax": "Error → TypeError, ReferenceError, RangeError, etc.",
            "example": "try {\n    let obj = null;\n    console.log(obj.property);\n} catch (error) {\n    if (error instanceof TypeError) {\n        console.log(\"Type error occurred\");\n    } else if (error instanceof ReferenceError) {\n        console.log(\"Reference error occurred\");\n    } else {\n        console.log(\"Other error: \" + error.message);\n    }\n}",
            "language": "JavaScript"
        },
        {
            "syntax": "Error → TypeError, ReferenceError, RangeError, etc.",
            "example": "try {\n    let obj: any = null;\n    console.log(obj.property);\n} catch (error: any) {\n    if (error instanceof TypeError) {\n        console.log(\"Type error occurred\");\n    } else if (error instanceof ReferenceError) {\n        console.log(\"Reference error occurred\");\n    } else {\n        console.log(\"Other error: \" + error.message);\n    }\n}",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "Java has extensive exception hierarchy with checked exceptions. Python has built-in exception types. JavaScript has core error types. TypeScript uses JavaScript error types with type checking."
}', 'learnin', CURRENT_TIMESTAMP, 'LLM'),

                                                                                              (6, 'Throwing and Creating Custom Exceptions', '{
    "explaination": "How to throw exceptions and create custom exception classes for application-specific errors",
    "language_details": [
        {
            "syntax": "throw new ExceptionType(message);\nclass CustomException extends Exception { }",
            "example": "class InsufficientFundsException extends Exception {\n    public InsufficientFundsException(String message) {\n        super(message);\n    }\n}\n\npublic void withdraw(double amount) throws InsufficientFundsException {\n    if (amount > balance) {\n        throw new InsufficientFundsException(\"Insufficient funds: \" + balance);\n    }\n    balance -= amount;\n}",
            "language": "Java"
        },
        {
            "syntax": "raise ExceptionType(message)\nclass CustomException(Exception):",
            "example": "class InsufficientFundsException(Exception):\n    def __init__(self, message):\n        super().__init__(message)\n\ndef withdraw(amount):\n    global balance\n    if amount > balance:\n        raise InsufficientFundsException(f\"Insufficient funds: {balance}\")\n    balance -= amount",
            "language": "Python"
        },
        {
            "syntax": "throw new Error(message);\nclass CustomError extends Error { }",
            "example": "class InsufficientFundsError extends Error {\n    constructor(message) {\n        super(message);\n        this.name = \"InsufficientFundsError\";\n    }\n}\n\nfunction withdraw(amount) {\n    if (amount > balance) {\n        throw new InsufficientFundsError(`Insufficient funds: ${balance}`);\n    }\n    balance -= amount;\n}",
            "language": "JavaScript"
        },
        {
            "syntax": "throw new Error(message);\nclass CustomError extends Error { }",
            "example": "class InsufficientFundsError extends Error {\n    constructor(message: string) {\n        super(message);\n        this.name = \"InsufficientFundsError\";\n    }\n}\n\nfunction withdraw(amount: number): void {\n    if (amount > balance) {\n        throw new InsufficientFundsError(`Insufficient funds: ${balance}`);\n    }\n    balance -= amount;\n}",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "Java uses throws keyword in method signature. Python uses raise. JavaScript/TypeScript use throw. All allow custom exception classes by extending base exception types."
}', 'learnin', CURRENT_TIMESTAMP, 'SME'),

                                                                                              (6, 'Best Practices and Error Recovery', '{
    "explaination": "Guidelines for effective exception handling and strategies for error recovery",
    "language_details": [
        {
            "syntax": "Specific catches, resource management with try-with-resources",
            "example": "// Try-with-resources for automatic cleanup\ntry (FileReader reader = new FileReader(\"file.txt\");\n     BufferedReader br = new BufferedReader(reader)) {\n    String line = br.readLine();\n    System.out.println(line);\n} catch (IOException e) {\n    System.err.println(\"Error reading file: \" + e.getMessage());\n    // Log and recover or rethrow\n}",
            "language": "Java"
        },
        {
            "syntax": "Context managers with with statement, specific exceptions",
            "example": "try:\n    with open(\"file.txt\", \"r\") as file:\n        content = file.read()\n        print(content)\nexcept FileNotFoundError:\n    print(\"File not found, using default configuration\")\n    # Recovery logic\nexcept PermissionError:\n    print(\"Permission denied, check file permissions\")\n    # Alternative logic",
            "language": "Python"
        },
        {
            "syntax": "Async error handling, promise rejection handling",
            "example": "async function fetchData() {\n    try {\n        const response = await fetch(https://api.example.com/data);\n        if (!response.ok) {\n            throw new Error(`HTTP error! status: ${response.status}`);\n        }\n        const data = await response.json();\n        return data;\n    } catch (error) {\n        console.error(Fetch failed:, error);\n        // Return default data or retry logic\n        return { default: true };\n    }\n}",
            "language": "JavaScript"
        },
        {
            "syntax": "Async error handling, type-safe error handling",
            "example": "async function fetchData(): Promise<any> {\n    try {\n        const response = await fetch(''https://api.example.com/data'');\n        if (!response.ok) {\n            throw new Error(`HTTP error! status: ${response.status}`);\n        }\n        const data = await response.json();\n        return data;\n    } catch (error: any) {\n        console.error(''Fetch failed:'', error);\n        // Return default data with proper typing\n        return { default: true };\n    }\n}",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "Java has try-with-resources for automatic cleanup. Python has context managers. JavaScript/TypeScript focus on async error handling. All emphasize catching specific exceptions and graceful recovery."
}', 'learnin', CURRENT_TIMESTAMP, 'LLM');

-- Main Topic 7: Inheritance & Polymorphism - Topics
INSERT INTO topics (main_topic_id, title, content, creator_id, created_at, created_using) VALUES
                                                                                              (7, 'Inheritance and Base Classes', '{
    "explaination": "Creating class hierarchies where subclasses inherit properties and methods from parent classes",
    "language_details": [
        {
            "syntax": "class Subclass extends Superclass { }",
            "example": "public class Animal {\n    protected String name;\n    \n    public Animal(String name) {\n        this.name = name;\n    }\n    \n    public void speak() {\n        System.out.println(\"Animal sound\");\n    }\n}\n\npublic class Dog extends Animal {\n    public Dog(String name) {\n        super(name);\n    }\n    \n    @Override\n    public void speak() {\n        System.out.println(name + \" says: Woof!\");\n    }\n}",
            "language": "Java"
        },
        {
            "syntax": "class Subclass(Superclass):",
            "example": "class Animal:\n    def __init__(self, name):\n        self.name = name\n    \n    def speak(self):\n        print(\"Animal sound\")\n\nclass Dog(Animal):\n    def __init__(self, name):\n        super().__init__(name)\n    \n    def speak(self):\n        print(f\"{self.name} says: Woof!\")",
            "language": "Python"
        },
        {
            "syntax": "class Subclass extends Superclass { }",
            "example": "class Animal {\n    constructor(name) {\n        this.name = name;\n    }\n    \n    speak() {\n        console.log(\"Animal sound\");\n    }\n}\n\nclass Dog extends Animal {\n    constructor(name) {\n        super(name);\n    }\n    \n    speak() {\n        console.log(`${this.name} says: Woof!`);\n    }\n}",
            "language": "JavaScript"
        },
        {
            "syntax": "class Subclass extends Superclass { }",
            "example": "class Animal {\n    protected name: string;\n    \n    constructor(name: string) {\n        this.name = name;\n    }\n    \n    speak(): void {\n        console.log(\"Animal sound\");\n    }\n}\n\nclass Dog extends Animal {\n    constructor(name: string) {\n        super(name);\n    }\n    \n    speak(): void {\n        console.log(`${this.name} says: Woof!`);\n    }\n}",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "All languages use ''extends'' keyword for inheritance. Java uses ''@Override'' annotation. Python uses super() for parent constructor. JavaScript/TypeScript use super() call in constructor."
}', 'learnin', CURRENT_TIMESTAMP, 'SME'),

                                                                                              (7, 'Method Overriding and Super Keyword', '{
    "explaination": "Replacing parent class methods in subclasses and accessing parent class functionality",
    "language_details": [
        {
            "syntax": "@Override\nsuper.method()\nsuper()",
            "example": "public class Vehicle {\n    protected String brand;\n    \n    public Vehicle(String brand) {\n        this.brand = brand;\n    }\n    \n    public void start() {\n        System.out.println(brand + \" vehicle starting\");\n    }\n}\n\npublic class Car extends Vehicle {\n    private int doors;\n    \n    public Car(String brand, int doors) {\n        super(brand);  // Call parent constructor\n        this.doors = doors;\n    }\n    \n    @Override\n    public void start() {\n        super.start();  // Call parent method\n        System.out.println(\"Car with \" + doors + \" doors is ready\");\n    }\n}",
            "language": "Java"
        },
        {
            "syntax": "super().method()\nsuper().__init__()",
            "example": "class Vehicle:\n    def __init__(self, brand):\n        self.brand = brand\n    \n    def start(self):\n        print(f\"{self.brand} vehicle starting\")\n\nclass Car(Vehicle):\n    def __init__(self, brand, doors):\n        super().__init__(brand)  # Call parent constructor\n        self.doors = doors\n    \n    def start(self):\n        super().start()  # Call parent method\n        print(f\"Car with {self.doors} doors is ready\")",
            "language": "Python"
        },
        {
            "syntax": "super.method()\nsuper()",
            "example": "class Vehicle {\n    constructor(brand) {\n        this.brand = brand;\n    }\n    \n    start() {\n        console.log(`${this.brand} vehicle starting`);\n    }\n}\n\nclass Car extends Vehicle {\n    constructor(brand, doors) {\n        super(brand);  // Call parent constructor\n        this.doors = doors;\n    }\n    \n    start() {\n        super.start();  // Call parent method\n        console.log(`Car with ${this.doors} doors is ready`);\n    }\n}",
            "language": "JavaScript"
        },
        {
            "syntax": "super.method()\nsuper()",
            "example": "class Vehicle {\n    protected brand: string;\n    \n    constructor(brand: string) {\n        this.brand = brand;\n    }\n    \n    start(): void {\n        console.log(`${this.brand} vehicle starting`);\n    }\n}\n\nclass Car extends Vehicle {\n    private doors: number;\n    \n    constructor(brand: string, doors: number) {\n        super(brand);  // Call parent constructor\n        this.doors = doors;\n    }\n    \n    start(): void {\n        super.start();  // Call parent method\n        console.log(`Car with ${this.doors} doors is ready`);\n    }\n}",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "All languages use ''super'' keyword to access parent class. Java requires @Override annotation. Python uses super() for both constructor and methods. JavaScript/TypeScript use super for constructor and super.method() for methods."
}', 'learnin', CURRENT_TIMESTAMP, 'LLM'),

                                                                                              (7, 'Polymorphism and Dynamic Binding', '{
    "explaination": "Ability of objects to take many forms and the runtime determination of method calls",
    "language_details": [
        {
            "syntax": "ParentClass obj = new ChildClass()",
            "example": "public class Shape {\n    public void draw() {\n        System.out.println(\"Drawing a shape\");\n    }\n}\n\npublic class Circle extends Shape {\n    @Override\n    public void draw() {\n        System.out.println(\"Drawing a circle\");\n    }\n}\n\npublic class Square extends Shape {\n    @Override\n    public void draw() {\n        System.out.println(\"Drawing a square\");\n    }\n}\n\n// Polymorphism in action\nShape shape1 = new Circle();\nShape shape2 = new Square();\nshape1.draw();  // Output: Drawing a circle\nshape2.draw();  // Output: Drawing a square",
            "language": "Java"
        },
        {
            "syntax": "Duck typing - if it quacks like a duck, it''s a duck",
            "example": "class Shape:\n    def draw(self):\n        print(\"Drawing a shape\")\n\nclass Circle(Shape):\n    def draw(self):\n        print(\"Drawing a circle\")\n\nclass Square(Shape):\n    def draw(self):\n        print(\"Drawing a square\")\n\n# Polymorphism in action\nshapes = [Circle(), Square(), Shape()]\nfor shape in shapes:\n    shape.draw()\n# Output: Drawing a circle, Drawing a square, Drawing a shape",
            "language": "Python"
        },
        {
            "syntax": "Prototype-based polymorphism",
            "example": "class Shape {\n    draw() {\n        console.log(\"Drawing a shape\");\n    }\n}\n\nclass Circle extends Shape {\n    draw() {\n        console.log(\"Drawing a circle\");\n    }\n}\n\nclass Square extends Shape {\n    draw() {\n        console.log(\"Drawing a square\");\n    }\n}\n\n// Polymorphism in action\nconst shapes = [new Circle(), new Square(), new Shape()];\nshapes.forEach(shape => shape.draw());\n// Output: Drawing a circle, Drawing a square, Drawing a shape",
            "language": "JavaScript"
        },
        {
            "syntax": "Interface-based polymorphism",
            "example": "interface Shape {\n    draw(): void;\n}\n\nclass Circle implements Shape {\n    draw(): void {\n        console.log(\"Drawing a circle\");\n    }\n}\n\nclass Square implements Shape {\n    draw(): void {\n        console.log(\"Drawing a square\");\n    }\n}\n\n// Polymorphism in action\nconst shapes: Shape[] = [new Circle(), new Square()];\nshapes.forEach(shape => shape.draw());\n// Output: Drawing a circle, Drawing a square",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "Java and TypeScript use interface-based polymorphism. Python uses duck typing. JavaScript uses prototype-based inheritance. All support runtime polymorphism where the actual method called depends on the object type."
}', 'learnin', CURRENT_TIMESTAMP, 'SME'),

                                                                                              (7, 'Abstract Classes and Interfaces', '{
    "explaination": "Defining contracts and partial implementations that must be completed by subclasses",
    "language_details": [
        {
            "syntax": "abstract class, interface, implements",
            "example": "// Abstract class\nabstract class Animal {\n    protected String name;\n    \n    public Animal(String name) {\n        this.name = name;\n    }\n    \n    // Abstract method - must be implemented by subclasses\n    public abstract void makeSound();\n    \n    // Concrete method\n    public void sleep() {\n        System.out.println(name + \" is sleeping\");\n    }\n}\n\n// Interface\ninterface Swimmable {\n    void swim();\n}\n\nclass Dolphin extends Animal implements Swimmable {\n    public Dolphin(String name) {\n        super(name);\n    }\n    \n    @Override\n    public void makeSound() {\n        System.out.println(name + \" clicks and whistles\");\n    }\n    \n    @Override\n    public void swim() {\n        System.out.println(name + \" is swimming gracefully\");\n    }\n}",
            "language": "Java"
        },
        {
            "syntax": "ABC (Abstract Base Classes), @abstractmethod",
            "example": "from abc import ABC, abstractmethod\n\nclass Animal(ABC):\n    def __init__(self, name):\n        self.name = name\n    \n    @abstractmethod\n    def make_sound(self):\n        pass\n    \n    def sleep(self):\n        print(f\"{self.name} is sleeping\")\n\nclass Dog(Animal):\n    def make_sound(self):\n        print(f\"{self.name} says: Woof!\")\n\n# Interface-like behavior using ABC\nclass Swimmable(ABC):\n    @abstractmethod\n    def swim(self):\n        pass\n\nclass Dolphin(Animal, Swimmable):\n    def make_sound(self):\n        print(f\"{self.name} clicks and whistles\")\n    \n    def swim(self):\n        print(f\"{self.name} is swimming gracefully\")",
            "language": "Python"
        },
        {
            "syntax": "No native abstract classes, use conventions or TypeScript",
            "example": "// JavaScript - using convention\nclass Animal {\n    constructor(name) {\n        if (this.constructor === Animal) {\n            throw new Error(\"Cannot instantiate abstract class\");\n        }\n        this.name = name;\n    }\n    \n    makeSound() {\n        throw new Error(\"Method ''makeSound()'' must be implemented\");\n    }\n    \n    sleep() {\n        console.log(`${this.name} is sleeping`);\n    }\n}\n\nclass Dog extends Animal {\n    makeSound() {\n        console.log(`${this.name} says: Woof!`);\n    }\n}",
            "language": "JavaScript"
        },
        {
            "syntax": "abstract class, interface, implements",
            "example": "// Abstract class\nabstract class Animal {\n    protected name: string;\n    \n    constructor(name: string) {\n        this.name = name;\n    }\n    \n    abstract makeSound(): void;\n    \n    sleep(): void {\n        console.log(`${this.name} is sleeping`);\n    }\n}\n\n// Interface\ninterface Swimmable {\n    swim(): void;\n}\n\nclass Dolphin extends Animal implements Swimmable {\n    constructor(name: string) {\n        super(name);\n    }\n    \n    makeSound(): void {\n        console.log(`${this.name} clicks and whistles`);\n    }\n    \n    swim(): void {\n        console.log(`${this.name} is swimming gracefully`);\n    }\n}",
            "language": "TypeScript"
        }
    ],
    "code_difference_explaination": "Java has built-in abstract classes and interfaces. Python uses ABC module. JavaScript lacks native abstract classes (convention-based). TypeScript adds abstract classes and interfaces similar to Java."
}', 'learnin', CURRENT_TIMESTAMP, 'LLM');

-- ============================================================================
-- Verification Query
-- ============================================================================

-- Verify all topics were inserted successfully
SELECT main_topic_id, COUNT(*) as subtopic_count,
       SUM(CASE WHEN created_using = 'SME' THEN 1 ELSE 0 END) as sme_count
FROM topics
GROUP BY main_topic_id
ORDER BY main_topic_id;

-- Count total topics
SELECT COUNT(*) as total_topics FROM topics;

-- ============================================================================
-- End of Script
-- ============================================================================

-- Script Summary:
-- - Total Topics Inserted: 28 (4 per main topic × 7 main topics)
-- - Each main topic has exactly 2 topics with created_using = 'SME'
-- - Each main topic has exactly 2 topics with created_using = 'LLM'
-- - All topics created by user 'learnin'
-- - Complete coverage of OOP, Exception Handling, and Inheritance concepts-- - Complete coverage of OOP, Exception Handling, and Inheritance concepts