package com.ignite.CBL;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CblBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
