package com.ignite.CBL.service;

import com.ignite.CBL.dto.CompletionValidationResponse;
import com.ignite.CBL.dto.MainTopicEngagementResponseDTO;
import com.ignite.CBL.dto.TopicEngagementDTO;


public interface   UserMainTopicEngagementService {
    public CompletionValidationResponse validateAndMarkCompletion(Integer mainTopicId, String language);

    public MainTopicEngagementResponseDTO getMainTopicEngagement(Integer mainTopicId);
}
