package com.ignite.CBL.service;

import com.ignite.CBL.dto.TopicEngagementResponseDTO;
import com.ignite.CBL.dto.TopicLanguageEngagementRequestDTO;
import com.ignite.CBL.dto.MainTopicEngagementResponseDTO;
import com.ignite.CBL.dto.MainTopicEngagementResponseDTO;

public interface UserTopicEngagementService {

    MainTopicEngagementResponseDTO updateLanguageWiseEngagement(TopicLanguageEngagementRequestDTO requestDTO);

    TopicEngagementResponseDTO getTopicEngagement(Integer topicId);

    TopicEngagementResponseDTO markMcqAsVisited(Integer topicId, String language);

    MainTopicEngagementResponseDTO getMainTopicEngagement(Integer mainTopicId);
}