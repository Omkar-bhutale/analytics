package com.ignite.CBL.dto.learning;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for "Mark as Complete" button status
 * Response for: GET /api/user/learning/progress/mark-complete-status
 *
 * Tells frontend whether button should be enabled and why
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MarkCompleteStatusDTO {
    private Boolean canMarkComplete;
    private String reason;  // Explanation if cannot mark complete
}

