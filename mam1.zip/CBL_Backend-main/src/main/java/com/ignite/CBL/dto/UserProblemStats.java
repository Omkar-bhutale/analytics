package com.ignite.CBL.dto;

public interface UserProblemStats {
    String getUserId();
    String getUserName();
    Long getTotalSolved();
    Long getSolvedInJava();
    Long getSolvedInPython();
    Long getSolvedInJavascript();
    Long getSolvedInTypescript();
}