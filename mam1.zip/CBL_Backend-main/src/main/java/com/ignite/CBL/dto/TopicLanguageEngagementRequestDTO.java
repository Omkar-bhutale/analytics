package com.ignite.CBL.dto;

import com.ignite.CBL.entity.Language;
import lombok.Data;

@Data
public class TopicLanguageEngagementRequestDTO {
    private Integer topicId;
    private Language language;   // ENUM: JAVA, PYTHON, JAVASCRIPT, TYPESCRIPT
    private Long timeSpentSeconds;
}