package com.ignite.CBL.dto.learning;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for time delta request (sent when user switches language/subtopic/topic)
 * Request for: POST /api/user/learning/time-tracking/delta
 *
 * Contains incremental time to be added (not full time)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TimeDeltaRequestDTO {
    private Integer subtopicId;
    private String language;     // "JAVA", "PYTHON", "JAVASCRIPT", "TYPESCRIPT"
    private Long deltaSeconds;   // Incremental time to add
}

