package com.ignite.CBL.controller;

import com.ignite.CBL.dto.MainTopicSubTopicsResponceDTO;
import com.ignite.CBL.dto.TopicDTO;
import com.ignite.CBL.dto.TopicImportResponse;
import com.ignite.CBL.service.TopicService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/sme/topics")
@RequiredArgsConstructor
@Validated
@Tag(name = "Topic Management", description = "APIs for managing topics by SME")
public class TopicSMEController {

    private final TopicService topicService;

    @PostMapping(value = "/import",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(summary = "Import topics from Excel file",
            description = "Upload an Excel file with two columns: MainTopic and Topic. Creates main topics and topics if they don't exist.")
    @ApiResponse(responseCode = "200", description = "Successfully imported topics",
            content = @Content(schema = @Schema(implementation = TopicImportResponse.class)))
    public ResponseEntity<TopicImportResponse> importTopicsFromExcel(
            @Parameter(description = "Excel file containing main topics and topics", required = true)
            @RequestParam("file") MultipartFile file) {

        if (file.isEmpty()) {
            throw new IllegalArgumentException("File is empty");
        }

        TopicImportResponse response = topicService.importFromExcel(file);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/{topicId}")
    @Operation(summary = "Get topic by ID",
            responses = {
                @ApiResponse(responseCode = "200", description = "Successfully retrieved topic",
                        content = @Content(schema = @Schema(implementation = TopicDTO.class))),
                @ApiResponse(responseCode = "404", description = "Topic not found")
            })
    public ResponseEntity<TopicDTO> getTopicById(
            @Parameter(description = "ID of the topic to be retrieved", required = true)
            @PathVariable Integer topicId) {
        return topicService.findTopicById(topicId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/by-title/{title}")
    @Operation(summary = "Get topic by title")
    public ResponseEntity<TopicDTO> getTopicByTitle(
            @Parameter(description = "Title of the topic to be retrieved", required = true)
            @PathVariable String title) {
        return topicService.findTopicByTitle(title)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/main-topic/{mainTopicId}")
    @Operation(summary = "Get all topics by main topic ID with pagination")
    public ResponseEntity<List<TopicDTO>> getTopicsByMainTopic(
            @Parameter(description = "ID of the main topic", required = true)
            @PathVariable Integer mainTopicId
           ) {
        return ResponseEntity.ok(topicService.findAllByMainTopicId(mainTopicId));
    }

    @PostMapping("/{mainTopicId}")
    @Operation(summary = "Create a new topic")
    @ResponseStatus(HttpStatus.CREATED)
    public TopicDTO createTopic(
            @Parameter(description = "ID of the main topic", required = true)
            @PathVariable Integer mainTopicId,
            @Valid @RequestBody TopicDTO topicDTO) {
        return topicService.createTopic(mainTopicId, topicDTO);
    }

    @PostMapping("/batch/{mainTopicId}")
    @Operation(summary = "Create multiple topics")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<Integer> createTopics(
            @Parameter(description = "ID of the main topic", required = true)
            @PathVariable Integer mainTopicId,
            @Valid @RequestBody List<TopicDTO> topicDTOs) {
        int createdCount = topicService.createTopics(mainTopicId, topicDTOs);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdCount);
    }

    @PutMapping("/{topicId}")
    @Operation(summary = "Update an existing topic")
    public ResponseEntity<TopicDTO> updateTopic(
            @Parameter(description = "ID of the topic to be updated", required = true)
            @PathVariable Integer topicId,
            @Valid @RequestBody TopicDTO topicDTO) {
        return topicService.updateTopic(topicId, topicDTO)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{topicId}")
    @Operation(summary = "Delete a topic by ID")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public ResponseEntity<Void> deleteTopicById(
            @Parameter(description = "ID of the topic to be deleted", required = true)
            @PathVariable Integer topicId) {
        if (topicService.deleteTopicById(topicId)) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
    @GetMapping("/main-topics")
    @Operation(summary = "Get all main topics with their subtopics")
    public ResponseEntity<List<MainTopicSubTopicsResponceDTO>> getAllMainTopicSubTopics() {
        List<MainTopicSubTopicsResponceDTO> mainTopicSubTopics = topicService.findAllMainTopicSubTopics();
        return ResponseEntity.ok(mainTopicSubTopics);
    }

//    @DeleteMapping("/main-topic/{mainTopicId}")
//    @Operation(summary = "Delete all topics by main topic ID")
//    @ResponseStatus(HttpStatus.NO_CONTENT)
//    public ResponseEntity<Void> deleteAllByMainTopicId(
//            @Parameter(description = "ID of the main topic", required = true)
//            @PathVariable Integer mainTopicId) {
//        int deletedCount = topicService.deleteAllByMainTopicId(mainTopicId);
//        if (deletedCount > 0) {
//            return ResponseEntity.noContent().build();
//        }
//        return ResponseEntity.notFound().build();
//    }

    @GetMapping("/exists/title/{title}")
    @Operation(summary = "Check if a topic with the given title exists")
    public ResponseEntity<Boolean> checkTitleExists(
            @Parameter(description = "Title to check", required = true)
            @PathVariable String title) {
        return ResponseEntity.ok(topicService.existsByTitle(title));
    }
}
