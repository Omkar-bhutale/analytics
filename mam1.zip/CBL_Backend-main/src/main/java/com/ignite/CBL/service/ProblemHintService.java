package com.ignite.CBL.service;

import com.ignite.CBL.dto.ProblemHintResponseDTO;

public interface ProblemHintService {
    ProblemHintResponseDTO getHintForProblem(Integer problemId);
}