package com.ignite.CBL.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.Set;

@Getter
@Setter
public class UserDashboardResponceDTO {
    private String userId;
    private String userName;
    private String batchName;
    private List<UserProblemReportDTO> userProblemReportDTOS;
}
