package com.ignite.CBL.controller;

import com.ignite.CBL.dto.learning.*;
import com.ignite.CBL.service.LearningPageService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controller for Learning Page APIs
 * Handles all endpoints for topics, subtopics, time tracking, and progress
 */
@RestController
@RequestMapping("/api/user/learning")
@RequiredArgsConstructor
public class LearningPageController {

    private final LearningPageService learningPageService;

    // ========== A. TOPIC & CONTENT APIs ==========

    /**
     * Get all main topics (for sidebar)
     * GET /api/user/learning/main-topics
     */
    @GetMapping("/main-topics")
    public ResponseEntity<List<MainTopicSummaryDTO>> getAllMainTopics(
            @AuthenticationPrincipal UserDetails userDetails) {
        List<MainTopicSummaryDTO> mainTopics = learningPageService.getAllMainTopics(userDetails.getUsername());
        return ResponseEntity.ok(mainTopics);
    }

    /**
     * Get all subtopics for a main topic
     * GET /api/user/learning/main-topics/{mainTopicId}/subtopics
     */
    @GetMapping("/main-topics/{mainTopicId}/subtopics")
    public ResponseEntity<List<SubtopicSummaryDTO>> getSubtopicsByMainTopic(
            @PathVariable Integer mainTopicId,
            @AuthenticationPrincipal UserDetails userDetails) {
        List<SubtopicSummaryDTO> subtopics = learningPageService.getSubtopicsByMainTopic(
                mainTopicId,
                userDetails.getUsername()
        );
        return ResponseEntity.ok(subtopics);
    }

    /**
     * Get subtopic content with all languages and MCQ status
     * GET /api/user/learning/subtopics/{subtopicId}
     */
    @GetMapping("/subtopics/{subtopicId}")
    public ResponseEntity<SubtopicContentDTO> getSubtopicContent(
            @PathVariable Integer subtopicId,
            @AuthenticationPrincipal UserDetails userDetails) {
        SubtopicContentDTO content = learningPageService.getSubtopicContent(
                subtopicId,
                userDetails.getUsername()
        );
        return ResponseEntity.ok(content);
    }

    // ========== B. TIMER APIs ==========

    /**
     * Get timer data for a main topic (all languages)
     * GET /api/user/learning/time-tracking/main-topic/{mainTopicId}
     */
    @GetMapping("/time-tracking/main-topic/{mainTopicId}")
    public ResponseEntity<MainTopicTimerDTO> getMainTopicTimer(
            @PathVariable Integer mainTopicId,
            @AuthenticationPrincipal UserDetails userDetails) {
        MainTopicTimerDTO timer = learningPageService.getMainTopicTimer(
                mainTopicId,
                userDetails.getUsername()
        );
        return ResponseEntity.ok(timer);
    }

    /**
     * Send time delta for subtopic + language
     * POST /api/user/learning/time-tracking/delta
     */
    @PostMapping("/time-tracking/delta")
    public ResponseEntity<TimeDeltaResponseDTO> sendTimeDelta(
            @RequestBody TimeDeltaRequestDTO request,
            @AuthenticationPrincipal UserDetails userDetails) {
        TimeDeltaResponseDTO response = learningPageService.updateTimeDelta(
                request,
                userDetails.getUsername()
        );
        return ResponseEntity.ok(response);
    }

    // ========== C. PROGRESS/COMPLETION APIs ==========

    /**
     * Get status for "Mark as Complete" button
     * GET /api/user/learning/progress/mark-complete-status?mainTopicId={id}&language={lang}
     */
    @GetMapping("/progress/mark-complete-status")
    public ResponseEntity<MarkCompleteStatusDTO> getMarkCompleteStatus(
            @RequestParam Integer mainTopicId,
            @RequestParam String language,
            @AuthenticationPrincipal UserDetails userDetails) {
        MarkCompleteStatusDTO status = learningPageService.getMarkCompleteStatus(
                mainTopicId,
                language,
                userDetails.getUsername()
        );
        return ResponseEntity.ok(status);
    }

    /**
     * Mark main topic as complete for a language
     * PUT /api/user/learning/progress/{mainTopicId}/mark-complete?language={lang}
     */
    @PutMapping("/progress/{mainTopicId}/mark-complete")
    public ResponseEntity<CompletionResponseDTO> markTopicComplete(
            @PathVariable Integer mainTopicId,
            @RequestParam String language,
            @AuthenticationPrincipal UserDetails userDetails) {
        CompletionResponseDTO response = learningPageService.markTopicComplete(
                mainTopicId,
                language,
                userDetails.getUsername()
        );
        return ResponseEntity.ok(response);
    }

    /**
     * Get MCQ status for a subtopic (all languages)
     * GET /api/user/learning/progress/mcq-status/{subtopicId}
     */
    @GetMapping("/progress/mcq-status/{subtopicId}")
    public ResponseEntity<McqStatusDTO> getMcqStatus(
            @PathVariable Integer subtopicId,
            @AuthenticationPrincipal UserDetails userDetails) {
        McqStatusDTO status = learningPageService.getMcqStatus(
                subtopicId,
                userDetails.getUsername()
        );
        return ResponseEntity.ok(status);
    }

    /**
     * Mark MCQ as visited for subtopic + language
     * PUT /api/user/learning/progress/{subtopicId}/mcq-visited?language={lang}
     */
    @PutMapping("/progress/{subtopicId}/mcq-visited")
    public ResponseEntity<CompletionResponseDTO> markMcqVisited(
            @PathVariable Integer subtopicId,
            @RequestParam String language,
            @AuthenticationPrincipal UserDetails userDetails) {
        CompletionResponseDTO response = learningPageService.markMcqVisited(
                subtopicId,
                language,
                userDetails.getUsername()
        );
        return ResponseEntity.ok(response);
    }
}

