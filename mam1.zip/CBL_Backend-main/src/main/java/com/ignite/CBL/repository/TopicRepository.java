package com.ignite.CBL.repository;

import com.ignite.CBL.dto.TopicDTO;
import com.ignite.CBL.entity.MainTopic;
import com.ignite.CBL.entity.Topic;
import com.ignite.CBL.entity.Topic;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Repository
public interface TopicRepository extends JpaRepository<Topic, Integer> {
    
    @Query("SELECT new com.ignite.CBL.dto.TopicDTO(t.topicId, t.title, t.content, t.createdAt, t.createdUsing) " +
           "FROM Topic t WHERE t.topicId = :topicId")
    Optional<TopicDTO> findTopicDTOById(@Param("topicId") Integer topicId);
    
    @Query("SELECT t FROM Topic t LEFT JOIN FETCH t.mainTopic WHERE t.topicId = :topicId")
    Optional<Topic> findByIdWithMainTopic(@Param("topicId") Integer topicId);
    
    @Query("SELECT new com.ignite.CBL.dto.TopicDTO(t.topicId, t.title, t.content, t.createdAt, t.createdUsing) " +
           "FROM Topic t WHERE t.title = :title")
    Optional<TopicDTO> findTopicDTOByTitle(@Param("title") String title);
    
    @Query("SELECT new com.ignite.CBL.dto.TopicDTO(t.topicId, t.title, t.content, t.createdAt, t.createdUsing) " +
           "FROM Topic t WHERE t.mainTopic.mainTopicId = :mainTopicId")
    List<TopicDTO> findAllByMainTopicId(@Param("mainTopicId") Integer mainTopicId);
    
    @Query("SELECT t FROM Topic t LEFT JOIN FETCH t.mainTopic WHERE t.mainTopic.mainTopicId = :mainTopicId")
    List<Topic> findAllByMainTopicIdWithMainTopic(@Param("mainTopicId") Integer mainTopicId);
    @Query("SELECT t FROM Topic t LEFT JOIN FETCH t.problems WHERE t.topicId = :topicId")
    Optional<Topic> findByIdWithProblems(@Param("topicId") Integer topicId);
    
    boolean existsByTitle(String title);
    
    @Query("SELECT COUNT(t) > 0 FROM Topic t WHERE t.title = :title AND t.mainTopic.mainTopicId = :mainTopicId")
    boolean existsByTitleAndMainTopicId(@Param("title") String title, @Param("mainTopicId") Integer mainTopicId);
    
    @Modifying
    @Query("DELETE FROM Topic t WHERE t.mainTopic.mainTopicId = :mainTopicId")
    @Transactional
    int deleteByMainTopicId(@Param("mainTopicId") Integer mainTopicId);
    @Modifying
    @Transactional
    @Query("UPDATE Topic t SET t.title = :title, t.content = :content WHERE t.topicId = :topicId")
    int updateTopic(@Param("topicId") Integer topicId, 
                   @Param("title") String title, 
                   @Param("content") String content);
    
    @Query("SELECT new com.ignite.CBL.dto.TopicDTO(t.topicId, t.title, t.content, t.createdAt, t.createdUsing) " +
           "FROM Topic t WHERE t.mainTopic.mainTopicId = :mainTopicId")
    List<TopicDTO> findByMainTopicId(@Param("mainTopicId") Integer mainTopicId);

    @Query("SELECT mt FROM MainTopic mt WHERE mt.mainTopicId = :mainTopicId")
    Optional<MainTopic> findMainTopicById(@Param("mainTopicId") Integer mainTopicId);

    @Query("SELECT t FROM Topic t LEFT JOIN FETCH t.mainTopic WHERE t.mainTopic.mainTopicId = :mainTopicId")
    List<Topic> findAllByMainTopicIdComplete(@Param("mainTopicId") Integer mainTopicId);
}
