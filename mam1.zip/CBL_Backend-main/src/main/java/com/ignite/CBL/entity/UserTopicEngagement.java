
package com.ignite.CBL.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "user_topic_engagement")
@Getter
@Setter
public class UserTopicEngagement {

    @EmbeddedId
    private UserTopicEngagementId userTopicEngagementId;

    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("userId")
    @JoinColumn(name = "user_id", updatable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("topicId")
    @JoinColumn(name = "topic_id", updatable = false)
    @JsonBackReference("topic-engagements")
    private Topic topic;

    @Column(name = "total_seconds_spent", nullable = false)
    private int totalTimeSpent = 0;

    @Column(name = "last_activity_at", nullable = false)
    private LocalDateTime lastActivityAt;

    @Column(name = "java_time_seconds")
    private Long javaTimeSeconds = 0L;

    @Column(name = "python_time_seconds")
    private Long pythonTimeSeconds = 0L;

    @Column(name = "javascript_time_seconds")
    private Long javascriptTimeSeconds = 0L;

    @Column(name = "typescript_time_seconds")
    private Long typescriptTimeSeconds = 0L;

    @Column(name = "java_visited")
    private Boolean javaVisited = false;

    @Column(name = "python_visited")
    private Boolean pythonVisited = false;

    @Column(name = "javascript_visited")
    private Boolean javascriptVisited = false;

    @Column(name = "typescript_visited")
    private Boolean typescriptVisited = false;


    @Column(name = "mcq_visited")
    private Boolean mcqVisited = false;

    // ✅ NEW: MCQ visit tracking per language
    @Column(name = "java_mcq_visited")
    private Boolean javaMcqVisited = false;

    @Column(name = "python_mcq_visited")
    private Boolean pythonMcqVisited = false;

    @Column(name = "javascript_mcq_visited")
    private Boolean javascriptMcqVisited = false;

    @Column(name = "typescript_mcq_visited")
    private Boolean typescriptMcqVisited = false;





    @Column(name = "is_completed", nullable = false)
    private boolean isCompleted = false;
}
