package com.ignite.CBL.service;

import com.ignite.CBL.dto.*;
import com.ignite.CBL.entity.Difficulty;
import com.ignite.CBL.entity.ProblemSubmission;

import java.util.List;
import java.util.Optional;

public interface ProblemSubmissionService {

    public ProblemCodeResponceDTO getProblemToSolve(Integer problemId);
    public void saveCodeAndTime(SaveCodeAndTimeRequest SaveCodeAndTimeRequest);
    public boolean saveSubmission(ProblemSubmissionRequestDTO problemSubmissionRequestDTO);

    ProblemCodeResponceDTO getMainTopicProblem(Integer mainTopicId);

    public List<ProblemSubmissionResponceDTO> getAllSubmissions(Integer problemId);
    
    List<MainTopicSubTopicsResponceDTO> getAllProblems();

    /**
     * Get all submissions for the logged-in user
     */
    List<ProblemSubmissionResponceDTO> getUserSubmissions();

    /**
     * Get all submissions for a specific user by userId
     */
    List<ProblemSubmissionResponceDTO> getUserSubmissions(String userId);

}
