package com.ignite.CBL.dto.learning;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for subtopic content with all languages
 * Response for: GET /api/user/learning/subtopics/{subtopicId}
 *
 * Contains:
 * - Subtopic metadata
 * - Content as raw JSON (frontend will parse)
 * - MCQ visited status per language
 * - Whether this is the last subtopic
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SubtopicContentDTO {
    private Integer subtopicId;
    private String name;
    private Integer mainTopicId;
    private JsonNode content;  // Send raw JSON directly to frontend
    private McqStatusDTO mcqStatus;
    private Boolean isLastSubtopic;
}

