package com.ignite.CBL.dto.learning;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for subtopic summary (sidebar display under main topic)
 * Response for: GET /api/user/learning/main-topics/{mainTopicId}/subtopics
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SubtopicSummaryDTO {
    private Integer subtopicId;
    private String name;
}

