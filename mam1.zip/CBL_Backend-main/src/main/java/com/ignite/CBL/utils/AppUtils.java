package com.ignite.CBL.utils;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;

public class AppUtils {
    public static String getCurrentUserId(){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String userId = null;
        if (authentication != null && authentication.getPrincipal() instanceof Jwt) {
            Jwt principal1 = (Jwt) authentication.getPrincipal();
            userId = principal1.getClaim("preferred_username").toString().substring(0,7);
            System.out.println("Hello, " + principal1.getClaim("preferred_username").toString().substring(0,7) + "! You accessed a secured resource manually.");
        }
        return userId;
    }
}
