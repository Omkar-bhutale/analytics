package com.ignite.CBL.entity;


import com.fasterxml.jackson.databind.JsonNode;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;


import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "users")
@Getter
@Setter
public class  User {
    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private String userId;

    @Column(name = "name",nullable = false,unique = true)
    private String name;

    @Column(name = "email",nullable = false,unique = true)
    private String email;

    @Column(name = "batch")
    private String batch;

    @Column(name = "sub_batch")
    private String subBatch;

    @Column(name = "created_at",updatable = false)
    private LocalDateTime createdAt;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "insights",columnDefinition = "jsonb")
    private JsonNode userInsights;




    @PrePersist
    private void prePersist() {
        this.createdAt = LocalDateTime.now();
    }



}
