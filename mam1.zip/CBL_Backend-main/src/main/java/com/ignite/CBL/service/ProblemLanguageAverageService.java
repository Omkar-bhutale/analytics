package com.ignite.CBL.service;

import com.ignite.CBL.dto.ProblemLanguageAverageDTO;

import java.util.List;

public interface ProblemLanguageAverageService {

    /**
     * Get average time spent on each language for all problems
     */
    List<ProblemLanguageAverageDTO> getProblemLanguageAverages();

    /**
     * Get average time spent on each language for problems in a specific main topic
     */
    List<ProblemLanguageAverageDTO> getProblemLanguageAveragesByMainTopic(Integer mainTopicId);

    /**
     * Get average time spent on each language for problems in a specific topic
     */
    List<ProblemLanguageAverageDTO> getProblemLanguageAveragesByTopic(Integer topicId);

    /**
     * Get average time spent on each language for problems of a specific difficulty
     */
    List<ProblemLanguageAverageDTO> getProblemLanguageAveragesByDifficulty(String difficulty);
}

