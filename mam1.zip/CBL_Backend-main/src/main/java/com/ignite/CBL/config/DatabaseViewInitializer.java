package com.ignite.CBL.config;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class DatabaseViewInitializer {

    private final JdbcTemplate jdbcTemplate;

    @PostConstruct
    public void createDatabaseViews() {
        createMainTopicLanguageAverageView();
        createProblemLanguageAverageView();
        createTopicProblemLanguageAverageView();
    }

    private void createMainTopicLanguageAverageView() {
        try {
            String dropSql = "DROP VIEW IF EXISTS vw_main_topic_language_average CASCADE";
            jdbcTemplate.execute(dropSql);
            log.info("🗑️ Dropped view 'vw_main_topic_language_average' if it existed");

            String createSql = """
                CREATE VIEW vw_main_topic_language_average AS
                SELECT
                    m.main_topic_id,
                    m.title AS main_topic_title,
                    ROUND(AVG(e.java_time_seconds), 2) AS avg_java_time,
                    ROUND(AVG(e.python_time_seconds), 2) AS avg_python_time,
                    ROUND(AVG(e.javascript_time_seconds), 2) AS avg_javascript_time,
                    ROUND(AVG(e.typescript_time_seconds), 2) AS avg_typescript_time,
                    ROUND(AVG(e.total_seconds_spent), 2) AS avg_total_time,
                    COUNT(CASE WHEN e.java_completed = true THEN 1 END) AS java_completed_count,
                    COUNT(CASE WHEN e.python_completed = true THEN 1 END) AS python_completed_count,
                    COUNT(CASE WHEN e.javascript_completed = true THEN 1 END) AS javascript_completed_count,
                    COUNT(CASE WHEN e.typescript_completed = true THEN 1 END) AS typescript_completed_count,
                    COUNT(DISTINCT e.user_id) AS total_users_engaged
                FROM user_main_topic_engagement e
                JOIN main_topics m ON e.main_topic_id = m.main_topic_id
                GROUP BY m.main_topic_id, m.title
                ORDER BY m.main_topic_id;
                """;

            jdbcTemplate.execute(createSql);
            log.info("✅ View 'vw_main_topic_language_average' created successfully");
        } catch (Exception ex) {
            log.error("❌ Failed to create view vw_main_topic_language_average: {}", ex.getMessage(), ex);
        }
    }

    private void createProblemLanguageAverageView() {
        try {
            String dropSql = "DROP VIEW IF EXISTS vw_problem_language_average CASCADE";
            jdbcTemplate.execute(dropSql);
            log.info("🗑️ Dropped view 'vw_problem_language_average' if it existed");

            String createSql = """
                CREATE VIEW vw_problem_language_average AS
                SELECT
                    p.problem_id,
                    p.title AS problem_title,
                    p.difficulty,
                    t.topic_id,
                    t.title AS topic_title,
                    m.main_topic_id,
                    m.title AS main_topic_title,
                    ROUND(AVG(e.java_time_seconds), 2) AS avg_java_time,
                    ROUND(AVG(e.python_time_seconds), 2) AS avg_python_time,
                    ROUND(AVG(e.javascript_time_seconds), 2) AS avg_javascript_time,
                    ROUND(AVG(e.typescript_time_seconds), 2) AS avg_typescript_time,
                    ROUND(AVG(e.total_seconds_spent), 2) AS avg_total_time,
                    COUNT(CASE WHEN e.java_completed = true THEN 1 END) AS java_completed_count,
                    COUNT(CASE WHEN e.python_completed = true THEN 1 END) AS python_completed_count,
                    COUNT(CASE WHEN e.javascript_completed = true THEN 1 END) AS javascript_completed_count,
                    COUNT(CASE WHEN e.typescript_completed = true THEN 1 END) AS typescript_completed_count,
                    COUNT(DISTINCT e.user_id) AS total_users_attempted
                FROM user_problem_engagement e
                JOIN problems p ON e.problem_id = p.problem_id
                JOIN topics t ON p.topic_id = t.topic_id
                JOIN main_topics m ON t.main_topic_id = m.main_topic_id
                GROUP BY p.problem_id, p.title, p.difficulty, t.topic_id, t.title, m.main_topic_id, m.title
                ORDER BY p.problem_id;
                """;

            jdbcTemplate.execute(createSql);
            log.info("✅ View 'vw_problem_language_average' created successfully");
        } catch (Exception ex) {
            log.error("❌ Failed to create view vw_problem_language_average: {}", ex.getMessage(), ex);
        }
    }

    private void createTopicProblemLanguageAverageView() {
        try {
            String dropSql = "DROP VIEW IF EXISTS vw_topic_problem_language_average CASCADE";
            jdbcTemplate.execute(dropSql);
            log.info("🗑️ Dropped view 'vw_topic_problem_language_average' if it existed");

            String createSql = """
                CREATE VIEW vw_topic_problem_language_average AS
                SELECT
                    p.problem_id,
                    p.title AS problem_title,
                    p.difficulty,
                    t.topic_id,
                    t.title AS topic_title,
                    m.main_topic_id,
                    m.title AS main_topic_title,
                    ROUND(AVG(e.java_time_seconds), 2) AS avg_java_time,
                    ROUND(AVG(e.python_time_seconds), 2) AS avg_python_time,
                    ROUND(AVG(e.javascript_time_seconds), 2) AS avg_javascript_time,
                    ROUND(AVG(e.typescript_time_seconds), 2) AS avg_typescript_time,
                    ROUND(AVG(e.total_seconds_spent), 2) AS avg_total_time,
                    COUNT(CASE WHEN e.java_completed = true THEN 1 END) AS java_completed_count,
                    COUNT(CASE WHEN e.python_completed = true THEN 1 END) AS python_completed_count,
                    COUNT(CASE WHEN e.javascript_completed = true THEN 1 END) AS javascript_completed_count,
                    COUNT(CASE WHEN e.typescript_completed = true THEN 1 END) AS typescript_completed_count,
                    COUNT(DISTINCT e.user_id) AS total_users_attempted
                FROM user_problem_engagement e
                JOIN problems p ON e.problem_id = p.problem_id
                JOIN topics t ON p.topic_id = t.topic_id
                JOIN main_topics m ON t.main_topic_id = m.main_topic_id
                LEFT JOIN main_topics mt ON mt.main_problem_id = p.problem_id
                WHERE mt.main_problem_id IS NULL
                GROUP BY p.problem_id, p.title, p.difficulty, t.topic_id, t.title, m.main_topic_id, m.title
                ORDER BY p.problem_id;
                """;

            jdbcTemplate.execute(createSql);
            log.info("✅ View 'vw_topic_problem_language_average' created successfully");
        } catch (Exception ex) {
            log.error("❌ Failed to create view vw_topic_problem_language_average: {}", ex.getMessage(), ex);
        }
    }
}