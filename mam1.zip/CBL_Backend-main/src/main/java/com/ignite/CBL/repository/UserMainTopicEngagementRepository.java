package com.ignite.CBL.repository;

import com.ignite.CBL.entity.*;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserMainTopicEngagementRepository extends JpaRepository<UserMainTopicEngagement, UserMainTopicEngagementId> {
    
    Optional<UserMainTopicEngagement> findByUser_UserIdAndMainTopic_MainTopicId(String userId, Integer mainTopicId);
    
    boolean existsByUser_UserIdAndMainTopic_MainTopicId(String userId, Integer maintopicId);
    
//    @Modifying
//    @Transactional
//    @Query("DELETE FROM UserTopicEngagement ute WHERE ute.topic.topicId = :topicId")
//    void deleteByTopicId(@Param("topicId") Integer topicId);
}
