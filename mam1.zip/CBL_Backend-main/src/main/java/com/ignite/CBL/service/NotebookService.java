package com.ignite.CBL.service;

import com.ignite.CBL.dto.NotebookResponseDTO;
import com.ignite.CBL.entity.Language;
import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface NotebookService {

    String uploadNotebook(Integer mainTopicId, Language language, String title, MultipartFile file);

    List<NotebookResponseDTO> getAllNotebooks(Integer mainTopicId);

    Resource downloadNotebook(Integer notebookId);

    String updateNotebookTitle(Integer notebookId, String newTitle);

    String deleteNotebook(Integer notebookId);
}
