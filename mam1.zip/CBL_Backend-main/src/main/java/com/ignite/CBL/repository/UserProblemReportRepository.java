package com.ignite.CBL.repository;

import com.fasterxml.jackson.databind.JsonNode;
import com.ignite.CBL.entity.Problem;
import com.ignite.CBL.entity.User;
import com.ignite.CBL.entity.UserProblemReport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;


public interface UserProblemReportRepository extends JpaRepository<UserProblemReport, Integer> {
    Optional<UserProblemReport> findByUser_UserIdAndProblem_ProblemId(String userId, Integer problemId);
    List<UserProblemReport> findByUser_UserId(String userId);

    @Query("""
    SELECT upr.insight
    FROM UserProblemReport upr
    WHERE upr.user.userId = :userId AND upr.problem.problemId = :problemId
""")
    JsonNode findInsightByUserIdAndProblemId(String userId, Integer problemId);




}
