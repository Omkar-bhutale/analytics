package com.ignite.CBL.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.ignite.CBL.dto.ProblemInfoDTO;
import com.ignite.CBL.entity.UserProblemReport;

import java.util.List;

public interface AdminDashboardService {
    long countTotalSolvedInJava();
    long  countTotalSolvedPython();
    long countTotalSolvedJavaScript();
    long countTotalSolvedTypeScript();
    long countTotalUsers();
    long countTotalProblems();
    long countTotalSubmissions();

    List<ProblemInfoDTO> fetchUserProblemSolvedInfo(String userId);

    JsonNode getUserProblemInsight(String userId, Integer problemId);
}
