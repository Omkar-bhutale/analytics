package com.ignite.CBL.dto.learning;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for completion/action responses
 * Response for:
 * - PUT /api/user/learning/progress/{mainTopicId}/mark-complete
 * - PUT /api/user/learning/progress/{subtopicId}/mcq-visited
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CompletionResponseDTO {
    private Boolean success;
    private String message;
}

