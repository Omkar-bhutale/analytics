package com.ignite.CBL.config;


import com.ignite.CBL.entity.User;
import com.ignite.CBL.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.core.convert.converter.Converter;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtClaimNames;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.security.oauth2.server.resource.authentication.JwtGrantedAuthoritiesConverter;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;


@Component
@RequiredArgsConstructor
@Profile("!test")
public class JwtAuthConverter implements Converter<Jwt, AbstractAuthenticationToken> {

    private final JwtGrantedAuthoritiesConverter jwtAuthenticationConverter
            =new JwtGrantedAuthoritiesConverter();

    private final UserRepository userRepository;


    @Value("${spring.security.oauth2.resourceserver.jwt.principal-claim-name}")
    private  String jwtPrincipleName;

    @Value("${spring.security.oauth2.resourceserver.jwt.resource-id}")
    private  String resourceId;

    @Override
    public AbstractAuthenticationToken convert(@NonNull Jwt jwt) {

        Collection<GrantedAuthority> authorities= Stream.concat(
                        jwtAuthenticationConverter.convert(jwt).stream(),
                        extractResourceAccess(jwt).stream())
                .collect(Collectors.toSet());
        return new JwtAuthenticationToken(
                jwt,
                authorities,
                getPrincipleName(jwt)
        );
    }

    private String getPrincipleName(Jwt jwt) {
        String claimName= JwtClaimNames.SUB;
        if(jwtPrincipleName!=null){
            claimName=jwtPrincipleName;
        }
        return jwt.getClaim(claimName);

    }


    private Collection<? extends GrantedAuthority> extractResourceAccess(Jwt jwt) {
        Map<String,Object> resourceAccess;
        Map<String,Object> resource;
        Collection<String> resourceRoles;

        if(jwt.getClaim("resource_access")==null) {
            return Set.of();
        }

        String userId = jwt.getClaim("preferred_username").toString().substring(0,7);

        // Extract batch and subbatch from Ignite roles
        String[] batchInfo = extractBatchAndSubBatch(jwt);
        String batch = batchInfo[0];
        String subBatch = batchInfo[1];

        if(!userRepository.existsById(userId)){
            // Create new user with batch and subbatch
            User user = new User();
            user.setUserId(userId);
            user.setName(jwt.getClaim("name"));
            user.setCreatedAt(LocalDateTime.now());
            user.setEmail(jwt.getClaim("email"));
            user.setBatch(batch);
            user.setSubBatch(subBatch);
            userRepository.save(user);
            System.out.println("New user created: " + user);
        } else {
            // Update existing user if batch/subbatch is missing or changed
            User existingUser = userRepository.findById(userId).orElse(null);
            if (existingUser != null && (existingUser.getBatch() == null || existingUser.getSubBatch() == null
                || !existingUser.getBatch().equals(batch) || !existingUser.getSubBatch().equals(subBatch))) {
                existingUser.setBatch(batch);
                existingUser.setSubBatch(subBatch);
                userRepository.save(existingUser);
                System.out.println("User updated with batch info: " + existingUser);
            }
        }

        resourceAccess=jwt.getClaim("resource_access");


        if(resourceAccess.get(resourceId)==null){
            return Set.of();
        }

        @SuppressWarnings("unchecked")
        Map<String, Object> resourceMap = (Map<String, Object>) resourceAccess.get(resourceId);
        resource = resourceMap;
        System.out.println(resource);

        @SuppressWarnings("unchecked")
        Collection<String> roles = (Collection<String>) resource.get("roles");
        resourceRoles = roles;

        return resourceRoles
                .stream()
                .map(role->new SimpleGrantedAuthority("ROLE_"+role))
                .collect(Collectors.toSet());
    }

    /**
     * Extract batch and subbatch from JWT Ignite roles
     * Format: "B45_A4" means Batch=45, SubBatch=A4
     * @param jwt JWT token
     * @return String array [batch, subBatch], or [null, null] if not found
     */
    private String[] extractBatchAndSubBatch(Jwt jwt) {
        try {
            Map<String, Object> resourceAccess = jwt.getClaim("resource_access");
            if (resourceAccess != null && resourceAccess.containsKey("Ignite")) {
                @SuppressWarnings("unchecked")
                Map<String, Object> igniteResource = (Map<String, Object>) resourceAccess.get("Ignite");

                if (igniteResource != null && igniteResource.containsKey("roles")) {
                    @SuppressWarnings("unchecked")
                    Collection<String> igniteRoles = (Collection<String>) igniteResource.get("roles");

                    // Find role matching pattern B{number}_{letter}{number}
                    for (String role : igniteRoles) {
                        if (role.matches("B\\d+_[A-Z]\\d+")) {
                            // Split by underscore: "B45_A4" -> ["B45", "A4"]
                            String[] parts = role.split("_");
                            String batch = parts[0].substring(1); // Remove 'B' prefix: "45"
                            String subBatch = parts[1]; // Keep as is: "A4"
                            return new String[]{batch, subBatch};
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error extracting batch and subbatch: " + e.getMessage());
        }
        return new String[]{null, null};
    }
}
