
package com.ignite.CBL.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ignite.CBL.dto.ProblemHintResponseDTO;
import com.ignite.CBL.entity.Problem;
import com.ignite.CBL.exception.ResourceNotFoundException;
import com.ignite.CBL.repository.ProblemRepository;
import com.ignite.CBL.service.ProblemHintService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProblemHintServiceImpl implements ProblemHintService {

    private final ProblemRepository problemRepository;
    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;

    @Value("${external.llm.hint-url}")
    private String llmHintApiUrl;

    @Override
    @Transactional
    public ProblemHintResponseDTO getHintForProblem(Integer problemId) {
        Problem problem = problemRepository.findById(problemId)
                .orElseThrow(() -> new ResourceNotFoundException("Problem not found with id: " + problemId));


        if (problem.getHint() != null) {
            log.info("Hint found in DB for problemId: {}", problemId);
            return new ProblemHintResponseDTO(problemId, problem.getTitle(), problem.getHint());

        }
        ObjectMapper objectMapper = new ObjectMapper();
        ObjectNode emptyObjectNode = objectMapper.createObjectNode();

        return new ProblemHintResponseDTO(problemId,problem.getTitle(),emptyObjectNode);
//
//        Map<String, Object> body = new HashMap<>();
//        body.put("problem_title", problem.getTitle());
//        body.put("problem_description", problem.getDescription());
//
//        HttpHeaders headers = new HttpHeaders();
//        headers.setContentType(MediaType.APPLICATION_JSON);
//
//        HttpEntity<Map<String, Object>> request = new HttpEntity<>(body, headers);

//        try {
//            log.info("Fetching hint from external LLM for problemId: {}", problemId);
//            ResponseEntity<String> response = restTemplate.postForEntity(llmHintApiUrl, request, String.class);
//
//            if (response.getStatusCode().is2xxSuccessful()) {
//                JsonNode hintResponse = objectMapper.readTree(response.getBody());
//
//
//                problem.setHint(hintResponse);
//                problemRepository.save(problem);
//
//                log.info("Hint saved successfully for problemId: {}", problemId);
//                return new ProblemHintResponseDTO(problemId, problem.getTitle(), hintResponse);
//            } else {
//                throw new RuntimeException("Failed to fetch hint: " + response.getStatusCode());
//            }
//
//        } catch (Exception e) {
//            log.error("Error fetching hint from external API for problemId {}: {}", problemId, e.getMessage());
//            throw new RuntimeException("Unable to generate hint currently", e);
//        }
    }
}