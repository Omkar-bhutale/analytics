//package com.ignite.CBL.config;
//
//import lombok.RequiredArgsConstructor;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.core.io.ClassPathResource;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
//
//import javax.sql.DataSource;
//import java.io.BufferedReader;
//import java.io.InputStreamReader;
//import java.nio.charset.StandardCharsets;
//import java.util.stream.Collectors;
//
//@Configuration
//@RequiredArgsConstructor
//@Slf4j
//public class DatabaseInitializer {
//
//    private final DataSource dataSource;
//    private final JdbcTemplate jdbcTemplate;
//
//    @Bean
//    public CommandLineRunner initializeDatabase() {
//        return args -> {
//            // Check if database is already initialized by checking if users table has data
//            try {
//                Long userCount = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM users", Long.class);
//                if (userCount != null && userCount > 0) {
//                    log.info("Database already initialized with {} users. Skipping initialization.", userCount);
//                    return;
//                }
//            } catch (Exception e) {
//                log.info("Users table not found or empty. Starting initialization...");
//            }
//
//            log.info("========================================");
//            log.info("Starting Database Initialization");
//            log.info("========================================");
//
//            // Since ddl-auto=update, skip schema creation and only insert data
//            String[] sqlFiles = {
//                "sql/insert_users_data.sql",
//                "sql/insert_main_topics_data.sql",
//                "sql/insert_topic_data_fixed.sql",
//                "sql/insert_problems_data.sql",
//                "sql/insert_problems_testcases_data.sql",
//                "sql/insert_mcqs_data.sql",
//                "sql/insert_user_topic_engagement_data.sql",
//                "sql/fix_user_problem_engagement_solved_status.sql"
//            };
//
//            for (String sqlFile : sqlFiles) {
//                try {
//                    log.info("Executing: {}", sqlFile);
//                    executeSqlFile(sqlFile);
//                    log.info("✓ Successfully executed: {}", sqlFile);
//                } catch (Exception e) {
//                    log.error("✗ Error executing {}: {}", sqlFile, e.getMessage());
//                    // Continue with other files even if one fails
//                }
//            }
//
//            log.info("========================================");
//            log.info("Database Initialization Completed");
//            log.info("========================================");
//        };
//    }
//
//    private void executeSqlFile(String sqlFilePath) throws Exception {
//        ClassPathResource resource = new ClassPathResource(sqlFilePath);
//
//        if (!resource.exists()) {
//            log.warn("SQL file not found: {}. Skipping...", sqlFilePath);
//            return;
//        }
//
//        try (BufferedReader reader = new BufferedReader(
//                new InputStreamReader(resource.getInputStream(), StandardCharsets.UTF_8))) {
//
//            String sqlContent = reader.lines().collect(Collectors.joining("\n"));
//
//            // Split by semicolon but be careful with JSON and functions
//            String[] statements = sqlContent.split(";(?=(?:[^'\"]*['\"][^'\"]*['\"])*[^'\"]*$)");
//
//            for (String statement : statements) {
//                String trimmedStatement = statement.trim();
//
//                // Skip empty statements and comments
//                if (trimmedStatement.isEmpty() ||
//                    trimmedStatement.startsWith("--") ||
//                    trimmedStatement.startsWith("//")) {
//                    continue;
//                }
//
//                try {
//                    jdbcTemplate.execute(trimmedStatement);
//                } catch (Exception e) {
//                    // Log but don't stop - some statements might fail due to constraints
//                    log.debug("Statement execution info: {}", e.getMessage());
//                }
//            }
//        }
//    }
//}
