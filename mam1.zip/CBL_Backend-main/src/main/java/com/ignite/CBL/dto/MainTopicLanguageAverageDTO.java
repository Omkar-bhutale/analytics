package com.ignite.CBL.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MainTopicLanguageAverageDTO {
    private Integer mainTopicId;
    private String mainTopicTitle;
    private Double avgJavaTime;
    private Double avgPythonTime;
    private Double avgJavascriptTime;
    private Double avgTypescriptTime;
    private Double avgTotalTime;
    private Long javaCompletedCount;
    private Long pythonCompletedCount;
    private Long javascriptCompletedCount;
    private Long typescriptCompletedCount;
    private Long totalUsersEngaged;
}