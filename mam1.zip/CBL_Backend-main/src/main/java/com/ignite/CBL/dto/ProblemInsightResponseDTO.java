
package com.ignite.CBL.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProblemInsightResponseDTO {

    private String algorithm_pseudocode_match_summary;
    private boolean optimized_solution_exists;

    private List<Map<String, Object>> language_performances;
}