package com.ignite.CBL.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TopicWithProblemsInfoDTO {
    private Long topicId;
    private String topicName;
    private List<ProblemInfoDTO> problems;
}