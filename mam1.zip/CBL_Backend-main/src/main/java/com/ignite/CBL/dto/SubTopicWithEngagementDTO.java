package com.ignite.CBL.dto;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SubTopicWithEngagementDTO {
    private Integer topicId;
    private String title;
    private JsonNode content;

    // Engagement fields
    private Boolean javaVisited;
    private Boolean pythonVisited;
    private Boolean javascriptVisited;
    private Boolean typescriptVisited;
    private Boolean mcqVisited;
    private Long javaTimeSeconds;
    private Long pythonTimeSeconds;
    private Long javascriptTimeSeconds;
    private Long typescriptTimeSeconds;
    private Long totalTimeSpent;
    private LocalDateTime lastActivityAt;
}

