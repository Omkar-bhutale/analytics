package com.ignite.CBL.dto.learning;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for MCQ visited status (all languages)
 * Response for: GET /api/user/learning/progress/mcq-status/{subtopicId}
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class McqStatusDTO {
    private Boolean java;
    private Boolean python;
    private Boolean javascript;
    private Boolean typescript;
}

