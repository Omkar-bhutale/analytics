package com.ignite.CBL.controller;

import com.ignite.CBL.dto.AlgorithmRequestDTO;
import com.ignite.CBL.dto.AlgorithmResponceDTO;
import com.ignite.CBL.service.AlgorithmSubmissionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user/algorithm-submissions")
@RequiredArgsConstructor
@Tag(name = "Algorithm Submission", description = "Algorithm submission management APIs")
public class AlgorithmSubmissionController {

    private final AlgorithmSubmissionService algorithmSubmissionService;

    @Value("${user.id}")
    private String userId;

    @PostMapping
    @Operation(summary = "Create or update algorithm submission", description = "Save or update an algorithm submission for a problem")
    public ResponseEntity<AlgorithmResponceDTO> saveOrUpdateAlgorithm(
            @Valid @RequestBody AlgorithmRequestDTO algorithmRequestDTO) {
        AlgorithmResponceDTO response = algorithmSubmissionService.saveOrUpdateAlgorithm(algorithmRequestDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/problem/{problemId}")
    @Operation(summary = "Get algorithm by problem ID", description = "Retrieve algorithm submission for a specific problem")
    public ResponseEntity<AlgorithmResponceDTO> getAlgorithmByProblemId(
            @PathVariable Integer problemId) {
        AlgorithmResponceDTO response = algorithmSubmissionService.getAlgorithmByProblemId(problemId);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/problem/{problemId}/exists")
    @Operation(summary = "Check if algorithm exists", description = "Check if an algorithm submission exists for a problem and user")
    public ResponseEntity<Boolean> existsByProblemIdAndUserId(
            @PathVariable Integer problemId) {
        Boolean exists = algorithmSubmissionService.existByProblemId(problemId);
        return ResponseEntity.ok(exists);
    }

    @GetMapping("/problem/{problemId}/is-correct")
    @Operation(summary = "Check if algorithm is correct", description = "Check if the algorithm submission is marked as correct")
    public ResponseEntity<Boolean> isAlgorithmCorrect(
            @PathVariable Integer problemId) {
        Boolean isCorrect = algorithmSubmissionService.isAlgorithmCorrect(problemId);
        return ResponseEntity.ok(isCorrect);
    }
}
