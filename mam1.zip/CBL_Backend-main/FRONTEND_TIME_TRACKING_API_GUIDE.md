# 🚀 Complete API Guide for Frontend Time Tracking & Completion

**Date:** November 7, 2025  
**Target:** Frontend Development Team  
**Purpose:** Time tracking + Completion flow for Main Topics

---

## 📊 Current API Overview

You have **ALL the APIs you need**! Here's how to use them:

---

## 🎯 Main Flow: Time Tracking + Completion

### **Architecture:**
```
Frontend Tracks: Main Topic + Language (User Perspective)
         ↓
Backend Stores: Subtopic + Language (Implementation Detail)
         ↓
Backend Aggregates: Main Topic + Language (Automatically)
```

---

## 📡 Available APIs

### **1. Get All Main Topics with Engagement** 🔍
**Purpose:** Initial page load - get all topics with current progress

```http
GET /user/topic-engagement/all-main-topics-sub-topics
Authorization: Bearer <token>
```

**Response:**
```json
[
  {
    "mainTopicId": 1,
    "mainTopicName": "Data Structures",
    "mainTopicDescription": "Learn about arrays, linked lists, stacks...",
    "subTopics": [
      { "topicId": 1, "title": "Arrays", "content": {...} },
      { "topicId": 2, "title": "Linked Lists", "content": {...} },
      { "topicId": 3, "title": "Stacks", "content": {...} }
    ],
    "completed": false,
    "javaCompleted": false,
    "pythonCompleted": false,
    "javascriptCompleted": false,
    "typescriptCompleted": false,
    "javaTimeSeconds": 1200,      // 20 minutes
    "pythonTimeSeconds": 600,      // 10 minutes
    "javascriptTimeSeconds": 0,
    "typescriptTimeSeconds": 0,
    "totalTimeSeconds": 1800,      // 30 minutes total
    "lastActivityAt": "2025-11-07T10:30:00"
  }
]
```

**Frontend Usage:**
```javascript
// On page load
const mainTopics = await api.get('/user/topic-engagement/all-main-topics-sub-topics');

// Display sidebar with progress
mainTopics.forEach(topic => {
  displayMainTopicCard({
    id: topic.mainTopicId,
    name: topic.mainTopicName,
    javaProgress: topic.javaTimeSeconds,
    pythonProgress: topic.pythonTimeSeconds,
    javaCompleted: topic.javaCompleted,
    pythonCompleted: topic.pythonCompleted
  });
});
```

---

### **2. Update Time (Every 30 Seconds)** ⏱️
**Purpose:** Send time deltas as user works on topics

```http
PUT /user/topic-engagement/language
Content-Type: application/json
Authorization: Bearer <token>

{
  "topicId": 1,               // Subtopic ID (e.g., "Arrays")
  "language": "JAVA",         // JAVA, PYTHON, JAVASCRIPT, TYPESCRIPT
  "timeSpentSeconds": 30      // Delta (time since last update)
}
```

**Response:** (Main Topic Engagement)
```json
{
  "mainTopicId": 1,
  "mainTopicName": "Data Structures",
  "javaTimeSeconds": 1230,        // Updated! Was 1200, now +30
  "pythonTimeSeconds": 600,
  "totalTimeSeconds": 1830,
  "javaCompleted": false,
  "pythonCompleted": false,
  "completed": false,
  "lastActivityAt": "2025-11-07T10:30:30"
}
```

**Frontend Implementation:**
```javascript
// Timer for current subtopic
let currentSubtopicId = 1; // Arrays
let currentLanguage = 'JAVA';
let secondsSinceLastUpdate = 0;

// Every second
setInterval(() => {
  secondsSinceLastUpdate++;
}, 1000);

// Every 30 seconds, send update
setInterval(async () => {
  if (secondsSinceLastUpdate > 0) {
    const response = await api.put('/user/topic-engagement/language', {
      topicId: currentSubtopicId,
      language: currentLanguage,
      timeSpentSeconds: secondsSinceLastUpdate
    });
    
    // Update UI with main topic data
    updateMainTopicProgress(response);
    
    // Reset counter
    secondsSinceLastUpdate = 0;
  }
}, 30000);
```

---

### **3. Mark MCQ as Visited (Language-Specific)** ✅
**Purpose:** Track MCQ completion per language per subtopic

```http
PUT /user/topic-engagement/{topicId}/mcq-visited?language=JAVA
Authorization: Bearer <token>
```

**Example:**
```http
PUT /user/topic-engagement/1/mcq-visited?language=JAVA
```

**Frontend Usage:**
```javascript
// When user completes MCQ for "Arrays" in Java
const completeMCQ = async (subtopicId, language) => {
  await api.put(`/user/topic-engagement/${subtopicId}/mcq-visited?language=${language}`);
  
  // Show success toast
  showToast(`✅ ${language} MCQ completed for this topic!`);
};
```

**⚠️ Important:** This API needs to be updated to accept `language` parameter (currently it doesn't - needs backend update)

---

### **4. Get Main Topic Engagement** 📊
**Purpose:** Get detailed engagement for a specific main topic

```http
GET /user/topic-engagement/main-topic/1/engagement
Authorization: Bearer <token>
```

**Response:**
```json
{
  "mainTopicId": 1,
  "mainTopicName": "Data Structures",
  "completed": false,
  "javaCompleted": false,
  "pythonCompleted": false,
  "javascriptCompleted": false,
  "typescriptCompleted": false,
  "javaTimeSeconds": 1230,
  "pythonTimeSeconds": 600,
  "javascriptTimeSeconds": 0,
  "typescriptTimeSeconds": 0,
  "totalTimeSeconds": 1830,
  "lastActivityAt": "2025-11-07T10:30:30"
}
```

**Frontend Usage:**
```javascript
// When user clicks on a main topic
const getMainTopicDetails = async (mainTopicId) => {
  const engagement = await api.get(`/user/topic-engagement/main-topic/${mainTopicId}/engagement`);
  
  // Display detailed progress modal
  showProgressModal({
    name: engagement.mainTopicName,
    languages: {
      java: { time: engagement.javaTimeSeconds, completed: engagement.javaCompleted },
      python: { time: engagement.pythonTimeSeconds, completed: engagement.pythonCompleted },
      javascript: { time: engagement.javascriptTimeSeconds, completed: engagement.javascriptCompleted },
      typescript: { time: engagement.typescriptTimeSeconds, completed: engagement.typescriptCompleted }
    }
  });
};
```

---

### **5. Mark Main Topic as Complete** 🏆
**Purpose:** User clicks "Mark as Complete" button for a language

```http
PUT /user/user-main-topic-engagement/1/validate-completion?language=JAVA
Authorization: Bearer <token>
```

**Response (Success):**
```json
{
  "success": true,
  "message": "Congratulations! Main topic marked as completed for JAVA."
}
```

**Response (Failure - Missing Requirements):**
```json
{
  "success": false,
  "message": "Please complete all MCQs in JAVA for all subtopics."
}
```

**Other Possible Errors:**
- `"Please visit all subtopics for JAVA."`
- `"Please complete all MCQs in JAVA for all subtopics."`
- `"Please spend at least 2 minutes or solve the Code Here problem for JAVA."`

**Frontend Usage:**
```javascript
// When user clicks "Mark as Complete" button
const markAsComplete = async (mainTopicId, language) => {
  try {
    const response = await api.put(
      `/user/user-main-topic-engagement/${mainTopicId}/validate-completion?language=${language}`
    );
    
    if (response.success) {
      // Show success animation
      showSuccessAnimation(`🎉 ${language} Completed!`);
      
      // Refresh main topic engagement
      await refreshMainTopicEngagement(mainTopicId);
    } else {
      // Show what's missing
      showErrorToast(response.message);
    }
  } catch (error) {
    showErrorToast('Failed to mark as complete. Please try again.');
  }
};
```

---

## 🎨 Complete Frontend Implementation Example

### **Step 1: Initialize on Page Load**
```javascript
const LearningPage = () => {
  const [mainTopics, setMainTopics] = useState([]);
  const [currentMainTopic, setCurrentMainTopic] = useState(null);
  const [currentSubtopic, setCurrentSubtopic] = useState(null);
  const [currentLanguage, setCurrentLanguage] = useState('JAVA');
  const [timer, setTimer] = useState(0);

  useEffect(() => {
    loadMainTopics();
  }, []);

  const loadMainTopics = async () => {
    const data = await api.get('/user/topic-engagement/all-main-topics-sub-topics');
    setMainTopics(data);
    
    // Set first topic and subtopic as current
    if (data.length > 0) {
      setCurrentMainTopic(data[0]);
      if (data[0].subTopics.length > 0) {
        setCurrentSubtopic(data[0].subTopics[0]);
      }
    }
  };
```

### **Step 2: Time Tracking Timer**
```javascript
  // Timer runs every second
  useEffect(() => {
    const interval = setInterval(() => {
      setTimer(prev => prev + 1);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  // Auto-save every 30 seconds
  useEffect(() => {
    const saveInterval = setInterval(async () => {
      if (timer > 0 && currentSubtopic) {
        await saveTimeToBackend();
      }
    }, 30000); // 30 seconds

    return () => clearInterval(saveInterval);
  }, [timer, currentSubtopic, currentLanguage]);

  const saveTimeToBackend = async () => {
    if (!currentSubtopic) return;

    try {
      const response = await api.put('/user/topic-engagement/language', {
        topicId: currentSubtopic.topicId,
        language: currentLanguage,
        timeSpentSeconds: timer
      });

      // Update main topic engagement in state
      updateMainTopicInState(response);
      
      // Reset timer
      setTimer(0);
    } catch (error) {
      console.error('Failed to save time:', error);
    }
  };

  const updateMainTopicInState = (updatedEngagement) => {
    setMainTopics(prev => prev.map(topic => 
      topic.mainTopicId === updatedEngagement.mainTopicId 
        ? { ...topic, ...updatedEngagement }
        : topic
    ));
  };
```

### **Step 3: Handle Language Switch**
```javascript
  const handleLanguageChange = async (newLanguage) => {
    // Save current time before switching
    if (timer > 0) {
      await saveTimeToBackend();
    }

    // Switch language
    setCurrentLanguage(newLanguage);
    setTimer(0); // Reset timer for new language
  };
```

### **Step 4: Handle Subtopic Change**
```javascript
  const handleSubtopicChange = async (newSubtopic) => {
    // Save current time before switching
    if (timer > 0) {
      await saveTimeToBackend();
    }

    // Switch subtopic
    setCurrentSubtopic(newSubtopic);
    setTimer(0); // Reset timer for new subtopic
  };
```

### **Step 5: Handle MCQ Completion**
```javascript
  const handleMCQComplete = async (subtopicId, language) => {
    try {
      await api.put(`/user/topic-engagement/${subtopicId}/mcq-visited?language=${language}`);
      
      showToast(`✅ ${language} MCQ completed!`);
      
      // Refresh main topic data
      await loadMainTopics();
    } catch (error) {
      showErrorToast('Failed to mark MCQ as complete');
    }
  };
```

### **Step 6: Handle Mark as Complete**
```javascript
  const handleMarkAsComplete = async (mainTopicId, language) => {
    try {
      const response = await api.put(
        `/user/user-main-topic-engagement/${mainTopicId}/validate-completion?language=${language}`
      );

      if (response.success) {
        // Success!
        showSuccessModal(response.message);
        
        // Refresh data
        await loadMainTopics();
      } else {
        // Show validation error
        showWarningModal(response.message);
      }
    } catch (error) {
      showErrorToast('Failed to mark as complete');
    }
  };
```

### **Step 7: Save on Page Unload**
```javascript
  useEffect(() => {
    const handleBeforeUnload = async (e) => {
      // Save any unsaved time before leaving
      if (timer > 0) {
        // Use sendBeacon for reliable sending during page unload
        const data = JSON.stringify({
          topicId: currentSubtopic.topicId,
          language: currentLanguage,
          timeSpentSeconds: timer
        });
        
        navigator.sendBeacon('/user/topic-engagement/language', data);
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [timer, currentSubtopic, currentLanguage]);
```

---

## 📊 Display Progress to User

### **Sidebar - Main Topics List**
```javascript
const Sidebar = ({ mainTopics, currentMainTopicId }) => {
  return (
    <div className="sidebar">
      {mainTopics.map(topic => (
        <div key={topic.mainTopicId} className="topic-card">
          <h3>{topic.mainTopicName}</h3>
          
          {/* Language Progress Badges */}
          <div className="language-badges">
            <Badge completed={topic.javaCompleted} time={topic.javaTimeSeconds}>
              {topic.javaCompleted ? '✅' : '🔄'} Java
            </Badge>
            <Badge completed={topic.pythonCompleted} time={topic.pythonTimeSeconds}>
              {topic.pythonCompleted ? '✅' : '🔄'} Python
            </Badge>
            <Badge completed={topic.javascriptCompleted} time={topic.javascriptTimeSeconds}>
              {topic.javascriptCompleted ? '✅' : '🔄'} JS
            </Badge>
            <Badge completed={topic.typescriptCompleted} time={topic.typescriptTimeSeconds}>
              {topic.typescriptCompleted ? '✅' : '🔄'} TS
            </Badge>
          </div>
          
          {/* Total Time */}
          <div className="total-time">
            Total: {formatTime(topic.totalTimeSeconds)}
          </div>
        </div>
      ))}
    </div>
  );
};
```

### **Main Content - Current Topic Progress**
```javascript
const TopicProgress = ({ currentMainTopic, currentLanguage, onMarkComplete }) => {
  const currentLangTime = currentMainTopic[`${currentLanguage.toLowerCase()}TimeSeconds`];
  const currentLangCompleted = currentMainTopic[`${currentLanguage.toLowerCase()}Completed`];

  return (
    <div className="topic-progress">
      <h2>{currentMainTopic.mainTopicName}</h2>
      
      {/* Current Language Progress */}
      <div className="current-language">
        <h3>{currentLanguage}</h3>
        <div className="progress-bar">
          <div style={{ width: `${Math.min(currentLangTime / 36, 100)}%` }} />
        </div>
        <p>Time: {formatTime(currentLangTime)}</p>
        
        {/* Mark as Complete Button */}
        {!currentLangCompleted && (
          <button onClick={() => onMarkComplete(currentMainTopic.mainTopicId, currentLanguage)}>
            Mark {currentLanguage} as Complete
          </button>
        )}
        
        {currentLangCompleted && (
          <div className="completed-badge">
            ✅ {currentLanguage} Completed!
          </div>
        )}
      </div>
    </div>
  );
};
```

---

## 🔧 Key Points

### **✅ DO:**
1. **Track time at subtopic level** - Send `topicId` (subtopic ID) in time updates
2. **Show progress at main topic level** - Display aggregated main topic data to user
3. **Save every 30 seconds** - Balance between accuracy and API calls
4. **Save on page unload** - Don't lose user progress
5. **Save before switching** - Subtopic or language change should save current time
6. **Use deltas** - Send time since last update, not cumulative

### **❌ DON'T:**
1. **Don't send cumulative time** - Backend expects deltas (time since last update)
2. **Don't track time for main topics directly** - Track subtopics, backend aggregates
3. **Don't auto-complete** - User must explicitly click "Mark as Complete"
4. **Don't call APIs too frequently** - 30 seconds is optimal

---

## 📋 Completion Requirements Checklist

For user to mark a language as complete for a main topic:

- ✅ **All subtopics visited** in that language
- ✅ **All MCQs completed** in that language (for all subtopics)
- ✅ **Code problem attempted** (2+ minutes OR solved)

**Show this checklist in UI:**
```javascript
const CompletionChecklist = ({ mainTopicId, language }) => {
  const [requirements, setRequirements] = useState({
    subtopicsVisited: false,
    mcqsCompleted: false,
    problemAttempted: false
  });

  return (
    <div className="completion-checklist">
      <h4>Requirements to mark {language} as complete:</h4>
      <ul>
        <li className={requirements.subtopicsVisited ? 'done' : ''}>
          {requirements.subtopicsVisited ? '✅' : '⏳'} Visit all subtopics in {language}
        </li>
        <li className={requirements.mcqsCompleted ? 'done' : ''}>
          {requirements.mcqsCompleted ? '✅' : '⏳'} Complete all MCQs in {language}
        </li>
        <li className={requirements.problemAttempted ? 'done' : ''}>
          {requirements.problemAttempted ? '✅' : '⏳'} Attempt Code Here problem (2 min or solve)
        </li>
      </ul>
    </div>
  );
};
```

---

## 🚨 Action Items

### **Backend Update Needed:**
**MCQ Visited API needs language parameter:**
```java
// Current (needs update):
PUT /user/topic-engagement/{topicId}/mcq-visited

// Should be:
PUT /user/topic-engagement/{topicId}/mcq-visited?language=JAVA
```

**Update `markMcqAsVisited` method to:**
1. Accept `language` parameter
2. Set language-specific MCQ flag (`javaMcqVisited`, `pythonMcqVisited`, etc.)
3. Not set generic `mcqVisited` flag

---

**Status:** ✅ **All APIs Available**  
**Action:** Use the APIs as documented above for complete time tracking + completion flow  
**Update Needed:** MCQ API to accept language parameter  


