
4. **Null Safety:**
   - Check if entities exist before accessing properties
   - Handle Optional<> properly
   - Initialize default values for new engagements

5. **JSON Parsing:**
   - Topic.content is JsonNode type
   - Use Jackson to parse: `objectMapper.readValue()`
   - Or navigate using JsonNode methods: `.get()`, `.path()`

---

## 📝 Next Steps

1. ✅ Review the created files
2. ✅ Create missing repositories if needed
3. ✅ Implement each service method one by one
4. ✅ Test each endpoint with Postman/curl
5. ✅ Handle edge cases and errors
6. ✅ Add logging for debugging
7. ✅ Update frontend to use new APIs

---

## 🎯 Implementation Order (Recommended)

1. **Phase 1:** Topic/Subtopic APIs
   - getAllMainTopics()
   - getSubtopicsByMainTopic()
   - getSubtopicContent()

2. **Phase 2:** Timer APIs
   - getMainTopicTimer()
   - updateTimeDelta()

3. **Phase 3:** Progress APIs
   - getMcqStatus()
   - markMcqVisited()
   - getMarkCompleteStatus()
   - markTopicComplete()

---

Good luck with the implementation! All the structure is ready - you just need to fill in the business logic. 🚀
# Learning Page API Implementation Guide

## 📁 Files Created

### Controller
- `LearningPageController.java` - REST API endpoints

### Service
- `LearningPageService.java` - Business logic (with TODO placeholders)

### DTOs
- `MainTopicSummaryDTO.java` - Main topic list
- `SubtopicSummaryDTO.java` - Subtopic list
- `SubtopicContentDTO.java` - Subtopic content with all languages
- `MainTopicTimerDTO.java` - Timer data per language
- `TimeDeltaRequestDTO.java` - Time delta request
- `TimeDeltaResponseDTO.java` - Time delta response
- `MarkCompleteStatusDTO.java` - Mark complete button status
- `CompletionResponseDTO.java` - Generic completion response
- `McqStatusDTO.java` - MCQ visited status per language

---

## 🔧 What You Need to Implement

All service methods have `TODO` comments with implementation hints.

### 1. getAllMainTopics()
**What to do:**
```java
1. Fetch all MainTopic entities from database
2. Map to MainTopicSummaryDTO (mainTopicId, name)
3. Return list
```

**Query needed:**
```sql
SELECT main_topic_id, title FROM main_topics ORDER BY main_topic_id
```

---

### 2. getSubtopicsByMainTopic()
**What to do:**
```java
1. Find MainTopic by mainTopicId
2. Get all Topic entities under this MainTopic
3. Map to SubtopicSummaryDTO (subtopicId=topicId, name=title)
4. Return list
```

**Query needed:**
```sql
SELECT topic_id, title FROM topics 
WHERE main_topic_id = ? 
ORDER BY topic_id
```

---

### 3. getSubtopicContent()
**What to do:**
```java
1. Find Topic by subtopicId (topicId)
2. Extract content JSON (already has all languages in it)
3. Parse JSON to extract:
   - explanation
   - languages array (language, example, notes for each)
4. Get UserTopicEngagement for user + subtopic
5. Extract MCQ visited flags (javaMcqVisited, pythonMcqVisited, etc.)
6. Determine if this is last subtopic:
   - Get mainTopicId from Topic
   - Count total subtopics under this main topic
   - Check if current subtopic has highest topicId
7. Build and return SubtopicContentDTO
```

**Example content JSON structure:**
```json
{
  "explanation": "Variables store data...",
  "language_details": [
    {
      "language": "Java",
      "example": "int x = 10;",
      "code_difference_explanation": "Java is strongly typed"
    },
    {
      "language": "Python",
      "example": "x = 10",
      "code_difference_explanation": "Python is dynamically typed"
    }
  ]
}
```

---

### 4. getMainTopicTimer()
**What to do:**
```java
1. Find MainTopic by mainTopicId
2. Get all Topic entities (subtopics) under this MainTopic
3. For each subtopic:
   - Find UserTopicEngagement for user + subtopic
   - Accumulate javaTimeSeconds
   - Accumulate pythonTimeSeconds
   - Accumulate javascriptTimeSeconds
   - Accumulate typescriptTimeSeconds
4. Return MainTopicTimerDTO with totals
```

**Pseudo-code:**
```java
long totalJava = 0;
long totalPython = 0;
// ... for each language

for (Topic subtopic : subtopics) {
    UserTopicEngagement engagement = findEngagement(user, subtopic);
    if (engagement != null) {
        totalJava += engagement.getJavaTimeSeconds();
        totalPython += engagement.getPythonTimeSeconds();
        // ... etc
    }
}

return new MainTopicTimerDTO(totalJava, totalPython, totalJs, totalTs);
```

---

### 5. updateTimeDelta()
**What to do:**
```java
1. Find Topic by subtopicId
2. Find or create UserTopicEngagement:
   - If exists: fetch from DB
   - If not exists: create new with all fields = 0/false
3. Update language-specific time using helper method:
   - Call updateLanguageTime(engagement, language, deltaSeconds)
   - This adds delta to appropriate field and sets visited flag
4. Update totalTimeSpent
5. Set lastActivityAt = LocalDateTime.now()
6. Save UserTopicEngagement
7. Get new total for this language using getLanguageTime()
8. Return TimeDeltaResponseDTO(success=true, newTotal=...)
```

**Important:**
- Use `@Transactional` to ensure atomic updates
- Helper methods are already provided in service

---

### 6. getMarkCompleteStatus()
**What to do:**
```java
1. Find MainTopic by mainTopicId
2. Get all subtopics under this main topic
3. For EACH subtopic, validate:
   a) UserTopicEngagement exists (user visited)
   b) Language-specific time > 60 seconds
   c) At least one MCQ completed (any language)
   d) If not first subtopic, previous subtopics have time > 0
4. Check if user is on LAST subtopic:
   - This is required constraint
   - Frontend should only call this on last subtopic
5. Build validation result:
   - If all pass: canMarkComplete = true, reason = "All constraints met"
   - If any fail: canMarkComplete = false, reason = specific error
6. Return MarkCompleteStatusDTO
```

**Validation reasons examples:**
```
"Not on last subtopic"
"Java time (45s) is less than required 60s"
"MCQ not completed for any language"
"Previous subtopic 'Variables' not visited"
```

---

### 7. markTopicComplete()
**What to do:**
```java
1. Call getMarkCompleteStatus() internally to validate
2. If canMarkComplete = false:
   - Return CompletionResponseDTO(success=false, message=reason)
3. If canMarkComplete = true:
   - Find/create UserMainTopicEngagement for user + main topic
   - Set language-specific completion flag (e.g., javaCompleted = true)
   - Set completionTimestamp
   - Save entity
   - Return CompletionResponseDTO(success=true, message="Completed successfully")
```

**Note:**
You may need to create a UserMainTopicEngagement entity if it doesn't exist yet.

---

### 8. getMcqStatus()
**What to do:**
```java
1. Find Topic by subtopicId
2. Find UserTopicEngagement for user + subtopic
3. If engagement exists:
   - Extract javaMcqVisited, pythonMcqVisited, etc.
4. If engagement doesn't exist:
   - All flags = false (not visited)
5. Return McqStatusDTO
```

---

### 9. markMcqVisited()
**What to do:**
```java
1. Find Topic by subtopicId
2. Find or create UserTopicEngagement for user + subtopic
3. Update language-specific MCQ flag using helper method:
   - Call updateLanguageMcqFlag(engagement, language)
4. Save UserTopicEngagement
5. Return CompletionResponseDTO(success=true, message="MCQ marked as visited")
```

---

## 🔗 Required Repositories

Make sure you have these repositories injected:

```java
private final UserRepository userRepository;
private final MainTopicRepository mainTopicRepository;
private final TopicRepository topicRepository;
private final UserTopicEngagementRepository userTopicEngagementRepository;
```

If `MainTopicRepository` doesn't exist, create it:
```java
@Repository
public interface MainTopicRepository extends JpaRepository<MainTopic, Integer> {
}
```

---

## 📊 Database Queries You'll Need

### Find engagement by user and topic
```java
Optional<UserTopicEngagement> findByUserTopicEngagementId_UserIdAndUserTopicEngagementId_TopicId(
    Integer userId, Integer topicId
);
```

### Get all topics by main topic
```java
List<Topic> findByMainTopic_MainTopicId(Integer mainTopicId);
```

### Check if topic is last in main topic
```java
@Query("SELECT CASE WHEN t.topicId = (SELECT MAX(t2.topicId) FROM Topic t2 WHERE t2.mainTopic.mainTopicId = :mainTopicId) THEN true ELSE false END FROM Topic t WHERE t.topicId = :topicId")
Boolean isLastSubtopic(@Param("topicId") Integer topicId, @Param("mainTopicId") Integer mainTopicId);
```

---

## 🧪 Testing Endpoints

### 1. Get Main Topics
```bash
GET http://localhost:8080/api/user/learning/main-topics
Authorization: Bearer <token>
```

### 2. Get Subtopics
```bash
GET http://localhost:8080/api/user/learning/main-topics/1/subtopics
Authorization: Bearer <token>
```

### 3. Get Subtopic Content
```bash
GET http://localhost:8080/api/user/learning/subtopics/12
Authorization: Bearer <token>
```

### 4. Get Timer
```bash
GET http://localhost:8080/api/user/learning/time-tracking/main-topic/1
Authorization: Bearer <token>
```

### 5. Send Time Delta
```bash
POST http://localhost:8080/api/user/learning/time-tracking/delta
Authorization: Bearer <token>
Content-Type: application/json

{
  "subtopicId": 12,
  "language": "JAVA",
  "deltaSeconds": 45
}
```

### 6. Get Mark Complete Status
```bash
GET http://localhost:8080/api/user/learning/progress/mark-complete-status?mainTopicId=1&language=JAVA
Authorization: Bearer <token>
```

### 7. Mark Complete
```bash
PUT http://localhost:8080/api/user/learning/progress/1/mark-complete?language=JAVA
Authorization: Bearer <token>
```

### 8. Get MCQ Status
```bash
GET http://localhost:8080/api/user/learning/progress/mcq-status/12
Authorization: Bearer <token>
```

### 9. Mark MCQ Visited
```bash
PUT http://localhost:8080/api/user/learning/progress/12/mcq-visited?language=JAVA
Authorization: Bearer <token>
```

---

## ⚠️ Important Notes

1. **Helper Methods Provided:**
   - `updateLanguageTime()` - Updates time for specific language
   - `updateLanguageMcqFlag()` - Updates MCQ flag for specific language
   - `getLanguageTime()` - Gets time for specific language

2. **Transaction Management:**
   - All update methods should use `@Transactional`
   - This ensures data consistency

3. **Error Handling:**
   - Add try-catch blocks for database operations
   - Return meaningful error messages
   - Use appropriate HTTP status codes

