-- ============================================================================
-- CBL Backend - User Topic Engagement Data
-- Generated: October 27, 2025
-- Description: Realistic user engagement data with up to 6 hours max per topic
-- ============================================================================

-- User 2852985 (Stefy Merlin Faustinaa) - Strong in Python, learning Java
INSERT INTO user_topic_engagement (user_id, topic_id, total_seconds_spent, last_activity_at,
                                   java_time_seconds, python_time_seconds, javascript_time_seconds, typescript_time_seconds,
                                   java_visited, python_visited, javascript_visited, typescript_visited, mcq_visited, is_completed) VALUES
-- Data Types & Operators topics (1-4)
('2852985', 1, 18500, CURRENT_TIMESTAMP - INTERVAL '2 days', 4500, 12000, 1500, 500, true, true, true, false, true, true),
('2852985', 2, 16200, CURRENT_TIMESTAMP - INTERVAL '1 day', 4000, 10000, 1500, 700, true, true, true, false, true, true),
('2852985', 3, 14800, CURRENT_TIMESTAMP - INTERVAL '3 days', 3500, 9000, 1500, 800, true, true, true, false, true, false),
('2852985', 4, 13500, CURRENT_TIMESTAMP - INTERVAL '4 days', 3000, 8500, 1200, 800, true, true, true, false, true, true),

-- Conditionals & Loops topics (5-8)
('2852985', 5, 19800, CURRENT_TIMESTAMP - INTERVAL '1 day', 5000, 12000, 2000, 800, true, true, true, false, true, true),
('2852985', 6, 11500, CURRENT_TIMESTAMP - INTERVAL '5 days', 3000, 6500, 1200, 800, true, true, false, false, false, false),
('2852985', 7, 17500, CURRENT_TIMESTAMP - INTERVAL '2 days', 4500, 10000, 2000, 1000, true, true, true, false, true, true),
('2852985', 8, 14200, CURRENT_TIMESTAMP - INTERVAL '3 days', 3500, 8500, 1500, 700, true, true, true, false, true, false),

-- Functions topics (9-12)
('2852985', 9, 20500, CURRENT_TIMESTAMP - INTERVAL '1 day', 6000, 11500, 2000, 1000, true, true, true, false, true, true),
('2852985', 10, 15800, CURRENT_TIMESTAMP - INTERVAL '4 days', 4000, 9000, 1800, 1000, true, true, true, false, true, true),
('2852985', 11, 18800, CURRENT_TIMESTAMP - INTERVAL '2 days', 5000, 10500, 2000, 1300, true, true, true, false, true, false),
('2852985', 12, 16500, CURRENT_TIMESTAMP - INTERVAL '3 days', 4500, 9500, 1700, 800, true, true, true, false, true, true);

-- User 2854134 (Gopanwar Srikanth) - Strong in Java, exploring JavaScript
INSERT INTO user_topic_engagement (user_id, topic_id, total_seconds_spent, last_activity_at,
                                   java_time_seconds, python_time_seconds, javascript_time_seconds, typescript_time_seconds,
                                   java_visited, python_visited, javascript_visited, typescript_visited, mcq_visited, is_completed) VALUES
-- Data Types & Operators topics (1-4)
('2854134', 1, 19200, CURRENT_TIMESTAMP - INTERVAL '3 days', 12000, 3500, 3000, 700, true, true, true, false, true, true),
('2854134', 2, 16800, CURRENT_TIMESTAMP - INTERVAL '2 days', 10000, 3000, 2800, 1000, true, true, true, false, true, true),
('2854134', 3, 15500, CURRENT_TIMESTAMP - INTERVAL '4 days', 9500, 2500, 2500, 1000, true, true, true, false, true, false),
('2854134', 4, 14200, CURRENT_TIMESTAMP - INTERVAL '5 days', 8500, 2500, 2200, 1000, true, true, true, false, true, true),

-- Conditionals & Loops topics (5-8)
('2854134', 5, 20500, CURRENT_TIMESTAMP - INTERVAL '1 day', 13000, 3000, 3500, 1000, true, true, true, false, true, true),
('2854134', 6, 12500, CURRENT_TIMESTAMP - INTERVAL '6 days', 7000, 2000, 2500, 1000, true, true, false, false, false, false),
('2854134', 7, 18200, CURRENT_TIMESTAMP - INTERVAL '2 days', 11000, 2500, 3500, 1200, true, true, true, false, true, true),
('2854134', 8, 14800, CURRENT_TIMESTAMP - INTERVAL '3 days', 8500, 2500, 2800, 1000, true, true, true, false, true, false),

-- Functions topics (9-12)
('2854134', 9, 21500, CURRENT_TIMESTAMP - INTERVAL '1 day', 14000, 3000, 3500, 1000, true, true, true, false, true, true),
('2854134', 10, 16500, CURRENT_TIMESTAMP - INTERVAL '4 days', 10000, 2500, 3000, 1000, true, true, true, false, true, true),
('2854134', 11, 19500, CURRENT_TIMESTAMP - INTERVAL '2 days', 12000, 3000, 3500, 1000, true, true, true, false, true, false),
('2854134', 12, 17200, CURRENT_TIMESTAMP - INTERVAL '3 days', 10500, 2700, 3000, 1000, true, true, true, false, true, true);

-- User 2853304 (Debasish Routray) - Balanced across languages, strong in TypeScript
INSERT INTO user_topic_engagement (user_id, topic_id, total_seconds_spent, last_activity_at,
                                   java_time_seconds, python_time_seconds, javascript_time_seconds, typescript_time_seconds,
                                   java_visited, python_visited, javascript_visited, typescript_visited, mcq_visited, is_completed) VALUES
-- Data Types & Operators topics (1-4)
('2853304', 1, 17800, CURRENT_TIMESTAMP - INTERVAL '2 days', 4500, 4500, 4300, 4500, true, true, true, true, true, true),
('2853304', 2, 16500, CURRENT_TIMESTAMP - INTERVAL '1 day', 4000, 4000, 4000, 4500, true, true, true, true, true, true),
('2853304', 3, 15200, CURRENT_TIMESTAMP - INTERVAL '3 days', 3500, 3500, 3700, 4500, true, true, true, true, true, false),
('2853304', 4, 13800, CURRENT_TIMESTAMP - INTERVAL '4 days', 3000, 3000, 3300, 4500, true, true, true, true, true, true),

-- Conditionals & Loops topics (5-8)
('2853304', 5, 19500, CURRENT_TIMESTAMP - INTERVAL '1 day', 5000, 5000, 4500, 5000, true, true, true, true, true, true),
('2853304', 6, 11800, CURRENT_TIMESTAMP - INTERVAL '5 days', 3000, 3000, 2800, 3000, true, true, false, true, false, false),
('2853304', 7, 17200, CURRENT_TIMESTAMP - INTERVAL '2 days', 4500, 4500, 4200, 4000, true, true, true, true, true, true),
('2853304', 8, 14500, CURRENT_TIMESTAMP - INTERVAL '3 days', 3500, 3500, 3500, 4000, true, true, true, true, true, false),

-- Functions topics (9-12)
('2853304', 9, 20200, CURRENT_TIMESTAMP - INTERVAL '1 day', 5500, 5500, 4700, 4500, true, true, true, true, true, true),
('2853304', 10, 16200, CURRENT_TIMESTAMP - INTERVAL '4 days', 4500, 4500, 3700, 3500, true, true, true, true, true, true),
('2853304', 11, 18500, CURRENT_TIMESTAMP - INTERVAL '2 days', 5000, 5000, 4500, 4000, true, true, true, true, true, false),
('2853304', 12, 16800, CURRENT_TIMESTAMP - INTERVAL '3 days', 4500, 4500, 4300, 3500, true, true, true, true, true, true);

-- Continue with more users for remaining topics...
-- User 2928088 (Ankit Gupta) - Focused on JavaScript/TypeScript
INSERT INTO user_topic_engagement (user_id, topic_id, total_seconds_spent, last_activity_at,
                                   java_time_seconds, python_time_seconds, javascript_time_seconds, typescript_time_seconds,
                                   java_visited, python_visited, javascript_visited, typescript_visited, mcq_visited, is_completed) VALUES
-- Collections topics (13-16)
('2928088', 13, 18800, CURRENT_TIMESTAMP - INTERVAL '2 days', 2000, 2000, 7500, 7300, true, true, true, true, true, true),
('2928088', 14, 16500, CURRENT_TIMESTAMP - INTERVAL '1 day', 1500, 1500, 7000, 6500, true, true, true, true, true, true),
('2928088', 15, 17200, CURRENT_TIMESTAMP - INTERVAL '3 days', 1800, 1800, 7200, 6400, true, true, true, true, true, false),
('2928088', 16, 15800, CURRENT_TIMESTAMP - INTERVAL '4 days', 1200, 1200, 6800, 6600, true, true, true, true, true, true);

-- User 2927944 (Maria Grazia) - Java specialist
INSERT INTO user_topic_engagement (user_id, topic_id, total_seconds_spent, last_activity_at,
                                   java_time_seconds, python_time_seconds, javascript_time_seconds, typescript_time_seconds,
                                   java_visited, python_visited, javascript_visited, typescript_visited, mcq_visited, is_completed) VALUES
-- OOP topics (17-20)
('2927944', 17, 19500, CURRENT_TIMESTAMP - INTERVAL '1 day', 15000, 2000, 1500, 1000, true, true, true, false, true, true),
('2927944', 18, 18200, CURRENT_TIMESTAMP - INTERVAL '2 days', 14000, 1800, 1400, 1000, true, true, true, false, true, true),
('2927944', 19, 16800, CURRENT_TIMESTAMP - INTERVAL '3 days', 13000, 1500, 1300, 1000, true, true, true, false, true, false),
('2927944', 20, 15500, CURRENT_TIMESTAMP - INTERVAL '4 days', 12000, 1500, 1200, 800, true, true, true, false, true, true);

-- User 2918448 (Sunny Gupta) - Python enthusiast
INSERT INTO user_topic_engagement (user_id, topic_id, total_seconds_spent, last_activity_at,
                                   java_time_seconds, python_time_seconds, javascript_time_seconds, typescript_time_seconds,
                                   java_visited, python_visited, javascript_visited, typescript_visited, mcq_visited, is_completed) VALUES
-- Exception Handling topics (21-24)
('2918448', 21, 17800, CURRENT_TIMESTAMP - INTERVAL '2 days', 2000, 12000, 2500, 1300, true, true, true, false, true, true),
('2918448', 22, 16500, CURRENT_TIMESTAMP - INTERVAL '1 day', 1800, 11000, 2200, 1500, true, true, true, false, true, true),
('2918448', 23, 15200, CURRENT_TIMESTAMP - INTERVAL '3 days', 1500, 10000, 2000, 1700, true, true, true, false, true, false),
('2918448', 24, 14200, CURRENT_TIMESTAMP - INTERVAL '4 days', 1200, 9500, 1800, 1700, true, true, true, false, true, true);

-- User 2918705 (Amit Patel) - Full-stack developer (JavaScript/TypeScript focus)
INSERT INTO user_topic_engagement (user_id, topic_id, total_seconds_spent, last_activity_at,
                                   java_time_seconds, python_time_seconds, javascript_time_seconds, typescript_time_seconds,
                                   java_visited, python_visited, javascript_visited, typescript_visited, mcq_visited, is_completed) VALUES
-- Inheritance & Polymorphism topics (25-28)
('2918705', 25, 19200, CURRENT_TIMESTAMP - INTERVAL '1 day', 3000, 2500, 7000, 6700, true, true, true, true, true, true),
('2918705', 26, 17500, CURRENT_TIMESTAMP - INTERVAL '2 days', 2500, 2000, 6500, 6500, true, true, true, true, true, true),
('2918705', 27, 16800, CURRENT_TIMESTAMP - INTERVAL '3 days', 2300, 1800, 6200, 6500, true, true, true, true, true, false),
('2918705', 28, 15800, CURRENT_TIMESTAMP - INTERVAL '4 days', 2000, 1500, 5800, 6500, true, true, true, true, true, true);

-- User learnin (Learning Pavan Kumar) - Comprehensive across all languages
INSERT INTO user_topic_engagement (user_id, topic_id, total_seconds_spent, last_activity_at,
                                   java_time_seconds, python_time_seconds, javascript_time_seconds, typescript_time_seconds,
                                   java_visited, python_visited, javascript_visited, typescript_visited, mcq_visited, is_completed) VALUES
-- Sampling across different topic categories
('learnin', 1, 21600, CURRENT_TIMESTAMP - INTERVAL '1 day', 5400, 5400, 5400, 5400, true, true, true, true, true, true),
('learnin', 5, 20500, CURRENT_TIMESTAMP - INTERVAL '2 days', 5000, 5000, 5500, 5000, true, true, true, true, true, true),
('learnin', 9, 19800, CURRENT_TIMESTAMP - INTERVAL '3 days', 4800, 5000, 5000, 5000, true, true, true, true, true, true),
('learnin', 13, 19200, CURRENT_TIMESTAMP - INTERVAL '4 days', 4600, 4800, 4900, 4900, true, true, true, true, true, true),
('learnin', 17, 18500, CURRENT_TIMESTAMP - INTERVAL '5 days', 4500, 4500, 4800, 4700, true, true, true, true, true, true),
('learnin', 21, 17800, CURRENT_TIMESTAMP - INTERVAL '6 days', 4300, 4400, 4600, 4500, true, true, true, true, true, true),
('learnin', 25, 17200, CURRENT_TIMESTAMP - INTERVAL '7 days', 4200, 4200, 4400, 4400, true, true, true, true, true, true);

-- ============================================================================
-- Verification Query
-- ============================================================================

-- Check total engagement per user
SELECT user_id, COUNT(*) as topics_engaged,
       SUM(total_seconds_spent) as total_time_seconds,
       ROUND(SUM(total_seconds_spent)/3600.0, 2) as total_time_hours
FROM user_topic_engagement
GROUP BY user_id
ORDER BY user_id;

-- Check language distribution for a sample user
SELECT user_id,
       SUM(java_time_seconds) as total_java_seconds,
       SUM(python_time_seconds) as total_python_seconds,
       SUM(javascript_time_seconds) as total_javascript_seconds,
       SUM(typescript_time_seconds) as total_typescript_seconds
FROM user_topic_engagement

GROUP BY user_id;

-- ============================================================================
-- End of Script
-- ============================================================================