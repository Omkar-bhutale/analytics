# 🎯 START HERE - TTMS Quick Start Guide

## ✅ All Errors Fixed - Ready to Run!

---

## 🚀 Fastest Way to Start (Recommended)

### Step 1: Navigate to Project
```bash
cd D:\TTMS
```

### Step 2: Double-Click This File
```
start-application.bat
```

**That's it!** Both backend and frontend will start automatically.

---

## 📝 Manual Start (Alternative)

If you prefer to start manually or the script doesn't work:

### Terminal 1 - Backend
```bash
cd D:\TTMS
.\mvnw.cmd spring-boot:run
```
Wait for message: `Started TtmsApplication in X seconds`

### Terminal 2 - Frontend  
```bash
cd D:\TTMS\frontend
npm install
npm start
```
Browser will auto-open to http://localhost:3000

---

## 🔗 Access the Application

Once both servers are running:

### 🌐 Main Application
**Open in browser:** http://localhost:3000

### 📚 API Documentation
**Swagger UI:** http://localhost:8080/swagger-ui.html

### 💾 Database Console
**H2 Console:** http://localhost:8080/h2-console
- JDBC URL: `jdbc:h2:mem:ttmsdb`
- Username: `sa`
- Password: (leave empty)

---

## 🔑 Login Credentials

### 👨‍💼 Admin Login
```
Username: admin
Password: admin123
```

### 👤 Customer Login
1. Click "Register" to create account
2. Use password format: `Password@123`
   - Min 8 chars
   - 1 uppercase, 1 lowercase
   - 1 digit, 1 special char

---

## ✅ Quick Test (2 Minutes)

### Test 1: Customer Flow
1. Open http://localhost:3000
2. Click **"Register"**
3. Fill form:
   - Name: `John Doe`
   - Email: `john@example.com`
   - Phone: `9876543210`
   - Address: `123 Street, City`
   - Password: `Password@123`
4. Click **"Register"**
5. Click **"Login"** → Customer tab
6. Login with `john@example.com` / `Password@123`
7. Click **"Search Trains"**
8. Search: Mumbai → Delhi
9. Click **"Book Now"** on any train
10. Select seats and confirm

### Test 2: Admin Flow
1. Click **"Login"** → Admin tab
2. Login with `admin` / `admin123`
3. Click **"Manage Trains"**
4. Click **"Add Train"** tab
5. Fill train details
6. Click **"Add Train"**
7. Click **"Customers"** to view all customers

---

## 🎯 Features Available

### For Customers:
- ✅ Registration
- ✅ Login with JWT
- ✅ Search trains
- ✅ Book tickets (Sleeper/AC)
- ✅ View bookings
- ✅ Cancel bookings
- ✅ Update profile

### For Admin:
- ✅ Login
- ✅ Add trains
- ✅ Edit trains
- ✅ Delete trains
- ✅ View customers
- ✅ Activate/Deactivate customers

---

## 🛠️ Technology Stack

**Frontend:**
- ⚛️ React 18
- 🛣️ React Router v6
- 📡 Axios
- 🔔 React Toastify

**Backend:**
- 🍃 Spring Boot 3.5.7
- 🔐 Spring Security + JWT
- 💾 H2 Database
- 📖 Swagger/OpenAPI

---

## 📚 Documentation

| Document | Description |
|----------|-------------|
| `README.md` | Project overview |
| `COMPLETE_SETUP_GUIDE.md` | Detailed setup |
| `QUICK_REFERENCE.md` | Command reference |
| `API_DOCUMENTATION.md` | API details |
| `TROUBLESHOOTING.md` | Fix common issues |
| `ERRORS_FIXED.md` | What was fixed |

---

## 🐛 Having Issues?

### Backend won't start?
```bash
# Check Java version (must be 17+)
java -version

# Clean and rebuild
.\mvnw.cmd clean install
```

### Frontend won't start?
```bash
# Clear and reinstall
cd frontend
rmdir /s /q node_modules
npm install
npm start
```

### Can't login?
- **Admin:** Use `admin` / `admin123`
- **Customer:** Register first, then login
- Clear browser cache if issues persist

### Port already in use?
```bash
# Find and kill process on port 8080
netstat -ano | findstr :8080
taskkill /PID <PID> /F

# Or change port in application.properties
```

---

## 📤 Push to GitHub

When ready to push your code:

### Quick Way
```bash
# Double-click:
push-to-github.bat
```

### Manual Way
```bash
git init
git add .
git commit -m "Initial commit: TTMS with JWT and React"
git branch -M main
git remote add origin https://github.com/Omkar-bhutale/ttms.git
git push -u origin main
```

---

## 🎓 Project Highlights

### ✨ Security
- JWT token authentication
- Password encryption (BCrypt)
- Role-based access control
- Secure API endpoints

### 🎨 Frontend
- Modern React SPA
- Responsive design
- Real-time notifications
- Professional UI/UX

### 🔧 Backend
- RESTful API design
- Swagger documentation
- Input validation
- Exception handling

---

## 💡 Pro Tips

1. **Use Swagger** for API testing - easier than Postman
2. **JWT expires in 24h** - re-login if needed
3. **H2 resets on restart** - data is temporary
4. **Keep terminals open** - don't close them
5. **Test in Chrome** - best compatibility

---

## 🎉 You're All Set!

Your complete TTMS application is ready:

✅ No compilation errors  
✅ JWT authentication working  
✅ Frontend & Backend integrated  
✅ All features implemented  
✅ Documentation complete  

**Start the application and test it now!**

```bash
# Just run:
start-application.bat
```

Then open: **http://localhost:3000**

---

## 📞 Quick Links

- **Application:** http://localhost:3000
- **Swagger:** http://localhost:8080/swagger-ui.html
- **GitHub Repo:** https://github.com/Omkar-bhutale/ttms

---

**Happy Coding! 🚀**

