-- ============================================
-- STORED PROCEDURES AND VIEWS FOR TTMS APPLICATION
-- Using views for queries and procedures only for complex operations
-- ============================================

-- ============================================
-- CUSTOMER VIEWS
-- ============================================

-- View: Find customer by email
CREATE OR REPLACE VIEW vw_customer_by_email AS
SELECT c.id, c.name, c.email, c.phone_number, c.address, c.password, c.is_active
FROM customers c;

-- ============================================
-- CUSTOMER FUNCTIONS
-- ============================================

-- Function: Create customer (returns generated ID)
CREATE OR REPLACE FUNCTION fn_create_customer(
    p_name VARCHAR,
    p_email VARCHAR,
    p_phone_number VARCHAR,
    p_address VARCHAR,
    p_password VARCHAR
)
RETURNS BIGINT AS $$
DECLARE
    v_customer_id BIGINT;
BEGIN
    INSERT INTO customers (name, email, phone_number, address, password, is_active)
    VALUES (p_name, p_email, p_phone_number, p_address, p_password, true)
    RETURNING id INTO v_customer_id;

    RETURN v_customer_id;
END;
$$ LANGUAGE plpgsql;

-- Function: Update customer (returns affected row count)
CREATE OR REPLACE FUNCTION fn_update_customer(
    p_id BIGINT,
    p_name VARCHAR,
    p_email VARCHAR,
    p_phone_number VARCHAR,
    p_address VARCHAR
)
RETURNS INTEGER AS $$
DECLARE
    v_count INTEGER;
BEGIN
    UPDATE customers
    SET name = p_name,
        email = p_email,
        phone_number = p_phone_number,
        address = p_address
    WHERE id = p_id;

    GET DIAGNOSTICS v_count = ROW_COUNT;
    RETURN v_count;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- TRAIN VIEWS
-- ============================================

-- View: Train by train number
CREATE OR REPLACE VIEW vw_train_by_number AS
SELECT t.id, t.train_number, t.train_name, t.origin_station, t.destination_station,
       t.departure_time, t.arrival_time, t.sleeper_seats, t.ac_seats,
       t.available_sleeper_seats, t.available_ac_seats, t.sleeper_fare, t.ac_fare
FROM trains t;

-- View: Trains by route
CREATE OR REPLACE VIEW vw_trains_by_route AS
SELECT t.id, t.train_number, t.train_name, t.origin_station, t.destination_station,
       t.departure_time, t.arrival_time, t.sleeper_seats, t.ac_seats,
       t.available_sleeper_seats, t.available_ac_seats, t.sleeper_fare, t.ac_fare
FROM trains t;

-- ============================================
-- TRAIN FUNCTIONS
-- ============================================

-- Function: Create train (returns generated ID)
CREATE OR REPLACE FUNCTION fn_create_train(
    p_train_number VARCHAR,
    p_train_name VARCHAR,
    p_origin_station VARCHAR,
    p_destination_station VARCHAR,
    p_departure_time TIMESTAMP,
    p_arrival_time TIMESTAMP,
    p_sleeper_seats INTEGER,
    p_ac_seats INTEGER,
    p_sleeper_fare DOUBLE PRECISION,
    p_ac_fare DOUBLE PRECISION
)
RETURNS BIGINT AS $$
DECLARE
    v_train_id BIGINT;
BEGIN
    INSERT INTO trains (
        train_number, train_name, origin_station, destination_station,
        departure_time, arrival_time, sleeper_seats, ac_seats,
        available_sleeper_seats, available_ac_seats, sleeper_fare, ac_fare
    )
    VALUES (
        p_train_number, p_train_name, p_origin_station, p_destination_station,
        p_departure_time, p_arrival_time, p_sleeper_seats, p_ac_seats,
        p_sleeper_seats, p_ac_seats, p_sleeper_fare, p_ac_fare
    )
    RETURNING id INTO v_train_id;

    RETURN v_train_id;
END;
$$ LANGUAGE plpgsql;

-- Function: Update train (returns affected row count)
CREATE OR REPLACE FUNCTION fn_update_train(
    p_id BIGINT,
    p_train_name VARCHAR,
    p_origin_station VARCHAR,
    p_destination_station VARCHAR,
    p_departure_time TIMESTAMP,
    p_arrival_time TIMESTAMP,
    p_sleeper_seats INTEGER,
    p_ac_seats INTEGER,
    p_available_sleeper_seats INTEGER,
    p_available_ac_seats INTEGER,
    p_sleeper_fare DOUBLE PRECISION,
    p_ac_fare DOUBLE PRECISION
)
RETURNS INTEGER AS $$
DECLARE
    v_count INTEGER;
BEGIN
    UPDATE trains
    SET train_name = p_train_name,
        origin_station = p_origin_station,
        destination_station = p_destination_station,
        departure_time = p_departure_time,
        arrival_time = p_arrival_time,
        sleeper_seats = p_sleeper_seats,
        ac_seats = p_ac_seats,
        available_sleeper_seats = p_available_sleeper_seats,
        available_ac_seats = p_available_ac_seats,
        sleeper_fare = p_sleeper_fare,
        ac_fare = p_ac_fare
    WHERE id = p_id;

    GET DIAGNOSTICS v_count = ROW_COUNT;
    RETURN v_count;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- BOOKING VIEWS AND PROCEDURES
-- ============================================

-- View: Booking by ticket ID
CREATE OR REPLACE VIEW vw_booking_by_ticket_id AS
SELECT b.id, b.ticket_id, b.customer_id, b.train_id, b.origin_station,
       b.destination_station, b.travel_date, b.travel_class, b.number_of_seats,
       b.total_fare, b.status, b.booking_date_time, b.cancellation_date_time
FROM bookings b;

-- View: Bookings by customer
CREATE OR REPLACE VIEW vw_bookings_by_customer AS
SELECT b.id, b.ticket_id, b.customer_id, b.train_id, b.origin_station,
       b.destination_station, b.travel_date, b.travel_class, b.number_of_seats,
       b.total_fare, b.status, b.booking_date_time, b.cancellation_date_time
FROM bookings b
ORDER BY b.booking_date_time DESC;

-- View: Bookings by train
CREATE OR REPLACE VIEW vw_bookings_by_train AS
SELECT b.id, b.ticket_id, b.customer_id, b.train_id, b.origin_station,
       b.destination_station, b.travel_date, b.travel_class, b.number_of_seats,
       b.total_fare, b.status, b.booking_date_time, b.cancellation_date_time
FROM bookings b
ORDER BY b.booking_date_time DESC;

-- ============================================
-- BOOKING FUNCTIONS
-- ============================================

-- Function: Create booking (returns generated ID)
CREATE OR REPLACE FUNCTION fn_create_booking(
    p_ticket_id VARCHAR,
    p_customer_id BIGINT,
    p_train_id BIGINT,
    p_origin_station VARCHAR,
    p_destination_station VARCHAR,
    p_travel_date DATE,
    p_travel_class VARCHAR,
    p_number_of_seats INTEGER,
    p_total_fare DOUBLE PRECISION,
    p_booking_date_time TIMESTAMP
)
RETURNS BIGINT AS $$
DECLARE
    v_booking_id BIGINT;
BEGIN
    -- Insert booking
    INSERT INTO bookings (
        ticket_id, customer_id, train_id, origin_station, destination_station,
        travel_date, travel_class, number_of_seats, total_fare,
        status, booking_date_time
    )
    VALUES (
        p_ticket_id, p_customer_id, p_train_id, p_origin_station, p_destination_station,
        p_travel_date, p_travel_class, p_number_of_seats, p_total_fare,
        'CONFIRMED', p_booking_date_time
    )
    RETURNING id INTO v_booking_id;

    -- Update seat availability
    IF p_travel_class = 'SLEEPER' THEN
        UPDATE trains
        SET available_sleeper_seats = available_sleeper_seats - p_number_of_seats
        WHERE id = p_train_id;
    ELSIF p_travel_class = 'AC' THEN
        UPDATE trains
        SET available_ac_seats = available_ac_seats - p_number_of_seats
        WHERE id = p_train_id;
    END IF;

    RETURN v_booking_id;
END;
$$ LANGUAGE plpgsql;

-- Function: Update booking status (returns affected row count)
CREATE OR REPLACE FUNCTION fn_update_booking_status(
    p_id BIGINT,
    p_status VARCHAR,
    p_cancellation_date_time TIMESTAMP
)
RETURNS INTEGER AS $$
DECLARE
    v_count INTEGER;
BEGIN
    UPDATE bookings
    SET status = p_status,
        cancellation_date_time = p_cancellation_date_time
    WHERE id = p_id;

    GET DIAGNOSTICS v_count = ROW_COUNT;
    RETURN v_count;
END;
$$ LANGUAGE plpgsql;

-- Procedure: Cancel booking (complex operation with seat restoration)
CREATE OR REPLACE PROCEDURE sp_cancel_booking(p_booking_id BIGINT)
LANGUAGE plpgsql
AS $$
DECLARE
    v_train_id BIGINT;
    v_travel_class VARCHAR;
    v_number_of_seats INTEGER;
BEGIN
    -- Get booking details
    SELECT train_id, travel_class, number_of_seats
    INTO v_train_id, v_travel_class, v_number_of_seats
    FROM bookings
    WHERE id = p_booking_id;

    -- Update booking status
    UPDATE bookings
    SET status = 'CANCELLED',
        cancellation_date_time = CURRENT_TIMESTAMP
    WHERE id = p_booking_id;

    -- Restore seat availability
    IF v_travel_class = 'SLEEPER' THEN
        UPDATE trains
        SET available_sleeper_seats = available_sleeper_seats + v_number_of_seats
        WHERE id = v_train_id;
    ELSIF v_travel_class = 'AC' THEN
        UPDATE trains
        SET available_ac_seats = available_ac_seats + v_number_of_seats
        WHERE id = v_train_id;
    END IF;
END;
$$;

-- ============================================
-- ADMIN VIEWS
-- ============================================

-- View: Admin by username
CREATE OR REPLACE VIEW vw_admin_by_username AS
SELECT a.id, a.username, a.password
FROM admins a;

-- ============================================
-- REPORTING VIEWS
-- ============================================

-- View: Customer Bookings Summary
CREATE OR REPLACE VIEW vw_customer_bookings_summary AS
SELECT
    c.id AS customer_id,
    c.name AS customer_name,
    c.email AS customer_email,
    COUNT(b.id) AS total_bookings,
    COUNT(CASE WHEN b.status = 'CONFIRMED' THEN 1 END) AS confirmed_bookings,
    COUNT(CASE WHEN b.status = 'CANCELLED' THEN 1 END) AS cancelled_bookings,
    COALESCE(SUM(CASE WHEN b.status = 'CONFIRMED' THEN b.total_fare ELSE 0 END), 0) AS total_revenue
FROM customers c
LEFT JOIN bookings b ON c.id = b.customer_id
WHERE c.is_active = true
GROUP BY c.id, c.name, c.email;

-- View: Train Occupancy Status
CREATE OR REPLACE VIEW vw_train_occupancy AS
SELECT
    t.id AS train_id,
    t.train_number,
    t.train_name,
    t.origin_station,
    t.destination_station,
    t.departure_time,
    t.sleeper_seats,
    t.available_sleeper_seats,
    (t.sleeper_seats - t.available_sleeper_seats) AS booked_sleeper_seats,
    ROUND((t.sleeper_seats - t.available_sleeper_seats)::NUMERIC * 100.0 / NULLIF(t.sleeper_seats, 0), 2) AS sleeper_occupancy_percentage,
    t.ac_seats,
    t.available_ac_seats,
    (t.ac_seats - t.available_ac_seats) AS booked_ac_seats,
    ROUND((t.ac_seats - t.available_ac_seats)::NUMERIC * 100.0 / NULLIF(t.ac_seats, 0), 2) AS ac_occupancy_percentage
FROM trains t;

-- View: Booking Details with Customer and Train Info
CREATE OR REPLACE VIEW vw_booking_details AS
SELECT
    b.id AS booking_id,
    b.ticket_id,
    b.booking_date_time,
    b.travel_date,
    b.status,
    c.id AS customer_id,
    c.name AS customer_name,
    c.email AS customer_email,
    c.phone_number AS customer_phone,
    t.id AS train_id,
    t.train_number,
    t.train_name,
    b.origin_station,
    b.destination_station,
    b.travel_class,
    b.number_of_seats,
    b.total_fare,
    b.cancellation_date_time
FROM bookings b
INNER JOIN customers c ON b.customer_id = c.id
INNER JOIN trains t ON b.train_id = t.id;

-- View: Train Revenue Report
CREATE OR REPLACE VIEW vw_train_revenue AS
SELECT
    t.id AS train_id,
    t.train_number,
    t.train_name,
    t.origin_station,
    t.destination_station,
    COUNT(b.id) AS total_bookings,
    COUNT(CASE WHEN b.status = 'CONFIRMED' THEN 1 END) AS confirmed_bookings,
    COUNT(CASE WHEN b.status = 'CANCELLED' THEN 1 END) AS cancelled_bookings,
    COALESCE(SUM(CASE WHEN b.status = 'CONFIRMED' THEN b.total_fare ELSE 0 END), 0) AS total_revenue,
    COALESCE(SUM(CASE WHEN b.status = 'CONFIRMED' THEN b.number_of_seats ELSE 0 END), 0) AS total_seats_booked
FROM trains t
LEFT JOIN bookings b ON t.id = b.train_id
GROUP BY t.id, t.train_number, t.train_name, t.origin_station, t.destination_station;

-- View: Available Trains
CREATE OR REPLACE VIEW vw_available_trains AS
SELECT
    t.id,
    t.train_number,
    t.train_name,
    t.origin_station,
    t.destination_station,
    t.departure_time,
    t.arrival_time,
    t.available_sleeper_seats,
    t.available_ac_seats,
    t.sleeper_fare,
    t.ac_fare,
    (t.available_sleeper_seats > 0 OR t.available_ac_seats > 0) AS has_availability
FROM trains t
WHERE t.departure_time > CURRENT_TIMESTAMP;

