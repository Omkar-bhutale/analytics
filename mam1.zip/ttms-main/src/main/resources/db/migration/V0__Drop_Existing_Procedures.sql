-- Initialize stored procedures and views for TTMS Application
-- This script drops existing procedures and views before creating new ones

-- Drop existing functions if they exist
DROP FUNCTION IF EXISTS fn_create_customer CASCADE;
DROP FUNCTION IF EXISTS fn_update_customer CASCADE;
DROP FUNCTION IF EXISTS fn_create_train CASCADE;
DROP FUNCTION IF EXISTS fn_update_train CASCADE;
DROP FUNCTION IF EXISTS fn_create_booking CASCADE;
DROP FUNCTION IF EXISTS fn_update_booking_status CASCADE;

-- Drop existing procedures if they exist
DROP PROCEDURE IF EXISTS sp_cancel_booking CASCADE;

-- Drop existing views if they exist
DROP VIEW IF EXISTS vw_customer_by_email CASCADE;
DROP VIEW IF EXISTS vw_train_by_number CASCADE;
DROP VIEW IF EXISTS vw_trains_by_route CASCADE;
DROP VIEW IF EXISTS vw_booking_by_ticket_id CASCADE;
DROP VIEW IF EXISTS vw_bookings_by_customer CASCADE;
DROP VIEW IF EXISTS vw_bookings_by_train CASCADE;
DROP VIEW IF EXISTS vw_admin_by_username CASCADE;
DROP VIEW IF EXISTS vw_customer_bookings_summary CASCADE;
DROP VIEW IF EXISTS vw_train_occupancy CASCADE;
DROP VIEW IF EXISTS vw_booking_details CASCADE;
DROP VIEW IF EXISTS vw_train_revenue CASCADE;
DROP VIEW IF EXISTS vw_available_trains CASCADE;

DROP VIEW IF EXISTS vw_available_trains CASCADE;

