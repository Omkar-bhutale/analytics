package com.ignite.ttms.service;

import com.ignite.ttms.dto.TrainOccupancyReport;
import com.ignite.ttms.dto.TrainRequest;
import com.ignite.ttms.dto.TrainResponse;
import com.ignite.ttms.dto.TrainRevenueReport;
import com.ignite.ttms.dto.TrainSearchRequest;
import com.ignite.ttms.entity.Booking;
import com.ignite.ttms.entity.Train;
import com.ignite.ttms.repository.BookingRepository;
import com.ignite.ttms.repository.TrainRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TrainService {
    private final TrainRepository trainRepository;
    private final BookingRepository bookingRepository;

    @Transactional
    public TrainResponse registerTrain(TrainRequest request) {
        // Validate unique train number
        if (trainRepository.existsByTrainNumber(request.getTrainNumber())) {
            throw new RuntimeException("Train number already exists");
        }

        Long trainId = trainRepository.createTrain(
            request.getTrainNumber(),
            request.getTrainName(),
            request.getOriginStation(),
            request.getDestinationStation(),
            request.getDepartureTime(),
            request.getArrivalTime(),
            request.getSleeperSeats(),
            request.getAcSeats(),
            request.getSleeperFare(),
            request.getAcFare()
        );

        // Fetch the created train
        Train savedTrain = trainRepository.findById(trainId)
                .orElseThrow(() -> new RuntimeException("Train not found after creation"));

        // Handle intermediate stops separately (as they require separate table)
        if (request.getIntermediateStops() != null && !request.getIntermediateStops().isEmpty()) {
            savedTrain.setIntermediateStops(request.getIntermediateStops());
            trainRepository.save(savedTrain);
        }

        return mapToResponse(savedTrain);
    }

    @Transactional
    public TrainResponse updateTrain(String trainNumber, TrainRequest request) {
        Train train = trainRepository.findByTrainNumber(trainNumber)
                .orElseThrow(() -> new RuntimeException("Train not found"));

        // Check for schedule conflict
        if (trainRepository.existsScheduleConflict(
                request.getOriginStation(),
                request.getDestinationStation(),
                request.getDepartureTime(),
                request.getArrivalTime(),
                train.getId())) {
            throw new RuntimeException("Schedule conflict: Another train has the same departure and arrival times for this route");
        }

        // Calculate maintained seat differences
        int sleeperDiff = train.getSleeperSeats() - train.getAvailableSleeperSeats();
        int acDiff = train.getAcSeats() - train.getAvailableAcSeats();

        int newAvailableSleeperSeats = request.getSleeperSeats() - sleeperDiff;
        int newAvailableAcSeats = request.getAcSeats() - acDiff;

        // Update using function
        trainRepository.updateTrain(
            train.getId(),
            request.getTrainName(),
            request.getOriginStation(),
            request.getDestinationStation(),
            request.getDepartureTime(),
            request.getArrivalTime(),
            request.getSleeperSeats(),
            request.getAcSeats(),
            newAvailableSleeperSeats,
            newAvailableAcSeats,
            request.getSleeperFare(),
            request.getAcFare()
        );

        // Handle intermediate stops separately
        Train updatedTrain = trainRepository.findById(train.getId())
                .orElseThrow(() -> new RuntimeException("Train not found after update"));

        if (request.getIntermediateStops() != null) {
            updatedTrain.setIntermediateStops(request.getIntermediateStops());
            trainRepository.save(updatedTrain);
        }

        return mapToResponse(updatedTrain);
    }

    @Transactional
    public void deleteTrain(String trainNumber) {
        Train train = trainRepository.findByTrainNumber(trainNumber)
                .orElseThrow(() -> new RuntimeException("Train not found"));

        // Cancel all associated bookings
        List<Booking> bookings = bookingRepository.findByTrain(train);
        for (Booking booking : bookings) {
            if (booking.getStatus() == Booking.BookingStatus.CONFIRMED) {
                booking.setStatus(Booking.BookingStatus.CANCELLED);
                booking.setCancellationDateTime(java.time.LocalDateTime.now());
            }
        }
        bookingRepository.saveAll(bookings);

        // Delete the train
        trainRepository.delete(train);
    }

    public TrainResponse getTrainByNumber(String trainNumber) {
        Train train = trainRepository.findByTrainNumber(trainNumber)
                .orElseThrow(() -> new RuntimeException("Train not found"));
        return mapToResponse(train);
    }

    public List<TrainResponse> searchTrains(TrainSearchRequest request) {
        LocalDate travelDate = request.getTravelDate();
        LocalDate today = LocalDate.now();
        LocalDate maxDate = today.plusMonths(3);

        if (travelDate != null && (travelDate.isBefore(today) || travelDate.isAfter(maxDate))) {
            throw new RuntimeException("Travel date must be within the next 3 months");
        }

        List<Train> trains = trainRepository.findByRoute(
                request.getOriginStation(),
                request.getDestinationStation()
        );

        return trains.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public List<TrainResponse> getAllTrains() {
        return trainRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public List<TrainOccupancyReport> getTrainOccupancyReport() {
        List<Object[]> results = trainRepository.getTrainOccupancyReport();
        List<TrainOccupancyReport> reports = new ArrayList<>();

        for (Object[] row : results) {
            TrainOccupancyReport report = new TrainOccupancyReport();
            report.setTrainId(((Number) row[0]).longValue());
            report.setTrainNumber((String) row[1]);
            report.setTrainName((String) row[2]);
            report.setOriginStation((String) row[3]);
            report.setDestinationStation((String) row[4]);

            // Handle Timestamp to LocalDateTime conversion
            if (row[5] instanceof Timestamp) {
                report.setDepartureTime(((Timestamp) row[5]).toLocalDateTime());
            } else if (row[5] instanceof LocalDateTime) {
                report.setDepartureTime((LocalDateTime) row[5]);
            }

            report.setSleeperSeats(((Number) row[6]).intValue());
            report.setAvailableSleeperSeats(((Number) row[7]).intValue());
            report.setBookedSleeperSeats(((Number) row[8]).intValue());
            report.setSleeperOccupancyPercentage(row[9] != null ? ((Number) row[9]).doubleValue() : 0.0);
            report.setAcSeats(((Number) row[10]).intValue());
            report.setAvailableAcSeats(((Number) row[11]).intValue());
            report.setBookedAcSeats(((Number) row[12]).intValue());
            report.setAcOccupancyPercentage(row[13] != null ? ((Number) row[13]).doubleValue() : 0.0);

            reports.add(report);
        }

        return reports;
    }

    public List<TrainRevenueReport> getTrainRevenueReport() {
        List<Object[]> results = trainRepository.getTrainRevenueReport();
        List<TrainRevenueReport> reports = new ArrayList<>();

        for (Object[] row : results) {
            TrainRevenueReport report = new TrainRevenueReport();
            report.setTrainId(((Number) row[0]).longValue());
            report.setTrainNumber((String) row[1]);
            report.setTrainName((String) row[2]);
            report.setOriginStation((String) row[3]);
            report.setDestinationStation((String) row[4]);
            report.setTotalBookings(((Number) row[5]).longValue());
            report.setConfirmedBookings(((Number) row[6]).longValue());
            report.setCancelledBookings(((Number) row[7]).longValue());
            report.setTotalRevenue(row[8] != null ? ((Number) row[8]).doubleValue() : 0.0);
            report.setTotalSeatsBooked(((Number) row[9]).longValue());

            reports.add(report);
        }

        return reports;
    }

    private TrainResponse mapToResponse(Train train) {
        TrainResponse response = new TrainResponse();
        response.setId(train.getId());
        response.setTrainNumber(train.getTrainNumber());
        response.setTrainName(train.getTrainName());
        response.setOriginStation(train.getOriginStation());
        response.setDestinationStation(train.getDestinationStation());
        response.setIntermediateStops(train.getIntermediateStops());
        response.setDepartureTime(train.getDepartureTime());
        response.setArrivalTime(train.getArrivalTime());
        response.setSleeperSeats(train.getSleeperSeats());
        response.setAcSeats(train.getAcSeats());
        response.setAvailableSleeperSeats(train.getAvailableSleeperSeats());
        response.setAvailableAcSeats(train.getAvailableAcSeats());
        response.setSleeperFare(train.getSleeperFare());
        response.setAcFare(train.getAcFare());
        return response;
    }
}

