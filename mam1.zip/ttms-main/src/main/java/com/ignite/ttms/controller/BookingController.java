package com.ignite.ttms.controller;

import com.ignite.ttms.dto.BookingRequest;
import com.ignite.ttms.dto.BookingResponse;
import com.ignite.ttms.dto.CancellationRequest;
import com.ignite.ttms.service.BookingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
@Tag(name = "Booking Management", description = "APIs for booking and cancelling tickets")
public class BookingController {
    private final BookingService bookingService;

    @PostMapping
    @Operation(summary = "Book Ticket", description = "Book train tickets (1-6 seats per booking)")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Ticket booked successfully"),
            @ApiResponse(responseCode = "400", description = "Insufficient seats, invalid customer, or validation error")
    })
    public ResponseEntity<BookingResponse> bookTicket(@Valid @RequestBody BookingRequest request) {
        try {
            BookingResponse response = bookingService.bookTicket(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (RuntimeException e) {
            throw new RuntimeException("Booking failed: " + e.getMessage());
        }
    }

    @PostMapping("/cancel")
    @Operation(summary = "Cancel Ticket", description = "Cancel a booked ticket (must be 24 hours before departure)")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Ticket cancelled successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid ticket, unauthorized, or cancellation window expired")
    })
    public ResponseEntity<String> cancelTicket(@Valid @RequestBody CancellationRequest request) {
        String message = bookingService.cancelTicket(request);
        return ResponseEntity.ok(message);
    }

    @GetMapping("/customer/{customerId}")
    @Operation(summary = "Get Booking History", description = "Get all bookings for a customer")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Booking history retrieved"),
            @ApiResponse(responseCode = "404", description = "Customer not found")
    })
    public ResponseEntity<List<BookingResponse>> getBookingHistory(@PathVariable Long customerId) {
        List<BookingResponse> bookings = bookingService.getBookingHistory(customerId);
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/ticket/{ticketId}")
    @Operation(summary = "Get Booking by Ticket ID", description = "Retrieve booking details by ticket ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Booking found"),
            @ApiResponse(responseCode = "404", description = "Ticket not found")
    })
    public ResponseEntity<BookingResponse> getBookingByTicketId(@PathVariable String ticketId) {
        BookingResponse response = bookingService.getBookingByTicketId(ticketId);
        return ResponseEntity.ok(response);
    }
}
