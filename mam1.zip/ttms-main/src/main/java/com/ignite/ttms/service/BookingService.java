package com.ignite.ttms.service;

import com.ignite.ttms.dto.BookingRequest;
import com.ignite.ttms.dto.BookingResponse;
import com.ignite.ttms.dto.CancellationRequest;
import com.ignite.ttms.entity.Booking;
import com.ignite.ttms.entity.Customer;
import com.ignite.ttms.entity.Train;
import com.ignite.ttms.repository.BookingRepository;
import com.ignite.ttms.repository.CustomerRepository;
import com.ignite.ttms.repository.TrainRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BookingService {
    private final BookingRepository bookingRepository;
    private final CustomerRepository customerRepository;
    private final TrainRepository trainRepository;
    private final org.springframework.security.crypto.password.PasswordEncoder passwordEncoder;

    @Transactional
    public BookingResponse bookTicket(BookingRequest request) {
        // Validate customer
        Customer customer = customerRepository.findById(request.getCustomerId())
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        if (!customer.getIsActive()) {
            throw new RuntimeException("Customer account is deactivated");
        }

        // Validate train
        Train train = trainRepository.findByTrainNumber(request.getTrainNumber())
                .orElseThrow(() -> new RuntimeException("Train not found"));

        // Check seat availability
        int requestedSeats = request.getNumberOfSeats();
        String travelClass = request.getTravelClass();

        if ("SLEEPER".equals(travelClass)) {
            if (train.getAvailableSleeperSeats() < requestedSeats) {
                throw new RuntimeException("Insufficient sleeper seats available");
            }
        } else if ("AC".equals(travelClass)) {
            if (train.getAvailableAcSeats() < requestedSeats) {
                throw new RuntimeException("Insufficient AC seats available");
            }
        } else {
            throw new RuntimeException("Invalid travel class");
        }

        // Calculate fare
        double totalFare = calculateFare(train, travelClass, requestedSeats);

        // Generate ticket ID
        String ticketId = "TKT" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        LocalDateTime bookingDateTime = LocalDateTime.now();

        // Create booking using function
        Long bookingId = bookingRepository.createBooking(
            ticketId,
            customer.getId(),
            train.getId(),
            request.getOriginStation(),
            request.getDestinationStation(),
            request.getTravelDate(),
            travelClass,
            requestedSeats,
            totalFare,
            bookingDateTime
        );

        // Fetch created booking
        Booking savedBooking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found after creation"));

        return mapToResponse(savedBooking);
    }

    @Transactional
    public String cancelTicket(CancellationRequest request) {
        System.out.println("Cancellation request received for ticket: " + request.getTicketId());

        // Validate ticket
        Booking booking = bookingRepository.findByTicketId(request.getTicketId())
                .orElseThrow(() -> new RuntimeException("Ticket not found"));

        System.out.println("Booking found. Customer ID: " + booking.getCustomer().getId());

        // Verify customer and password
        Customer customer = booking.getCustomer();
        if (!customer.getId().equals(request.getCustomerId())) {
            throw new RuntimeException("Unauthorized: Ticket does not belong to this customer");
        }

        System.out.println("Customer verified. Checking password...");
        if (!passwordEncoder.matches(request.getPassword(), customer.getPassword())) {
            System.out.println("Password verification failed!");
            throw new RuntimeException("Invalid password");
        }

        System.out.println("Password verified successfully!");

        // Check if already cancelled
        if (booking.getStatus() == Booking.BookingStatus.CANCELLED) {
            throw new RuntimeException("Ticket is already cancelled");
        }

        // Cancellation window check
        LocalDateTime trainDepartureTime = booking.getTrain().getDepartureTime();
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime cancellationDeadline = trainDepartureTime.minusHours(24);

        System.out.println("Train departure time: " + trainDepartureTime);
        System.out.println("Current time: " + now);
        System.out.println("Cancellation deadline: " + cancellationDeadline);

        if (now.isAfter(cancellationDeadline)) {
            throw new RuntimeException("Cancellation not allowed: Must be done at least 24 hours before departure");
        }

        // Cancel booking using procedure (handles seat restoration automatically)
        bookingRepository.cancelBookingProcedure(booking.getId());

        return "Ticket cancelled successfully. Refund will be processed as per refund policy.";
    }

    public List<BookingResponse> getBookingHistory(Long customerId) {
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        List<Booking> bookings = bookingRepository.findByCustomerOrderByBookingDateTimeDesc(customer);

        return bookings.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public BookingResponse getBookingByTicketId(String ticketId) {
        Booking booking = bookingRepository.findByTicketId(ticketId)
                .orElseThrow(() -> new RuntimeException("Ticket not found"));
        return mapToResponse(booking);
    }

    private double calculateFare(Train train, String travelClass, int numberOfSeats) {
        double farePerSeat = "SLEEPER".equals(travelClass) ? train.getSleeperFare() : train.getAcFare();
        return farePerSeat * numberOfSeats;
    }

    private BookingResponse mapToResponse(Booking booking) {
        BookingResponse response = new BookingResponse();
        response.setId(booking.getId());
        response.setTicketId(booking.getTicketId());
        response.setCustomerId(booking.getCustomer().getId());
        response.setCustomerName(booking.getCustomer().getName());
        response.setTrainNumber(booking.getTrain().getTrainNumber());
        response.setTrainName(booking.getTrain().getTrainName());
        response.setOriginStation(booking.getOriginStation());
        response.setDestinationStation(booking.getDestinationStation());
        response.setTravelDate(booking.getTravelDate());
        response.setTravelClass(booking.getTravelClass());
        response.setNumberOfSeats(booking.getNumberOfSeats());
        response.setTotalFare(booking.getTotalFare());
        response.setStatus(booking.getStatus());
        response.setBookingDateTime(booking.getBookingDateTime());
        response.setCancellationDateTime(booking.getCancellationDateTime());
        return response;
    }
}

