package com.ignite.ttms.repository;

import com.ignite.ttms.entity.Booking;
import com.ignite.ttms.entity.Customer;
import com.ignite.ttms.entity.Train;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {

    @Query(value = "SELECT * FROM vw_booking_by_ticket_id WHERE ticket_id = :ticketId", nativeQuery = true)
    Optional<Booking> findByTicketId(@Param("ticketId") String ticketId);

    @Query(value = "SELECT * FROM vw_bookings_by_customer WHERE customer_id = :customerId", nativeQuery = true)
    List<Booking> findByCustomerOrderByBookingDateTimeDesc(@Param("customerId") Long customerId);

    // For backward compatibility with Customer object parameter
    default List<Booking> findByCustomerOrderByBookingDateTimeDesc(Customer customer) {
        return findByCustomerOrderByBookingDateTimeDesc(customer.getId());
    }

    @Query(value = "SELECT * FROM vw_bookings_by_train WHERE train_id = :trainId", nativeQuery = true)
    List<Booking> findByTrain(@Param("trainId") Long trainId);

    // For backward compatibility with Train object parameter
    default List<Booking> findByTrain(Train train) {
        return findByTrain(train.getId());
    }

    @Transactional
    @Query(value = "SELECT fn_create_booking(:ticketId, :customerId, :trainId, :originStation, :destinationStation, " +
           ":travelDate, :travelClass, :numberOfSeats, :totalFare, :bookingDateTime)", nativeQuery = true)
    Long createBooking(@Param("ticketId") String ticketId,
                      @Param("customerId") Long customerId,
                      @Param("trainId") Long trainId,
                      @Param("originStation") String originStation,
                      @Param("destinationStation") String destinationStation,
                      @Param("travelDate") LocalDate travelDate,
                      @Param("travelClass") String travelClass,
                      @Param("numberOfSeats") Integer numberOfSeats,
                      @Param("totalFare") Double totalFare,
                      @Param("bookingDateTime") LocalDateTime bookingDateTime);

    @Transactional
    @Modifying
    @Query(value = "CALL sp_cancel_booking(:bookingId)", nativeQuery = true)
    void cancelBookingProcedure(@Param("bookingId") Long bookingId);

    // View-based queries for reporting
    @Query(value = "SELECT * FROM vw_booking_details WHERE customer_id = :customerId", nativeQuery = true)
    List<Object[]> getBookingDetailsForCustomer(@Param("customerId") Long customerId);

    @Query(value = "SELECT * FROM vw_booking_details WHERE train_id = :trainId", nativeQuery = true)
    List<Object[]> getBookingDetailsForTrain(@Param("trainId") Long trainId);

    @Query(value = "SELECT * FROM vw_customer_bookings_summary", nativeQuery = true)
    List<Object[]> getCustomerBookingsSummary();
}

