package com.ignite.ttms.controller;

import com.ignite.ttms.dto.TrainOccupancyReport;
import com.ignite.ttms.dto.TrainRequest;
import com.ignite.ttms.dto.TrainResponse;
import com.ignite.ttms.dto.TrainRevenueReport;
import com.ignite.ttms.service.TrainService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin/trains")
@RequiredArgsConstructor
@Tag(name = "Admin - Train Management", description = "Admin APIs for managing trains")
public class AdminTrainController {
    private final TrainService trainService;

    @PostMapping
    @Operation(summary = "Register New Train", description = "Register a new train with complete details (Admin only)")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Train registered successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error or train number already exists")
    })
    public ResponseEntity<TrainResponse> registerTrain(@Valid @RequestBody TrainRequest request) {
        try {
            TrainResponse response = trainService.registerTrain(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (RuntimeException e) {
            throw new RuntimeException("Train registration failed: " + e.getMessage());
        }
    }

    @PutMapping("/{trainNumber}")
    @Operation(summary = "Update Train", description = "Update train details by train number (Admin only)")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Train updated successfully"),
            @ApiResponse(responseCode = "404", description = "Train not found"),
            @ApiResponse(responseCode = "400", description = "Schedule conflict or validation error")
    })
    public ResponseEntity<TrainResponse> updateTrain(
            @PathVariable String trainNumber,
            @Valid @RequestBody TrainRequest request) {
        try {
            TrainResponse response = trainService.updateTrain(trainNumber, request);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            throw new RuntimeException("Train update failed: " + e.getMessage());
        }
    }

    @DeleteMapping("/{trainNumber}")
    @Operation(summary = "Delete Train", description = "Delete train and cancel all associated bookings (Admin only)")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Train deleted successfully"),
            @ApiResponse(responseCode = "404", description = "Train not found")
    })
    public ResponseEntity<String> deleteTrain(@PathVariable String trainNumber) {
        try {
            trainService.deleteTrain(trainNumber);
            return ResponseEntity.ok("Train deleted successfully and associated bookings cancelled");
        } catch (RuntimeException e) {
            throw new RuntimeException("Train deletion failed: " + e.getMessage());
        }
    }

    @GetMapping("/{trainNumber}")
    @Operation(summary = "Get Train Details", description = "Get train details by train number (Admin only)")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Train found"),
            @ApiResponse(responseCode = "404", description = "Train not found")
    })
    public ResponseEntity<TrainResponse> getTrainByNumber(@PathVariable String trainNumber) {
        TrainResponse response = trainService.getTrainByNumber(trainNumber);
        return ResponseEntity.ok(response);
    }

    @GetMapping
    @Operation(summary = "Get All Trains", description = "Get all trains in the system (Admin only)")
    @ApiResponse(responseCode = "200", description = "List of all trains")
    public ResponseEntity<List<TrainResponse>> getAllTrains() {
        List<TrainResponse> trains = trainService.getAllTrains();
        return ResponseEntity.ok(trains);
    }

    @GetMapping("/reports/occupancy")
    @Operation(summary = "Get Train Occupancy Report", description = "Get seat occupancy details for all trains (Admin only)")
    @ApiResponse(responseCode = "200", description = "Train occupancy report")
    public ResponseEntity<List<TrainOccupancyReport>> getTrainOccupancyReport() {
        List<TrainOccupancyReport> report = trainService.getTrainOccupancyReport();
        return ResponseEntity.ok(report);
    }

    @GetMapping("/reports/revenue")
    @Operation(summary = "Get Train Revenue Report", description = "Get revenue and booking statistics for all trains (Admin only)")
    @ApiResponse(responseCode = "200", description = "Train revenue report")
    public ResponseEntity<List<TrainRevenueReport>> getTrainRevenueReport() {
        List<TrainRevenueReport> report = trainService.getTrainRevenueReport();
        return ResponseEntity.ok(report);
    }
}
