package com.ignite.ttms.repository;

import com.ignite.ttms.entity.Train;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface TrainRepository extends JpaRepository<Train, Long> {

    @Query(value = "SELECT * FROM vw_train_by_number WHERE train_number = :trainNumber", nativeQuery = true)
    Optional<Train> findByTrainNumber(@Param("trainNumber") String trainNumber);

    @Query(value = "SELECT CASE WHEN COUNT(*) > 0 THEN true ELSE false END FROM trains WHERE train_number = :trainNumber", nativeQuery = true)
    boolean existsByTrainNumber(@Param("trainNumber") String trainNumber);

    @Query(value = "SELECT * FROM vw_trains_by_route WHERE origin_station = :origin AND destination_station = :destination", nativeQuery = true)
    List<Train> findByRoute(@Param("origin") String origin, @Param("destination") String destination);

    @Query(value = "SELECT CASE WHEN COUNT(*) > 0 THEN true ELSE false END FROM trains " +
           "WHERE origin_station = :origin AND destination_station = :destination " +
           "AND departure_time = :departure AND arrival_time = :arrival AND id != :trainId", nativeQuery = true)
    boolean existsScheduleConflict(@Param("origin") String origin,
                                   @Param("destination") String destination,
                                   @Param("departure") LocalDateTime departure,
                                   @Param("arrival") LocalDateTime arrival,
                                   @Param("trainId") Long trainId);

    @Transactional
    @Query(value = "SELECT fn_create_train(:trainNumber, :trainName, :originStation, :destinationStation, " +
           ":departureTime, :arrivalTime, :sleeperSeats, :acSeats, :sleeperFare, :acFare)", nativeQuery = true)
    Long createTrain(@Param("trainNumber") String trainNumber,
                    @Param("trainName") String trainName,
                    @Param("originStation") String originStation,
                    @Param("destinationStation") String destinationStation,
                    @Param("departureTime") LocalDateTime departureTime,
                    @Param("arrivalTime") LocalDateTime arrivalTime,
                    @Param("sleeperSeats") Integer sleeperSeats,
                    @Param("acSeats") Integer acSeats,
                    @Param("sleeperFare") Double sleeperFare,
                    @Param("acFare") Double acFare);

    @Transactional
    @Modifying
    @Query(value = "SELECT fn_update_train(:id, :trainName, :originStation, :destinationStation, " +
           ":departureTime, :arrivalTime, :sleeperSeats, :acSeats, :availableSleeperSeats, " +
           ":availableAcSeats, :sleeperFare, :acFare)", nativeQuery = true)
    Integer updateTrain(@Param("id") Long id,
                       @Param("trainName") String trainName,
                       @Param("originStation") String originStation,
                       @Param("destinationStation") String destinationStation,
                       @Param("departureTime") LocalDateTime departureTime,
                       @Param("arrivalTime") LocalDateTime arrivalTime,
                       @Param("sleeperSeats") Integer sleeperSeats,
                       @Param("acSeats") Integer acSeats,
                       @Param("availableSleeperSeats") Integer availableSleeperSeats,
                       @Param("availableAcSeats") Integer availableAcSeats,
                       @Param("sleeperFare") Double sleeperFare,
                       @Param("acFare") Double acFare);

    @Transactional
    @Modifying
    @Query(value = "UPDATE trains SET available_sleeper_seats = available_sleeper_seats + :seatsChange " +
           "WHERE id = :trainId AND :seatType = 'SLEEPER'", nativeQuery = true)
    void updateSleeperSeats(@Param("trainId") Long trainId,
                           @Param("seatType") String seatType,
                           @Param("seatsChange") Integer seatsChange);

    @Transactional
    @Modifying
    @Query(value = "UPDATE trains SET available_ac_seats = available_ac_seats + :seatsChange " +
           "WHERE id = :trainId AND :seatType = 'AC'", nativeQuery = true)
    void updateAcSeats(@Param("trainId") Long trainId,
                      @Param("seatType") String seatType,
                      @Param("seatsChange") Integer seatsChange);

    // View-based queries for reporting
    @Query(value = "SELECT * FROM vw_train_occupancy", nativeQuery = true)
    List<Object[]> getTrainOccupancyReport();

    @Query(value = "SELECT * FROM vw_train_revenue", nativeQuery = true)
    List<Object[]> getTrainRevenueReport();
}

