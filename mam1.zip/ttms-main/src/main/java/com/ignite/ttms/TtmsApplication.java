package com.ignite.ttms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TtmsApplication {

    public static void main(String[] args) {
        SpringApplication.run(TtmsApplication.class, args);
    }

}
