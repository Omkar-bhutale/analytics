package com.ignite.ttms.config;

import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.jdbc.datasource.init.ScriptUtils;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;

/**
 * Database initialization component that executes SQL scripts on application startup.
 * This will create stored procedures and views for the TTMS application.
 *
 * DISABLED: Spring ScriptUtils cannot parse PL/pgSQL dollar quotes.
 * Run scripts manually in pgAdmin or use install-procedures.ps1
 */
// @Component
public class DatabaseInitializer implements ApplicationListener<ApplicationReadyEvent> {

    private final DataSource dataSource;
    private boolean initialized = false;

    public DatabaseInitializer(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void onApplicationEvent(ApplicationReadyEvent event) {
        if (!initialized) {
            try {
                ResourceDatabasePopulator populator = new ResourceDatabasePopulator();
                populator.setContinueOnError(true);
                populator.setSeparator(";");

                // Drop existing procedures
                populator.addScript(new ClassPathResource("db/migration/V0__Drop_Existing_Procedures.sql"));

                // Create procedures and views
                populator.addScript(new ClassPathResource("db/migration/V1__Create_Procedures_And_Views.sql"));

                // Execute with connection
                try (Connection conn = dataSource.getConnection()) {
                    ScriptUtils.executeSqlScript(conn, new ClassPathResource("db/migration/V0__Drop_Existing_Procedures.sql"));
                    ScriptUtils.executeSqlScript(conn, new ClassPathResource("db/migration/V1__Create_Procedures_And_Views.sql"));
                }

                System.out.println("=================================================");
                System.out.println("Database procedures and views initialized successfully!");
                System.out.println("=================================================");
                initialized = true;
            } catch (Exception e) {
                System.err.println("=================================================");
                System.err.println("Error initializing database procedures: " + e.getMessage());
                System.err.println("=================================================");
                e.printStackTrace();
                System.err.println("Application will continue but stored procedures may not be available.");
            }
        }
    }
}

