package com.ignite.ttms.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TrainRevenueReport {
    private Long trainId;
    private String trainNumber;
    private String trainName;
    private String originStation;
    private String destinationStation;
    private Long totalBookings;
    private Long confirmedBookings;
    private Long cancelledBookings;
    private Double totalRevenue;
    private Long totalSeatsBooked;
}

