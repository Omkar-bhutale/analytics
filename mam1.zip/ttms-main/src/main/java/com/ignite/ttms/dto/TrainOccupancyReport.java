package com.ignite.ttms.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TrainOccupancyReport {
    private Long trainId;
    private String trainNumber;
    private String trainName;
    private String originStation;
    private String destinationStation;
    private LocalDateTime departureTime;
    private Integer sleeperSeats;
    private Integer availableSleeperSeats;
    private Integer bookedSleeperSeats;
    private Double sleeperOccupancyPercentage;
    private Integer acSeats;
    private Integer availableAcSeats;
    private Integer bookedAcSeats;
    private Double acOccupancyPercentage;
}

