package com.ignite.ttms.repository;

import com.ignite.ttms.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {

    @Query(value = "SELECT * FROM vw_customer_by_email WHERE email = :email", nativeQuery = true)
    Optional<Customer> findByEmail(@Param("email") String email);

    @Query(value = "SELECT CASE WHEN COUNT(*) > 0 THEN true ELSE false END FROM customers WHERE email = :email", nativeQuery = true)
    boolean existsByEmail(@Param("email") String email);

    @Transactional
    @Query(value = "SELECT fn_create_customer(:name, :email, :phoneNumber, :address, :password)", nativeQuery = true)
    Long createCustomer(@Param("name") String name,
                       @Param("email") String email,
                       @Param("phoneNumber") String phoneNumber,
                       @Param("address") String address,
                       @Param("password") String password);

    @Transactional
    @Modifying
    @Query(value = "SELECT fn_update_customer(:id, :name, :email, :phoneNumber, :address)", nativeQuery = true)
    Integer updateCustomer(@Param("id") Long id,
                          @Param("name") String name,
                          @Param("email") String email,
                          @Param("phoneNumber") String phoneNumber,
                          @Param("address") String address);

    @Transactional
    @Modifying
    @Query(value = "UPDATE customers SET is_active = false WHERE id = :id", nativeQuery = true)
    void softDeleteCustomer(@Param("id") Long id);
}

