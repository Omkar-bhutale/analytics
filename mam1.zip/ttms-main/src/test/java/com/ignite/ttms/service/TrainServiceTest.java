package com.ignite.ttms.service;

import com.ignite.ttms.dto.TrainRequest;
import com.ignite.ttms.dto.TrainResponse;
import com.ignite.ttms.dto.TrainSearchRequest;
import com.ignite.ttms.entity.Booking;
import com.ignite.ttms.entity.Train;
import com.ignite.ttms.repository.BookingRepository;
import com.ignite.ttms.repository.TrainRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TrainServiceTest {

    @Mock
    private TrainRepository trainRepository;

    @Mock
    private BookingRepository bookingRepository;

    @InjectMocks
    private TrainService trainService;

    private Train testTrain;
    private TrainRequest trainRequest;

    @BeforeEach
    void setUp() {
        testTrain = new Train();
        testTrain.setId(1L);
        testTrain.setTrainNumber("12345");
        testTrain.setTrainName("Express Train");
        testTrain.setOriginStation("Mumbai");
        testTrain.setDestinationStation("Delhi");
        testTrain.setDepartureTime(LocalDateTime.now().plusDays(5));
        testTrain.setArrivalTime(LocalDateTime.now().plusDays(5).plusHours(12));
        testTrain.setSleeperSeats(100);
        testTrain.setAcSeats(50);
        testTrain.setAvailableSleeperSeats(100);
        testTrain.setAvailableAcSeats(50);
        testTrain.setSleeperFare(500.0);
        testTrain.setAcFare(1000.0);
        testTrain.setIntermediateStops(List.of("Surat", "Vadodara"));

        trainRequest = new TrainRequest();
        trainRequest.setTrainNumber("12345");
        trainRequest.setTrainName("Express Train");
        trainRequest.setOriginStation("Mumbai");
        trainRequest.setDestinationStation("Delhi");
        trainRequest.setDepartureTime(LocalDateTime.now().plusDays(5));
        trainRequest.setArrivalTime(LocalDateTime.now().plusDays(5).plusHours(12));
        trainRequest.setSleeperSeats(100);
        trainRequest.setAcSeats(50);
        trainRequest.setSleeperFare(500.0);
        trainRequest.setAcFare(1000.0);
        trainRequest.setIntermediateStops(List.of("Surat", "Vadodara"));
    }

    @Test
    void testRegisterTrain_Success() {
        // Arrange
        when(trainRepository.existsByTrainNumber("12345")).thenReturn(false);
        when(trainRepository.save(any(Train.class))).thenReturn(testTrain);

        // Act
        TrainResponse response = trainService.registerTrain(trainRequest);

        // Assert
        assertNotNull(response);
        assertEquals("12345", response.getTrainNumber());
        assertEquals("Express Train", response.getTrainName());
        assertEquals("Mumbai", response.getOriginStation());
        assertEquals("Delhi", response.getDestinationStation());
        assertEquals(100, response.getSleeperSeats());
        assertEquals(50, response.getAcSeats());
        assertEquals(500.0, response.getSleeperFare());
        assertEquals(1000.0, response.getAcFare());

        verify(trainRepository, times(1)).existsByTrainNumber("12345");
        verify(trainRepository, times(1)).save(any(Train.class));
    }

    @Test
    void testRegisterTrain_TrainNumberAlreadyExists() {
        // Arrange
        when(trainRepository.existsByTrainNumber("12345")).thenReturn(true);

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            trainService.registerTrain(trainRequest);
        });

        assertEquals("Train number already exists", exception.getMessage());
        verify(trainRepository, times(1)).existsByTrainNumber("12345");
        verify(trainRepository, never()).save(any(Train.class));
    }

    @Test
    void testUpdateTrain_Success() {
        // Arrange
        when(trainRepository.findByTrainNumber("12345")).thenReturn(Optional.of(testTrain));
        when(trainRepository.existsScheduleConflict(anyString(), anyString(), any(LocalDateTime.class),
                any(LocalDateTime.class), any(Long.class))).thenReturn(false);
        when(trainRepository.save(any(Train.class))).thenReturn(testTrain);

        // Act
        TrainResponse response = trainService.updateTrain("12345", trainRequest);

        // Assert
        assertNotNull(response);
        assertEquals("12345", response.getTrainNumber());
        verify(trainRepository, times(1)).findByTrainNumber("12345");
        verify(trainRepository, times(1)).save(any(Train.class));
    }

    @Test
    void testUpdateTrain_TrainNotFound() {
        // Arrange
        when(trainRepository.findByTrainNumber("12345")).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            trainService.updateTrain("12345", trainRequest);
        });

        assertEquals("Train not found", exception.getMessage());
        verify(trainRepository, times(1)).findByTrainNumber("12345");
        verify(trainRepository, never()).save(any(Train.class));
    }

    @Test
    void testUpdateTrain_ScheduleConflict() {
        // Arrange
        when(trainRepository.findByTrainNumber("12345")).thenReturn(Optional.of(testTrain));
        when(trainRepository.existsScheduleConflict(anyString(), anyString(), any(LocalDateTime.class),
                any(LocalDateTime.class), any(Long.class))).thenReturn(true);

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            trainService.updateTrain("12345", trainRequest);
        });

        assertTrue(exception.getMessage().contains("Schedule conflict"));
        verify(trainRepository, never()).save(any(Train.class));
    }

    @Test
    void testDeleteTrain_Success() {
        // Arrange
        List<Booking> bookings = new ArrayList<>();
        when(trainRepository.findByTrainNumber("12345")).thenReturn(Optional.of(testTrain));
        when(bookingRepository.findByTrain(testTrain)).thenReturn(bookings);

        // Act
        trainService.deleteTrain("12345");

        // Assert
        verify(trainRepository, times(1)).findByTrainNumber("12345");
        verify(trainRepository, times(1)).delete(testTrain);
    }

    @Test
    void testDeleteTrain_NotFound() {
        // Arrange
        when(trainRepository.findByTrainNumber("12345")).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            trainService.deleteTrain("12345");
        });

        assertEquals("Train not found", exception.getMessage());
        verify(trainRepository, never()).delete(any(Train.class));
    }

    @Test
    void testGetTrainByNumber_Success() {
        // Arrange
        when(trainRepository.findByTrainNumber("12345")).thenReturn(Optional.of(testTrain));

        // Act
        TrainResponse response = trainService.getTrainByNumber("12345");

        // Assert
        assertNotNull(response);
        assertEquals("12345", response.getTrainNumber());
        assertEquals("Express Train", response.getTrainName());
        verify(trainRepository, times(1)).findByTrainNumber("12345");
    }

    @Test
    void testGetTrainByNumber_NotFound() {
        // Arrange
        when(trainRepository.findByTrainNumber("99999")).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            trainService.getTrainByNumber("99999");
        });

        assertEquals("Train not found", exception.getMessage());
    }

    @Test
    void testSearchTrains_Success() {
        // Arrange
        TrainSearchRequest searchRequest = new TrainSearchRequest();
        searchRequest.setOriginStation("Mumbai");
        searchRequest.setDestinationStation("Delhi");
        searchRequest.setTravelDate(LocalDate.now().plusDays(5));

        List<Train> trains = new ArrayList<>();
        trains.add(testTrain);

        when(trainRepository.findByRoute("Mumbai", "Delhi")).thenReturn(trains);

        // Act
        List<TrainResponse> result = trainService.searchTrains(searchRequest);

        // Assert
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("12345", result.get(0).getTrainNumber());
        verify(trainRepository, times(1)).findByRoute("Mumbai", "Delhi");
    }

    @Test
    void testSearchTrains_InvalidTravelDate() {
        // Arrange
        TrainSearchRequest searchRequest = new TrainSearchRequest();
        searchRequest.setOriginStation("Mumbai");
        searchRequest.setDestinationStation("Delhi");
        searchRequest.setTravelDate(LocalDate.now().minusDays(1)); // Past date

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            trainService.searchTrains(searchRequest);
        });

        assertTrue(exception.getMessage().contains("within the next 3 months"));
    }

    @Test
    void testGetAllTrains_Success() {
        // Arrange
        List<Train> trains = new ArrayList<>();
        trains.add(testTrain);
        when(trainRepository.findAll()).thenReturn(trains);

        // Act
        List<TrainResponse> result = trainService.getAllTrains();

        // Assert
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("12345", result.get(0).getTrainNumber());
        verify(trainRepository, times(1)).findAll();
    }
}

