package com.ignite.ttms.service;

import com.ignite.ttms.dto.LoginRequest;
import com.ignite.ttms.dto.LoginResponse;
import com.ignite.ttms.entity.Admin;
import com.ignite.ttms.entity.Customer;
import com.ignite.ttms.repository.AdminRepository;
import com.ignite.ttms.repository.CustomerRepository;
import com.ignite.ttms.security.JwtUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @Mock
    private AdminRepository adminRepository;

    @Mock
    private CustomerRepository customerRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private JwtUtil jwtUtil;

    @InjectMocks
    private AuthService authService;

    private Admin testAdmin;
    private Customer testCustomer;
    private LoginRequest loginRequest;

    @BeforeEach
    void setUp() {
        testAdmin = new Admin();
        testAdmin.setId(1L);
        testAdmin.setUsername("admin");
        testAdmin.setPassword("$2a$10$encodedPassword");

        testCustomer = new Customer();
        testCustomer.setId(1L);
        testCustomer.setName("John Doe");
        testCustomer.setEmail("john@example.com");
        testCustomer.setPassword("$2a$10$encodedPassword");
        testCustomer.setIsActive(true);

        loginRequest = new LoginRequest();
        loginRequest.setUsername("admin");
        loginRequest.setPassword("admin123");
    }

    @Test
    void testAdminLogin_Success() {
        // Arrange
        when(adminRepository.findByUsername("admin")).thenReturn(Optional.of(testAdmin));
        when(passwordEncoder.matches("admin123", testAdmin.getPassword())).thenReturn(true);
        when(jwtUtil.generateToken("admin", "ADMIN")).thenReturn("mockJwtToken");

        // Act
        LoginResponse response = authService.adminLogin(loginRequest);

        // Assert
        assertNotNull(response);
        assertTrue(response.isSuccess());
        assertEquals("Login successful", response.getMessage());
        assertEquals(1L, response.getUserId());
        assertEquals("admin", response.getUsername());
        assertEquals("ADMIN", response.getRole());
        assertEquals("mockJwtToken", response.getToken());

        verify(adminRepository, times(1)).findByUsername("admin");
        verify(passwordEncoder, times(1)).matches("admin123", testAdmin.getPassword());
        verify(jwtUtil, times(1)).generateToken("admin", "ADMIN");
    }

    @Test
    void testAdminLogin_InvalidUsername() {
        // Arrange
        when(adminRepository.findByUsername("wrongadmin")).thenReturn(Optional.empty());

        loginRequest.setUsername("wrongadmin");

        // Act
        LoginResponse response = authService.adminLogin(loginRequest);

        // Assert
        assertNotNull(response);
        assertFalse(response.isSuccess());
        assertEquals("Please Enter Correct UserName and Password", response.getMessage());
        assertNull(response.getUserId());
        assertNull(response.getToken());

        verify(adminRepository, times(1)).findByUsername("wrongadmin");
        verify(passwordEncoder, never()).matches(anyString(), anyString());
    }

    @Test
    void testAdminLogin_InvalidPassword() {
        // Arrange
        when(adminRepository.findByUsername("admin")).thenReturn(Optional.of(testAdmin));
        when(passwordEncoder.matches("wrongpassword", testAdmin.getPassword())).thenReturn(false);

        loginRequest.setPassword("wrongpassword");

        // Act
        LoginResponse response = authService.adminLogin(loginRequest);

        // Assert
        assertNotNull(response);
        assertFalse(response.isSuccess());
        assertEquals("Please Enter Correct UserName and Password", response.getMessage());

        verify(passwordEncoder, times(1)).matches("wrongpassword", testAdmin.getPassword());
        verify(jwtUtil, never()).generateToken(anyString(), anyString());
    }

    @Test
    void testCustomerLogin_Success() {
        // Arrange
        loginRequest.setUsername("john@example.com");
        loginRequest.setPassword("password123");

        when(customerRepository.findByEmail("john@example.com")).thenReturn(Optional.of(testCustomer));
        when(passwordEncoder.matches("password123", testCustomer.getPassword())).thenReturn(true);
        when(jwtUtil.generateToken("john@example.com", "CUSTOMER")).thenReturn("mockJwtToken");

        // Act
        LoginResponse response = authService.customerLogin(loginRequest);

        // Assert
        assertNotNull(response);
        assertTrue(response.isSuccess());
        assertEquals("Login successful", response.getMessage());
        assertEquals(1L, response.getUserId());
        assertEquals("John Doe", response.getUsername());
        assertEquals("CUSTOMER", response.getRole());
        assertEquals("mockJwtToken", response.getToken());

        verify(customerRepository, times(1)).findByEmail("john@example.com");
        verify(passwordEncoder, times(1)).matches("password123", testCustomer.getPassword());
        verify(jwtUtil, times(1)).generateToken("john@example.com", "CUSTOMER");
    }

    @Test
    void testCustomerLogin_AccountDeactivated() {
        // Arrange
        testCustomer.setIsActive(false);
        loginRequest.setUsername("john@example.com");

        when(customerRepository.findByEmail("john@example.com")).thenReturn(Optional.of(testCustomer));

        // Act
        LoginResponse response = authService.customerLogin(loginRequest);

        // Assert
        assertNotNull(response);
        assertFalse(response.isSuccess());
        assertEquals("Account is deactivated", response.getMessage());

        verify(customerRepository, times(1)).findByEmail("john@example.com");
        verify(passwordEncoder, never()).matches(anyString(), anyString());
    }

    @Test
    void testCustomerLogin_InvalidEmail() {
        // Arrange
        loginRequest.setUsername("wrong@example.com");

        when(customerRepository.findByEmail("wrong@example.com")).thenReturn(Optional.empty());

        // Act
        LoginResponse response = authService.customerLogin(loginRequest);

        // Assert
        assertNotNull(response);
        assertFalse(response.isSuccess());
        assertEquals("Please Enter Correct UserName and Password", response.getMessage());

        verify(customerRepository, times(1)).findByEmail("wrong@example.com");
    }

    @Test
    void testCustomerLogin_InvalidPassword() {
        // Arrange
        loginRequest.setUsername("john@example.com");
        loginRequest.setPassword("wrongpassword");

        when(customerRepository.findByEmail("john@example.com")).thenReturn(Optional.of(testCustomer));
        when(passwordEncoder.matches("wrongpassword", testCustomer.getPassword())).thenReturn(false);

        // Act
        LoginResponse response = authService.customerLogin(loginRequest);

        // Assert
        assertNotNull(response);
        assertFalse(response.isSuccess());
        assertEquals("Please Enter Correct UserName and Password", response.getMessage());

        verify(passwordEncoder, times(1)).matches("wrongpassword", testCustomer.getPassword());
        verify(jwtUtil, never()).generateToken(anyString(), anyString());
    }
}

