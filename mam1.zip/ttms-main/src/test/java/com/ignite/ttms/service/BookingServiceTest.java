package com.ignite.ttms.service;

import com.ignite.ttms.dto.BookingRequest;
import com.ignite.ttms.dto.BookingResponse;
import com.ignite.ttms.dto.CancellationRequest;
import com.ignite.ttms.entity.Booking;
import com.ignite.ttms.entity.Customer;
import com.ignite.ttms.entity.Train;
import com.ignite.ttms.repository.BookingRepository;
import com.ignite.ttms.repository.CustomerRepository;
import com.ignite.ttms.repository.TrainRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BookingServiceTest {

    @Mock
    private BookingRepository bookingRepository;

    @Mock
    private CustomerRepository customerRepository;

    @Mock
    private TrainRepository trainRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private BookingService bookingService;

    private Customer testCustomer;
    private Train testTrain;
    private BookingRequest bookingRequest;
    private Booking testBooking;

    @BeforeEach
    void setUp() {
        // Setup test customer
        testCustomer = new Customer();
        testCustomer.setId(1L);
        testCustomer.setName("John Doe");
        testCustomer.setEmail("john@example.com");
        testCustomer.setPassword("$2a$10$encodedPassword");
        testCustomer.setIsActive(true);

        // Setup test train
        testTrain = new Train();
        testTrain.setId(1L);
        testTrain.setTrainNumber("12345");
        testTrain.setTrainName("Express Train");
        testTrain.setOriginStation("Mumbai");
        testTrain.setDestinationStation("Delhi");
        testTrain.setDepartureTime(LocalDateTime.now().plusDays(5));
        testTrain.setArrivalTime(LocalDateTime.now().plusDays(5).plusHours(12));
        testTrain.setSleeperSeats(100);
        testTrain.setAcSeats(50);
        testTrain.setAvailableSleeperSeats(100);
        testTrain.setAvailableAcSeats(50);
        testTrain.setSleeperFare(500.0);
        testTrain.setAcFare(1000.0);

        // Setup booking request
        bookingRequest = new BookingRequest();
        bookingRequest.setCustomerId(1L);
        bookingRequest.setTrainNumber("12345");
        bookingRequest.setOriginStation("Mumbai");
        bookingRequest.setDestinationStation("Delhi");
        bookingRequest.setTravelDate(LocalDate.now().plusDays(5));
        bookingRequest.setTravelClass("SLEEPER");
        bookingRequest.setNumberOfSeats(2);

        // Setup test booking
        testBooking = new Booking();
        testBooking.setId(1L);
        testBooking.setTicketId("TKT12345678");
        testBooking.setCustomer(testCustomer);
        testBooking.setTrain(testTrain);
        testBooking.setOriginStation("Mumbai");
        testBooking.setDestinationStation("Delhi");
        testBooking.setTravelDate(LocalDate.now().plusDays(5));
        testBooking.setTravelClass("SLEEPER");
        testBooking.setNumberOfSeats(2);
        testBooking.setTotalFare(1000.0);
        testBooking.setStatus(Booking.BookingStatus.CONFIRMED);
        testBooking.setBookingDateTime(LocalDateTime.now());
    }

    @Test
    void testBookTicket_Success() {
        // Arrange
        when(customerRepository.findById(1L)).thenReturn(Optional.of(testCustomer));
        when(trainRepository.findByTrainNumber("12345")).thenReturn(Optional.of(testTrain));
        when(bookingRepository.save(any(Booking.class))).thenReturn(testBooking);

        // Act
        BookingResponse response = bookingService.bookTicket(bookingRequest);

        // Assert
        assertNotNull(response);
        assertEquals("TKT12345678", response.getTicketId());
        assertEquals(1L, response.getCustomerId());
        assertEquals("John Doe", response.getCustomerName());
        assertEquals("12345", response.getTrainNumber());
        assertEquals(2, response.getNumberOfSeats());
        assertEquals(1000.0, response.getTotalFare());
        assertEquals(Booking.BookingStatus.CONFIRMED, response.getStatus());

        verify(customerRepository, times(1)).findById(1L);
        verify(trainRepository, times(1)).findByTrainNumber("12345");
        verify(bookingRepository, times(1)).save(any(Booking.class));
        verify(trainRepository, times(1)).save(any(Train.class));
    }

    @Test
    void testBookTicket_CustomerNotFound() {
        // Arrange
        when(customerRepository.findById(1L)).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            bookingService.bookTicket(bookingRequest);
        });

        assertEquals("Customer not found", exception.getMessage());
        verify(customerRepository, times(1)).findById(1L);
        verify(trainRepository, never()).findByTrainNumber(anyString());
    }

    @Test
    void testBookTicket_CustomerDeactivated() {
        // Arrange
        testCustomer.setIsActive(false);
        when(customerRepository.findById(1L)).thenReturn(Optional.of(testCustomer));

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            bookingService.bookTicket(bookingRequest);
        });

        assertEquals("Customer account is deactivated", exception.getMessage());
        verify(customerRepository, times(1)).findById(1L);
    }

    @Test
    void testBookTicket_TrainNotFound() {
        // Arrange
        when(customerRepository.findById(1L)).thenReturn(Optional.of(testCustomer));
        when(trainRepository.findByTrainNumber("12345")).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            bookingService.bookTicket(bookingRequest);
        });

        assertEquals("Train not found", exception.getMessage());
        verify(trainRepository, times(1)).findByTrainNumber("12345");
    }

    @Test
    void testBookTicket_InsufficientSleeperSeats() {
        // Arrange
        testTrain.setAvailableSleeperSeats(1);
        when(customerRepository.findById(1L)).thenReturn(Optional.of(testCustomer));
        when(trainRepository.findByTrainNumber("12345")).thenReturn(Optional.of(testTrain));

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            bookingService.bookTicket(bookingRequest);
        });

        assertEquals("Insufficient sleeper seats available", exception.getMessage());
    }

    @Test
    void testBookTicket_InsufficientACSeats() {
        // Arrange
        bookingRequest.setTravelClass("AC");
        testTrain.setAvailableAcSeats(1);
        when(customerRepository.findById(1L)).thenReturn(Optional.of(testCustomer));
        when(trainRepository.findByTrainNumber("12345")).thenReturn(Optional.of(testTrain));

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            bookingService.bookTicket(bookingRequest);
        });

        assertEquals("Insufficient AC seats available", exception.getMessage());
    }

    @Test
    void testBookTicket_InvalidTravelClass() {
        // Arrange
        bookingRequest.setTravelClass("FIRST_CLASS");
        when(customerRepository.findById(1L)).thenReturn(Optional.of(testCustomer));
        when(trainRepository.findByTrainNumber("12345")).thenReturn(Optional.of(testTrain));

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            bookingService.bookTicket(bookingRequest);
        });

        assertEquals("Invalid travel class", exception.getMessage());
    }

    @Test
    void testCancelTicket_Success() {
        // Arrange
        CancellationRequest cancellationRequest = new CancellationRequest();
        cancellationRequest.setTicketId("TKT12345678");
        cancellationRequest.setPassword("password123");
        cancellationRequest.setCustomerId(1L);

        when(bookingRepository.findByTicketId("TKT12345678")).thenReturn(Optional.of(testBooking));
        when(passwordEncoder.matches("password123", testCustomer.getPassword())).thenReturn(true);
        when(bookingRepository.save(any(Booking.class))).thenReturn(testBooking);

        // Act
        String result = bookingService.cancelTicket(cancellationRequest);

        // Assert
        assertNotNull(result);
        assertTrue(result.contains("cancelled successfully"));
        verify(bookingRepository, times(1)).findByTicketId("TKT12345678");
        verify(passwordEncoder, times(1)).matches("password123", testCustomer.getPassword());
        verify(bookingRepository, times(1)).save(any(Booking.class));
        verify(trainRepository, times(1)).save(any(Train.class));
    }

    @Test
    void testCancelTicket_TicketNotFound() {
        // Arrange
        CancellationRequest cancellationRequest = new CancellationRequest();
        cancellationRequest.setTicketId("INVALID");
        cancellationRequest.setPassword("password123");
        cancellationRequest.setCustomerId(1L);

        when(bookingRepository.findByTicketId("INVALID")).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            bookingService.cancelTicket(cancellationRequest);
        });

        assertEquals("Ticket not found", exception.getMessage());
        verify(bookingRepository, times(1)).findByTicketId("INVALID");
    }

    @Test
    void testCancelTicket_UnauthorizedCustomer() {
        // Arrange
        CancellationRequest cancellationRequest = new CancellationRequest();
        cancellationRequest.setTicketId("TKT12345678");
        cancellationRequest.setPassword("password123");
        cancellationRequest.setCustomerId(999L);

        when(bookingRepository.findByTicketId("TKT12345678")).thenReturn(Optional.of(testBooking));

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            bookingService.cancelTicket(cancellationRequest);
        });

        assertEquals("Unauthorized: Ticket does not belong to this customer", exception.getMessage());
    }

    @Test
    void testCancelTicket_InvalidPassword() {
        // Arrange
        CancellationRequest cancellationRequest = new CancellationRequest();
        cancellationRequest.setTicketId("TKT12345678");
        cancellationRequest.setPassword("wrongpassword");
        cancellationRequest.setCustomerId(1L);

        when(bookingRepository.findByTicketId("TKT12345678")).thenReturn(Optional.of(testBooking));
        when(passwordEncoder.matches("wrongpassword", testCustomer.getPassword())).thenReturn(false);

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            bookingService.cancelTicket(cancellationRequest);
        });

        assertEquals("Invalid password", exception.getMessage());
    }

    @Test
    void testCancelTicket_AlreadyCancelled() {
        // Arrange
        testBooking.setStatus(Booking.BookingStatus.CANCELLED);
        CancellationRequest cancellationRequest = new CancellationRequest();
        cancellationRequest.setTicketId("TKT12345678");
        cancellationRequest.setPassword("password123");
        cancellationRequest.setCustomerId(1L);

        when(bookingRepository.findByTicketId("TKT12345678")).thenReturn(Optional.of(testBooking));
        when(passwordEncoder.matches("password123", testCustomer.getPassword())).thenReturn(true);

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            bookingService.cancelTicket(cancellationRequest);
        });

        assertEquals("Ticket is already cancelled", exception.getMessage());
    }

    @Test
    void testGetBookingHistory_Success() {
        // Arrange
        List<Booking> bookings = new ArrayList<>();
        bookings.add(testBooking);

        when(customerRepository.findById(1L)).thenReturn(Optional.of(testCustomer));
        when(bookingRepository.findByCustomerOrderByBookingDateTimeDesc(testCustomer)).thenReturn(bookings);

        // Act
        List<BookingResponse> result = bookingService.getBookingHistory(1L);

        // Assert
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("TKT12345678", result.get(0).getTicketId());
        verify(customerRepository, times(1)).findById(1L);
        verify(bookingRepository, times(1)).findByCustomerOrderByBookingDateTimeDesc(testCustomer);
    }

    @Test
    void testGetBookingHistory_CustomerNotFound() {
        // Arrange
        when(customerRepository.findById(1L)).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            bookingService.getBookingHistory(1L);
        });

        assertEquals("Customer not found", exception.getMessage());
    }

    @Test
    void testGetBookingByTicketId_Success() {
        // Arrange
        when(bookingRepository.findByTicketId("TKT12345678")).thenReturn(Optional.of(testBooking));

        // Act
        BookingResponse result = bookingService.getBookingByTicketId("TKT12345678");

        // Assert
        assertNotNull(result);
        assertEquals("TKT12345678", result.getTicketId());
        assertEquals(1L, result.getCustomerId());
        verify(bookingRepository, times(1)).findByTicketId("TKT12345678");
    }

    @Test
    void testGetBookingByTicketId_NotFound() {
        // Arrange
        when(bookingRepository.findByTicketId("INVALID")).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            bookingService.getBookingByTicketId("INVALID");
        });

        assertEquals("Ticket not found", exception.getMessage());
    }
}

