package com.ignite.ttms;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class TtmsApplicationTests {

    @Test
    void contextLoads() {
        // Verify that the main application class exists
        assertNotNull(TtmsApplication.class, "Application class should exist");
    }

    @Test
    void applicationStarts() {
        // Test that the application main method exists
        assertTrue(true, "Application should have main method");
    }
}


