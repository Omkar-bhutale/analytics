import React, { useState, useEffect } from 'react';
import { getTrainOccupancyReport, getTrainRevenueReport } from '../services/api';
import '../index.css';

function AdminReports() {
    const [activeTab, setActiveTab] = useState('occupancy');
    const [occupancyData, setOccupancyData] = useState([]);
    const [revenueData, setRevenueData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    useEffect(() => {
        if (activeTab === 'occupancy') {
            fetchOccupancyReport();
        } else {
            fetchRevenueReport();
        }
    }, [activeTab]);

    const fetchOccupancyReport = async () => {
        try {
            setLoading(true);
            setError('');
            const data = await getTrainOccupancyReport();
            setOccupancyData(data);
        } catch (err) {
            setError(err.message || 'Failed to fetch occupancy report');
        } finally {
            setLoading(false);
        }
    };

    const fetchRevenueReport = async () => {
        try {
            setLoading(true);
            setError('');
            const data = await getTrainRevenueReport();
            setRevenueData(data);
        } catch (err) {
            setError(err.message || 'Failed to fetch revenue report');
        } finally {
            setLoading(false);
        }
    };

    const formatDateTime = (dateTime) => {
        if (!dateTime) return 'N/A';
        return new Date(dateTime).toLocaleString('en-IN', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    const formatCurrency = (amount) => {
        return new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: 'INR',
            minimumFractionDigits: 0
        }).format(amount || 0);
    };

    const getOccupancyColor = (percentage) => {
        if (percentage >= 80) return 'occupancy-high';
        if (percentage >= 50) return 'occupancy-medium';
        return 'occupancy-low';
    };

    return (
        <div className="container">
            <div className="page-header">
                <h2>Admin Reports</h2>
                <p>View train occupancy and revenue statistics</p>
            </div>

            <div className="tabs">
                <button
                    className={`tab ${activeTab === 'occupancy' ? 'active' : ''}`}
                    onClick={() => setActiveTab('occupancy')}
                >
                    Train Occupancy
                </button>
                <button
                    className={`tab ${activeTab === 'revenue' ? 'active' : ''}`}
                    onClick={() => setActiveTab('revenue')}
                >
                    Revenue Report
                </button>
            </div>

            {error && <div className="error-message">{error}</div>}

            {loading ? (
                <div className="loading">Loading report...</div>
            ) : (
                <>
                    {activeTab === 'occupancy' && (
                        <div className="report-container">
                            <div className="report-header">
                                <h3>Train Occupancy Report</h3>
                                <p>Real-time seat occupancy for all trains</p>
                            </div>

                            {occupancyData.length === 0 ? (
                                <div className="no-data">No trains available</div>
                            ) : (
                                <div className="table-responsive">
                                    <table className="report-table">
                                        <thead>
                                            <tr>
                                                <th>Train Number</th>
                                                <th>Train Name</th>
                                                <th>Route</th>
                                                <th>Departure</th>
                                                <th>Sleeper Seats</th>
                                                <th>Sleeper Occupancy</th>
                                                <th>AC Seats</th>
                                                <th>AC Occupancy</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {occupancyData.map((train) => (
                                                <tr key={train.trainId}>
                                                    <td className="train-number">{train.trainNumber}</td>
                                                    <td className="train-name">{train.trainName}</td>
                                                    <td>
                                                        <div className="route">
                                                            <span>{train.originStation}</span>
                                                            <span className="arrow">→</span>
                                                            <span>{train.destinationStation}</span>
                                                        </div>
                                                    </td>
                                                    <td>{formatDateTime(train.departureTime)}</td>
                                                    <td>
                                                        <div className="seat-info">
                                                            <span className="booked">{train.bookedSleeperSeats}</span>
                                                            <span>/</span>
                                                            <span className="total">{train.sleeperSeats}</span>
                                                            <span className="available">
                                                                ({train.availableSleeperSeats} available)
                                                            </span>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div className={`occupancy-bar ${getOccupancyColor(train.sleeperOccupancyPercentage)}`}>
                                                            <div
                                                                className="occupancy-fill"
                                                                style={{ width: `${train.sleeperOccupancyPercentage}%` }}
                                                            />
                                                            <span className="occupancy-text">
                                                                {train.sleeperOccupancyPercentage?.toFixed(1)}%
                                                            </span>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div className="seat-info">
                                                            <span className="booked">{train.bookedAcSeats}</span>
                                                            <span>/</span>
                                                            <span className="total">{train.acSeats}</span>
                                                            <span className="available">
                                                                ({train.availableAcSeats} available)
                                                            </span>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div className={`occupancy-bar ${getOccupancyColor(train.acOccupancyPercentage)}`}>
                                                            <div
                                                                className="occupancy-fill"
                                                                style={{ width: `${train.acOccupancyPercentage}%` }}
                                                            />
                                                            <span className="occupancy-text">
                                                                {train.acOccupancyPercentage?.toFixed(1)}%
                                                            </span>
                                                        </div>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            )}
                        </div>
                    )}

                    {activeTab === 'revenue' && (
                        <div className="report-container">
                            <div className="report-header">
                                <h3>Train Revenue Report</h3>
                                <p>Booking statistics and revenue for all trains</p>
                            </div>

                            {revenueData.length === 0 ? (
                                <div className="no-data">No trains available</div>
                            ) : (
                                <>
                                    <div className="summary-cards">
                                        <div className="summary-card">
                                            <h4>Total Bookings</h4>
                                            <p className="summary-value">
                                                {revenueData.reduce((sum, t) => sum + t.totalBookings, 0)}
                                            </p>
                                        </div>
                                        <div className="summary-card">
                                            <h4>Confirmed Bookings</h4>
                                            <p className="summary-value confirmed">
                                                {revenueData.reduce((sum, t) => sum + t.confirmedBookings, 0)}
                                            </p>
                                        </div>
                                        <div className="summary-card">
                                            <h4>Cancelled Bookings</h4>
                                            <p className="summary-value cancelled">
                                                {revenueData.reduce((sum, t) => sum + t.cancelledBookings, 0)}
                                            </p>
                                        </div>
                                        <div className="summary-card revenue">
                                            <h4>Total Revenue</h4>
                                            <p className="summary-value">
                                                {formatCurrency(revenueData.reduce((sum, t) => sum + t.totalRevenue, 0))}
                                            </p>
                                        </div>
                                    </div>

                                    <div className="table-responsive">
                                        <table className="report-table">
                                            <thead>
                                                <tr>
                                                    <th>Train Number</th>
                                                    <th>Train Name</th>
                                                    <th>Route</th>
                                                    <th>Total Bookings</th>
                                                    <th>Confirmed</th>
                                                    <th>Cancelled</th>
                                                    <th>Seats Booked</th>
                                                    <th>Revenue</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {revenueData.map((train) => (
                                                    <tr key={train.trainId}>
                                                        <td className="train-number">{train.trainNumber}</td>
                                                        <td className="train-name">{train.trainName}</td>
                                                        <td>
                                                            <div className="route">
                                                                <span>{train.originStation}</span>
                                                                <span className="arrow">→</span>
                                                                <span>{train.destinationStation}</span>
                                                            </div>
                                                        </td>
                                                        <td>{train.totalBookings}</td>
                                                        <td className="confirmed">{train.confirmedBookings}</td>
                                                        <td className="cancelled">{train.cancelledBookings}</td>
                                                        <td>{train.totalSeatsBooked}</td>
                                                        <td className="revenue">{formatCurrency(train.totalRevenue)}</td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </>
                            )}
                        </div>
                    )}
                </>
            )}
        </div>
    );
}

export default AdminReports;

