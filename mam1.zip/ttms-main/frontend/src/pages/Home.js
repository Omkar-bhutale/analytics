import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div className="page">
      <div className="container">
        <div className="hero">
          <h1>Welcome to TTMS</h1>
          <p>Your complete solution for train ticket booking and management</p>
          <Link to="/search-trains">
            <button className="btn btn-primary">Search Trains</button>
          </Link>
        </div>

        <div className="card">
          <h2>Features</h2>
          <div className="train-details">
            <div className="detail-item">
              <div className="detail-label">🚂 Search Trains</div>
              <div className="detail-value">Find trains between any stations</div>
            </div>
            <div className="detail-item">
              <div className="detail-label">🎫 Book Tickets</div>
              <div className="detail-value">Easy and secure booking</div>
            </div>
            <div className="detail-item">
              <div className="detail-label">📱 Manage Bookings</div>
              <div className="detail-value">View and cancel bookings</div>
            </div>
            <div className="detail-item">
              <div className="detail-label">👤 User Profile</div>
              <div className="detail-value">Manage your account</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;

