# TTMS Frontend - React Application

Complete React frontend for the Train Ticket Management System with JWT authentication.

## Features

- 🔐 **JWT Authentication** - Secure login for customers and admins
- 🚂 **Train Search** - Search trains between stations
- 🎫 **Booking Management** - Book tickets and view/cancel bookings
- 👤 **User Profile** - Manage customer profile
- 🛠️ **Admin Panel** - Manage trains and customers
- 📱 **Responsive Design** - Works on all devices

## Tech Stack

- React 18
- React Router v6
- Axios for API calls
- React Toastify for notifications
- Context API for state management

## Prerequisites

- Node.js (v14 or higher)
- npm or yarn
- Backend server running on http://localhost:8080

## Installation

1. Navigate to the frontend directory:
```bash
cd frontend
```

2. Install dependencies:
```bash
npm install
```

## Running the Application

1. Start the development server:
```bash
npm start
```

2. The application will open in your browser at `http://localhost:3000`

## Building for Production

Create an optimized production build:
```bash
npm run build
```

The build files will be in the `build` directory.

## Project Structure

```
frontend/
├── public/
│   └── index.html
├── src/
│   ├── components/
│   │   ├── Navbar.js          # Navigation bar
│   │   └── PrivateRoute.js    # Protected route wrapper
│   ├── context/
│   │   └── AuthContext.js     # Authentication context
│   ├── pages/
│   │   ├── Home.js            # Landing page
│   │   ├── Login.js           # Login page (Admin/Customer)
│   │   ├── Register.js        # Customer registration
│   │   ├── SearchTrains.js    # Search and book trains
│   │   ├── MyBookings.js      # View customer bookings
│   │   ├── Profile.js         # Customer profile management
│   │   ├── AdminTrains.js     # Admin train management
│   │   └── AdminCustomers.js  # Admin customer management
│   ├── services/
│   │   └── api.js             # API service layer
│   ├── App.js                 # Main app component
│   ├── index.js               # Entry point
│   └── index.css              # Global styles
└── package.json
```

## Available Routes

### Public Routes
- `/` - Home page
- `/login` - Login page
- `/register` - Customer registration
- `/search-trains` - Search trains (booking requires login)

### Customer Routes (Protected)
- `/my-bookings` - View and manage bookings
- `/profile` - Update profile

### Admin Routes (Protected)
- `/admin/trains` - Manage trains (add, edit, delete)
- `/admin/customers` - Manage customers (activate/deactivate)

## Default Admin Credentials

- **Username:** admin
- **Password:** admin123

## API Integration

The frontend connects to the backend API at `http://localhost:8080/api`

All API endpoints are configured in `src/services/api.js`:
- Authentication APIs
- Customer APIs
- Train APIs
- Booking APIs

## Features by User Role

### Customer Features
1. Register new account
2. Login with email and password
3. Search trains by origin and destination
4. Book train tickets (Sleeper/AC)
5. View booking history
6. Cancel bookings
7. Update profile information

### Admin Features
1. Login with admin credentials
2. Add new trains
3. Edit existing trains
4. Delete trains
5. View all customers
6. Activate/Deactivate customer accounts

## State Management

Uses React Context API for:
- User authentication state
- JWT token management
- User role and permissions

## Error Handling

- Form validation
- API error messages
- Toast notifications for user feedback
- Automatic token refresh handling

## Styling

Custom CSS with:
- Gradient backgrounds
- Card-based layouts
- Responsive grid system
- Smooth animations
- Mobile-friendly design

## Environment Variables

Create a `.env` file if you need to change the API URL:
```
REACT_APP_API_URL=http://localhost:8080/api
```

## Troubleshooting

### Port already in use
If port 3000 is already in use, you can run on a different port:
```bash
PORT=3001 npm start
```

### CORS Issues
Make sure the backend has CORS enabled for `http://localhost:3000`

### API Connection Failed
Ensure the backend server is running on `http://localhost:8080`

## Development

To contribute to the frontend:

1. Follow React best practices
2. Use functional components with hooks
3. Keep components modular and reusable
4. Handle loading and error states
5. Add proper validation for forms

## License

MIT License

