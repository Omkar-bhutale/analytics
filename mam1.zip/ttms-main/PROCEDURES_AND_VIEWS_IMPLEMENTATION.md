# Database Procedures and Views Implementation Summary

## Overview
Successfully converted the TTMS application to use **stored procedures and views** in PostgreSQL. The implementation follows best practices by using:
- **Views** for SELECT queries (read operations)
- **Stored Procedures** only for complex operations with side effects
- **JPA's native methods** (save/update/delete) for simple CRUD operations

## Implementation Strategy

### 1. Views (for Read Operations)
Views are used for all SELECT queries to provide:
- Better performance through query optimization
- Centralized query logic
- Easier maintenance
- Security through data abstraction

**Created Views:**
- `vw_customer_by_email` - Customer lookup by email
- `vw_train_by_number` - Train lookup by train number
- `vw_trains_by_route` - Trains on specific routes
- `vw_booking_by_ticket_id` - Booking lookup by ticket ID
- `vw_bookings_by_customer` - Customer's booking history
- `vw_bookings_by_train` - Train's booking records
- `vw_admin_by_username` - Admin lookup
- `vw_customer_bookings_summary` - Customer statistics
- `vw_train_occupancy` - Train seat occupancy status
- `vw_booking_details` - Complete booking details with joins
- `vw_train_revenue` - Train revenue reports
- `vw_available_trains` - Available trains for booking

### 2. Stored Procedures (for Complex Operations)
Procedures are used only for operations that require:
- Multiple table updates
- Complex business logic
- Transaction management

**Created Procedures:**
- `sp_cancel_booking(p_booking_id)` - Cancels booking and restores seat availability atomically

### 3. JPA Methods (for Simple CRUD)
Standard JPA repository methods are used for:
- Creating customers, trains, bookings (save)
- Updating records (save)
- Deleting records (delete/soft delete with UPDATE)

## Repository Configuration

### CustomerRepository
```java
- findByEmail() → Uses vw_customer_by_email
- existsByEmail() → Direct SQL query
- save() → JPA method (INSERT/UPDATE)
- softDeleteCustomer() → Direct UPDATE query
```

### TrainRepository
```java
- findByTrainNumber() → Uses vw_train_by_number
- findByRoute() → Uses vw_trains_by_route
- existsByTrainNumber() → Direct SQL query
- save() → JPA method (INSERT/UPDATE)
- updateSleeperSeats() → Direct UPDATE query
- updateAcSeats() → Direct UPDATE query
- getTrainOccupancyReport() → Uses vw_train_occupancy
- getTrainRevenueReport() → Uses vw_train_revenue
```

### BookingRepository
```java
- findByTicketId() → Uses vw_booking_by_ticket_id
- findByCustomerOrderByBookingDateTimeDesc() → Uses vw_bookings_by_customer
- findByTrain() → Uses vw_bookings_by_train
- save() → JPA method (INSERT/UPDATE)
- cancelBookingProcedure() → Calls sp_cancel_booking procedure
- getBookingDetailsForCustomer() → Uses vw_booking_details
- getCustomerBookingsSummary() → Uses vw_customer_bookings_summary
```

### AdminRepository
```java
- findByUsername() → Uses vw_admin_by_username
```

## Benefits of This Approach

1. **Performance**: Views can be indexed and optimized by PostgreSQL
2. **Maintainability**: Business logic in one place (database)
3. **Security**: Views can restrict column access
4. **Consistency**: Procedures ensure atomic operations
5. **Simplicity**: JPA handles simple CRUD without complexity
6. **Flexibility**: Easy to add more views/procedures as needed

## Migration Scripts

### V0__Drop_Existing_Procedures.sql
Drops all existing procedures and views to ensure clean installation

### V1__Create_Procedures_And_Views.sql
Creates all views and the sp_cancel_booking procedure

## Testing
- ✅ Application compiles successfully
- ✅ All repositories configured correctly
- ✅ Views and procedures syntax validated
- ✅ Integration with existing service layer maintained

## Next Steps
1. Test the application with PostgreSQL database
2. Run the Flyway migrations
3. Verify all CRUD operations work correctly
4. Test the cancellation procedure
5. Run integration tests

## Database Setup Command
```bash
# Run migrations
./mvnw clean spring-boot:run

# Or manually run the SQL scripts in order:
# 1. V0__Drop_Existing_Procedures.sql
# 2. V1__Create_Procedures_And_Views.sql
```

## Notes
- The approach avoids OUT parameters complexity in Spring JPA
- Procedures are used sparingly only where they add value
- All table names and column names match the entity definitions
- Transaction management handled by Spring's @Transactional

