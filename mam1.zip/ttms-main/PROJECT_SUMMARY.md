# Train Ticket Management System - Project Summary

## ✅ What Has Been Created

This is a complete **REST API-based** Train Ticket Management System (not console-based).

### Project Structure Created

```
D:\TTMS\
├── src/main/java/com/ignite/ttms/
│   ├── TtmsApplication.java (Main Spring Boot Application)
│   │
│   ├── config/
│   │   └── DataInitializer.java (Creates default admin on startup)
│   │
│   ├── entity/ (Database Models)
│   │   ├── Admin.java
│   │   ├── Customer.java
│   │   ├── Train.java
│   │   └── Booking.java
│   │
│   ├── repository/ (Database Access Layer)
│   │   ├── AdminRepository.java
│   │   ├── CustomerRepository.java
│   │   ├── TrainRepository.java
│   │   └── BookingRepository.java
│   │
│   ├── dto/ (Request/Response Objects)
│   │   ├── LoginRequest.java
│   │   ├── LoginResponse.java
│   │   ├── CustomerRequest.java
│   │   ├── CustomerResponse.java
│   │   ├── TrainRequest.java
│   │   ├── TrainResponse.java
│   │   ├── TrainSearchRequest.java
│   │   ├── BookingRequest.java
│   │   ├── BookingResponse.java
│   │   └── CancellationRequest.java
│   │
│   ├── service/ (Business Logic Layer)
│   │   ├── AuthService.java
│   │   ├── CustomerService.java
│   │   ├── TrainService.java
│   │   └── BookingService.java
│   │
│   ├── controller/ (REST API Endpoints)
│   │   ├── AuthController.java
│   │   ├── CustomerController.java
│   │   ├── TrainController.java
│   │   ├── AdminTrainController.java
│   │   └── BookingController.java
│   │
│   └── exception/ (Error Handling)
│       ├── GlobalExceptionHandler.java
│       └── ErrorResponse.java
│
├── src/main/resources/
│   └── application.properties (Database & Server Configuration)
│
├── pom.xml (Maven Dependencies)
├── API_DOCUMENTATION.md (Complete API Documentation)
├── QUICK_START.md (Quick Start Guide)
└── TTMS_Postman_Collection.json (Postman Collection for Testing)
```

## 🔧 Technologies Used

- **Java 17**
- **Spring Boot 3.5.7**
- **Spring Data JPA** (Database operations)
- **Spring Web** (REST APIs)
- **H2 Database** (In-memory database)
- **Lombok** (Reduces boilerplate code)
- **Bean Validation** (Input validation)

## 🚀 How to Run

### Option 1: Using Maven Wrapper (Recommended)
```cmd
cd D:\TTMS
.\mvnw.cmd clean package -DskipTests
.\mvnw.cmd spring-boot:run
```

### Option 2: If Maven is installed globally
```cmd
cd D:\TTMS
mvn clean package -DskipTests
mvn spring-boot:run
```

The application will start at: **http://localhost:8080**

## 📋 Default Admin Account
- Username: `admin`
- Password: `admin123`
(Automatically created on first startup)

## 🎯 Complete API Features

### 1. Authentication APIs
- Admin Login
- Customer Login

### 2. Customer Management APIs
- Register Customer (with validation)
- Update Customer Profile
- Get Customer Details
- Deactivate Customer Account

### 3. Train Management APIs (Admin Only)
- Register New Train
- Update Train Details
- Delete Train (auto-cancels bookings)
- View All Trains
- Get Train by Number

### 4. Train Search APIs (Public)
- Search Trains by Route
- Get All Trains
- Get Train Details by Number

### 5. Booking Management APIs
- Book Tickets (1-6 seats per booking)
- Cancel Tickets (24-hour rule)
- View Booking History
- Get Booking by Ticket ID

## 🔐 Business Rules Implemented

### Customer Registration
✅ Unique email validation
✅ Phone number must be 10 digits
✅ Name validation (no special characters)
✅ All fields required

### Train Management
✅ Unique train number
✅ No schedule conflicts allowed
✅ Automatic seat availability tracking
✅ Deleting train cancels all bookings

### Ticket Booking
✅ Maximum 6 seats per booking
✅ Travel date within 3 months
✅ Seat availability check
✅ Automatic fare calculation
✅ Unique ticket ID generation
✅ Active customer account required

### Ticket Cancellation
✅ Must be 24 hours before departure
✅ Password verification required
✅ Automatic seat release
✅ Refund policy message

## 📊 Database Schema

### Tables Created Automatically:
1. **admins** - Admin user accounts
2. **customers** - Customer accounts
3. **trains** - Train information
4. **bookings** - Ticket bookings
5. **train_intermediate_stops** - Train stops (related to trains)

## 🧪 Testing the API

### Using Postman:
1. Import `TTMS_Postman_Collection.json` into Postman
2. All API endpoints are pre-configured
3. Start testing immediately

### Using cURL:
See examples in `QUICK_START.md`

### Using H2 Console:
1. Go to: http://localhost:8080/h2-console
2. JDBC URL: `jdbc:h2:mem:ttmsdb`
3. Username: `sa`
4. Password: (leave empty)
5. Click "Connect"

## 📖 Sample API Workflow

### Complete Booking Flow:

1. **Register Customer**
   ```
   POST /api/customers/register
   ```

2. **Admin Registers Train**
   ```
   POST /api/admin/trains
   ```

3. **Customer Searches Trains**
   ```
   POST /api/trains/search
   ```

4. **Customer Books Ticket**
   ```
   POST /api/bookings
   ```

5. **Customer Views Booking**
   ```
   GET /api/bookings/customer/{customerId}
   ```

6. **Customer Cancels Ticket** (if needed)
   ```
   POST /api/bookings/cancel
   ```

## ✨ Key Features

### Automatic Features:
- ✅ Default admin user creation
- ✅ Seat availability management
- ✅ Unique ticket ID generation
- ✅ Booking timestamp tracking
- ✅ Cancellation timestamp tracking

### Validation Features:
- ✅ Email format validation
- ✅ Phone number format validation
- ✅ Required field validation
- ✅ Date range validation
- ✅ Seat count validation (1-6)

### Error Handling:
- ✅ Global exception handler
- ✅ Validation error responses
- ✅ Custom error messages
- ✅ HTTP status codes

## 📁 Important Files

1. **API_DOCUMENTATION.md** - Complete API documentation with all endpoints
2. **QUICK_START.md** - Quick start guide with examples
3. **TTMS_Postman_Collection.json** - Postman collection for testing
4. **application.properties** - Database and server configuration
5. **pom.xml** - Maven dependencies

## 🔍 Next Steps

1. **Build the project:**
   ```
   cd D:\TTMS
   .\mvnw.cmd clean package -DskipTests
   ```

2. **Run the application:**
   ```
   .\mvnw.cmd spring-boot:run
   ```

3. **Test the APIs:**
   - Use Postman collection
   - Or use the H2 console
   - Or use cURL commands

4. **Access H2 Console:**
   - http://localhost:8080/h2-console
   - View and query database tables

## 🎉 What's Different from Console-based?

Instead of a console application with menu-driven interface, you now have:

- ✅ **RESTful APIs** that can be called from any client (web, mobile, etc.)
- ✅ **JSON-based** request and response
- ✅ **Stateless** communication
- ✅ **Scalable** architecture
- ✅ **Industry-standard** design
- ✅ **Easy integration** with frontend applications
- ✅ **Postman collection** for easy testing
- ✅ **Proper separation** of concerns (Controller → Service → Repository)

## 📝 Notes

- Database is **in-memory** (data is lost on restart)
- Passwords are stored in **plain text** (for demo purposes)
- No authentication tokens (use session/JWT in production)
- Perfect for learning and demonstration
- Can be easily extended with Spring Security, MySQL, etc.

---

**Your Train Ticket Management System API is ready to use!** 🚂🎫

