# Quick Reference: Stored Procedures & Views

## Direct SQL Usage (for testing in pgAdmin/psql)

### Customer Operations
```sql
-- Find customer by email
SELECT * FROM sp_find_customer_by_email('john@example.com');

-- Check if email exists
SELECT sp_customer_email_exists('john@example.com');

-- Create customer
SELECT sp_create_customer('John Doe', 'john@example.com', '9876543210', '123 Street', '$2a$10$hashedpassword');

-- Update customer
SELECT sp_update_customer(1, 'John Updated', 'john@example.com', '9876543210', '456 Avenue');

-- Soft delete customer
SELECT sp_delete_customer(1);
```

### Train Operations
```sql
-- Find train by number
SELECT * FROM sp_find_train_by_number('12345');

-- Check if train number exists
SELECT sp_train_number_exists('12345');

-- Find trains by route
SELECT * FROM sp_find_trains_by_route('Mumbai', 'Delhi');

-- Check schedule conflict
SELECT sp_check_schedule_conflict('Mumbai', 'Delhi', '2025-11-20 10:00:00', '2025-11-20 18:00:00', 1);

-- Create train
SELECT sp_create_train(
    '12345', 'Express Train', 'Mumbai', 'Delhi',
    '2025-11-20 10:00:00', '2025-11-20 18:00:00',
    100, 50, 500.00, 1000.00
);

-- Update train
SELECT sp_update_train(
    1, '12345', 'Express Train Updated', 'Mumbai', 'Delhi',
    '2025-11-20 10:00:00', '2025-11-20 18:00:00',
    100, 50, 500.00, 1000.00
);

-- Update seat availability (negative = book, positive = cancel)
SELECT sp_update_seat_availability(1, 'SLEEPER', -5);  -- Book 5 sleeper seats
SELECT sp_update_seat_availability(1, 'AC', 3);        -- Release 3 AC seats
```

### Booking Operations
```sql
-- Find booking by ticket ID
SELECT * FROM sp_find_booking_by_ticket_id('TKT12345678');

-- Find bookings by customer
SELECT * FROM sp_find_bookings_by_customer(1);

-- Find bookings by train
SELECT * FROM sp_find_bookings_by_train(1);

-- Create booking
SELECT sp_create_booking(
    'TKT12345678', 1, 1, 'Mumbai', 'Delhi',
    '2025-11-20', 'SLEEPER', 2, 1000.00
);

-- Cancel booking
SELECT sp_cancel_booking(1);
```

### Admin Operations
```sql
-- Find admin by username
SELECT * FROM sp_find_admin_by_username('admin');
```

## Views - Ready-to-Use Reports

### Customer Bookings Summary
```sql
-- All customers summary
SELECT * FROM vw_customer_bookings_summary;

-- Specific customer
SELECT * FROM vw_customer_bookings_summary WHERE customer_email = 'john@example.com';

-- Top customers by revenue
SELECT * FROM vw_customer_bookings_summary ORDER BY total_revenue DESC LIMIT 10;
```

### Train Occupancy
```sql
-- All trains occupancy
SELECT * FROM vw_train_occupancy;

-- Trains with high occupancy (>80%)
SELECT * FROM vw_train_occupancy 
WHERE sleeper_occupancy_percentage > 80 OR ac_occupancy_percentage > 80;

-- Specific train occupancy
SELECT * FROM vw_train_occupancy WHERE train_number = '12345';
```

### Train Revenue
```sql
-- All trains revenue
SELECT * FROM vw_train_revenue;

-- Top revenue generating trains
SELECT * FROM vw_train_revenue ORDER BY total_revenue DESC LIMIT 10;

-- Trains with low bookings
SELECT * FROM vw_train_revenue WHERE confirmed_bookings < 5;
```

### Booking Details
```sql
-- All booking details
SELECT * FROM vw_booking_details;

-- Customer's bookings
SELECT * FROM vw_booking_details WHERE customer_email = 'john@example.com';

-- Train's bookings
SELECT * FROM vw_booking_details WHERE train_number = '12345';

-- Recent bookings
SELECT * FROM vw_booking_details 
WHERE booking_date_time > CURRENT_TIMESTAMP - INTERVAL '7 days'
ORDER BY booking_date_time DESC;

-- Cancelled bookings
SELECT * FROM vw_booking_details WHERE status = 'CANCELLED';
```

### Available Trains
```sql
-- All available trains
SELECT * FROM vw_available_trains;

-- Available trains by route
SELECT * FROM vw_available_trains 
WHERE origin_station = 'Mumbai' AND destination_station = 'Delhi';

-- Trains with specific seat availability
SELECT * FROM vw_available_trains WHERE available_sleeper_seats >= 10;
```

## Java Repository Usage

### Customer Repository
```java
// Find by email
Optional<Customer> customer = customerRepository.findByEmail("john@example.com");

// Check if exists
boolean exists = customerRepository.existsByEmail("john@example.com");

// Create (if you add the method usage in service)
Long customerId = customerRepository.createCustomer(name, email, phone, address, password);

// Update (if you add the method usage in service)
customerRepository.updateCustomer(id, name, email, phone, address);

// Soft delete (if you add the method usage in service)
customerRepository.softDeleteCustomer(id);
```

### Train Repository
```java
// Find by train number
Optional<Train> train = trainRepository.findByTrainNumber("12345");

// Check if train number exists
boolean exists = trainRepository.existsByTrainNumber("12345");

// Find by route
List<Train> trains = trainRepository.findByRoute("Mumbai", "Delhi");

// Check schedule conflict
boolean conflict = trainRepository.existsScheduleConflict(origin, destination, departure, arrival, trainId);

// Get reports
List<Object[]> occupancy = trainRepository.getTrainOccupancyReport();
List<Object[]> revenue = trainRepository.getTrainRevenueReport();
List<Train> availableTrains = trainRepository.findAvailableTrainsByRoute("Mumbai", "Delhi");
```

### Booking Repository
```java
// Find by ticket ID
Optional<Booking> booking = bookingRepository.findByTicketId("TKT12345678");

// Find by customer
List<Booking> bookings = bookingRepository.findByCustomerOrderByBookingDateTimeDesc(customer);
// OR with customer ID
List<Booking> bookings = bookingRepository.findByCustomerOrderByBookingDateTimeDesc(customerId);

// Find by train
List<Booking> bookings = bookingRepository.findByTrain(train);
// OR with train ID
List<Booking> bookings = bookingRepository.findByTrain(trainId);

// Get reports
List<Object[]> customerDetails = bookingRepository.getBookingDetailsForCustomer(customerId);
List<Object[]> trainDetails = bookingRepository.getBookingDetailsForTrain(trainId);
List<Object[]> summary = bookingRepository.getCustomerBookingsSummary();
```

### Admin Repository
```java
// Find by username
Optional<Admin> admin = adminRepository.findByUsername("admin");
```

## Performance Tips

1. **Use Views for Reporting**: Views are faster than joins in application code
2. **Batch Operations**: Procedures handle multiple operations atomically
3. **Indexing**: Ensure indexes exist on frequently queried columns
4. **Connection Pooling**: Configure Hikari CP for optimal performance

## Common Patterns

### Pattern 1: Create and Retrieve
```sql
-- Create and get ID in one call
SELECT sp_create_booking(...) AS booking_id;

-- Then retrieve full details
SELECT * FROM vw_booking_details WHERE booking_id = <returned_id>;
```

### Pattern 2: Transactional Operations
```sql
-- Both operations are atomic within the procedure
BEGIN;
SELECT sp_create_booking(...);  -- Creates booking AND updates seats
COMMIT;
```

### Pattern 3: Reporting
```sql
-- Use views for complex reporting
SELECT 
    customer_name,
    total_revenue,
    confirmed_bookings
FROM vw_customer_bookings_summary
WHERE total_revenue > 10000
ORDER BY total_revenue DESC;
```

## Backup Procedures

### Export Procedures
```bash
pg_dump -U postgres -d postgres --schema-only --routines-only -f procedures_backup.sql
```

### Export Views
```bash
pg_dump -U postgres -d postgres --schema-only -t 'vw_*' -f views_backup.sql
```

### Full Backup
```bash
pg_dump -U postgres -d postgres -f full_backup.sql
```

## Maintenance

### Refresh Views (if needed for materialized views in future)
```sql
-- Currently all views are regular views (auto-refresh)
-- If we create materialized views later:
REFRESH MATERIALIZED VIEW vw_train_revenue;
```

### Monitor Performance
```sql
-- Check slow queries
SELECT * FROM pg_stat_statements 
WHERE query LIKE '%sp_%' 
ORDER BY mean_exec_time DESC;

-- Check view usage
SELECT * FROM pg_stat_user_tables 
WHERE schemaname = 'public' 
AND relname LIKE 'vw_%';
```

## Testing Checklist

- [ ] All customer procedures work
- [ ] All train procedures work
- [ ] All booking procedures work
- [ ] Admin procedures work
- [ ] All views return data
- [ ] Seat updates are atomic in bookings
- [ ] Cancellations restore seats correctly
- [ ] Views show accurate aggregated data

