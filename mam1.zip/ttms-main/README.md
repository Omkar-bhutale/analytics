# 🚂 TTMS - Train Ticket Management System

A comprehensive full-stack web application for train ticket booking and management with JWT authentication, built with Spring Boot and React.

[![Spring Boot](https://img.shields.io/badge/Spring%20Boot-3.5.7-brightgreen.svg)](https://spring.io/projects/spring-boot)
[![React](https://img.shields.io/badge/React-18.2.0-blue.svg)](https://reactjs.org/)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

## 📋 Overview

TTMS is a modern train ticket management system that allows customers to search trains, book tickets, and manage their bookings online. Administrators can manage trains and customer accounts through a dedicated admin panel.

## ✨ Features

### 🔐 Security
- JWT-based authentication
- Role-based access control (Admin/Customer)
- Secure password encryption with BCrypt
- Token-based API authorization

### 👥 Customer Features
- User registration with validation
- Secure login system
- Search trains by origin and destination
- Book tickets (Sleeper/AC class)
- View booking history with PNR
- Cancel bookings
- Update profile information

### 🛠️ Admin Features
- Admin dashboard
- Add, edit, and delete trains
- Manage train schedules and pricing
- View all customers
- Activate/Deactivate customer accounts
- Monitor booking statistics

### 🎨 User Interface
- Modern React-based frontend
- Responsive design for all devices
- Real-time notifications
- Intuitive navigation
- Professional UI/UX

## 🏗️ Architecture

### Backend (Spring Boot)
- **Framework:** Spring Boot 3.5.7
- **Security:** Spring Security + JWT
- **Database:** H2 (in-memory)
- **ORM:** Spring Data JPA
- **API Documentation:** Swagger/OpenAPI 3.0
- **Validation:** Bean Validation

### Frontend (React)
- **Framework:** React 18
- **Routing:** React Router v6
- **HTTP Client:** Axios
- **Notifications:** React Toastify
- **State Management:** Context API

## 🚀 Quick Start

### Prerequisites
- Java 17+
- Node.js 14+
- npm or yarn
- Git

### Installation

1. **Clone the repository:**
```bash
git clone https://github.com/Omkar-bhutale/ttms.git
cd ttms
```

2. **Start the Backend:**
```bash
.\mvnw.cmd spring-boot:run
```
Backend will run on `http://localhost:8080`

3. **Start the Frontend:**
```bash
cd frontend
npm install
npm start
```
Frontend will run on `http://localhost:3000`

4. **Access the Application:**
- **Application:** http://localhost:3000
- **Swagger API:** http://localhost:8080/swagger-ui.html
- **H2 Console:** http://localhost:8080/h2-console

## 🔑 Default Credentials

### Admin Login
- Username: `admin`
- Password: `admin123`

### Customer
Register a new account from the registration page.

## 📚 Documentation

- **[Complete Setup Guide](COMPLETE_SETUP_GUIDE.md)** - Detailed setup instructions
- **[API Documentation](API_DOCUMENTATION.md)** - Complete API reference
- **[Customer API Guide](CUSTOMER_REGISTRATION_API.md)** - Customer endpoints
- **[Frontend README](frontend/README.md)** - Frontend documentation

## 🗂️ Project Structure

```
TTMS/
├── frontend/                    # React frontend application
│   ├── src/
│   │   ├── components/         # Reusable components
│   │   ├── context/            # Context providers
│   │   ├── pages/              # Page components
│   │   ├── services/           # API services
│   │   └── index.css           # Global styles
│   └── package.json
├── src/
│   ├── main/
│   │   ├── java/com/ignite/ttms/
│   │   │   ├── config/         # Configuration classes
│   │   │   ├── controller/     # REST controllers
│   │   │   ├── dto/            # Data Transfer Objects
│   │   │   ├── entity/         # JPA entities
│   │   │   ├── repository/     # Repositories
│   │   │   ├── security/       # JWT security
│   │   │   └── service/        # Business logic
│   │   └── resources/
│   │       └── application.properties
│   └── test/
├── pom.xml
└── README.md
```

## 🔌 API Endpoints

### Authentication
- `POST /api/auth/customer/login` - Customer login
- `POST /api/auth/admin/login` - Admin login

### Customers
- `POST /api/customers/register` - Register new customer
- `GET /api/customers/{id}` - Get customer profile
- `PUT /api/customers/{id}` - Update profile
- `DELETE /api/customers/{id}` - Deactivate account

### Trains
- `POST /api/trains/search` - Search trains
- `GET /api/trains` - Get all trains
- `POST /api/admin/trains` - Add train (Admin)
- `PUT /api/admin/trains/{id}` - Update train (Admin)
- `DELETE /api/admin/trains/{id}` - Delete train (Admin)

### Bookings
- `POST /api/bookings` - Create booking
- `GET /api/bookings/customer/{customerId}` - Get customer bookings
- `POST /api/bookings/cancel` - Cancel booking

## 🛡️ Security

- JWT tokens for stateless authentication
- Password encryption using BCrypt
- Role-based access control
- CORS enabled for frontend
- Input validation on all endpoints
- SQL injection prevention with JPA

## 🧪 Testing

### Using Swagger UI
1. Navigate to `http://localhost:8080/swagger-ui.html`
2. Login via `/api/auth/customer/login` or `/api/auth/admin/login`
3. Copy the JWT token from response
4. Click "Authorize" button and enter: `Bearer <token>`
5. Test any endpoint

### Using the Frontend
1. Open `http://localhost:3000`
2. Register or login
3. Test all features through the UI

## 🗄️ Database

**H2 In-Memory Database:**
- JDBC URL: `jdbc:h2:mem:ttmsdb`
- Username: `sa`
- Password: (empty)
- Console: `http://localhost:8080/h2-console`

**Note:** Data is reset when the application restarts.

## 🎯 Future Enhancements

- [ ] Payment gateway integration
- [ ] Email notifications
- [ ] PDF ticket generation
- [ ] Real-time seat availability
- [ ] Multi-language support
- [ ] Mobile application
- [ ] PostgreSQL/MySQL integration
- [ ] Train tracking
- [ ] SMS notifications

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

This project is licensed under the MIT License.

## 👨‍💻 Author

**Omkar Bhutale**
- GitHub: [@Omkar-bhutale](https://github.com/Omkar-bhutale)

## 🙏 Acknowledgments

- Spring Boot Team
- React Community
- All contributors

---

**⭐ If you find this project useful, please give it a star!** - Train Ticket Management System

A complete REST API-based Train Ticket Management System built with Spring Boot, JPA, and H2 Database.

## Features
- ✅ RESTful API architecture
- ✅ Admin and Customer authentication
- ✅ Train management (CRUD operations)
- ✅ Ticket booking and cancellation
- ✅ Seat availability management
- ✅ Swagger/OpenAPI documentation
- ✅ H2 in-memory database
- ✅ Input validation and exception handling

## Technology Stack
- Java 17
- Spring Boot 3.5.7
- Spring Data JPA
- H2 Database
- Swagger/OpenAPI
- Lombok
- Maven

## Quick Start

### Prerequisites
- Java 17 or higher
- Maven

### Running the Application
```bash
# Clone the repository
git clone https://github.com/Omkar-bhutale/ttms.git
cd ttms

# Build and run
.\mvnw.cmd clean package -DskipTests
.\mvnw.cmd spring-boot:run
```

The application will start at: **http://localhost:8080**

## API Documentation

### Swagger UI
Once the application is running, access the interactive API documentation at:
- **Swagger UI**: http://localhost:8080/swagger-ui.html
- **API Docs**: http://localhost:8080/api-docs

### H2 Database Console
- **URL**: http://localhost:8080/h2-console
- **JDBC URL**: `jdbc:h2:mem:ttmsdb`
- **Username**: `sa`
- **Password**: (leave empty)

## Default Credentials
- **Admin Login**
  - Username: `admin`
  - Password: `admin123`

## API Endpoints

### Authentication
- `POST /api/auth/admin/login` - Admin login
- `POST /api/auth/customer/login` - Customer login

### Customer Management
- `POST /api/customers/register` - Register new customer
- `GET /api/customers/{id}` - Get customer details
- `PUT /api/customers/{id}` - Update customer
- `DELETE /api/customers/{id}` - Deactivate customer

### Train Management (Admin)
- `POST /api/admin/trains` - Register new train
- `GET /api/admin/trains` - Get all trains
- `PUT /api/admin/trains/{trainNumber}` - Update train
- `DELETE /api/admin/trains/{trainNumber}` - Delete train

### Train Search (Public)
- `POST /api/trains/search` - Search trains by route
- `GET /api/trains` - Get all trains

### Booking Management
- `POST /api/bookings` - Book ticket
- `POST /api/bookings/cancel` - Cancel ticket
- `GET /api/bookings/customer/{customerId}` - Get booking history

## Project Structure
```
src/main/java/com/ignite/ttms/
├── config/          # Configuration classes
├── controller/      # REST API controllers
├── dto/            # Data Transfer Objects
├── entity/         # JPA entities
├── exception/      # Exception handlers
├── repository/     # Data access layer
└── service/        # Business logic layer
```

## Documentation Files
- `API_DOCUMENTATION.md` - Complete API documentation
- `QUICK_START.md` - Quick start guide
- `PROJECT_SUMMARY.md` - Project overview
- `TTMS_Postman_Collection.json` - Postman collection for testing

## License
This project is licensed under the Apache License 2.0.

## Contact
For support or queries, please open an issue on GitHub.

