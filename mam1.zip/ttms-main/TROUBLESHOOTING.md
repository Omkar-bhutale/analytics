3. Restart backend to reset database
4. Check DataInitializer.java was executed

---

### Issue: Customer registration fails

**Common reasons:**
1. Email already exists
2. Password doesn't meet requirements
3. Phone number not 10 digits
4. Name contains numbers/special chars

**Password requirements:**
- Minimum 8 characters
- At least 1 uppercase (A-Z)
- At least 1 lowercase (a-z)
- At least 1 digit (0-9)
- At least 1 special (@#$%^&+=)

**Valid example:** `Password@123`

---

### Issue: Booking fails

**Common reasons:**
1. Not logged in
2. No seats available
3. Invalid seat count
4. Train doesn't exist

**Solutions:**
1. Login first
2. Check available seats
3. Try different train
4. Refresh train list

---

## 🔴 GitHub Issues

### Issue: Git push fails

**Error Message:**
```
fatal: remote origin already exists
```

**Solution:**
```bash
git remote remove origin
git remote add origin https://github.com/Omkar-bhutale/ttms.git
git push -u origin main
```

---

### Issue: Authentication failed

**Error Message:**
```
remote: Invalid username or password
```

**Solutions:**
1. Use Personal Access Token instead of password
2. Generate token: GitHub → Settings → Developer settings → Personal access tokens
3. Use token as password when pushing

---

## 🔴 Performance Issues

### Issue: Backend slow to start

**Normal behavior:**
- First start takes 30-60 seconds
- Subsequent starts are faster

**To speed up:**
1. Use `.\mvnw.cmd spring-boot:run` instead of `.\mvnw.cmd clean install`
2. Don't clean every time
3. Increase JVM memory if needed

---

### Issue: Frontend slow to load

**Solutions:**
1. First `npm install` takes time (normal)
2. Development mode is slower than production
3. Build for production:
```bash
npm run build
```

---

## 🔴 Browser Issues

### Issue: Application works in Chrome but not others

**Solution:**
Modern browsers should work. If issues:
1. Update browser to latest version
2. Clear cache
3. Disable extensions
4. Use Chrome/Firefox for development

---

### Issue: Browser cache issues

**Symptoms:**
- Old code still running
- Changes not visible

**Solution:**
Hard refresh:
- Chrome: Ctrl+Shift+R
- Firefox: Ctrl+F5
- Or clear cache completely

---

## 📞 Getting More Help

If issues persist:

1. **Check logs:**
   - Backend: Terminal running Spring Boot
   - Frontend: Browser Console (F12)

2. **Review documentation:**
   - COMPLETE_SETUP_GUIDE.md
   - QUICK_REFERENCE.md
   - API_DOCUMENTATION.md

3. **Verify setup:**
   - Both servers running
   - Correct ports (8080, 3000)
   - Java 17+ installed
   - Node.js 14+ installed

4. **Test with Swagger:**
   - http://localhost:8080/swagger-ui.html
   - Test APIs directly

---

## ✅ Verification Checklist

Use this to verify everything is working:

**Backend:**
- [ ] Compiles without errors
- [ ] Starts on port 8080
- [ ] Swagger UI accessible
- [ ] H2 console accessible
- [ ] Admin login works in Swagger

**Frontend:**
- [ ] npm install successful
- [ ] Starts on port 3000
- [ ] Home page loads
- [ ] Can navigate between pages
- [ ] No console errors

**Integration:**
- [ ] Can register customer
- [ ] Customer login works
- [ ] Admin login works
- [ ] Can search trains
- [ ] Can book tickets
- [ ] Can view bookings

---

## 🎯 Still Having Issues?

1. Restart everything:
   - Close all terminals
   - Run `start-application.bat`
   - Wait for both to fully start

2. Clean everything:
   ```bash
   # Backend
   .\mvnw.cmd clean
   rmdir /s /q target

   # Frontend
   cd frontend
   rmdir /s /q node_modules build
   npm install
   ```

3. Verify environment:
   ```bash
   java -version    # 17+
   node -v          # 14+
   npm -v           # 6+
   ```

---

**Remember:** Most issues are resolved by restarting the application! 🔄
# 🔧 TTMS Troubleshooting Guide

## Common Issues and Solutions

---

## 🔴 Backend Issues

### Issue: Port 8080 is already in use

**Error Message:**
```
Port 8080 is already in use
```

**Solution:**
```bash
# Find process using port 8080
netstat -ano | findstr :8080

# Kill the process (replace <PID> with actual process ID)
taskkill /PID <PID> /F

# Or change port in application.properties
server.port=8081
```

---

### Issue: Maven compilation fails

**Error Message:**
```
Failed to execute goal org.apache.maven.plugins:maven-compiler-plugin
```

**Solutions:**
1. Clean and rebuild:
```bash
.\mvnw.cmd clean install -U
```

2. Delete target folder:
```bash
rmdir /s /q target
.\mvnw.cmd clean install
```

3. Verify Java version:
```bash
java -version  # Should be 17 or higher
```

---

### Issue: Database connection error

**Error Message:**
```
Unable to connect to database
```

**Solution:**
H2 is in-memory and should work automatically. If issues persist:
1. Check `application.properties`
2. Restart the application
3. Clear target folder and rebuild

---

### Issue: JWT token errors

**Error Message:**
```
JWT signature does not match
```

**Solutions:**
1. Clear browser localStorage
2. Login again to get new token
3. Check jwt.secret in application.properties matches

---

## 🔴 Frontend Issues

### Issue: Port 3000 is already in use

**Error Message:**
```
Something is already running on port 3000
```

**Solution:**
Frontend will ask if you want to use a different port. Type 'Y' to use port 3001.

Or manually kill the process:
```bash
netstat -ano | findstr :3000
taskkill /PID <PID> /F
```

---

### Issue: npm install fails

**Error Message:**
```
npm ERR! code ELIFECYCLE
```

**Solutions:**
1. Delete node_modules and package-lock.json:
```bash
cd frontend
rmdir /s /q node_modules
del package-lock.json
npm cache clean --force
npm install
```

2. Try using different npm registry:
```bash
npm config set registry https://registry.npmjs.org/
npm install
```

---

### Issue: API calls return 401 Unauthorized

**Symptoms:**
- Can't fetch data after login
- All API calls fail with 401

**Solutions:**
1. Check if JWT token is stored:
   - Open browser DevTools (F12)
   - Go to Application → Local Storage
   - Verify 'token' exists

2. Token might be expired:
   - Logout and login again
   - Default expiry is 24 hours

3. Backend not running:
   - Verify backend is running on port 8080
   - Check: http://localhost:8080/swagger-ui.html

---

### Issue: CORS errors

**Error Message:**
```
Access to XMLHttpRequest has been blocked by CORS policy
```

**Solutions:**
1. Verify backend CORS is configured (already done)
2. Make sure backend is running
3. Clear browser cache
4. Try different browser

---

### Issue: Blank page or won't load

**Symptoms:**
- White screen
- No content displayed

**Solutions:**
1. Check browser console (F12) for errors
2. Verify all files are created correctly
3. Clear browser cache (Ctrl+Shift+Delete)
4. Restart development server:
```bash
npm start
```

---

### Issue: React Router not working

**Symptoms:**
- 404 errors on page refresh
- Routes don't work

**Solutions:**
1. This is expected in development mode
2. Always navigate using the UI links
3. For production, configure server redirects

---

## 🔴 Integration Issues

### Issue: Frontend can't connect to backend

**Symptoms:**
- Network errors
- Can't fetch data
- API calls timeout

**Checklist:**
1. ✅ Backend is running on port 8080
2. ✅ Frontend is running on port 3000
3. ✅ Check backend URL in api.js (http://localhost:8080/api)
4. ✅ No firewall blocking connections
5. ✅ Both running on same machine

**Solution:**
```bash
# Test backend manually
curl http://localhost:8080/api/trains

# If this fails, backend is not running properly
```

---

### Issue: Login successful but redirects fail

**Symptoms:**
- Login returns success
- But doesn't redirect
- Stays on login page

**Solutions:**
1. Check browser console for errors
2. Verify token is returned in response
3. Clear browser cache and cookies
4. Try incognito/private mode

---

## 🔴 Build Issues

### Issue: Maven build fails

**Error Message:**
```
BUILD FAILURE
```

**Solutions:**
1. Check Java version:
```bash
java -version  # Must be 17+
```

2. Clean build:
```bash
.\mvnw.cmd clean
.\mvnw.cmd install -DskipTests
```

3. Update Maven wrapper:
```bash
.\mvnw.cmd -N wrapper:wrapper
```

---

### Issue: npm build fails

**Error Message:**
```
npm ERR! Failed at the react-scripts build script
```

**Solutions:**
1. Increase memory:
```bash
set NODE_OPTIONS=--max_old_space_size=4096
npm run build
```

2. Clean install:
```bash
rmdir /s /q node_modules build
npm install
npm run build
```

---

## 🔴 Data Issues

### Issue: Admin login doesn't work

**Default credentials:**
- Username: `admin`
- Password: `admin123`

**Solutions:**
1. Verify you're on Admin tab (not Customer)
2. Check case sensitivity

