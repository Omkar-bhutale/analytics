package com.ignite.CBL.service.impl;

import com.ignite.CBL.dto.*;
import com.ignite.CBL.entity.*;
import com.ignite.CBL.repository.ProblemSubmissionRepository;
import com.ignite.CBL.repository.UserProblemReportRepository;
import com.ignite.CBL.repository.UserRepository;
import com.ignite.CBL.service.UserDashboardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional
public class UserDashboardServiceImpl implements UserDashboardService {
    @Value("${user.id}")
    private String userId;

    private final UserRepository userRepository;
    private final UserProblemReportRepository userProblemReportRepository;
    private final ProblemSubmissionRepository problemSubmissionRepository;

    @Autowired
    public UserDashboardServiceImpl(UserRepository userRepository,
                                  UserProblemReportRepository userProblemReportRepository,
                                  ProblemSubmissionRepository problemSubmissionRepository) {
        this.userRepository = userRepository;
        this.userProblemReportRepository = userProblemReportRepository;
        this.problemSubmissionRepository = problemSubmissionRepository;
    }

    @Override
    public List<UserDashboardResponceDTO> getAllUsersDashboard() {
        // Get all users
        List<User> allUsers = userRepository.findAll();
        
        return allUsers.stream()
            .map(user -> {
                // Get all problem reports for the user
                List<UserProblemReport> userProblemReports = userProblemReportRepository.findByUser_UserId(user.getUserId());
                
                // Create and populate the response DTO
                UserDashboardResponceDTO userDashboard = new UserDashboardResponceDTO();
                userDashboard.setUserId(user.getUserId());
                userDashboard.setUserName(user.getName());
                userDashboard.setBatchName("Ignite Batch");
                
                // Convert problem reports to DTOs with submissions
                List<UserProblemReportDTO> problemReportDTOs = userProblemReports.stream()
                    .map(report -> {
                        UserProblemReportDTO dto = convertToUserProblemReportDTO(report);
                        
                        // Get all submissions for this report
                        List<ProblemSubmission> submissions = problemSubmissionRepository
                            .findByUserProblemReport_UserProblemReportIdOrderBySubmittedAtDesc(report.getUserProblemReportId());
                        
                        // Convert submissions to DTOs
                        List<ProblemSubmissionResponceDTO> submissionDTOs = submissions.stream()
                            .map(this::convertToProblemSubmissionDTO)
                            .collect(Collectors.toList());
                        
                        dto.setSubmissions(submissionDTOs);
                        return dto;
                    })
                    .collect(Collectors.toList());
                
                userDashboard.setUserProblemReportDTOS(problemReportDTOs);
                return userDashboard;
            })
            .collect(Collectors.toList());
    }

    @Override
    public UserDashboardResponceDTO getUserDashboard() {
        // Get user details
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("User not found with id: " + userId));
            
        // Get user's problem reports
        List<UserProblemReport> userProblemReports = userProblemReportRepository.findByUser_UserId(userId);
        
        // Create response DTO
        UserDashboardResponceDTO response = new UserDashboardResponceDTO();
        response.setUserId(userId);
        response.setUserName(user.getName());
        response.setBatchName("Ignite Batch");
        
        // Convert each problem report to DTO with its submissions
        List<UserProblemReportDTO> problemReportDTOs = userProblemReports.stream()
            .map(report -> {
                // Convert report to DTO
                UserProblemReportDTO dto = convertToUserProblemReportDTO(report);
                
                // Get all submissions for this report
                List<ProblemSubmission> submissions = problemSubmissionRepository
                    .findByUserProblemReport_UserProblemReportIdOrderBySubmittedAtDesc(report.getUserProblemReportId());
                
                // Convert submissions to DTOs and set to the report DTO
                List<ProblemSubmissionResponceDTO> submissionDTOs = submissions.stream()
                    .map(this::convertToProblemSubmissionDTO)
                    .collect(Collectors.toList());
                
                dto.setSubmissions(submissionDTOs);
                return dto;
            })
            .collect(Collectors.toList());
        
        response.setUserProblemReportDTOS(problemReportDTOs);
        
        return response;
    }
    
    private UserProblemReportDTO convertToUserProblemReportDTO(UserProblemReport report) {
        UserProblemReportDTO dto = new UserProblemReportDTO();
        dto.setSolved(report.isSolved());
        dto.setTotalAttempts(report.getTotalAttempts());
        dto.setLanguagesUsed(report.getLanguagesUsed());
        
        if (report.getProblem() != null) {
            ProblemDTO problemDTO = new ProblemDTO();
            problemDTO.setProblemId(report.getProblem().getProblemId());
            problemDTO.setTitle(report.getProblem().getTitle());
            problemDTO.setDifficulty(report.getProblem().getDifficulty());
            problemDTO.setDescription(report.getProblem().getDescription());
            dto.setProblem(problemDTO);

        }
        
        return dto;
    }
    
    private ProblemSubmissionResponceDTO convertToProblemSubmissionDTO(ProblemSubmission submission) {
        return ProblemSubmissionResponceDTO.builder()
            .problemId(submission.getProblem().getProblemId())
            .language(submission.getLanguage().name())
            .code(submission.getCode())
            .isCorrect(submission.getIsSolved())
            .totalTestCasesPassed(submission.getPassedTestCases())
            .totalTestCases(submission.getTotalTestCases())
            .insights(submission.getInsights())
            .build();
    }
}
