package com.ignite.CBL.repository;

import com.ignite.CBL.entity.Problem;
import com.ignite.CBL.entity.User;
import com.ignite.CBL.entity.UserProblemReport;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;


public interface UserProblemReportRepository extends JpaRepository<UserProblemReport, Integer> {
    Optional<UserProblemReport> findByUser_UserIdAndProblem_ProblemId(String userId, Integer problemId);
    List<UserProblemReport> findByUser_UserId(String userId);

}
