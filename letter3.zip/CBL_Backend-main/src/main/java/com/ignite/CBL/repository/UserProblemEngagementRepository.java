package com.ignite.CBL.repository;

import com.ignite.CBL.entity.UserProblemEngagement;
import com.ignite.CBL.entity.UserProblemEngagementId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserProblemEngagementRepository extends JpaRepository<UserProblemEngagement, UserProblemEngagementId> {
    Optional<UserProblemEngagement> findById_UserIdAndId_ProblemId(String userId, Integer problemId);
}
