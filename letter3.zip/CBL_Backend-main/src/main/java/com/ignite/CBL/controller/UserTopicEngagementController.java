package com.ignite.CBL.controller;

import com.ignite.CBL.dto.TopicEngagementDTO;
import com.ignite.CBL.exception.ResourceNotFoundException;
import com.ignite.CBL.service.UserTopicEngagementService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user/topic-engagement")
@Tag(name = "Topic Engagement", description = "APIs for managing user engagement with topics")
@Slf4j
public class UserTopicEngagementController {

    private final UserTopicEngagementService userTopicEngagementService;

    @Autowired
    public UserTopicEngagementController(UserTopicEngagementService userTopicEngagementService) {
        this.userTopicEngagementService = userTopicEngagementService;
    }

    @PostMapping("/{topicId}/start")
    @Operation(summary = "Get or create topic engagement and ensure tracking is started")
    public ResponseEntity<TopicEngagementDTO> getOrStartTopicEngagement(@PathVariable Integer topicId) {
        TopicEngagementDTO engagement = userTopicEngagementService.getOrStartTopicEngagement(topicId);
        return ResponseEntity.ok(engagement);
    }

    @PutMapping("/{topicId}/time")
    @Operation(summary = "Update total time spent on a topic")
    public ResponseEntity<TopicEngagementDTO> updateTotalTimeSpent(
            @PathVariable Integer topicId,
            @RequestParam int totalTimeInSeconds) {
        TopicEngagementDTO engagement = userTopicEngagementService.updateTotalTimeSpent(topicId, totalTimeInSeconds);
        return ResponseEntity.ok(engagement);
    }

    @PostMapping("/{topicId}/complete")
    @Operation(summary = "Mark a topic as completed")
    public ResponseEntity<TopicEngagementDTO> markTopicAsCompleted(@PathVariable Integer topicId) {
        TopicEngagementDTO engagement = userTopicEngagementService.markTopicAsCompleted(topicId);
        return ResponseEntity.ok(engagement);
    }

    @GetMapping("/{topicId}")
    @Operation(summary = "Get engagement details for a topic")
    public ResponseEntity<TopicEngagementDTO> getTopicEngagement(
            @Parameter(description = "ID of the topic", required = true)
            @PathVariable Integer topicId) {
        try {
            TopicEngagementDTO engagement = userTopicEngagementService.getTopicEngagement(topicId);
            return ResponseEntity.ok(engagement);
        } catch (ResourceNotFoundException ex) {
            log.error("Topic not found with id: {}", topicId, ex);
            return ResponseEntity.notFound().build();
        } catch (Exception ex) {
            log.error("Error getting topic engagement for topicId: {}", topicId, ex);
            return ResponseEntity.internalServerError().build();
        }
    }
}
