package com.ignite.CBL.repository;

import com.ignite.CBL.entity.AlgorithmSubmission;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface AlgorithmSubmissionRepository extends JpaRepository<AlgorithmSubmission, Integer> {
    Optional<AlgorithmSubmission> findByProblem_ProblemIdAndUser_UserId(Integer problemId, String userId);
}
