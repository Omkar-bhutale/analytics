package com.ignite.CBL.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SavedCodes {
    private String java;
    private String python;
    private String javascript;
    private String typescript;
}
