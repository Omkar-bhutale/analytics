package com.ignite.CBL.service;

import com.ignite.CBL.dto.AlgorithmRequestDTO;
import com.ignite.CBL.dto.AlgorithmResponceDTO;

public interface AlgorithmSubmissionService {

    public AlgorithmResponceDTO saveOrUpdateAlgorithm(AlgorithmRequestDTO algorithmRequestDTO);
    public AlgorithmResponceDTO getAlgorithmByProblemId(Integer problemId);
    public Boolean existByProblemId(Integer problemId);
    public Boolean isAlgorithmCorrect(Integer problemId);

}
