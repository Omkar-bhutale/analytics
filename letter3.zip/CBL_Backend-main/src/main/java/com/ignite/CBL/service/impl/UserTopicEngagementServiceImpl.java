package com.ignite.CBL.service.impl;

import com.ignite.CBL.dto.TopicEngagementDTO;
import com.ignite.CBL.entity.*;
import com.ignite.CBL.exception.ResourceNotFoundException;
import com.ignite.CBL.repository.TopicRepository;
import com.ignite.CBL.repository.UserRepository;
import com.ignite.CBL.repository.UserTopicEngagementRepository;
import com.ignite.CBL.service.UserTopicEngagementService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserTopicEngagementServiceImpl implements UserTopicEngagementService {
    
    @Value("${user.id}")
    private String userId;

    private final UserTopicEngagementRepository userTopicEngagementRepository;
    private final UserRepository userRepository;
    private final TopicRepository topicRepository;

    @Override
    @Transactional
    public TopicEngagementDTO getOrStartTopicEngagement(Integer topicId) {
        // Check if user exists
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));
        
        // Check if topic exists
        Topic topic = topicRepository.findById(topicId)
                .orElseThrow(() -> new ResourceNotFoundException("Topic not found with id: " + topicId));
        
        // Try to find existing engagement
        Optional<UserTopicEngagement> existingEngagement = userTopicEngagementRepository
                .findByUser_UserIdAndTopic_TopicId(userId, topicId);
        
        UserTopicEngagement engagement;
        
        if (existingEngagement.isPresent()) {
            // Update existing engagement
            engagement = existingEngagement.get();
            engagement.setLastActivityAt(LocalDateTime.now());
        } else {
            // Create new engagement
            engagement = new UserTopicEngagement();
            UserTopicEngagementId id = new UserTopicEngagementId();
            id.setUserId(userId);
            id.setTopicId(topicId);
            engagement.setUserTopicEngagementId(id);
            engagement.setUser(user);
            engagement.setTopic(topic);
            engagement.setLastActivityAt(LocalDateTime.now());
            engagement.setTotalTimeSpent(0);
            engagement.setCompleted(false);
        }
        
        UserTopicEngagement savedEngagement = userTopicEngagementRepository.save(engagement);
        return mapToDTO(savedEngagement);
    }

    @Override
    @Transactional
    public TopicEngagementDTO updateTotalTimeSpent(Integer topicId, int totalTimeInSeconds) {
        // Check if topic exists first
        if (!topicRepository.existsById(topicId)) {
            throw new ResourceNotFoundException("Topic not found with id: " + topicId);
        }
        
        // Get or create engagement if it doesn't exist
        UserTopicEngagement engagement = userTopicEngagementRepository
                .findByUser_UserIdAndTopic_TopicId(userId, topicId)
                .orElseGet(() -> {
                    User user = userRepository.findById(userId)
                            .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));
                    Topic topic = topicRepository.findById(topicId).orElseThrow();
                    
                    UserTopicEngagement newEngagement = new UserTopicEngagement();
                    UserTopicEngagementId id = new UserTopicEngagementId();
                    id.setUserId(userId);
                    id.setTopicId(topicId);
                    newEngagement.setUserTopicEngagementId(id);
                    newEngagement.setUser(user);
                    newEngagement.setTopic(topic);
                    newEngagement.setTotalTimeSpent(0);
                    newEngagement.setCompleted(false);
                    return newEngagement;
                });
        
        // Update the total time spent and last activity
        engagement.setTotalTimeSpent(totalTimeInSeconds);
        engagement.setLastActivityAt(LocalDateTime.now());
        
        UserTopicEngagement updatedEngagement = userTopicEngagementRepository.save(engagement);
        return mapToDTO(updatedEngagement);
    }

    @Override
    @Transactional
    public TopicEngagementDTO markTopicAsCompleted(Integer topicId) {
        // Get the engagement
        UserTopicEngagement engagement = userTopicEngagementRepository
                .findByUser_UserIdAndTopic_TopicId(userId, topicId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        String.format("No engagement found for topic %d", topicId)));
        
        // Mark as completed
        engagement.setCompleted(true);
        engagement.setLastActivityAt(LocalDateTime.now());
        
        UserTopicEngagement updatedEngagement = userTopicEngagementRepository.save(engagement);
        
        return mapToDTO(updatedEngagement);
    }

    @Override
    public TopicEngagementDTO getTopicEngagement(Integer topicId) {
        return userTopicEngagementRepository
                .findByUser_UserIdAndTopic_TopicId(userId, topicId)
                .map(this::mapToDTO)
                .orElseThrow(() -> new ResourceNotFoundException(
                        String.format("No engagement found for topic %d", topicId)));
    }
    
    private TopicEngagementDTO mapToDTO(UserTopicEngagement engagement) {
        return TopicEngagementDTO.builder()
                .userId(engagement.getUser().getUserId())
                .topicId(engagement.getTopic().getTopicId())
                .topicName(engagement.getTopic().getTitle())
                .content(engagement.getTopic().getContent()) // Add content from Topic
                .totalTimeSpent(engagement.getTotalTimeSpent())
                .isCompleted(engagement.isCompleted())
                .lastActivityAt(engagement.getLastActivityAt())
                .build();
    }
}
