# CBL Backend API Documentation

**Version:** 1.0  
**Last Updated:** October 27, 2025  
**Base URL (Dev):** `http://localhost:8080`  
**Base URL (Prod):** `https://your-production-url.com`

---

## 📋 Table of Contents

1. [Authentication](#1-authentication)
2. [User Dashboard APIs](#2-user-dashboard-apis)
3. [Topic Engagement APIs](#3-topic-engagement-apis)
4. [Problem Submission APIs](#4-problem-submission-apis)
5. [Algorithm & Pseudocode APIs](#5-algorithm--pseudocode-apis)
6. [MCQ APIs](#6-mcq-apis)
7. [Notebook APIs](#7-notebook-apis)
8. [Main Topic Engagement APIs](#8-main-topic-engagement-apis)
9. [Admin Dashboard APIs](#9-admin-dashboard-apis)
10. [Analytics APIs](#10-analytics-apis)
11. [Error Codes](#11-error-codes)

---

## 1. Authentication

All user-specific APIs require JWT authentication.

**Required Headers:**
```
Authorization: Bearer <JWT_TOKEN>
Content-Type: application/json
```

---

## 2. User Dashboard APIs

### 2.1 Get Dashboard Info
**GET** `/user/dashboard/info`

Returns user problems, reports, and submissions.

**Response:**
```json
{
  "userId": "2918705",
  "userName": "John Doe",
  "batchName": "Ignite Batch",
  "userProblemReportDTOS": [
    {
      "problem": {
        "problemId": 1,
        "title": "Two Sum",
        "difficulty": "EASY"
      },
      "solved": true,
      "totalAttempts": 5,
      "languagesUsed": ["JAVA", "PYTHON"],
      "submissions": [...]
    }
  ]
}
```

### 2.2 Get Dashboard Statistics
**GET** `/user/dashboard/stats`

Returns detailed statistics with AI insights.

**Response:**
```json
{
  "userId": "2918705",
  "userName": "John Doe",
  "email": "john@example.com",
  "totalProblems": {"total": 150, "solved": 45, "percentage": 30.0},
  "difficultyStats": {
    "easy": {"total": 50, "solved": 25, "percentage": 50.0},
    "medium": {"total": 70, "solved": 15, "percentage": 21.43},
    "hard": {"total": 30, "solved": 5, "percentage": 16.67}
  },
  "languageStats": {"java": 20, "python": 15, "javascript": 8, "typescript": 2},
  "insights": {
    "overallInsight": "User shows steady progress...",
    "pythonInsight": "Excellent loops understanding...",
    "javaInsight": "Strong OOP skills..."
  }
}
```

### 2.3 Get All User Submissions
**GET** `/user/dashboard/submissions`

Returns all submissions across all problems.

---

## 3. Topic Engagement APIs

### 3.1 Get All Main Topics with Subtopics
**GET** `/user/topic-engagement/all-main-topics-sub-topics`

**Response:**
```json
[
  {
    "mainTopicId": 1,
    "mainTopicName": "Data Structures",
    "mainTopicDescription": "Learn fundamental data structures",
    "subTopics": [
      {
        "topicId": 1,
        "title": "Arrays",
        "content": {...},
        "createdAt": "2025-01-15T10:30:00"
      }
    ]
  }
]
```

### 3.2 Update Language Engagement
**PUT** `/user/topic-engagement/language`

**Request:**
```json
{
  "topicId": 12,
  "language": "JAVA",
  "timeSpentSeconds": 300,
  "isCompleted": true
}
```

**Response:**
```json
{
  "topicId": 12,
  "topicTitle": "Spring Boot Basics",
  "totalTimeSpent": 1800,
  "isCompleted": false,
  "lastActivityAt": "2025-10-27T07:18:12",
  "languageStats": {
    "java": {"timeSeconds": 900, "completed": true},
    "python": {"timeSeconds": 300, "completed": false}
  }
}
```

### 3.3 Get Topic Engagement
**GET** `/user/topic-engagement/{topicId}`

### 3.4 Mark MCQ as Visited
**PUT** `/user/topic-engagement/{topicId}/mcq-visited`

---

## 4. Problem Submission APIs

### 4.1 Get Problem Hint
**GET** `/user/problem-submissions/{problemId}/hint`

**Response:**
```json
{
  "problemId": 1,
  "hint": "Try using a hash map...",
  "createdAt": "2025-10-27T07:00:00"
}
```

### 4.2 Get Problem to Solve
**GET** `/user/problem-submissions/{problemId}`

**Response:**
```json
{
  "problemId": 1,
  "title": "Two Sum",
  "difficulty": "EASY",
  "description": "Given an array...",
  "examples": [...],
  "testCases": [...],
  "savedCode": {
    "java": "public class Solution {...}",
    "python": "def two_sum(nums, target): ..."
  },
  "timeSpent": {"java": 450, "python": 320}
}
```

### 4.3 Get All Submissions
**GET** `/user/problem-submissions/{problemId}/submissions`

### 4.4 Save Submission
**PUT** `/user/problem-submissions/submission`

**Request:**
```json
{
  "problemId": 1,
  "language": "JAVA",
  "code": "public class Solution {...}",
  "isSolved": true,
  "passedTestCases": 10,
  "totalTestCases": 10,
  "insights": "Great job!"
}
```

**Response:** `true`

### 4.5 Save Code and Time
**PUT** `/user/problem-submissions/save-code`

**Request:**
```json
{
  "problemId": 1,
  "language": "JAVA",
  "code": "public class Solution {...}",
  "timeSpentSeconds": 450
}
```

### 4.6 Get Main Topic Problem
**GET** `/user/problem-submissions/main-topic?mainTopicId={id}`

### 4.7 Get All Problems
**GET** `/user/problem-submissions/all`

---

## 5. Algorithm & Pseudocode APIs

### 5.1 Algorithm Submission

#### Create/Update Algorithm
**POST** `/user/algorithm-submissions`

**Request:**
```json
{
  "problemId": 1,
  "algorithm": "1. Initialize hash map\n2. Iterate...",
  "isCorrect": true,
  "insights": "Clear algorithm"
}
```

#### Get Algorithm
**GET** `/user/algorithm-submissions/problem/{problemId}`

#### Check Exists
**GET** `/user/algorithm-submissions/problem/{problemId}/exists`

#### Check Correct
**GET** `/user/algorithm-submissions/problem/{problemId}/is-correct`

### 5.2 Pseudocode Submission

#### Create/Update Pseudocode
**POST** `/user/pseudocode-submissions`

**Request:**
```json
{
  "problemId": 1,
  "pseudocode": "FUNCTION twoSum(nums, target)...",
  "isCorrect": true,
  "insights": "Well-structured"
}
```

#### Get Pseudocode
**GET** `/user/pseudocode-submissions/problem/{problemId}`

#### Check Exists
**GET** `/user/pseudocode-submissions/problem/{problemId}/exists`

#### Check Correct
**GET** `/user/pseudocode-submissions/problem/{problemId}/is-correct`

---

## 6. MCQ APIs

### 6.1 Get MCQ by ID
**GET** `/user/mcqs/{id}`

### 6.2 Get All MCQs by Topic
**GET** `/user/mcqs/topic/{topicId}`

**Response:**
```json
[
  {
    "mcqId": 1,
    "topicId": 5,
    "question": "What is the time complexity of binary search?",
    "options": ["O(n)", "O(log n)", "O(n^2)", "O(1)"],
    "correctAnswer": 1,
    "explanation": "Binary search divides..."
  }
]
```

### 6.3 Count MCQs by Topic
**GET** `/user/mcqs/topic/{topicId}/count`

---

## 7. Notebook APIs

### 7.1 Get Notebooks for Main Topic
**GET** `/user/notebooks/{mainTopicId}`

**Response:**
```json
[
  {
    "notebookId": 1,
    "title": "Introduction to Data Structures",
    "language": "PYTHON",
    "downloadUrl": "/user/notebooks/download/1",
    "uploadedAt": "2025-10-15T10:00:00"
  }
]
```

### 7.2 Download Notebook
**GET** `/user/notebooks/download/{notebookId}`

Returns file download.

---

## 8. Main Topic Engagement APIs

### 8.1 Validate and Mark Completion
**PUT** `/user/user-main-topic-engagement/{mainTopicId}/validate-completion?language={language}`

**Response (Success):**
```json
{
  "success": true,
  "message": "Congratulations! Completed all requirements.",
  "mainTopicId": 1,
  "language": "JAVA",
  "completed": true,
  "requirements": {
    "allSubTopicsVisited": true,
    "allMcqsCompleted": true,
    "problemSolved": true
  }
}
```

**Response (Incomplete):**
```json
{
  "success": false,
  "message": "Haven't completed all requirements.",
  "missingRequirements": [
    "Complete all MCQs",
    "Solve main topic problem in JAVA"
  ]
}
```

---

## 9. Admin Dashboard APIs

### 9.1 Get All Users Dashboard
**GET** `/api/admin/dashboard`

### 9.2 Get All Users Stats
**GET** `/api/admin/dashboard/users-stats`

**Response:**
```json
[
  {
    "userId": "2918705",
    "userName": "John Doe",
    "userEmail": "john@example.com",
    "totalProblems": 150,
    "totalSolved": 45,
    "totalSolvedPercentage": 30.0,
    "easyTotal": 50,
    "easySolved": 25,
    "javaSolved": 20,
    "pythonSolved": 15
  }
]
```

### 9.3 Get User Stats
**GET** `/api/admin/dashboard/user-stats/{userId}`

### 9.4 Get Problems Info
**GET** `/api/admin/dashboard/problems-info`

### 9.5 Get Dashboard Stats
**GET** `/api/admin/dashboard/stats`

**Response:**
```json
{
  "totalUsers": 250,
  "totalProblems": 150,
  "totalSolved": 3450,
  "totalSolvedJava": 1200,
  "totalSolvedPython": 1050
}
```

### 9.6 Get User Problem Report
**GET** `/api/admin/dashboard/user-problem-report?userId={userId}&problemId={problemId}`

### 9.7 Get User Submissions
**GET** `/api/admin/dashboard/user-submissions/{userId}`

---

## 10. Analytics APIs

**Base Path:** `/open/analytics`

### 10.1 Main Topic Averages
**GET** `/open/analytics/main-topic-averages`

**Response:**
```json
[
  {
    "mainTopicId": 1,
    "mainTopicTitle": "Data Structures",
    "avgJavaTime": 1250.50,
    "avgPythonTime": 980.25,
    "avgJavascriptTime": 1100.75,
    "avgTypescriptTime": 1050.00,
    "avgTotalTime": 4381.50,
    "javaCompletedCount": 45,
    "pythonCompletedCount": 38,
    "javascriptCompletedCount": 42,
    "typescriptCompletedCount": 35,
    "totalUsersEngaged": 120
  }
]
```

### 10.2 Problem Averages (ALL)
**GET** `/open/analytics/problem-averages`

**Response:**
```json
[
  {
    "problemId": 1,
    "problemTitle": "Two Sum",
    "difficulty": "EASY",
    "topicId": 1,
    "topicTitle": "Arrays",
    "mainTopicId": 1,
    "mainTopicTitle": "Data Structures",
    "avgJavaTime": 450.50,
    "avgPythonTime": 320.25,
    "avgJavascriptTime": 500.00,
    "avgTypescriptTime": 480.75,
    "avgTotalTime": 1751.50,
    "javaCompletedCount": 85,
    "pythonCompletedCount": 72,
    "javascriptCompletedCount": 68,
    "typescriptCompletedCount": 55,
    "totalUsersAttempted": 150
  }
]
```

### 10.3 Filter Problem Averages

**By Main Topic:**  
**GET** `/open/analytics/problem-averages/main-topic/{mainTopicId}`

**By Topic:**  
**GET** `/open/analytics/problem-averages/topic/{topicId}`

**By Difficulty:**  
**GET** `/open/analytics/problem-averages/difficulty/{difficulty}`  
_(difficulty: EASY, MEDIUM, HARD)_

### 10.4 Topic-Level Problem Averages (NON-MANDATORY)
**GET** `/open/analytics/topic-problem-averages`

Returns averages for non-mandatory topic problems only (excludes main topic mandatory problems).

### 10.5 Filter Topic Problem Averages

**By Main Topic:**  
**GET** `/open/analytics/topic-problem-averages/main-topic/{mainTopicId}`

**By Topic:**  
**GET** `/open/analytics/topic-problem-averages/topic/{topicId}`

**By Difficulty:**  
**GET** `/open/analytics/topic-problem-averages/difficulty/{difficulty}`

---

## 11. Error Codes

| Code | Description |
|------|-------------|
| 200 | Success |
| 201 | Created |
| 400 | Bad Request - Invalid input |
| 401 | Unauthorized - Missing/invalid token |
| 403 | Forbidden - Insufficient permissions |
| 404 | Not Found - Resource doesn't exist |
| 500 | Internal Server Error |

### Common Error Response Format
```json
{
  "timestamp": "2025-10-27T07:30:00",
  "status": 404,
  "error": "Not Found",
  "message": "User not found with id: 2918705",
  "path": "/user/dashboard/stats"
}
```

---

## 📝 API Usage Notes

### 1. **Problem Solving Workflow**
1. Submit Algorithm → **POST** `/user/algorithm-submissions`
2. Submit Pseudocode → **POST** `/user/pseudocode-submissions`
3. Get Problem → **GET** `/user/problem-submissions/{problemId}`
4. Save Code periodically → **PUT** `/user/problem-submissions/save-code`
5. Submit Solution → **PUT** `/user/problem-submissions/submission`

### 2. **Topic Engagement Workflow**
1. Get all topics → **GET** `/user/topic-engagement/all-main-topics-sub-topics`
2. Track time per language → **PUT** `/user/topic-engagement/language`
3. Mark MCQ completed → **PUT** `/user/topic-engagement/{topicId}/mcq-visited`
4. Validate completion → **PUT** `/user/user-main-topic-engagement/{mainTopicId}/validate-completion`

### 3. **Language Values**
Use uppercase: `JAVA`, `PYTHON`, `JAVASCRIPT`, `TYPESCRIPT`

### 4. **Difficulty Values**
Use uppercase: `EASY`, `MEDIUM`, `HARD`

### 5. **Time Tracking**
- Time is measured in **seconds**
- Always increment, don't reset
- Backend auto-calculates totals

### 6. **Analytics APIs**
- No authentication required (open endpoints)
- Suitable for public dashboards
- Real-time aggregated data

---

## 🔗 Additional Resources

- **Swagger UI:** `http://localhost:8080/swagger-ui/index.html`
- **API Health:** `http://localhost:8080/actuator/health`
- **Database Views:** Auto-created on startup

---

**For Support:** Contact backend team  
**Documentation Version:** 1.0 (October 2025)
