package com.ignite.CBL.service;

import com.ignite.CBL.dto.UserDashboardResponceDTO;
import com.ignite.CBL.dto.UserProblemReportDTO;
import com.ignite.CBL.dto.UserProblemStats;
import com.ignite.CBL.entity.*;
import com.ignite.CBL.repository.*;
import com.ignite.CBL.service.impl.UserDashboardServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDateTime;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UserDashboardServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private UserProblemReportRepository userProblemReportRepository;

    @Mock
    private ProblemSubmissionRepository problemSubmissionRepository;

    @Mock
    private AdminDashboardRepository adminDashboardRepository;

    @Mock
    private ProblemRepository problemRepository;

    @InjectMocks
    private UserDashboardServiceImpl userDashboardService;

    private final String testUserId = "test-user-123";
    private final String otherUserId = "other-user-456";

    @BeforeEach
    void setUp() {
        // Create a real user for testing
        User testUser = createUser("test-user-123", "Test User");
        when(userRepository.findById("test-user-123")).thenReturn(Optional.of(testUser));

        // Set the test user ID
        ReflectionTestUtils.setField(userDashboardService, "userId", "test-user-123");
    }

    @Test
    void getUserDashboard_ShouldReturnUserDashboard() {
        // Arrange
        User user = createUser(testUserId, "Test User");
        when(userRepository.findById(testUserId)).thenReturn(Optional.of(user));
        when(userProblemReportRepository.findByUser_UserId(testUserId))
            .thenReturn(Collections.emptyList());

        // Act
        UserDashboardResponceDTO result = userDashboardService.getUserDashboard();

        // Assert
        assertNotNull(result);
        assertEquals(testUserId, result.getUserId());
        assertEquals("Test User", result.getUserName());
        assertTrue(result.getUserProblemReportDTOS().isEmpty());
    }

    @Test
    void getAllUsersDashboard_ShouldReturnAllUsers() {
        // Arrange
        User user1 = createUser("user1", "User One");
        User user2 = createUser("user2", "User Two");

        when(userRepository.findAll()).thenReturn(Arrays.asList(user1, user2));
        when(userProblemReportRepository.findByUser_UserId(anyString()))
            .thenReturn(Collections.emptyList());

        // Act
        List<UserDashboardResponceDTO> result = userDashboardService.getAllUsersDashboard();

        // Assert
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("user1", result.get(0).getUserId());
        assertEquals("user2", result.get(1).getUserId());
    }

    @Test
    void getUserDashboardStats_ShouldReturnStats() {
        // Arrange
        User user = createUser(testUserId, "Test User");
        Problem problem = createProblem(1, "Test Problem");
        UserProblemReport report = createUserProblemReport(1, user, problem, "SOLVED");

        when(userRepository.findById(testUserId)).thenReturn(Optional.of(user));
        when(userProblemReportRepository.findByUser_UserId(testUserId))
            .thenReturn(Collections.singletonList(report));
        when(problemRepository.count()).thenReturn(100L);
        when(adminDashboardRepository.countProblemsSolvedByUser(testUserId)).thenReturn(25L);
        when(problemSubmissionRepository
            .findByUserProblemReport_UserProblemReportIdOrderBySubmittedAtDesc(1))
            .thenReturn(Collections.emptyList());

        // Act
        Map<String, Object> result = userDashboardService.getUserDashboardStats();

        // Assert
        assertNotNull(result);
        assertEquals(100L, result.get("totalProblems"));
        assertEquals(25L, result.get("solvedProblems"));
        assertNotNull(result.get("recentReports"));
    }

    @Test
    void getUserDashboardStats_WithUserId_ShouldReturnStatsForSpecificUser() {
        // Arrange
        User user = createUser("other-user-456", "Other User");
        when(userRepository.findById("other-user-456")).thenReturn(Optional.of(user));
        when(userProblemReportRepository.findByUser_UserId("other-user-456"))
            .thenReturn(Collections.emptyList());
        when(problemRepository.count()).thenReturn(50L);
        when(adminDashboardRepository.countProblemsSolvedByUser("other-user-456")).thenReturn(10L);

        // Act
        Map<String, Object> result = userDashboardService.getUserDashboardStats("other-user-456");

        // Assert
        assertNotNull(result);
        assertEquals(50L, result.get("totalProblems"));
        assertEquals(10L, result.get("solvedProblems"));
    }

    @Test
    void getAllUsersWithProblemStats_ShouldReturnStats() {
        // Arrange
        List<UserProblemStats> expectedStats = new ArrayList<>();
        
        // Create real implementations of the interface for testing
        UserProblemStats stats1 = new UserProblemStats() {
            @Override public String getUserId() { return "user1"; }
            @Override public String getUserName() { return "User One"; }
            @Override public Long getTotalSolved() { return 5L; }
            @Override public Long getSolvedInJava() { return 2L; }
            @Override public Long getSolvedInPython() { return 1L; }
            @Override public Long getSolvedInJavascript() { return 1L; }
            @Override public Long getSolvedInTypescript() { return 1L; }
        };
        
        UserProblemStats stats2 = new UserProblemStats() {
            @Override public String getUserId() { return "user2"; }
            @Override public String getUserName() { return "User Two"; }
            @Override public Long getTotalSolved() { return 10L; }
            @Override public Long getSolvedInJava() { return 4L; }
            @Override public Long getSolvedInPython() { return 3L; }
            @Override public Long getSolvedInJavascript() { return 2L; }
            @Override public Long getSolvedInTypescript() { return 1L; }
        };
        
        expectedStats.add(stats1);
        expectedStats.add(stats2);
        
        when(adminDashboardRepository.findAllUsersWithProblemStats()).thenReturn(expectedStats);

        // Act
        List<UserProblemStats> result = userDashboardService.getAllUsersWithProblemStats();

        // Assert
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("User One", result.get(0).getUserName());
        assertEquals("User Two", result.get(1).getUserName());
    }

    @Test
    void getUserDashboard_WhenUserNotFound_ShouldThrowException() {
        // Arrange
        when(userRepository.findById(testUserId)).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(RuntimeException.class, () -> userDashboardService.getUserDashboard());
    }

    // Helper methods
    private User createUser(String userId, String name) {
        User user = new User();
        user.setUserId(userId);
        user.setName(name);
        return user;
    }

    private Problem createProblem(int id, String title) {
        Problem problem = new Problem();
        problem.setProblemId(id);
        problem.setTitle(title);
        return problem;
    }

    private UserProblemReport createUserProblemReport(int id, User user, Problem problem, String status) {
        UserProblemReport report = new UserProblemReport();
        report.setUserProblemReportId(id);
        report.setUser(user);
        report.setProblem(problem);
        report.setTotalAttempts(1);
        report.setLanguagesUsed(Set.of(Language.JAVA));
        report.setInsight(new ObjectMapper().createObjectNode());
        return report;
    }
}
