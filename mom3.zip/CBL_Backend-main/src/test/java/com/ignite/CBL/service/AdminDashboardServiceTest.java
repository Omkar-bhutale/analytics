package com.ignite.CBL.service;

import com.ignite.CBL.repository.AdminDashboardRepository;
import com.ignite.CBL.repository.ProblemRepository;
import com.ignite.CBL.repository.ProblemSubmissionRepository;
import com.ignite.CBL.repository.UserRepository;
import com.ignite.CBL.service.impl.AdminDashboardServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AdminDashboardServiceTest {

    @Mock
    private AdminDashboardRepository adminDashboardRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private ProblemRepository problemRepository;

    @Mock
    private ProblemSubmissionRepository problemSubmissionRepository;

    @InjectMocks
    private AdminDashboardServiceImpl adminDashboardService;

    @Test
    void countTotalSolvedInJava_ShouldReturnCount() {
        // Arrange
        long expectedCount = 10L;
        when(adminDashboardRepository.countProblemsSolvedByLanguage("JAVA")).thenReturn(expectedCount);

        // Act
        long result = adminDashboardService.countTotalSolvedInJava();

        // Assert
        assertEquals(expectedCount, result);
    }

    @Test
    void countTotalSolvedPython_ShouldReturnCount() {
        // Arrange
        long expectedCount = 8L;
        when(adminDashboardRepository.countProblemsSolvedByLanguage("PYTHON")).thenReturn(expectedCount);

        // Act
        long result = adminDashboardService.countTotalSolvedPython();

        // Assert
        assertEquals(expectedCount, result);
    }

    @Test
    void countTotalSolvedJavaScript_ShouldReturnCount() {
        // Arrange
        long expectedCount = 15L;
        when(adminDashboardRepository.countProblemsSolvedByLanguage("JAVASCRIPT")).thenReturn(expectedCount);

        // Act
        long result = adminDashboardService.countTotalSolvedJavaScript();

        // Assert
        assertEquals(expectedCount, result);
    }

    @Test
    void countTotalSolvedTypeScript_ShouldReturnCount() {
        // Arrange
        long expectedCount = 12L;
        when(adminDashboardRepository.countProblemsSolvedByLanguage("TYPESCRIPT")).thenReturn(expectedCount);

        // Act
        long result = adminDashboardService.countTotalSolvedTypeScript();

        // Assert
        assertEquals(expectedCount, result);
    }

    @Test
    void countTotalUsers_ShouldReturnUserCount() {
        // Arrange
        long expectedCount = 50L;
        when(userRepository.count()).thenReturn(expectedCount);

        // Act
        long result = adminDashboardService.countTotalUsers();

        // Assert
        assertEquals(expectedCount, result);
    }

    @Test
    void countTotalProblems_ShouldReturnProblemCount() {
        // Arrange
        long expectedCount = 100L;
        when(problemRepository.count()).thenReturn(expectedCount);

        // Act
        long result = adminDashboardService.countTotalProblems();

        // Assert
        assertEquals(expectedCount, result);
    }

    @Test
    void countTotalSubmissions_ShouldReturnSubmissionCount() {
        // Arrange
        long expectedCount = 200L;
        when(problemSubmissionRepository.count()).thenReturn(expectedCount);

        // Act
        long result = adminDashboardService.countTotalSubmissions();

        // Assert
        assertEquals(expectedCount, result);
    }
}
