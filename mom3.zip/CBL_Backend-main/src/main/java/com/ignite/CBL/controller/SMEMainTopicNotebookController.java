package com.ignite.CBL.controller;

import com.ignite.CBL.dto.NotebookResponseDTO;
import com.ignite.CBL.entity.Language;
import com.ignite.CBL.service.NotebookService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

@RestController
@RequestMapping("/sme/notebooks")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "SME Notebook Management", description = "Upload, list, update, delete, and download Jupyter notebooks for main topics")
public class SMEMainTopicNotebookController {

    private final NotebookService notebookService;


    @Operation(summary = "Upload Jupyter Notebook for a MainTopic (with title and language)")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Notebook uploaded successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid input or file format"),
            @ApiResponse(responseCode = "500", description = "Server error while uploading")
    })
    @RequestBody(
            content = @Content(mediaType = MediaType.MULTIPART_FORM_DATA_VALUE)
    )
    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<String> uploadNotebook(
            @RequestParam Integer mainTopicId,
            @RequestParam Language language,
            @RequestParam(required = false) String title,
            @RequestParam("file") MultipartFile file
    ) {
        String response = notebookService.uploadNotebook(mainTopicId, language, title, file);
        return ResponseEntity.ok(response);
    }


    @GetMapping
    @Operation(summary = "Get all uploaded notebooks (optionally by mainTopicId)")
    public ResponseEntity<List<NotebookResponseDTO>> getAllNotebooks(
            @RequestParam(required = false) Integer mainTopicId
    ) {
        return ResponseEntity.ok(notebookService.getAllNotebooks(mainTopicId));
    }


    @GetMapping("/download/{notebookId}")
    @Operation(summary = "Download a specific notebook file by ID")
    public ResponseEntity<Resource> downloadNotebook(@PathVariable Integer notebookId) {
        Resource resource = notebookService.downloadNotebook(notebookId);
        String fileName = resource.getFilename();

        String contentType;
        try {
            Path filePath = resource.getFile().toPath();
            contentType = Files.probeContentType(filePath);


            if (contentType == null || contentType.isBlank()) {
                contentType = "application/octet-stream";
            }
        } catch (Exception e) {
            contentType = "application/octet-stream";
        }

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(contentType))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"")
                .body(resource);
    }


    // ✅ Update notebook title
    @PutMapping("/{notebookId}/title")
    @Operation(summary = "Update notebook title")
    public ResponseEntity<String> updateNotebookTitle(
            @PathVariable Integer notebookId,
            @RequestParam String newTitle
    ) {
        String response = notebookService.updateNotebookTitle(notebookId, newTitle);
        return ResponseEntity.ok(response);
    }

    // ✅ Delete notebook
    @DeleteMapping("/{notebookId}")
    @Operation(summary = "Delete a notebook by ID")
    public ResponseEntity<String> deleteNotebook(@PathVariable Integer notebookId) {
        String response = notebookService.deleteNotebook(notebookId);
        return ResponseEntity.ok(response);
    }
}
