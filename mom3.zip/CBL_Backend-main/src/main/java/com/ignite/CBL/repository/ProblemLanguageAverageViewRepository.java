package com.ignite.CBL.repository;

import com.ignite.CBL.entity.view.ProblemLanguageAverageView;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProblemLanguageAverageViewRepository extends JpaRepository<ProblemLanguageAverageView, Integer> {

    // Get all problem averages ordered by problem_id (Spring Data JPA will auto-generate)
    List<ProblemLanguageAverageView> findAllByOrderByProblemIdAsc();

    // Get averages for a specific main topic
    List<ProblemLanguageAverageView> findByMainTopicIdOrderByProblemIdAsc(Integer mainTopicId);

    // Get averages for a specific topic
    List<ProblemLanguageAverageView> findByTopicIdOrderByProblemIdAsc(Integer topicId);

    // Get averages by difficulty
    List<ProblemLanguageAverageView> findByDifficultyOrderByProblemIdAsc(String difficulty);
}