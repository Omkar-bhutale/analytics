package com.ignite.CBL.dto;

import com.fasterxml.jackson.databind.JsonNode;
import com.ignite.CBL.entity.SavedCodes;
import lombok.Data;

@Data
public class ProblemCodeResponceDTO {
    private ProblemDTO problemDTO;
    private SavedCodes savedCodes;
    private Integer totalSecondsSpent;
    private Long javaTimeSeconds;
    private Long pythonTimeSeconds;
    private Long javascriptTimeSeconds;
    private Long typescriptTimeSeconds;
    private JsonNode hint;




}
