package com.ignite.CBL.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TopicEngagementDTO {
    private String userId;
    private Integer topicId;
    private String topicName;
    private JsonNode content;  // Added content field from Topic entity
    private int totalTimeSpent;
    private boolean isCompleted;
    
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime lastActivityAt;
    
    // Helper method to format time in HH:MM:SS
    public String getFormattedTimeSpent() {
        int hours = totalTimeSpent / 3600;
        int minutes = (totalTimeSpent % 3600) / 60;
        int seconds = totalTimeSpent % 60;
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }
}
