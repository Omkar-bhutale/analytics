package com.ignite.CBL.service.impl;

import com.ignite.CBL.dto.ProblemLanguageAverageDTO;
import com.ignite.CBL.repository.ProblemLanguageAverageViewRepository;
import com.ignite.CBL.service.ProblemLanguageAverageService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProblemLanguageAverageServiceImpl implements ProblemLanguageAverageService {

    private final ProblemLanguageAverageViewRepository viewRepository;
    private final ModelMapper modelMapper;

    @Override
    public List<ProblemLanguageAverageDTO> getProblemLanguageAverages() {
        log.debug("Fetching all problem language averages");
        return viewRepository.findAllByOrderByProblemIdAsc().stream()
                .map(view -> modelMapper.map(view, ProblemLanguageAverageDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<ProblemLanguageAverageDTO> getProblemLanguageAveragesByMainTopic(Integer mainTopicId) {
        log.debug("Fetching problem language averages for main topic: {}", mainTopicId);
        return viewRepository.findByMainTopicIdOrderByProblemIdAsc(mainTopicId).stream()
                .map(view -> modelMapper.map(view, ProblemLanguageAverageDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<ProblemLanguageAverageDTO> getProblemLanguageAveragesByTopic(Integer topicId) {
        log.debug("Fetching problem language averages for topic: {}", topicId);
        return viewRepository.findByTopicIdOrderByProblemIdAsc(topicId).stream()
                .map(view -> modelMapper.map(view, ProblemLanguageAverageDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<ProblemLanguageAverageDTO> getProblemLanguageAveragesByDifficulty(String difficulty) {
        log.debug("Fetching problem language averages for difficulty: {}", difficulty);
        return viewRepository.findByDifficultyOrderByProblemIdAsc(difficulty.toUpperCase()).stream()
                .map(view -> modelMapper.map(view, ProblemLanguageAverageDTO.class))
                .collect(Collectors.toList());
    }
}
