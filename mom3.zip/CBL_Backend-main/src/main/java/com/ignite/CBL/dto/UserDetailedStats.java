// UserDetailedStats.java
package com.ignite.CBL.dto;

import com.fasterxml.jackson.databind.JsonNode;

import java.util.Map;

public interface UserDetailedStats {
    // Basic Info
    String getUserId();
    String getUserName();

    String getUserInsights();

    String getUserEmail();
    
    // Problem Counts
    Integer getTotalProblems();
    Integer getTotalSolved();
    Integer getEasySolved();
    Integer getMediumSolved();
    Integer getHardSolved();
    
    // Language Specific
    Integer getJavaSolved();
    Integer getPythonSolved();
    Integer getJavascriptSolved();
    Integer getTypescriptSolved();
    
    // Percentages
    default Double getTotalSolvedPercentage() {
        return getTotalProblems() > 0 ? 
            (getTotalSolved() * 100.0) / getTotalProblems() : 0.0;
    }
    
    default Double getEasySolvedPercentage() {
        return getEasyTotal() > 0 ? 
            (getEasySolved() * 100.0) / getEasyTotal() : 0.0;
    }
    
    default Double getMediumSolvedPercentage() {
        return getMediumTotal() > 0 ? 
            (getMediumSolved() * 100.0) / getMediumTotal() : 0.0;
    }
    
    default Double getHardSolvedPercentage() {
        return getHardTotal() > 0 ? 
            (getHardSolved() * 100.0) / getHardTotal() : 0.0;
    }
    
    // These will be set by the service
    Integer getEasyTotal();
    Integer getMediumTotal();
    Integer getHardTotal();
}