package com.ignite.CBL.entity.view;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.Subselect;

@Entity
@Immutable
@Subselect("SELECT " +
        "m.main_topic_id, " +
        "m.title AS main_topic_title, " +
        "ROUND(AVG(e.java_time_seconds), 2) AS avg_java_time, " +
        "ROUND(AVG(e.python_time_seconds), 2) AS avg_python_time, " +
        "ROUND(AVG(e.javascript_time_seconds), 2) AS avg_javascript_time, " +
        "ROUND(AVG(e.typescript_time_seconds), 2) AS avg_typescript_time, " +
        "ROUND(AVG(e.total_seconds_spent), 2) AS avg_total_time, " +
        "COUNT(CASE WHEN e.java_completed = true THEN 1 END) AS java_completed_count, " +
        "COUNT(CASE WHEN e.python_completed = true THEN 1 END) AS python_completed_count, " +
        "COUNT(CASE WHEN e.javascript_completed = true THEN 1 END) AS javascript_completed_count, " +
        "COUNT(CASE WHEN e.typescript_completed = true THEN 1 END) AS typescript_completed_count, " +
        "COUNT(DISTINCT e.user_id) AS total_users_engaged " +
        "FROM user_main_topic_engagement e " +
        "JOIN main_topics m ON e.main_topic_id = m.main_topic_id " +
        "GROUP BY m.main_topic_id, m.title")
@Getter
@Setter
public class MainTopicLanguageAverageView {

    @Id
    private Integer mainTopicId;
    private String mainTopicTitle;
    private Double avgJavaTime;
    private Double avgPythonTime;
    private Double avgJavascriptTime;
    private Double avgTypescriptTime;
    private Double avgTotalTime;
    private Long javaCompletedCount;
    private Long pythonCompletedCount;
    private Long javascriptCompletedCount;
    private Long typescriptCompletedCount;
    private Long totalUsersEngaged;
}