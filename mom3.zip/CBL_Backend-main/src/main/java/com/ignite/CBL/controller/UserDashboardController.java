package com.ignite.CBL.controller;

import com.ignite.CBL.dto.ProblemSubmissionResponceDTO;
import com.ignite.CBL.dto.UserDashboardResponceDTO;
import com.ignite.CBL.service.ProblemSubmissionService;
import com.ignite.CBL.service.UserDashboardService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/user/dashboard")
@RequiredArgsConstructor
@Tag(name = "User Dashboard", description = "APIs for user dashboard information and statistics")
public class UserDashboardController {

    private final UserDashboardService userDashboardService;
    private final ProblemSubmissionService problemSubmissionService;

    @GetMapping("/info")
    @Operation(summary = "Get user dashboard information",
               description = "Returns dashboard data including user problems, reports, and submissions for the logged-in user")
    public ResponseEntity<UserDashboardResponceDTO> getUserDashboard() {
        UserDashboardResponceDTO dashboardData = userDashboardService.getUserDashboard();
        return ResponseEntity.ok(dashboardData);
    }

    @GetMapping("/stats")
    @Operation(summary = "Get user dashboard statistics",
               description = "Returns detailed statistics including total problems solved, difficulty breakdown, language stats, and AI-generated insights")
    public ResponseEntity<Map<String, Object>> getUserStats() {
        return ResponseEntity.ok(userDashboardService.getUserDashboardStats());
    }

    @GetMapping("/submissions")
    @Operation(summary = "Get all user problem submissions",
               description = "Returns all problem submissions made by the logged-in user across all problems, including code, language, test results, and AI-generated insights")
    public ResponseEntity<List<ProblemSubmissionResponceDTO>> getUserSubmissions() {
        List<ProblemSubmissionResponceDTO> submissions = problemSubmissionService.getUserSubmissions();
        return ResponseEntity.ok(submissions);
    }
}
