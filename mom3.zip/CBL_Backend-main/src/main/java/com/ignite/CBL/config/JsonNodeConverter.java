package com.ignite.CBL.config;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

import java.util.logging.Logger;

@Converter(autoApply = true)
public class JsonNodeConverter implements AttributeConverter<JsonNode, String> {
    private static final ObjectMapper mapper = new ObjectMapper();
    private static final Logger logger = Logger.getLogger(JsonNodeConverter.class.getName());
    
    @Override
    public String convertToDatabaseColumn(JsonNode attribute) {
        if (attribute == null) {
            return null;
        }
        try {
            return mapper.writeValueAsString(attribute);
        } catch (Exception e) {
            logger.warning("Error converting JsonNode to database column: " + e.getMessage());
            return null;
        }
    }
    
    @Override
    public JsonNode convertToEntityAttribute(String dbData) {
        if (dbData == null || dbData.trim().isEmpty()) {
            return null;
        }
        try {
            return mapper.readTree(dbData);
        } catch (Exception e) {
            logger.warning("Error converting database column to JsonNode: " + e.getMessage());
            // Return the raw string as a text node if parsing fails
            return mapper.valueToTree(dbData);
        }
    }
}