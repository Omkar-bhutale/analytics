package com.ignite.CBL.service.impl;

import com.ignite.CBL.dto.TopicEngagementResponseDTO;
import com.ignite.CBL.dto.TopicLanguageEngagementRequestDTO;
import com.ignite.CBL.entity.*;
import com.ignite.CBL.exception.ResourceNotFoundException;
import com.ignite.CBL.repository.TopicRepository;
import com.ignite.CBL.repository.UserRepository;
import com.ignite.CBL.repository.UserTopicEngagementRepository;
import com.ignite.CBL.service.UserTopicEngagementService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserTopicEngagementServiceImpl implements UserTopicEngagementService {

    private final UserTopicEngagementRepository engagementRepository;
    private final TopicRepository topicRepository;
    private final UserRepository userRepository;

    @Value("${user.id}")
    private String userId;

    @Override
    @Transactional
    public TopicEngagementResponseDTO updateLanguageWiseEngagement(TopicLanguageEngagementRequestDTO request) {
        log.info("Updating engagement for topic {}, language: {}", request.getTopicId(), request.getLanguage());

        Topic topic = topicRepository.findById(request.getTopicId())
                .orElseThrow(() -> new ResourceNotFoundException("Topic not found with id: " + request.getTopicId()));

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));

        UserTopicEngagement engagement = engagementRepository
                .findByUser_UserIdAndTopic_TopicId(userId, request.getTopicId())
                .orElseGet(() -> createNewEngagement(user, topic));

        //  Update time & completion based on language
        switch (request.getLanguage()) {
            case JAVA -> {

                engagement.setJavaTimeSeconds(
                        (engagement.getJavaTimeSeconds() == null ? 0 : engagement.getJavaTimeSeconds()) + request.getTimeSpentSeconds());
                engagement.setJavaVisited(true);
            }
            case PYTHON -> {

                engagement.setPythonTimeSeconds(
                        (engagement.getPythonTimeSeconds() == null ? 0 : engagement.getPythonTimeSeconds()) + request.getTimeSpentSeconds());
                engagement.setPythonVisited(true);
            }
            case JAVASCRIPT -> {


                engagement.setJavascriptTimeSeconds(
                        (engagement.getJavascriptTimeSeconds() == null ? 0 : engagement.getJavascriptTimeSeconds()) + request.getTimeSpentSeconds());
                engagement.setJavascriptVisited(true);
            }
            case TYPESCRIPT -> {

                engagement.setTypescriptTimeSeconds(
                        (engagement.getTypescriptTimeSeconds() == null ? 0 : engagement.getTypescriptTimeSeconds()) + request.getTimeSpentSeconds());
                engagement.setTypescriptVisited(true);
            }
        }

        //  Recalculate total time
        long totalTime = (engagement.getJavaTimeSeconds() == null ? 0 : engagement.getJavaTimeSeconds()) +
                (engagement.getPythonTimeSeconds() == null ? 0 : engagement.getPythonTimeSeconds()) +
                (engagement.getJavascriptTimeSeconds() == null ? 0 : engagement.getJavascriptTimeSeconds()) +
                (engagement.getTypescriptTimeSeconds() == null ? 0 : engagement.getTypescriptTimeSeconds());
        engagement.setTotalTimeSpent((int) totalTime);

        //  Mark overall completion if all languages are completed
//        boolean allCompleted = Boolean.TRUE.equals(engagement.getJavaVisited())
//                && Boolean.TRUE.equals(engagement.getPythonVisited())
//                && Boolean.TRUE.equals(engagement.getJavascriptVisited())
//                && Boolean.TRUE.equals(engagement.getTypescriptVisited());

//        engagement.setCompleted(allCompleted);
        engagement.setLastActivityAt(LocalDateTime.now());

        UserTopicEngagement saved = engagementRepository.save(engagement);
        log.info("Engagement updated successfully for topic {} by user {}", topic.getTopicId(), userId);

        return mapToDTO(saved);
    }

    @Override
    @Transactional
    public TopicEngagementResponseDTO getTopicEngagement(Integer topicId) {

        Topic topic = topicRepository.findById(topicId)
                .orElseThrow(() -> new ResourceNotFoundException("Topic not found with id: " + topicId));

        // Fetch user
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));

        // Find existing or create new engagement with default values
        UserTopicEngagement engagement = engagementRepository
                .findByUser_UserIdAndTopic_TopicId(userId, topicId)
                .orElseGet(() -> {
                    UserTopicEngagement newEngagement = new UserTopicEngagement();
                    UserTopicEngagementId id = new UserTopicEngagementId();
                    id.setUserId(userId);
                    id.setTopicId(topicId);
                    newEngagement.setUserTopicEngagementId(id);
                    newEngagement.setUser(user);
                    newEngagement.setTopic(topic);
                    newEngagement.setLastActivityAt(LocalDateTime.now());

                    // 🕒 Set default values
                    newEngagement.setTotalTimeSpent(0);
                    newEngagement.setJavaTimeSeconds(0L);
                    newEngagement.setPythonTimeSeconds(0L);
                    newEngagement.setJavascriptTimeSeconds(0L);
                    newEngagement.setTypescriptTimeSeconds(0L);

                    newEngagement.setJavaVisited(false);
                    newEngagement.setPythonVisited(false);
                    newEngagement.setJavascriptVisited(false);
                    newEngagement.setTypescriptVisited(false);

                    newEngagement.setCompleted(false);

                    // Save to DB immediately
                    return engagementRepository.save(newEngagement);
                });

        return mapToDTO(engagement);
    }

    @Override
    @Transactional
    public TopicEngagementResponseDTO markMcqAsVisited(Integer topicId) {
        log.info("Marking MCQ as visited for topic {} by user {}", topicId, userId);

        Topic topic = topicRepository.findById(topicId)
                .orElseThrow(() -> new ResourceNotFoundException("Topic not found with id: " + topicId));

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));

        UserTopicEngagement engagement = engagementRepository
                .findByUser_UserIdAndTopic_TopicId(userId, topicId)
                .orElseGet(() -> createNewEngagement(user, topic));

        // Mark MCQ as visited
        engagement.setMcqVisited(true);
        engagement.setLastActivityAt(LocalDateTime.now());

        UserTopicEngagement saved = engagementRepository.save(engagement);
        log.info("MCQ marked as visited successfully for topic {} by user {}", topicId, userId);

        return mapToDTO(saved);
    }

    private UserTopicEngagement createNewEngagement(User user, Topic topic) {
        UserTopicEngagement engagement = new UserTopicEngagement();
        UserTopicEngagementId id = new UserTopicEngagementId();
        id.setUserId(user.getUserId());
        id.setTopicId(topic.getTopicId());

        engagement.setUserTopicEngagementId(id);
        engagement.setUser(user);
        engagement.setTopic(topic);
        engagement.setLastActivityAt(LocalDateTime.now());

        // Initialize all time fields to prevent null issues
        engagement.setTotalTimeSpent(0);
        engagement.setJavaTimeSeconds(0L);
        engagement.setPythonTimeSeconds(0L);
        engagement.setJavascriptTimeSeconds(0L);
        engagement.setTypescriptTimeSeconds(0L);

        // Initialize visited flags
        engagement.setJavaVisited(false);
        engagement.setPythonVisited(false);
        engagement.setJavascriptVisited(false);
        engagement.setTypescriptVisited(false);
        engagement.setMcqVisited(false);

        engagement.setCompleted(false);

        return engagement;
    }

    private TopicEngagementResponseDTO mapToDTO(UserTopicEngagement engagement) {
        return TopicEngagementResponseDTO.builder()
                .topicId(engagement.getTopic().getTopicId())
                .topicTitle(engagement.getTopic().getTitle())
                .totalTimeSpent(engagement.getTotalTimeSpent())
                .lastActivityAt(engagement.getLastActivityAt())
                .languageStats(Map.of(
                        "java", Map.of(
                                "timeSeconds", engagement.getJavaTimeSeconds(),
                                "completed", engagement.getJavaVisited()
                        ),
                        "python", Map.of(
                                "timeSeconds", engagement.getPythonTimeSeconds(),
                                "completed", engagement.getPythonVisited()
                        ),
                        "javascript", Map.of(
                                "timeSeconds", engagement.getJavascriptTimeSeconds(),
                                "completed", engagement.getJavascriptVisited()
                        ),
                        "typescript", Map.of(
                                "timeSeconds", engagement.getTypescriptTimeSeconds(),
                                "completed", engagement.getTypescriptVisited()
                        )
                ))
                .build();
    }
}
