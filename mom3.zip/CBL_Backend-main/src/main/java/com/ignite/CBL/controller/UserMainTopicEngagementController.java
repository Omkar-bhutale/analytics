package com.ignite.CBL.controller;

import com.ignite.CBL.dto.CompletionValidationResponse;
import com.ignite.CBL.service.UserMainTopicEngagementService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;



@RestController
@RequestMapping("/user/user-main-topic-engagement")
@RequiredArgsConstructor
@Tag(name = "User main Topic Engagement")
public class UserMainTopicEngagementController {

    private final UserMainTopicEngagementService userMainTopicEngagementService;

    @PutMapping("/{mainTopicId}/validate-completion")
    @Operation(summary = "Validate and mark completion for a MainTopic based on subtopic visits, MCQs, and Code Here engagement")
    public ResponseEntity<CompletionValidationResponse> validateAndMarkCompletion(
            @PathVariable Integer mainTopicId,
            @RequestParam String language) {


        CompletionValidationResponse response =
                userMainTopicEngagementService.validateAndMarkCompletion(mainTopicId, language.toUpperCase());


        if (response.isSuccess()) {
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.badRequest().body(response);
        }
    }




}
