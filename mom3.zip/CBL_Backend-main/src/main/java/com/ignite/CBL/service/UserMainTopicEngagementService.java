package com.ignite.CBL.service;

import com.ignite.CBL.dto.CompletionValidationResponse;
import com.ignite.CBL.dto.TopicEngagementDTO;


public interface   UserMainTopicEngagementService {
    public CompletionValidationResponse validateAndMarkCompletion(Integer mainTopicId, String language);
}
