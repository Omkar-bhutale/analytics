package com.ignite.CBL.dto;

import com.ignite.CBL.entity.Language;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
@Schema(name = "NotebookUploadRequest", description = "Form data for uploading a Jupyter notebook")
public class NotebookUploadRequest {

    @Schema(description = "MainTopic ID", example = "5")
    private Integer mainTopicId;

    @Schema(description = "Programming language of the notebook", example = "JAVA", implementation = Language.class)
    private Language language;

    @Schema(description = "Custom title for the notebook", example = "If-Else Practice Notebook")
    private String title;

    @Schema(description = "Jupyter notebook (.ipynb) file", type = "string", format = "binary")
    private MultipartFile file;
}