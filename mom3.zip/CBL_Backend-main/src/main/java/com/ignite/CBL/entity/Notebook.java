package com.ignite.CBL.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "notebooks")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Notebook {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "notebook_id")
    private Integer notebookId;

    @Column(name = "title", nullable = false)
    private String title; // short readable title (optional for UI display)

    @Column(name = "file_path", nullable = false, columnDefinition = "TEXT")
    private String filePath; // full or relative path (e.g., /uploads/notebooks/mainTopic_5/file.ipynb)

    @Column(name = "uploaded_at", nullable = false)
    private LocalDateTime uploadedAt;

    @Enumerated(EnumType.STRING)
    @Column(name = "language", nullable = false)
    private Language language;

    @Column(name = "uploaded_by", nullable = false)
    private String uploadedBy;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "main_topic_id", nullable = false)
    @JsonBackReference("main-topic-notebooks")
    private MainTopic mainTopic;

    @PrePersist
    protected void onCreate() {
        this.uploadedAt = LocalDateTime.now();
    }
}
