package com.ignite.CBL.config;


import com.ignite.CBL.entity.User;
import com.ignite.CBL.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.core.convert.converter.Converter;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtClaimNames;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.security.oauth2.server.resource.authentication.JwtGrantedAuthoritiesConverter;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;


@Component
@RequiredArgsConstructor
@Profile("!test")
public class JwtAuthConverter implements Converter<Jwt, AbstractAuthenticationToken> {

    private final JwtGrantedAuthoritiesConverter jwtAuthenticationConverter
            =new JwtGrantedAuthoritiesConverter();

    private final UserRepository userRepository;


    @Value("${spring.security.oauth2.resourceserver.jwt.principal-claim-name}")
    private  String jwtPrincipleName;

    @Value("${spring.security.oauth2.resourceserver.jwt.resource-id}")
    private  String resourceId;

    @Override
    public AbstractAuthenticationToken convert(@NonNull Jwt jwt) {

        Collection<GrantedAuthority> authorities= Stream.concat(
                        jwtAuthenticationConverter.convert(jwt).stream(),
                        extractResourceAccess(jwt).stream())
                .collect(Collectors.toSet());
        return new JwtAuthenticationToken(
                jwt,
                authorities,
                getPrincipleName(jwt)
        );
    }

    private String getPrincipleName(Jwt jwt) {
        String claimName= JwtClaimNames.SUB;
        if(jwtPrincipleName!=null){
            claimName=jwtPrincipleName;
        }
        return jwt.getClaim(claimName);

    }


    private Collection<? extends GrantedAuthority> extractResourceAccess(Jwt jwt) {
        Map<String,Object> resourceAccess;
        Map<String,Object> resource;
        Collection<String> resourceRoles;

        if(jwt.getClaim("resource_access")==null) {
            return Set.of();
        }

        if(!userRepository.existsById(jwt.getClaim("preferred_username").toString().substring(0,7))){
            User user = new User();
            user.setUserId(jwt.getClaim("preferred_username").toString().substring(0,7));
            user.setName(jwt.getClaim("name"));
            user.setCreatedAt(LocalDateTime.now());
            user.setEmail(jwt.getClaim("email"));
            userRepository.save(user);
            System.out.println(user);

        }

        resourceAccess=jwt.getClaim("resource_access");


        if(resourceAccess.get(resourceId)==null){
            return Set.of();
        }

        @SuppressWarnings("unchecked")
        Map<String, Object> resourceMap = (Map<String, Object>) resourceAccess.get(resourceId);
        resource = resourceMap;
        System.out.println(resource);

        @SuppressWarnings("unchecked")
        Collection<String> roles = (Collection<String>) resource.get("roles");
        resourceRoles = roles;

        return resourceRoles
                .stream()
                .map(role->new SimpleGrantedAuthority("ROLE_"+role))
                .collect(Collectors.toSet());
    }
}
