package com.ignite.CBL.service.impl;

import com.ignite.CBL.dto.CompletionValidationResponse;
import com.ignite.CBL.dto.TopicEngagementDTO;
import com.ignite.CBL.entity.*;
import com.ignite.CBL.exception.ResourceNotFoundException;
import com.ignite.CBL.repository.*;
import com.ignite.CBL.service.UserMainTopicEngagementService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Set;

@RequiredArgsConstructor
@Service
public class UserMainTopicEngagementServiceImpl implements UserMainTopicEngagementService {
    @Value("${user.id}")
    private String userId;

    private final MainTopicRepository mainTopicRepository;
    private final UserMainTopicEngagementRepository userMainTopicEngagementRepository;
    private final UserRepository userRepository;
    private final UserProblemEngagementRepository userProblemEngagementRepository;
    private final UserTopicEngagementRepository userTopicEngagementRepository;
    @Override
    @Transactional
    public CompletionValidationResponse validateAndMarkCompletion(Integer mainTopicId, String language) {

        MainTopic mainTopic = mainTopicRepository.findById(mainTopicId)
                .orElseThrow(() -> new ResourceNotFoundException("MainTopic not found with id: " + mainTopicId));

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));

        // 🔹 Fetch or create engagement for this main topic
        UserMainTopicEngagement mainEngagement = userMainTopicEngagementRepository
                .findByUser_UserIdAndMainTopic_MainTopicId(userId, mainTopicId)
                .orElseGet(() -> {
                    UserMainTopicEngagement e = new UserMainTopicEngagement();
                    UserMainTopicEngagementId id = new UserMainTopicEngagementId();
                    id.setUserId(userId);
                    id.setMainTopicId(mainTopicId);
                    e.setUserTopicEngagementId(id);
                    e.setUser(user);
                    e.setMainTopic(mainTopic);
                    e.setLastActivityAt(LocalDateTime.now());
                    return userMainTopicEngagementRepository.save(e);
                });

        // 🔹 Validate all subtopics for that language
        Set<Topic> subtopics = mainTopic.getTopics();
        boolean allSubtopicsVisited = true;
        boolean allMcqsVisited = true;

        for (Topic topic : subtopics) {
            Optional<UserTopicEngagement> engagementOpt =
                    userTopicEngagementRepository.findByUser_UserIdAndTopic_TopicId(userId, topic.getTopicId());

            if (engagementOpt.isEmpty()) {
                allSubtopicsVisited = false;
                break;
            }

            UserTopicEngagement engagement = engagementOpt.get();

            boolean languageVisited = switch (language.toUpperCase()) {
                case "JAVA" -> Boolean.TRUE.equals(engagement.getJavaVisited());
                case "PYTHON" -> Boolean.TRUE.equals(engagement.getPythonVisited());
                case "JAVASCRIPT" -> Boolean.TRUE.equals(engagement.getJavascriptVisited());
                case "TYPESCRIPT" -> Boolean.TRUE.equals(engagement.getTypescriptVisited());
                default -> false;
            };

            if (!languageVisited) {
                allSubtopicsVisited = false;
            }

            if (Boolean.FALSE.equals(engagement.getMcqVisited())) {
                allMcqsVisited = false;
            }
        }

        // 🔹 Check Code Here engagement (Main Problem)
        Problem mainProblem = mainTopic.getMainProblem();
        if (mainProblem == null) {
            return new CompletionValidationResponse(false, "MainTopic has no associated Code Here problem.");
        }

        Optional<UserProblemEngagement> problemEngagementOpt =
                userProblemEngagementRepository.findById_UserIdAndId_ProblemId(userId, mainProblem.getProblemId());

        if (problemEngagementOpt.isEmpty()) {
            return new CompletionValidationResponse(false, "You have not yet opened the Code Here problem.");
        }

        UserProblemEngagement problemEngagement = problemEngagementOpt.get();

        // 🔹 Check per-language time and completion for Code Here
        long timeSpent = switch (language.toUpperCase()) {
            case "JAVA" -> problemEngagement.getJavaTimeSeconds();
            case "PYTHON" -> problemEngagement.getPythonTimeSeconds();
            case "JAVASCRIPT" -> problemEngagement.getJavascriptTimeSeconds();
            case "TYPESCRIPT" -> problemEngagement.getTypescriptTimeSeconds();
            default -> 0L;
        };

        boolean problemSolved = switch (language.toUpperCase()) {
            case "JAVA" -> Boolean.TRUE.equals(problemEngagement.getJavaCompleted());
            case "PYTHON" -> Boolean.TRUE.equals(problemEngagement.getPythonCompleted());
            case "JAVASCRIPT" -> Boolean.TRUE.equals(problemEngagement.getJavascriptCompleted());
            case "TYPESCRIPT" -> Boolean.TRUE.equals(problemEngagement.getTypescriptCompleted());
            default -> false;
        };

        boolean codeHereValid = (timeSpent >= 120) || problemSolved;

        if (!allSubtopicsVisited) {
            return new CompletionValidationResponse(false, "Please visit all subtopics for " + language + ".");
        }
        if (!allMcqsVisited) {
            return new CompletionValidationResponse(false, "Please complete all MCQs for all subtopics.");
        }
        if (!codeHereValid) {
            return new CompletionValidationResponse(false, "Please spend at least 2 minutes or solve the Code Here problem for " + language + ".");
        }

        // ✅ All conditions met → mark completion
        mainEngagement.setCompleted(true);

        switch (language.toUpperCase()) {
            case "JAVA" -> mainEngagement.setJavaCompleted(true);
            case "PYTHON" -> mainEngagement.setPythonCompleted(true);
            case "JAVASCRIPT" -> mainEngagement.setJavascriptCompleted(true);
            case "TYPESCRIPT" -> mainEngagement.setTypescriptCompleted(true);
        }

        mainEngagement.setLastActivityAt(LocalDateTime.now());
        userMainTopicEngagementRepository.save(mainEngagement);

        return new CompletionValidationResponse(true, "Congratulations! Main topic marked as completed for " + language + ".");
    }

}
