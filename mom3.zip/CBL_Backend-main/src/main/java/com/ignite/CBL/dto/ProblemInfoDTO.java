package com.ignite.CBL.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.ignite.CBL.entity.Difficulty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashSet;
import java.util.Set;

// ProblemDTO.java
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProblemInfoDTO {

    private Integer id;
    private String title;

}