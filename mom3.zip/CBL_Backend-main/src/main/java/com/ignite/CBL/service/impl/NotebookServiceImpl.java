package com.ignite.CBL.service.impl;

import com.ignite.CBL.dto.NotebookResponseDTO;
import com.ignite.CBL.entity.Language;
import com.ignite.CBL.entity.MainTopic;
import com.ignite.CBL.entity.Notebook;
import com.ignite.CBL.exception.ResourceNotFoundException;
import com.ignite.CBL.repository.MainTopicRepository;
import com.ignite.CBL.repository.NotebookRepository;
import com.ignite.CBL.service.NotebookService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class NotebookServiceImpl implements NotebookService {

    private final MainTopicRepository mainTopicRepository;
    private final NotebookRepository notebookRepository;

    @Value("${file.upload-dir}")
    private String uploadBaseDir;

    @Value("${user.id}")
    private String smeUserId;


    @Override
    public String uploadNotebook(Integer mainTopicId, Language language, String title, MultipartFile file) {
        log.info("Uploading notebook for mainTopic [{}] and language [{}] by SME [{}]", mainTopicId, language, smeUserId);

        String originalFilename = file.getOriginalFilename();
        if (file.isEmpty() || originalFilename == null || !originalFilename.endsWith(".ipynb")) {
            throw new IllegalArgumentException("Only .ipynb files are allowed.");
        }

        MainTopic mainTopic = mainTopicRepository.findById(mainTopicId)
                .orElseThrow(() -> new ResourceNotFoundException("MainTopic not found with id: " + mainTopicId));

        Path topicDir = Paths.get(uploadBaseDir, "mainTopic_" + mainTopicId);
        try {
            Files.createDirectories(topicDir);
        } catch (IOException e) {
            throw new RuntimeException("Failed to create upload directory.", e);
        }

        String timestamp = LocalDateTime.now().toString().replace(":", "-");
        String storedFileName = language.name().toLowerCase() + "_" + timestamp + "_" + originalFilename;
        Path filePath = topicDir.resolve(storedFileName);

        try {
            file.transferTo(filePath.toFile());
        } catch (IOException e) {
            throw new RuntimeException("Error saving notebook file.", e);
        }

        String notebookTitle = (title == null || title.trim().isEmpty()) ? originalFilename : title.trim();

        Notebook notebook = Notebook.builder()
                .title(notebookTitle)
                .filePath(filePath.toString())
                .language(language)
                .uploadedBy(smeUserId)
                .mainTopic(mainTopic)
                .uploadedAt(LocalDateTime.now())
                .build();

        notebookRepository.save(notebook);
        log.info("Notebook uploaded successfully: {}", notebook.getFilePath());

        return "Notebook uploaded successfully for " + language + " (" + notebookTitle + ")";
    }

    // ✅ Get all notebooks
    @Override
    public List<NotebookResponseDTO> getAllNotebooks(Integer mainTopicId) {
        List<Notebook> notebooks = (mainTopicId != null)
                ? notebookRepository.findByMainTopic_MainTopicId(mainTopicId)
                : notebookRepository.findAll();

        if (notebooks.isEmpty()) {
            throw new ResourceNotFoundException("No notebooks found" + (mainTopicId != null ? " for MainTopic ID: " + mainTopicId : ""));
        }

        return notebooks.stream()
                .map(nb -> NotebookResponseDTO.builder()
                        .notebookId(nb.getNotebookId())
                        .title(nb.getTitle())
                        .language(nb.getLanguage().name())
                        .uploadedBy(nb.getUploadedBy())
                        .uploadedAt(nb.getUploadedAt())
                        .downloadUrl("/sme/notebooks/download/" + nb.getNotebookId())
                        .build())
                .collect(Collectors.toList());
    }

    // ✅ Download notebook
    @Override
    public Resource downloadNotebook(Integer notebookId) {
        Notebook notebook = notebookRepository.findById(notebookId)
                .orElseThrow(() -> new ResourceNotFoundException("Notebook not found with ID: " + notebookId));

        File file = new File(notebook.getFilePath());
        if (!file.exists()) {
            throw new ResourceNotFoundException("Notebook file not found on server.");
        }

        return new FileSystemResource(file);
    }

    // ✅ Update notebook title
    @Override
    public String updateNotebookTitle(Integer notebookId, String newTitle) {
        Notebook notebook = notebookRepository.findById(notebookId)
                .orElseThrow(() -> new ResourceNotFoundException("Notebook not found with ID: " + notebookId));

        notebook.setTitle(newTitle.trim());
        notebookRepository.save(notebook);

        return "Notebook title updated successfully to: " + newTitle;
    }

    // ✅ Delete notebook
    @Override
    public String deleteNotebook(Integer notebookId) {
        Notebook notebook = notebookRepository.findById(notebookId)
                .orElseThrow(() -> new ResourceNotFoundException("Notebook not found with ID: " + notebookId));

        File file = new File(notebook.getFilePath());
        if (file.exists()) {
            if (!file.delete()) {
                log.warn("Failed to delete file: {}", file.getPath());
            } else {
                log.info("Notebook file deleted successfully: {}", file.getPath());
            }
        }

        notebookRepository.delete(notebook);
        return "Notebook deleted successfully (ID: " + notebookId + ")";
    }
}
