package com.ignite.CBL.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ignite.CBL.dto.ProblemInfoDTO;
import com.ignite.CBL.entity.Language;
import com.ignite.CBL.entity.Problem;
import com.ignite.CBL.entity.User;
import com.ignite.CBL.entity.UserProblemReport;
import com.ignite.CBL.exception.ResourceNotFoundException;
import com.ignite.CBL.repository.*;
import com.ignite.CBL.service.AdminDashboardService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AdminDashboardServiceImpl implements AdminDashboardService {

    private final AdminDashboardRepository adminDashboardRepository;
    private final UserRepository userRepository;
    private final ProblemRepository problemRepository;
    private final ProblemSubmissionRepository problemSubmissionRepository;
    private final UserProblemEngagementRepository userProblemEngagementRepository;
    private final UserProblemReportRepository userProblemReportRepository;

    @Override
    public long countTotalSolvedInJava() {
        return adminDashboardRepository.countProblemsSolvedByLanguage("JAVA");
    }

    @Override
    public long countTotalSolvedPython() {
        return adminDashboardRepository.countProblemsSolvedByLanguage("PYTHON");
    }

    @Override
    public long countTotalSolvedJavaScript() {
        return adminDashboardRepository.countProblemsSolvedByLanguage("JAVASCRIPT");
    }

    @Override
    public long countTotalSolvedTypeScript() {
        return adminDashboardRepository.countProblemsSolvedByLanguage("TYPESCRIPT");
    }
    @Override
    public long countTotalUsers() {
        return userRepository.count();
    }

    @Override
    public long countTotalProblems() {
        return problemRepository.count();
    }

    @Override
    public long countTotalSubmissions() {
        return problemSubmissionRepository.count();
    }

    @Override
    public List<ProblemInfoDTO> fetchUserProblemSolvedInfo(String userId) {

        return userProblemEngagementRepository.findUserSolvedProblems(userId);
//        return null;
    }
    public JsonNode getUserProblemInsight(String userId, Integer problemId) {
        return userProblemReportRepository.findInsightByUserIdAndProblemId(userId,problemId);

    }


}