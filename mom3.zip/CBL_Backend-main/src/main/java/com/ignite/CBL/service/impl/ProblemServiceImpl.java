package com.ignite.CBL.service.impl;

import com.ignite.CBL.dto.ProblemCodeResponceDTO;
import com.ignite.CBL.dto.ProblemDTO;
import com.ignite.CBL.dto.ProblemTestCaseDTO;
import com.ignite.CBL.entity.Difficulty;
import com.ignite.CBL.entity.Problem;
import com.ignite.CBL.entity.ProblemTestCase;
import com.ignite.CBL.entity.Topic;
import com.ignite.CBL.exception.ResourceNotFoundException;
import com.ignite.CBL.repository.ProblemRepository;
import com.ignite.CBL.repository.TopicRepository;
import com.ignite.CBL.service.ProblemService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class ProblemServiceImpl implements ProblemService {

    private final ProblemRepository problemRepository;
    private final TopicRepository topicRepository;

    @Override
    public ProblemDTO saveProblem(Integer topicId, ProblemDTO problemDTO) {
        log.debug("Saving problem for topic id: {}", topicId);
        Topic topic = topicRepository.findById(topicId)
                .orElseThrow(() -> new ResourceNotFoundException("Topic not found with id: " + topicId));

        Problem problem = new Problem();
        problem.setTitle(problemDTO.getTitle());
        problem.setDescription(problemDTO.getDescription());
        problem.setDifficulty(problemDTO.getDifficulty());
        problem.setTopic(topic);

        if (problemDTO.getTestCases() != null) {
            problemDTO.getTestCases().forEach(tc -> {
                ProblemTestCase testCase = new ProblemTestCase();
                testCase.setInput(tc.getInput());
                testCase.setExpectedOutput(tc.getExpectedOutput());
                testCase.setIsPublic(tc.getIsPublic());
                problem.addTestCase(testCase);
            });
        }

        Problem savedProblem = problemRepository.save(problem);
        log.debug("Saved problem with id: {}", savedProblem.getProblemId());
        return convertToDTO(savedProblem);
    }

    @Override
    public List<ProblemDTO> saveProblemsByTopicId(Integer topicId, List<ProblemDTO> problemDTOs) {
        log.debug("Saving {} problems for topic id: {}", problemDTOs != null ? problemDTOs.size() : 0, topicId);
        if (topicId == null || problemDTOs == null || problemDTOs.isEmpty()) {
            log.warn("No problems to save for topic id: {}", topicId);
            return Collections.emptyList();
        }

        Topic topic = topicRepository.findById(topicId)
                .orElseThrow(() -> new ResourceNotFoundException("Topic not found with id: " + topicId));

        // First save all problems
        List<Problem> problems = problemDTOs.stream()
                .map(dto -> {
                    Problem problem = new Problem();
                    problem.setTitle(dto.getTitle());
                    problem.setDescription(dto.getDescription());
                    problem.setDifficulty(dto.getDifficulty());
                    problem.setTopic(topic);
                    problem.setHint(dto.getHint());

                    return problem;
                })
                .collect(Collectors.toList());

        List<Problem> savedProblems = problemRepository.saveAll(problems);

        // Then handle test cases for each problem
        for (int i = 0; i < savedProblems.size(); i++) {
            Problem problem = savedProblems.get(i);
            ProblemDTO dto = problemDTOs.get(i);
            
            if (dto.getTestCases() != null && !dto.getTestCases().isEmpty()) {
                for (ProblemTestCaseDTO tcDto : dto.getTestCases()) {
                    ProblemTestCase testCase = new ProblemTestCase();
                    testCase.setInput(tcDto.getInput());
                    testCase.setExpectedOutput(tcDto.getExpectedOutput());
                    testCase.setIsPublic(tcDto.getIsPublic());
                    testCase.setProblem(problem);
                    problem.addTestCase(testCase);
                }
            }
        }

        // Save again to persist the test cases
        savedProblems = problemRepository.saveAll(savedProblems);
        
        List<ProblemDTO> result = savedProblems.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
        log.debug("Saved {} problems for topic id: {}", result.size(), topicId);
        return result;
    }

    @Override
    public ProblemDTO fetchProblemById(Integer problemId) {
        log.debug("Fetching problem by id: {}", problemId);
        Problem problem = problemRepository.findById(problemId)
                .orElseThrow(() -> {
                    log.error("Problem not found with id: {}", problemId);
                    return new ResourceNotFoundException("Problem not found with id: " + problemId);
                });
        log.debug("Fetched problem with id: {}", problemId);
        return convertToDTO(problem);
    }

    @Override
    public List<ProblemDTO> fetchProblemsByTopicId(Integer topicId) {
        log.debug("Fetching problems for topic id: {}", topicId);
        if (!topicRepository.existsById(topicId)) {
            log.error("Topic not found with id: {}", topicId);
            throw new ResourceNotFoundException("Topic not found with id: " + topicId);
        }
        return problemRepository.findByTopic_TopicId(topicId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }


    @Override
    public void deleteProblemById(Integer problemId) {
        log.debug("Deleting problem with id: {}", problemId);
        if (!problemRepository.existsById(problemId)) {
            log.error("Problem not found with id: {}", problemId);
            throw new ResourceNotFoundException("Problem not found with id: " + problemId);
        }
        problemRepository.deleteById(problemId);
        log.debug("Deleted problem with id: {}", problemId);
    }

    @Override
    @Transactional
    public int deleteProblemByTopicId(Integer topicId) {
        log.debug("Deleting all problems for topic id: {}", topicId);
        if (!topicRepository.existsById(topicId)) {
            log.error("Topic not found with id: {}", topicId);
            throw new ResourceNotFoundException("Topic not found with id: " + topicId);
        }
        
        List<Problem> problems = problemRepository.findByTopic_TopicId(topicId);
        int count = problems.size();
        
        if (count > 0) {
            problemRepository.deleteAll(problems);
            log.debug("Deleted {} problems for topic id: {}", count, topicId);
        } else {
            log.debug("No problems found to delete for topic id: {}", topicId);
        }
        
        return count;
    }

    private ProblemDTO convertToDTO(Problem problem) {
        ProblemDTO dto = new ProblemDTO();
        dto.setProblemId(problem.getProblemId());
        dto.setTitle(problem.getTitle());
        dto.setDescription(problem.getDescription());
        dto.setDifficulty(problem.getDifficulty());

        // Convert test cases if needed
        if (problem.getTestCases() != null) {
            Set<ProblemTestCaseDTO> testCaseDTOs = problem.getTestCases().stream()
                    .map(tc -> {
                        ProblemTestCaseDTO tcDto = new ProblemTestCaseDTO();
                        tcDto.setTestCaseId(tc.getTestCaseId());
                        tcDto.setInput(tc.getInput());
                        tcDto.setExpectedOutput(tc.getExpectedOutput());
                        tcDto.setIsPublic(tc.getIsPublic());
                        return tcDto;
                    })
                    .collect(Collectors.toSet());
            dto.setTestCases(testCaseDTOs);
        }

        return dto;
    }
}