package com.ignite.CBL.repository;

import com.ignite.CBL.entity.view.TopicProblemLanguageAverageView;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TopicProblemLanguageAverageViewRepository extends JpaRepository<TopicProblemLanguageAverageView, Integer> {

    // Get all topic-level (non-mandatory) problem averages ordered by problem_id
    List<TopicProblemLanguageAverageView> findAllByOrderByProblemIdAsc();

    // Get averages for a specific main topic
    List<TopicProblemLanguageAverageView> findByMainTopicIdOrderByProblemIdAsc(Integer mainTopicId);

    // Get averages for a specific topic
    List<TopicProblemLanguageAverageView> findByTopicIdOrderByProblemIdAsc(Integer topicId);

    // Get averages by difficulty
    List<TopicProblemLanguageAverageView> findByDifficultyOrderByProblemIdAsc(String difficulty);
}
