package com.ignite.CBL.repository;

import com.ignite.CBL.dto.ProblemInfoDTO;
import com.ignite.CBL.dto.UserDetailedStats;
import com.ignite.CBL.dto.UserProblemStats;
import com.ignite.CBL.entity.Language;
import com.ignite.CBL.entity.ProblemSubmission;
import com.ignite.CBL.entity.UserProblemEngagement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AdminDashboardRepository extends JpaRepository<UserProblemEngagement, Long> {

    // Total number of users
    // Total number of users (directly from users table)
    @Query("SELECT COUNT(u) FROM User u")
    Long countTotalUsers();

    // Total number of problems (directly from problems table)
    @Query("SELECT COUNT(p) FROM Problem p")
    Long countTotalProblems();


    // Total number of problems solved (across all users)
    @Query("SELECT COUNT(DISTINCT upe.id.problemId) FROM UserProblemEngagement upe WHERE upe.isSolved = true")
    Long countTotalProblemsSolved();
    
    // Total number of problems solved in Java
//    @Query("SELECT COUNT(DISTINCT upe.id.problemId) " +
//           "FROM UserProblemEngagement upe " +
//           "JOIN ProblemSubmission ps ON upe.id.userId = ps.user.userId AND upe.id.problemId = ps.problem.problemId " +
//           "WHERE upe.isSolved = true AND ps.language = :language")
//    Long countProblemsSolvedByLanguage(@Param("language") Language language);
    
    // Get all solved problems with their languages
    @Query("SELECT upe.id.problemId, ps.language " +
           "FROM UserProblemEngagement upe " +
           "JOIN ProblemSubmission ps ON upe.id.userId = ps.user.userId AND upe.id.problemId = ps.problem.problemId " +
           "WHERE upe.isSolved = true")
    List<Object[]> findAllSolvedProblemsWithLanguages();

    @Query(value = "SELECT COUNT(DISTINCT upe.problem_id) " +
            "FROM user_problem_engagement upe " +
            "JOIN problem_submissions ps ON upe.user_id = ps.user_id AND upe.problem_id = ps.problem_id " +
            "WHERE upe.is_solved = true AND ps.language = ?1",
            nativeQuery = true)
    Long countProblemsSolvedByLanguage(String language);

    // 1. Total problems solved by a specific user
    @Query(value = "SELECT COUNT(DISTINCT upe.problem_id) " +
            "FROM user_problem_engagement upe " +
            "WHERE upe.user_id = :userId AND upe.is_solved = true",
            nativeQuery = true)
    Long countProblemsSolvedByUser(@Param("userId") String userId);

    // 2. Count of problems solved by language for a specific user
    @Query(value = "SELECT ps.language, COUNT(DISTINCT upe.problem_id) " +
            "FROM user_problem_engagement upe " +
            "JOIN problem_submissions ps ON upe.user_id = ps.user_id AND upe.problem_id = ps.problem_id " +
            "WHERE upe.user_id = :userId AND upe.is_solved = true " +
            "GROUP BY ps.language",
            nativeQuery = true)
    List<Object[]> countProblemsByLanguageForUser(@Param("userId") String userId);

    // 3. Count of problems solved by difficulty for a specific user
    @Query(value = "SELECT p.difficulty, COUNT(DISTINCT upe.problem_id) " +
            "FROM user_problem_engagement upe " +
            "JOIN problems p ON upe.problem_id = p.problem_id " +
            "WHERE upe.user_id = :userId AND upe.is_solved = true " +
            "GROUP BY p.difficulty",
            nativeQuery = true)
    List<Object[]> countProblemsByDifficultyForUser(@Param("userId") String userId);

    @Query(value = "SELECT " +
            "u.user_id as userId, " +
            "u.name as userName, " +
            "COUNT(DISTINCT upe.problem_id) as totalSolved, " +
            "COUNT(DISTINCT CASE WHEN ps.language = 'JAVA' THEN upe.problem_id END) as solvedInJava, " +
            "COUNT(DISTINCT CASE WHEN ps.language = 'PYTHON' THEN upe.problem_id END) as solvedInPython, " +
            "COUNT(DISTINCT CASE WHEN ps.language = 'JAVASCRIPT' THEN upe.problem_id END) as solvedInJavascript, " +
            "COUNT(DISTINCT CASE WHEN ps.language = 'TYPESCRIPT' THEN upe.problem_id END) as solvedInTypescript " +
            "FROM users u " +
            "LEFT JOIN user_problem_engagement upe ON u.user_id = upe.user_id AND upe.is_solved = true " +
            "LEFT JOIN problem_submissions ps ON upe.user_id = ps.user_id AND upe.problem_id = ps.problem_id " +
            "GROUP BY u.user_id, u.name " +
            "ORDER BY totalSolved DESC", nativeQuery = true)
    List<UserProblemStats> findAllUsersWithProblemStats();

    @Query(value = "SELECT " +
            "u.user_id as userId, " +
            "u.name as userName, " +
            "u.email as userEmail, "+
            "u.insights as userInsights ,"+
            "(SELECT COUNT(DISTINCT p.problem_id) FROM problems p) as totalProblems, " +
            "COUNT(DISTINCT upe.problem_id) as totalSolved, " +
            "COUNT(DISTINCT CASE WHEN p.difficulty = 'EASY' THEN upe.problem_id END) as easySolved, " +
            "COUNT(DISTINCT CASE WHEN p.difficulty = 'MEDIUM' THEN upe.problem_id END) as mediumSolved, " +
            "COUNT(DISTINCT CASE WHEN p.difficulty = 'HARD' THEN upe.problem_id END) as hardSolved, " +
            "COUNT(DISTINCT CASE WHEN ps.language = 'JAVA' THEN upe.problem_id END) as javaSolved, " +
            "COUNT(DISTINCT CASE WHEN ps.language = 'PYTHON' THEN upe.problem_id END) as pythonSolved, " +
            "COUNT(DISTINCT CASE WHEN ps.language = 'JAVASCRIPT' THEN upe.problem_id END) as javascriptSolved, " +
            "COUNT(DISTINCT CASE WHEN ps.language = 'TYPESCRIPT' THEN upe.problem_id END) as typescriptSolved, " +
            "(SELECT COUNT(*) FROM problems p WHERE p.difficulty = 'EASY') as easyTotal, " +
            "(SELECT COUNT(*) FROM problems p WHERE p.difficulty = 'MEDIUM') as mediumTotal, " +
            "(SELECT COUNT(*) FROM problems p WHERE p.difficulty = 'HARD') as hardTotal " +
            "FROM users u " +
            "LEFT JOIN user_problem_engagement upe ON u.user_id = upe.user_id AND upe.is_solved = true " +
            "LEFT JOIN problem_submissions ps ON upe.user_id = ps.user_id AND upe.problem_id = ps.problem_id " +
            "LEFT JOIN problems p ON upe.problem_id = p.problem_id " +
            "WHERE u.user_id = :userId " +
            "GROUP BY u.user_id, u.name", nativeQuery = true)
    Optional<UserDetailedStats> findUserDetailedStats(@Param("userId") String userId);

//    List<ProblemInfoDTO> findUserProblemInfos(@Param("userId") String userId);




}