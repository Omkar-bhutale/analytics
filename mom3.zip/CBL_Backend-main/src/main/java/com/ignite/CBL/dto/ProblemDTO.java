package com.ignite.CBL.dto;

import com.fasterxml.jackson.databind.JsonNode;
import com.ignite.CBL.entity.Difficulty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashSet;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProblemDTO {
    private Integer problemId;
    private String title;
    private String description;
    private Difficulty difficulty;
    private Set<ProblemTestCaseDTO> testCases = new HashSet<>();

    private JsonNode hint;


}