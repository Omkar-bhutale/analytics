package com.ignite.CBL.service;

import com.ignite.CBL.dto.TopicEngagementResponseDTO;
import com.ignite.CBL.dto.TopicLanguageEngagementRequestDTO;

public interface UserTopicEngagementService {

    TopicEngagementResponseDTO updateLanguageWiseEngagement(TopicLanguageEngagementRequestDTO requestDTO);

    TopicEngagementResponseDTO getTopicEngagement(Integer topicId);

    TopicEngagementResponseDTO markMcqAsVisited(Integer topicId);
}