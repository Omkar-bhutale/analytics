package com.ignite.CBL.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TopicEngagementResponseDTO {

    private Integer topicId;
    private String topicTitle;


    private int totalTimeSpent;



    private Map<String, Object> languageStats;

    private LocalDateTime lastActivityAt;
}
