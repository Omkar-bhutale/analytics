package com.ignite.CBL.controller;

import com.ignite.CBL.dto.MainTopicLanguageAverageDTO;
import com.ignite.CBL.dto.ProblemLanguageAverageDTO;
import com.ignite.CBL.dto.TopicProblemLanguageAverageDTO;
import com.ignite.CBL.service.MainTopicLanguageAverageService;
import com.ignite.CBL.service.ProblemLanguageAverageService;
import com.ignite.CBL.service.TopicProblemLanguageAverageService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/open/analytics")
@RequiredArgsConstructor
@Tag(name = "Admin Analytics", description = "APIs for analytics on main topic and problem language averages")
public class MainTopicLanguageAverageController {

    private final MainTopicLanguageAverageService averageService;
    private final ProblemLanguageAverageService problemAverageService;
    private final TopicProblemLanguageAverageService topicProblemAverageService;

    @GetMapping("/main-topic-averages")
    @Operation(
        summary = "Get average time spent on each language per main topic",
        description = "Returns average time (in seconds) spent by all users on Java, Python, JavaScript, TypeScript, and overall per main topic"
    )
    public ResponseEntity<List<MainTopicLanguageAverageDTO>> getMainTopicLanguageAverages() {
        return ResponseEntity.ok(averageService.getMainTopicLanguageAverages());
    }

    @GetMapping("/problem-averages")
    @Operation(
        summary = "Get average time spent on each language per problem (ALL problems)",
        description = "Returns average time (in seconds) spent by all users on Java, Python, JavaScript, TypeScript, and overall per problem with difficulty and topic information. Includes both mandatory and non-mandatory problems."
    )
    public ResponseEntity<List<ProblemLanguageAverageDTO>> getProblemLanguageAverages() {
        return ResponseEntity.ok(problemAverageService.getProblemLanguageAverages());
    }

    @GetMapping("/problem-averages/main-topic/{mainTopicId}")
    @Operation(
        summary = "Get average time spent on each language per problem for a specific main topic (ALL problems)",
        description = "Returns average time spent by all users on each language for ALL problems within a specific main topic"
    )
    public ResponseEntity<List<ProblemLanguageAverageDTO>> getProblemLanguageAveragesByMainTopic(
            @Parameter(description = "ID of the main topic", required = true)
            @PathVariable Integer mainTopicId) {
        return ResponseEntity.ok(problemAverageService.getProblemLanguageAveragesByMainTopic(mainTopicId));
    }

    @GetMapping("/problem-averages/topic/{topicId}")
    @Operation(
        summary = "Get average time spent on each language per problem for a specific topic (ALL problems)",
        description = "Returns average time spent by all users on each language for ALL problems within a specific topic"
    )
    public ResponseEntity<List<ProblemLanguageAverageDTO>> getProblemLanguageAveragesByTopic(
            @Parameter(description = "ID of the topic", required = true)
            @PathVariable Integer topicId) {
        return ResponseEntity.ok(problemAverageService.getProblemLanguageAveragesByTopic(topicId));
    }

    @GetMapping("/problem-averages/difficulty/{difficulty}")
    @Operation(
        summary = "Get average time spent on each language per problem for a specific difficulty level (ALL problems)",
        description = "Returns average time spent by all users on each language for ALL problems of a specific difficulty (EASY, MEDIUM, HARD)"
    )
    public ResponseEntity<List<ProblemLanguageAverageDTO>> getProblemLanguageAveragesByDifficulty(
            @Parameter(description = "Problem difficulty (EASY, MEDIUM, HARD)", required = true)
            @PathVariable String difficulty) {
        return ResponseEntity.ok(problemAverageService.getProblemLanguageAveragesByDifficulty(difficulty));
    }

    // Topic-level (non-mandatory) problem endpoints

    @GetMapping("/topic-problem-averages")
    @Operation(
        summary = "Get average time spent on each language per topic-level problem (NON-MANDATORY only)",
        description = "Returns average time (in seconds) spent by all users on Java, Python, JavaScript, TypeScript, and overall for topic-level problems only. Excludes mandatory main topic problems."
    )
    public ResponseEntity<List<TopicProblemLanguageAverageDTO>> getTopicProblemLanguageAverages() {
        return ResponseEntity.ok(topicProblemAverageService.getTopicProblemLanguageAverages());
    }

    @GetMapping("/topic-problem-averages/main-topic/{mainTopicId}")
    @Operation(
        summary = "Get average time spent on each language per topic-level problem for a specific main topic (NON-MANDATORY only)",
        description = "Returns average time spent by all users on each language for topic-level problems within a specific main topic. Excludes mandatory problems."
    )
    public ResponseEntity<List<TopicProblemLanguageAverageDTO>> getTopicProblemLanguageAveragesByMainTopic(
            @Parameter(description = "ID of the main topic", required = true)
            @PathVariable Integer mainTopicId) {
        return ResponseEntity.ok(topicProblemAverageService.getTopicProblemLanguageAveragesByMainTopic(mainTopicId));
    }

    @GetMapping("/topic-problem-averages/topic/{topicId}")
    @Operation(
        summary = "Get average time spent on each language per topic-level problem for a specific topic (NON-MANDATORY only)",
        description = "Returns average time spent by all users on each language for topic-level problems within a specific topic. Excludes mandatory problems."
    )
    public ResponseEntity<List<TopicProblemLanguageAverageDTO>> getTopicProblemLanguageAveragesByTopic(
            @Parameter(description = "ID of the topic", required = true)
            @PathVariable Integer topicId) {
        return ResponseEntity.ok(topicProblemAverageService.getTopicProblemLanguageAveragesByTopic(topicId));
    }

    @GetMapping("/topic-problem-averages/difficulty/{difficulty}")
    @Operation(
        summary = "Get average time spent on each language per topic-level problem for a specific difficulty level (NON-MANDATORY only)",
        description = "Returns average time spent by all users on each language for topic-level problems of a specific difficulty (EASY, MEDIUM, HARD). Excludes mandatory problems."
    )
    public ResponseEntity<List<TopicProblemLanguageAverageDTO>> getTopicProblemLanguageAveragesByDifficulty(
            @Parameter(description = "Problem difficulty (EASY, MEDIUM, HARD)", required = true)
            @PathVariable String difficulty) {
        return ResponseEntity.ok(topicProblemAverageService.getTopicProblemLanguageAveragesByDifficulty(difficulty));
    }
}