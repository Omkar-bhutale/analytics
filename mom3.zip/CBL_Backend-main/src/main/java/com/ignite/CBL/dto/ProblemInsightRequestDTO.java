package com.ignite.CBL.dto;

import com.ignite.CBL.entity.Language;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProblemInsightRequestDTO {

    private String question;           // problem description
    private String user_algorithm;     // algorithm steps (from AlgorithmSubmission)
    private String user_pseudocode;    // pseudocode (from PseudocodeSubmission)

    private List<LanguageAttemptDTO> attempts;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class LanguageAttemptDTO {
        private String language;
        private String code;
        private Long time_taken;
        private Integer is_test_cases_passed;
        private Integer total_no_test_cases;
    }
}
