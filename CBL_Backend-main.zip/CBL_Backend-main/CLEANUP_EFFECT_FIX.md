# 🐛 Cleanup Effect Bug Fix

**Date:** November 10, 2025  
**Issue:** Cleanup function running every second instead of only on topic/language switch  
**Status:** ✅ FIXED

---

## 🔴 Problem

The cleanup `useEffect` was sending API requests **every second** instead of only when switching topics/languages:

```
✅ Cleanup: Sent 1s for Subtopic 20 (Methods and Instance Variables) in Java
✅ Cleanup: Sent 1s for Subtopic 20 (Methods and Instance Variables) in Java
✅ Cleanup: Sent 1s for Subtopic 20 (Methods and Instance Variables) in Java
... (repeating every second)
```

**Error:**
```
PUT http://10.57.155.30:8081/user/topic-engagement/language 500 (Internal Server Error)
```

---

## 🔍 Root Cause

The cleanup `useEffect` had `timers` in its dependency array:

```javascript
useEffect(() => {
    return () => {
        // Cleanup logic using timers[currentTimerKey]
    };
}, [currentTimerKey, selectedSubtopic, timers, findTopicId]);
//                                      ^^^^^^ PROBLEM!
```

**Why this caused the issue:**

1. `timers` state updates **every second** (from the timer interval)
2. When `timers` changes, React re-runs the effect
3. Before re-running, React calls the **cleanup function** (the `return` statement)
4. This cleanup function sends the API request
5. Result: API request sent every second! ❌

---

## ✅ Solution

**Remove `timers` from the dependency array** and capture the current values at effect setup time:

```javascript
useEffect(() => {
    // ✅ Capture current values when effect runs
    const prevTimerKey = currentTimerKey;
    const prevSubtopic = selectedSubtopic;

    return () => {
        // Cleanup: use captured values
        if (prevTimerKey && prevSubtopic) {
            const currentTime = timers[prevTimerKey] || 0;
            // ... send cleanup request
        }
    };
    // ✅ FIXED: Removed 'timers' from dependencies
}, [currentTimerKey, selectedSubtopic, findTopicId]);
```

**How this fixes it:**

1. Effect only re-runs when `currentTimerKey` or `selectedSubtopic` **actually changes**
2. Cleanup function only runs when:
   - User switches to a different subtopic
   - User switches to a different language
   - Component unmounts (page navigation)
3. Timer ticking every second no longer triggers cleanup ✅

---

## 🧪 Expected Behavior After Fix

### **Before Fix (❌ Wrong):**
```
00:00:01 → ✅ Cleanup: Sent 1s
00:00:02 → ✅ Cleanup: Sent 1s
00:00:03 → ✅ Cleanup: Sent 1s
... (every second)
```

### **After Fix (✅ Correct):**
```
User views Arrays in Java for 45 seconds
User switches to Linked Lists
→ ✅ Cleanup: Sent 15s for Subtopic 1 (Arrays) in Java
(No more requests until next switch)
```

---

## 📊 When Cleanup Should Run

| Scenario | Should Send Cleanup? | Why |
|----------|---------------------|-----|
| Timer ticks (1s, 2s, 3s...) | ❌ NO | Just counting, no switch |
| User switches subtopic | ✅ YES | Save time for previous subtopic |
| User switches language | ✅ YES | Save time for previous language |
| User closes browser | ✅ YES | Save unsaved time |
| User navigates away | ✅ YES | Save unsaved time |
| 30-second auto-save triggers | ❌ NO | Handled by separate effect |

---

## 🔧 Related Code Sections

### **1. Timer Effect (Separate - Still has `timers` dependency)**
```javascript
// ✅ This one SHOULD have timers in dependencies
useEffect(() => {
    intervalRef.current = setInterval(() => {
        setTimers(prev => ({
            ...prev,
            [currentTimerKey]: (prev[currentTimerKey] || 0) + 1,
        }));
    }, 1000);
    return () => clearInterval(intervalRef.current);
}, [currentTimerKey, isLanguageCompletedForTopic]);
```
**Why it's OK here:** This effect needs to update state every second.

### **2. Periodic Sync Effect (Still has `timers` dependency)**
```javascript
// ✅ This one SHOULD have timers in dependencies
useEffect(() => {
    const syncInterval = setInterval(() => {
        const currentTime = timers[currentTimerKey] || 0;
        // Send time every 30 seconds
    }, 30000);
    return () => clearInterval(syncInterval);
}, [currentTimerKey, isLanguageCompletedForTopic, timers, selectedSubtopic, findTopicId]);
```
**Why it's OK here:** Needs latest timer value for periodic sync.

### **3. Cleanup Effect (FIXED - Removed `timers` dependency)**
```javascript
// ✅ This one should NOT have timers in dependencies
useEffect(() => {
    const prevTimerKey = currentTimerKey;
    const prevSubtopic = selectedSubtopic;
    
    return () => {
        // Only runs when currentTimerKey or selectedSubtopic changes
        const currentTime = timers[prevTimerKey] || 0;
        // Send cleanup request
    };
}, [currentTimerKey, selectedSubtopic, findTopicId]);
```
**Why it's different:** Only needs to run on actual switches, not timer ticks.

---

## 🎯 Key Takeaway

**React `useEffect` cleanup functions run:**
1. Before the effect re-runs (when dependencies change)
2. When the component unmounts

**Be careful with dependencies!**
- If you include a state that changes frequently (like `timers` updating every second)
- The cleanup will run frequently too
- This can cause unintended side effects (like our API spam)

**Solution:**
- Only include dependencies that represent **actual changes** you want to react to
- For cleanup-on-switch behavior, only depend on the "switch triggers" (topic, subtopic, language)
- Not on the data being accumulated (timers)

---

## ✅ Verification

**Test the fix:**

1. Open the learning page
2. Stay on one subtopic for 10+ seconds
3. Check console - should see:
   - ✅ Timer counting: 1s, 2s, 3s...
   - ✅ Periodic sync every 30s
   - ❌ NO cleanup messages every second
4. Switch to different subtopic
5. Check console - should see:
   - ✅ ONE cleanup message with accumulated time
   - ✅ Timer starts for new subtopic

**Expected console output:**
```
✅ Time synced: Subtopic 1 (Arrays) in Java - 30s
✅ Time synced: Subtopic 1 (Arrays) in Java - 30s
[User switches to Linked Lists]
✅ Cleanup: Sent 15s for Subtopic 1 (Arrays) in Java
[Timer continues for Linked Lists]
```

---

**Status:** ✅ **BUG FIXED**  
**Impact:** Reduced unnecessary API calls from ~60/minute to only on actual switches  
**Performance:** Significantly improved - no more API spam

