import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { TbNotebook } from "react-icons/tb";
import Navbar from "../Components/Navbar";
import { Toaster } from 'react-hot-toast';
import { usePersistentTopicTimers } from "./usePersistentTopicTimers";
import { TopicTimer } from "./TopicTimer";
import { Sidebar } from "./Sidebar";
import { SessionContentsModal } from "./SessionContentsModal";
import { DataTypesTabs } from "./DataTypesTabs";
import * as learningApi from "./learningApi";

export default function LearningPage({ onLogout }) {
    const location = useLocation();
    const navigate = useNavigate();
    const [fetchedData, setFetchedData] = useState([]);
    const [isDataLoading, setIsDataLoading] = useState(true);
    const [dataError, setDataError] = useState(null);
    const [isModalOpen, setIsModalOpen] = useState(false);

    // Helper to read state from localStorage
    const getInitialState = (key, defaultValue) => {
        try {
            const saved = localStorage.getItem(key);
            // Handle explicit "null" string used for clearing persistent subtopic
            if (saved === "null") return null;
            return saved !== null ? saved : defaultValue;
        } catch (error) {
            console.error(`Error reading ${key} from localStorage:`, error);
            return defaultValue;
        }
    };

    const [selectedLanguage, setSelectedLanguage] = useState(
        getInitialState("selectedLanguage", "Java")
    );

    //  Fetch all main topics & subtopics from backend using NEW API
    useEffect(() => {
        const fetchLearningContent = async () => {
            try {
                // Step 1: Fetch main topics
                const mainTopics = await learningApi.getAllMainTopics();

                // Step 2: For each main topic, fetch subtopics
                const topicsWithSubtopics = await Promise.all(
                    mainTopics.map(async (mainTopic) => {
                        const subtopics = await learningApi.getSubtopicsByMainTopic(mainTopic.mainTopicId);
                        return {
                            mainTopicId: mainTopic.mainTopicId,
                            mainTopicName: mainTopic.name,
                            subTopics: subtopics.map(sub => ({
                                topicId: sub.subtopicId,
                                title: sub.name
                            }))
                        };
                    })
                );

                console.log("✅ Fetched learning content:", topicsWithSubtopics);
                localStorage.setItem("fetchedAPIData", JSON.stringify(topicsWithSubtopics));
                setFetchedData(topicsWithSubtopics);
            } catch (error) {
                console.error("API Fetch Error:", error);
                setDataError("Failed to fetch learning content from API.");
            } finally {
                setIsDataLoading(false);
            }
        };
        fetchLearningContent();

    }, []);

    const subtopicFromQuiz = location.state?.subtopic || null;
    const quizPassed = location.state?.quizPassed || false;

    // Get persisted values early
    const persistedTopic = getInitialState("selectedTopic", null);
    const persistedSubtopic = getInitialState("selectedSubtopic", null);
    const initialDefaultTopic = subtopicFromQuiz
        ? null // Will be resolved by validation effect
        : persistedTopic || null;

    const initialDefaultSubtopic = subtopicFromQuiz
        ? subtopicFromQuiz
        : persistedSubtopic || null;

    // We will let the validation effect determine the *actual* initial state after data loads.
    const [selectedTopic, setSelectedTopic] = useState(initialDefaultTopic);
    const [selectedSubtopic, setSelectedSubtopic] = useState(initialDefaultSubtopic);

    //  Use our custom timer hook
    const { timers, completedItems, setCompletedItems, markLanguageComplete, markQuizPassed } =
        usePersistentTopicTimers(selectedTopic, selectedSubtopic, selectedLanguage, fetchedData);

    //  Persistence effect for Topic and Subtopic
    useEffect(() => {
        if (selectedTopic) {
            localStorage.setItem("selectedTopic", selectedTopic);
        }
        if (selectedSubtopic) {
            localStorage.setItem("selectedSubtopic", selectedSubtopic);
        } else {
            localStorage.setItem("selectedSubtopic", "null"); // Explicitly set "null" string for clearing
        }
    }, [selectedTopic, selectedSubtopic]);

    //  Persistence effect for Language
    useEffect(() => {
        localStorage.setItem("selectedLanguage", selectedLanguage);
    }, [selectedLanguage]);

    useEffect(() => {
        // Only run if quiz was passed and navigation state is present
        if (quizPassed && location.state.mainTopic && location.state.subtopic) {
            const { mainTopic, subtopic } = location.state;

            // 1. ✅ UPDATED: Mark the quiz as passed with current language
            markQuizPassed(mainTopic, subtopic, selectedLanguage);

            // 2. Set the selected topic/subtopic to the one the quiz was for.
            setSelectedTopic(mainTopic);
            setSelectedSubtopic(subtopic);

            // 3. Clear the navigation state immediately after processing
            navigate(location.pathname, { replace: true, state: {} });
        }
    }, [quizPassed, location.state, navigate, markQuizPassed, selectedLanguage]);

    useEffect(() => {
        if (isDataLoading || fetchedData.length === 0) return;
        let newTopic = selectedTopic;
        let newSubtopic = selectedSubtopic;
        if (!newTopic || !fetchedData.some(t => t.mainTopicName === newTopic)) {
            const topicForSub = fetchedData.find(t => t.subTopics.some(s => s.title === newSubtopic))?.mainTopicName;

            newTopic = topicForSub || fetchedData[0]?.mainTopicName || null;
        }
        const currentTopicData = fetchedData.find(t => t.mainTopicName === newTopic);
        // --- 2. Resolve Subtopic ---
        const subtopicExistsInTopic = currentTopicData?.subTopics?.some(s => s.title === newSubtopic);
        // If subtopic is null OR invalid for the resolved topic, set to the first subtopic of the topic.
        if (!newSubtopic || !subtopicExistsInTopic) {
            newSubtopic = currentTopicData?.subTopics?.[0]?.title || null;
        }
        // Apply state updates only if they've changed
        if (newTopic !== selectedTopic) {
            setSelectedTopic(newTopic);
        }
        if (newSubtopic !== selectedSubtopic) {
            setSelectedSubtopic(newSubtopic);
        }

        // Dependencies: runs after data loads and whenever topic/subtopic state changes to re-validate.
    }, [isDataLoading, fetchedData, selectedTopic, selectedSubtopic]);

    //  REVISED TIMER KEY: Now scoped to TOPIC::LANGUAGE
    const currentTimerKey = selectedTopic && selectedLanguage
        ? `${selectedTopic}::${selectedLanguage}`
        : null;

    //  Render logic
    if (isDataLoading)
        return <div style={{ textAlign: 'center', marginTop: '50px' }}>Loading course content...</div>;
    if (dataError)
        return <div style={{ textAlign: 'center', marginTop: '50px', color: 'red' }}>{dataError}</div>;
    if (fetchedData.length === 0 || !selectedTopic || !selectedSubtopic)
        return <div style={{ textAlign: 'center', marginTop: '50px' }}>No content available.</div>;

    return (
        <div style={{ height: "100vh", overflow: "visible", display: "flex", flexDirection: "column" }}>
            <Toaster
                position="top-right"
                toastOptions={{
                    success: {
                        duration: 4000,
                        style: {
                            background: '#10B981',
                            color: '#fff',
                        },
                    },
                    error: {
                        duration: 5000,
                        style: {
                            background: '#EF4444',
                            color: '#fff',
                        },
                    },
                }}
            />
            <Navbar onLogout={onLogout} />
            <div style={{ display: "flex", flex: 1, fontFamily: "sans-serif", overflow: "visible" }}>
                {/* Sidebar */}
                <Sidebar
                    topics={fetchedData}
                    selectedTopic={selectedTopic}
                    setSelectedTopic={setSelectedTopic}
                    selectedSubtopic={selectedSubtopic}
                    setSelectedSubtopic={setSelectedSubtopic}
                    completedItems={completedItems}
                />

                {/* Main content area */}
                <div
                    style={{
                        flex: 1,
                        padding: "0px 30px",
                        height: "100%",
                        overflowY: "auto",
                        background: "#f6f7fb",
                    }}
                >
                    {/* Header with topic name, timer & session contents button */}
                    <div
                        style={{
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            marginBottom: 20,
                        }}
                    >
                        <div>
                            <h1 style={{ margin: 0, fontWeight: "bold", fontSize: "48px" }}>
                                {selectedTopic}
                            </h1>
                            <h3 style={{ marginTop: 35, color: "#09122C" }}>{selectedSubtopic}</h3>
                        </div>
                        <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
                            {/* Session Contents Button */}
                            <button
                                onClick={() => setIsModalOpen(true)}
                                style={{
                                    background: "#DD6B20",
                                    color: "#fff",
                                    padding: "8px 16px",
                                    borderRadius: "6px",
                                    fontSize: "14px",
                                    fontWeight: "500",
                                    border: "none",
                                    cursor: "pointer",
                                    display: "flex",
                                    alignItems: "center",
                                    gap: "8px",
                                }}
                            >
                                <TbNotebook style={{ fontSize: "18px" }} />
                                Session Contents
                            </button>
                            {/* Timer */}
                            <TopicTimer currentTimerKey={currentTimerKey} timers={timers} />
                        </div>
                    </div>

                    <p>Learn about {selectedSubtopic} in {selectedTopic} across languages.</p>

                    {/* Tabs for explanation + quiz */}
                    <DataTypesTabs
                        selectedTopic={selectedTopic}
                        selectedSubtopic={selectedSubtopic}
                        completedItems={completedItems}
                        fetchedData={fetchedData}
                        markLanguageComplete={markLanguageComplete}
                        setSelectedLanguage={setSelectedLanguage}
                        setCompletedItems={setCompletedItems}
                        navigate={navigate}
                    />
                </div>
            </div>

            {/* Session Contents Modal */}
            <SessionContentsModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                selectedTopic={selectedTopic}
                fetchedData={fetchedData}
            />
        </div>
    );
}

