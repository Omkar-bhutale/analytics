import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { FaCode } from "react-icons/fa";
import { TbBulb, TbCheck } from "react-icons/tb";
import axios from "./axiosConfig";
import { BASE_URL } from "./axiosConfig";
import { questionMap } from "./constants";
import toast from "react-hot-toast";
import * as learningApi from "./learningApi";

export function DataTypesTabs({
    selectedTopic,
    selectedSubtopic,
    completedItems,
    fetchedData,
    markLanguageComplete,
    setSelectedLanguage,
    setCompletedItems,
    navigate
}) {
    const topicData = fetchedData.find(t => t.mainTopicName === selectedTopic);
    const subtopicData = topicData?.subTopics?.find(s => s.title === selectedSubtopic);
    const subtopicIndex = topicData?.subTopics.findIndex(s => s.title === selectedSubtopic);
    const isLastSubtopic = subtopicIndex === (topicData?.subTopics.length - 1);
    const [questionId, setQuestionId] = useState(1);

    // Fetch subtopic content with all languages
    const [subtopicContent, setSubtopicContent] = useState(null);
    const [isLoadingContent, setIsLoadingContent] = useState(false);

    useEffect(() => {
        const fetchContent = async () => {
            if (!subtopicData?.topicId) return;

            setIsLoadingContent(true);
            try {
                const content = await learningApi.getSubtopicContent(subtopicData.topicId);
                setSubtopicContent(content);
                console.log("✅ Fetched subtopic content:", content);
            } catch (error) {
                console.error("Failed to fetch subtopic content:", error);
            } finally {
                setIsLoadingContent(false);
            }
        };

        fetchContent();
    }, [subtopicData?.topicId]);

    const languages = ["Java", "Python", "JavaScript", "TypeScript"];

    // Use localStorage to persist the selected language tab
    const [tab, setTab] = useState(() => {
        const savedLang = localStorage.getItem('selectedLanguageTab');
        if (savedLang && languages.includes(savedLang)) {
            return savedLang;
        }
        return languages[0] || "Java";
    });

    // Helper: read visited keys array from localStorage
    const readVisited = () => JSON.parse(localStorage.getItem("visitedLanguages") || "[]");

    // When the tab (language) changes we persist selected language and mark visited for this (topic, subtopic, language)
    useEffect(() => {
        setSelectedLanguage(tab);
        localStorage.setItem('selectedLanguageTab', tab); // save tab selection

        // NEW: Use per-subtopic-per-language visited key
        // Format: `${topic}::${subtopic}::${language}::visited`
        if (!selectedTopic || !selectedSubtopic || !tab) return;

        const langVisitedKey = `${selectedTopic}::${selectedSubtopic}::${tab}::visited`;

        const visitedLanguages = readVisited();

        if (!visitedLanguages.includes(langVisitedKey)) {
            const updatedVisited = [...visitedLanguages, langVisitedKey];
            localStorage.setItem("visitedLanguages", JSON.stringify(updatedVisited));

            // Dispatch event so tick marks update everywhere
            window.dispatchEvent(new Event("visitedLanguagesUpdated"));

            // After recording this visit, check: have all languages for THIS subtopic been visited?
            const allLangsVisitedForThisSubtopic = languages.every(lang =>
                updatedVisited.includes(`${selectedTopic}::${selectedSubtopic}::${lang}::visited`)
            );

            if (allLangsVisitedForThisSubtopic) {
                const subtopicCompleteKey = `${selectedTopic}::${selectedSubtopic}::subtopic_complete`;
                setCompletedItems(prev => {
                    if (prev.includes(subtopicCompleteKey)) return prev;
                    const next = [...prev, subtopicCompleteKey];

                    // After adding this subtopic completion, optionally auto-mark main topic if all subtopics are complete
                    const allSubtopicsComplete = (topicData?.subTopics || []).every(sub =>
                        next.includes(`${selectedTopic}::${sub.title}::subtopic_complete`)
                    );
                    if (allSubtopicsComplete) {
                        const mainTopicCompleteKey = `${selectedTopic}::main_topic_complete`;
                        if (!next.includes(mainTopicCompleteKey)) next.push(mainTopicCompleteKey);
                    }

                    return next;
                });
            }
        }
    }, [tab, selectedTopic, selectedSubtopic, setSelectedLanguage, setCompletedItems, topicData, languages]);

    // Update tab when subtopic changes (no logic changes, but kept)
    useEffect(() => {
        const savedLang = localStorage.getItem('selectedLanguageTab');
        if (languages.length > 0) {
            if (savedLang && languages.includes(savedLang)) {
                setTab(savedLang);
            } else if (!languages.includes(tab)) {
                setTab(languages[0]);
            }
        }
    }, [selectedSubtopic, languages, tab]);

    const currentLangDetail = subtopicContent?.content?.language_details?.find(
        d => d.language === tab
    );

    const currentData = {
        content: subtopicContent?.content?.explaination || "Explanation not available.",
        code: currentLangDetail?.example || "Example code not available.",
        note:
            currentLangDetail?.code_difference_explaination ||
            "No difference note provided.",
    };

    // Get MCQ status for current language from backend response
    const mcqVisitedForCurrentLang = subtopicContent?.mcqStatus?.[tab.toLowerCase()] || false;

    const quizKey = `${selectedTopic}::${selectedSubtopic}`;
    const isQuizCompleted = completedItems.includes(`${quizKey}::passed`);

    // Language completion check at Topic level (when user has explicitly "marked as complete")
    const isLangCompletedForTopic = completedItems.includes(`${selectedTopic}::${tab}`);

    // Helper: read visited array (local)
    const visitedLanguages = readVisited();

    // Determine if the current language has been visited for ALL subtopics of the current topic
    const allSubtopicsVisitedForThisLang = (topicData?.subTopics || []).every(sub =>
        visitedLanguages.includes(`${selectedTopic}::${sub.title}::${tab}::visited`)
    );

    // For UI tab tick: show tick if language is marked complete OR user has visited this language across all subtopics
    const isLanguageTicked = (lang) => {
        const langCompleteKey = `${selectedTopic}::${lang}`;
        const isExplicitComplete = completedItems.includes(langCompleteKey);
        const allVisited = (topicData?.subTopics || []).every(sub =>
            visitedLanguages.includes(`${selectedTopic}::${sub.title}::${lang}::visited`)
        );
        return isExplicitComplete || allVisited;
    };

    // Enable "Mark as Complete" only if:
    // 1) This is last subtopic (already enforced where button renders)
    // 2) The current language has visits for every subtopic (allSubtopicsVisitedForThisLang)
    // 3) The quiz for the LAST subtopic is passed
    const lastSubtopicTitle = topicData?.subTopics?.[topicData.subTopics.length - 1]?.title;
    const isLastQuizPassed = lastSubtopicTitle ? completedItems.includes(`${selectedTopic}::${lastSubtopicTitle}::passed`) : false;

    //  Updated: Enable Mark as Complete only if ALL subtopics in ALL languages are visited & quiz passed
    const allLanguages = ["Java", "Python", "JavaScript", "TypeScript"];

    // Check if ALL subtopics across ALL languages have been visited
    const allSubtopicsVisitedInAllLanguages = (topicData?.subTopics || []).every(sub =>
        allLanguages.every(lang =>
            visitedLanguages.includes(`${selectedTopic}::${sub.title}::${lang}::visited`)
        )
    );

    // Enable button only when ALL subtopics across all languages are visited AND last quiz is passed
    //  Enable "Mark as Complete" only when all subtopics in the current language are visited
    const canMarkLanguageComplete = allSubtopicsVisitedForThisLang;

    const handleTopicwiseQuestionFetch = async () => {
        try {
            // Get the mainTopicId from the current selected topic
            if (!topicData?.mainTopicId) {
                toast.error("Main Topic ID not found");
                console.error("Main Topic ID not found for:", selectedTopic);
                return;
            }

            console.log(`🔍 Fetching problem for ${selectedTopic} (mainTopicId: ${topicData.mainTopicId})`);

            // The axios interceptor will automatically add the Authorization header.
            const response = await axios.get(
                `${BASE_URL}/user/problem-submissions/main-topic`,
                {
                    params: { mainTopicId: topicData.mainTopicId },
                }
            );

            if (response.data && response.data.problemDTO) {
                const fetchedProblemId = response.data.problemDTO.problemId;
                setQuestionId(fetchedProblemId);
                console.log(`✅ Fetched Problem ID for ${selectedTopic} (mainTopicId: ${topicData.mainTopicId}):`, fetchedProblemId);
                toast.success("Problem loaded successfully! Redirecting...");

                // ✅ Navigate to compiler with the newly fetched ID
                navigate(`/compiler/${fetchedProblemId}`, {
                    state: {
                        selectedTopic: selectedTopic,
                        selectedSubTopic: selectedSubtopic,
                        subtopics: topicData?.subTopics?.map(s => s.title) || []
                    }
                });

            } else {
                console.error("Invalid API response structure:", response.data);
                toast.error("Failed to load problem");
            }
        } catch (error) {
            console.error("Error fetching main topic problem:", error);
            if (error.response?.status === 401 || error.response?.status === 403) {
                toast.error("Authentication failed. Please login again.");
            } else {
                toast.error("Failed to fetch problem. Please try again.");
            }
        }
    };

    const handleMarkComplete = async () => {
        if (isLangCompletedForTopic || !canMarkLanguageComplete) {
            toast.error("Cannot mark as complete. Requirements not met.");
            return;
        }

        if (!topicData?.mainTopicId) {
            toast.error("Main Topic ID not found");
            return;
        }

        try {
            toast.loading("Validating completion...", { id: "mark-complete" });

            // First check if user can mark complete
            const status = await learningApi.getMarkCompleteStatus(topicData.mainTopicId, tab);

            if (!status.canMarkComplete) {
                toast.error(status.reason, { id: "mark-complete" });
                return;
            }

            // If validation passes, mark as complete
            const response = await learningApi.markTopicComplete(topicData.mainTopicId, tab);

            if (response.success) {
                toast.success(response.message, { id: "mark-complete" });

                // Mark this language as complete in local state
                markLanguageComplete(selectedTopic, selectedSubtopic, tab);

                // Move to next language if needed
                const currentIndex = languages.indexOf(tab);
                const nextIndex = currentIndex + 1;
                if (nextIndex < languages.length) {
                    setTab(languages[nextIndex]);
                } else {
                    toast.success("🎉 All languages completed for this topic!");
                }
            } else {
                toast.error(response.message || "Failed to mark complete", { id: "mark-complete" });
            }
        } catch (error) {
            console.error("Error marking complete:", error);
            toast.error("Failed to mark complete. Please try again.", { id: "mark-complete" });
        }
    };

    return (
        <div>
            {/* Language Tabs */}
            <div style={{ display: "flex", margin: "0 0 15px 0", gap: 30 }}>
                {languages.map((lang) => {
                    const isThisLangCompleted = isLanguageTicked(lang);
                    return (
                        <button
                            key={lang}
                            onClick={() => setTab(lang)}
                            style={{
                                padding: "8px 24px",
                                background: tab === lang ? "#09122C" : "#DD6B20",
                                border: "none",
                                fontWeight: tab === lang ? "bold" : "normal",
                                cursor: "pointer",
                                fontSize: 17,
                                color: "#fff",
                                marginBottom: 23,
                                marginTop: 25,
                            }}
                        >
                            {lang}{" "}
                            {isThisLangCompleted && (
                                <TbCheck style={{ color: "#fff", marginLeft: 5 }} />
                            )}
                        </button>
                    );
                })}
            </div>

            {/* Content Section */}
            <div style={{ marginTop: 8, padding: 8 }}>
                <h3 style={{ marginBottom: 8 }}>{`${selectedSubtopic} in ${tab}`}</h3>
                <p style={{ marginBottom: 8 }}>{currentData.content}</p>
                <pre
                    style={{
                        background: "#fff",
                        color: "#333",
                        padding: 16,
                        fontSize: 15,
                        borderRadius: 6,
                        marginBottom: 10,
                    }}
                >
                    {currentData.code}
                </pre>

                <small style={{ color: "#333", fontSize: 14 }}>
                    <b>Note:</b> {currentData.note}
                </small>

                <div style={{ marginTop: 12, display: "flex", gap: "20px" }}>
                    {/* Take MCQ Button - Uses backend MCQ status */}
                    <Link
                        to={!mcqVisitedForCurrentLang ? `/mcq_page/${questionMap[tab] || 'default'}` : "#"}
                        state={{ mainTopic: selectedTopic, subtopic: selectedSubtopic }}
                        style={{ textDecoration: "none" }}
                        onClick={(e) => mcqVisitedForCurrentLang && e.preventDefault()}
                    >
                        <button
                            style={{
                                padding: "6px 14px",
                                fontSize: "14px",
                                borderRadius: "6px",
                                cursor: mcqVisitedForCurrentLang ? "not-allowed" : "pointer",
                                background: mcqVisitedForCurrentLang ? "#DD6B20" : "#09122C",
                                color: "#fff",
                                border: "none",
                                display: "flex",
                                alignItems: "center",
                            }}
                        >
                            <TbBulb style={{ marginRight: "10px" }} />
                            {mcqVisitedForCurrentLang ? "MCQ Completed" : "Take MCQ"}
                        </button>
                    </Link>

                    {/* Code Here Button - Visible ONLY on the last subtopic */}
                    {isLastSubtopic && (
                        <div style={{ textDecoration: "none" }}>
                            <button
                                onClick={handleTopicwiseQuestionFetch}
                                style={{
                                    padding: "6px 14px",
                                    fontSize: "14px",
                                    borderRadius: "6px",
                                    cursor: "pointer",
                                    background: "#09122C",
                                    color: "#fff",
                                    border: "none",
                                    display: "flex",
                                    alignItems: "center",
                                }}
                            >
                                <FaCode style={{ marginRight: "10px" }} />
                                Code here
                            </button>
                        </div>
                    )}

                    {/* Mark as Complete Button - Only on last subtopic */}
                    {isLastSubtopic && (
                        <button
                            onClick={handleMarkComplete}
                            disabled={isLangCompletedForTopic || !canMarkLanguageComplete}
                            style={{
                                padding: "6px 14px",
                                fontSize: "14px",
                                borderRadius: "6px",
                                cursor: (isLangCompletedForTopic || !canMarkLanguageComplete) ? "not-allowed" : "pointer",
                                background: (isLangCompletedForTopic || !canMarkLanguageComplete) ? "#09122C" : "#DD6B20",
                                color: "#fff",
                                border: "none",
                                display: "flex",
                                alignItems: "center",
                                order: 99,
                                marginLeft: 'auto'
                            }}
                        >
                            <TbCheck style={{ marginRight: "10px" }} />
                            {isLangCompletedForTopic ? `Completed (${tab})` : "Mark as Complete"}
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
}

