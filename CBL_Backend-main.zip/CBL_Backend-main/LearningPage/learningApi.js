import axios from "./axiosConfig";
import { BASE_URL } from "./axiosConfig";

/**
 * Learning Page API Service
 * All API calls for the new LearningPageController endpoints
 */

// ========== A. TOPIC & CONTENT APIs ==========

/**
 * Get all main topics for sidebar
 * GET /api/user/learning/main-topics
 */
export const getAllMainTopics = async () => {
    const response = await axios.get(`${BASE_URL}/api/user/learning/main-topics`);
    return response.data;
};

/**
 * Get all subtopics for a main topic
 * GET /api/user/learning/main-topics/{mainTopicId}/subtopics
 */
export const getSubtopicsByMainTopic = async (mainTopicId) => {
    const response = await axios.get(`${BASE_URL}/api/user/learning/main-topics/${mainTopicId}/subtopics`);
    return response.data;
};

/**
 * Get subtopic content with all languages and MCQ status
 * GET /api/user/learning/subtopics/{subtopicId}
 */
export const getSubtopicContent = async (subtopicId) => {
    const response = await axios.get(`${BASE_URL}/api/user/learning/subtopics/${subtopicId}`);
    return response.data;
};

// ========== B. TIMER APIs ==========

/**
 * Get timer data for main topic (all languages)
 * GET /api/user/learning/time-tracking/main-topic/{mainTopicId}
 */
export const getMainTopicTimer = async (mainTopicId) => {
    const response = await axios.get(`${BASE_URL}/api/user/learning/time-tracking/main-topic/${mainTopicId}`);
    return response.data;
};

/**
 * Send time delta for subtopic + language
 * POST /api/user/learning/time-tracking/delta
 */
export const sendTimeDelta = async (subtopicId, language, deltaSeconds) => {
    const response = await axios.post(`${BASE_URL}/api/user/learning/time-tracking/delta`, {
        subtopicId,
        language: language.toUpperCase(),
        deltaSeconds
    });
    return response.data;
};

// ========== C. PROGRESS/COMPLETION APIs ==========

/**
 * Get status for "Mark as Complete" button
 * GET /api/user/learning/progress/mark-complete-status
 */
export const getMarkCompleteStatus = async (mainTopicId, language) => {
    const response = await axios.get(`${BASE_URL}/api/user/learning/progress/mark-complete-status`, {
        params: {
            mainTopicId,
            language: language.toUpperCase()
        }
    });
    return response.data;
};

/**
 * Mark main topic as complete for a language
 * PUT /api/user/learning/progress/{mainTopicId}/mark-complete
 */
export const markTopicComplete = async (mainTopicId, language) => {
    const response = await axios.put(
        `${BASE_URL}/api/user/learning/progress/${mainTopicId}/mark-complete`,
        null,
        {
            params: {
                language: language.toUpperCase()
            }
        }
    );
    return response.data;
};

/**
 * Get MCQ status for subtopic (all languages)
 * GET /api/user/learning/progress/mcq-status/{subtopicId}
 */
export const getMcqStatus = async (subtopicId) => {
    const response = await axios.get(`${BASE_URL}/api/user/learning/progress/mcq-status/${subtopicId}`);
    return response.data;
};

/**
 * Mark MCQ as visited for subtopic + language
 * PUT /api/user/learning/progress/{subtopicId}/mcq-visited
 */
export const markMcqVisited = async (subtopicId, language) => {
    const response = await axios.put(
        `${BASE_URL}/api/user/learning/progress/${subtopicId}/mcq-visited`,
        null,
        {
            params: {
                language: language.toUpperCase()
            }
        }
    );
    return response.data;
};

