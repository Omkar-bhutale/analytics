import axios from "axios";
import Cookies from "js-cookie";

// Base URL for API calls
export const BASE_URL = import.meta.env.VITE_API_BASE_URL;

// ✅ Configure axios to include token in all requests
// Clear any existing interceptors first to avoid duplicates
axios.interceptors.request.handlers = [];

axios.interceptors.request.use(
    (config) => {
        const token = Cookies.get('token');
        console.log('🔑 Axios Interceptor - Token:', token ? 'Found' : 'Not Found');
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
            console.log('✅ Authorization header set:', config.headers.Authorization);
        } else {
            console.warn('⚠️ No token found in cookies');
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

export default axios;

