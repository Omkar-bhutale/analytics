import React, { useState, useEffect } from "react";
import { FaChevronDown, FaChevronUp } from "react-icons/fa";
import { TbCheck } from "react-icons/tb";

export function Sidebar({
    topics,
    selectedTopic,
    setSelectedTopic,
    selectedSubtopic,
    setSelectedSubtopic,
    completedItems
}) {
    const [openTopic, setOpenTopic] = useState(selectedTopic);

    useEffect(() => setOpenTopic(selectedTopic), [selectedTopic]);

    const toggleTopic = (title) => {
        const newOpenTopic = openTopic === title ? null : title;
        setSelectedTopic(title); // Always update the selectedTopic

        setOpenTopic(newOpenTopic);

        const topicEntry = topics.find(t => t.mainTopicName === title);
        if (newOpenTopic === title && topicEntry && topicEntry.subTopics.length > 0) {
            const isCurrentSubtopicValid = topicEntry.subTopics.some(sub => sub.title === selectedSubtopic);
            if (!isCurrentSubtopicValid) {
                setSelectedSubtopic(topicEntry.subTopics[0].title);
            }
        }
    };

    const selectSubtopic = (subTitle) => {
        // Find the main topic for the selected subtopic
        const newTopic = topics.find(t => t.subTopics.some(s => s.title === subTitle))?.mainTopicName;

        // If the main topic is different, update both topic and openTopic state
        if (newTopic && newTopic !== selectedTopic) {
            setSelectedTopic(newTopic);
            setOpenTopic(newTopic);
        }

        // Always set the new subtopic
        setSelectedSubtopic(subTitle);
    };

    // Checks for subtopic completion (all languages + quiz passed)
    const isSubtopicCompleted = (mainTopicName, subTitle) =>
        completedItems.includes(`${mainTopicName}::${subTitle}::subtopic_complete`);

    // Checks for main topic completion (all subtopics complete)
    const isMainTopicCompleted = (mainTopicName) => {
        const topicData = topics.find(t => t.mainTopicName === mainTopicName);
        if (!topicData) return false;

        // Get all subtopics of this main topic
        const allSubtopics = topicData.subTopics || [];

        // The languages that must be marked as complete by the user
        const allLanguages = ["Java", "Python", "JavaScript", "TypeScript"];

        // Each subtopic must have ALL languages marked complete
        const isEverySubtopicFullyCompleted = allSubtopics.every(sub =>
            allLanguages.every(lang =>
                completedItems.includes(`${mainTopicName}::${lang}`)
            )
        );

        // Return true only if all subtopics across all languages are marked complete
        return isEverySubtopicFullyCompleted;
    };

    return (
        <div
            style={{
                width: 220,
                background: "#09122C",
                color: "#fff",
                position: "sticky",
                top: 0,
                height: "100vh",
                overflowY: "auto",
                scrollBehavior: "smooth",
                fontFamily: "sans-serif",
                padding: "10px 0",
                boxSizing: "border-box",
            }}
        >
            <div
                style={{
                    fontWeight: "bold",
                    marginLeft: 70,
                    fontSize: 20,
                    marginBottom: 10,
                }}
            >
                Topics
            </div>

            <ul style={{ listStyle: "none", padding: 0, margin: "16px 0" }}>
                {topics.map((mainTopic) => {
                    const mainTopicCompleted = isMainTopicCompleted(mainTopic.mainTopicName);
                    return (
                        <li style={{ marginBottom: 14 }} key={mainTopic.mainTopicId}>
                            {/* Main Topic */}
                            <div
                                style={{
                                    marginLeft: 13,
                                    fontWeight: 600,
                                    cursor: "pointer",
                                    transition: "all 0.2s ease",
                                    backgroundColor: selectedTopic === mainTopic.mainTopicName ? "transparent" : "transparent",
                                    fontSize: selectedTopic === mainTopic.mainTopicName ? "1.1rem" : "1rem",
                                    borderRadius: "4px",
                                    padding: "6px 8px",
                                    marginBottom: 6,
                                    marginTop: 20,
                                    display: "flex",
                                    justifyContent: "space-between",
                                    alignItems: "center",
                                }}
                                onClick={() => toggleTopic(mainTopic.mainTopicName)}
                            >
                                <span>{mainTopic.mainTopicName}</span>

                                <div style={{ display: "flex", alignItems: "center", gap: "5px" }}>
                                    {mainTopicCompleted && <TbCheck style={{ color: "#fff" }} />}
                                    {openTopic === mainTopic.mainTopicName ? (
                                        <FaChevronUp style={{ color: "#fff" }} />
                                    ) : (
                                        <FaChevronDown style={{ color: "#fff" }} />
                                    )}
                                </div>
                            </div>

                            {/* Subtopics */}
                            {openTopic === mainTopic.mainTopicName && mainTopic.subTopics.length > 0 && (
                                <ul style={{ listStyle: "none", margin: 0, paddingLeft: 26 }}>
                                    {mainTopic.subTopics.map((subTopic) => {
                                        const completed = isSubtopicCompleted(
                                            mainTopic.mainTopicName,
                                            subTopic.title
                                        );
                                        return (
                                            <li
                                                key={subTopic.topicId}
                                                style={{
                                                    fontWeight: 400,
                                                    marginTop: 3,
                                                    cursor: "pointer",
                                                    backgroundColor:
                                                        selectedSubtopic === subTopic.title ? "#DD6B20" : "transparent",
                                                    fontSize:
                                                        selectedSubtopic === subTopic.title ? "1.05rem" : "1rem",
                                                    borderRadius: "4px",
                                                    padding: "3px 6px",
                                                    transition: "all 0.2s ease",
                                                    display: "flex",
                                                    justifyContent: "space-between",
                                                    alignItems: "center",
                                                }}
                                                onClick={() => selectSubtopic(subTopic.title)}
                                            >
                                                <span>{subTopic.title}</span>
                                                {completed && <TbCheck style={{ color: "#fff", marginLeft: 5 }} />}
                                            </li>
                                        );
                                    })}
                                </ul>
                            )}
                        </li>
                    );
                })}
            </ul>
        </div>
    );
}

