# ✅ Update: Language Engagement API Now Returns Main Topic Engagement

**Date:** November 7, 2025  
**Change Type:** API Response Enhancement  
**Endpoint:** `PUT /user/topic-engagement/language`

---

## 🎯 What Changed

The `updateLanguageWiseEngagement` API now returns **MainTopicEngagementResponseDTO** instead of void/204 No Content.

### **Why This Change?**

**Frontend Requirement:**
- Frontend works with **Main Topic + Language** level
- After updating time for a subtopic, frontend needs the **aggregated main topic data** immediately
- This eliminates the need for a separate API call to fetch main topic engagement

---

## 📊 Complete Flow

### **1. Frontend Sends Time Update**
```json
PUT /user/topic-engagement/language
{
  "topicId": 12,          // Subtopic ID
  "language": "JAVA",
  "timeSpentSeconds": 300
}
```

### **2. Backend Processing**
1. ✅ Find subtopic and user
2. ✅ Update subtopic engagement (Java time += 300s, javaVisited = true)
3. ✅ Recalculate subtopic's total time across all languages
4. ✅ Save subtopic engagement to `user_topic_engagement` table
5. ✅ **Call `updateMainTopicEngagement()`** to aggregate all subtopics to main topic
6. ✅ **Fetch and return the updated main topic engagement**

### **3. Backend Response**
```json
HTTP/1.1 200 OK
Content-Type: application/json

{
  "mainTopicId": 1,
  "mainTopicName": "Data Structures",
  "completed": false,
  "javaCompleted": true,
  "pythonCompleted": false,
  "javascriptCompleted": false,
  "typescriptCompleted": false,
  "javaTimeSeconds": 3600,
  "pythonTimeSeconds": 1800,
  "javascriptTimeSeconds": 900,
  "typescriptTimeSeconds": 600,
  "totalTimeSeconds": 6900,
  "lastActivityAt": "2025-11-07T10:30:00"
}
```

---

## 🔧 Technical Implementation

### **Files Modified:**

#### 1. **Service Interface** - `UserTopicEngagementService.java`
```java
// Changed from void to MainTopicEngagementResponseDTO
MainTopicEngagementResponseDTO updateLanguageWiseEngagement(TopicLanguageEngagementRequestDTO requestDTO);
```

#### 2. **Service Implementation** - `UserTopicEngagementServiceImpl.java`
```java
@Override
@Transactional
public MainTopicEngagementResponseDTO updateLanguageWiseEngagement(TopicLanguageEngagementRequestDTO request) {
    // ...update subtopic engagement...
    
    engagementRepository.save(engagement);
    
    // 🔥 Update MainTopic cumulative engagement
    updateMainTopicEngagement(topic, user);
    
    // 🔥 Get the main topic and return its engagement
    MainTopic mainTopic = topic.getMainTopic();
    if (mainTopic == null) {
        throw new ResourceNotFoundException("Main topic not found for topic id: " + request.getTopicId());
    }
    
    return getMainTopicEngagement(mainTopic.getMainTopicId());
}
```

**Key Logic:**
- After updating subtopic, calls `updateMainTopicEngagement()` which:
  - Fetches all subtopics for the main topic
  - Aggregates time for each language across all subtopics
  - Calculates language completion status (all subtopics visited + MCQ completed)
  - Updates the `user_main_topic_engagement` table
- Then fetches and returns the complete main topic engagement

#### 3. **Controller** - `UserTopicEngagementController.java`
```java
@PutMapping("/language")
public ResponseEntity<MainTopicEngagementResponseDTO> updateLanguageEngagement(
        @RequestBody TopicLanguageEngagementRequestDTO requestDTO) {
    MainTopicEngagementResponseDTO response = userTopicEngagementService.updateLanguageWiseEngagement(requestDTO);
    return ResponseEntity.ok(response);
}
```

**Changed from:**
- `ResponseEntity<Void>` with `noContent().build()`

**To:**
- `ResponseEntity<MainTopicEngagementResponseDTO>` with `ok(response)`

---

## ✨ Benefits

### **1. Efficiency**
- ✅ **Single API Call:** Frontend gets updated main topic data immediately
- ✅ **No Extra Request:** No need to call `/all-main-topics-sub-topics` or `/main-topic/{id}/engagement`
- ✅ **Real-time Update:** Frontend sees aggregated progress instantly

### **2. Frontend Simplification**
```javascript
// ✅ BEFORE: Two API calls needed
await fetch('/user/topic-engagement/language', {
  method: 'PUT',
  body: JSON.stringify({ topicId: 12, language: 'JAVA', timeSpentSeconds: 300 })
});
// Then fetch main topic data separately...
const mainTopic = await fetch('/user/topic-engagement/all-main-topics-sub-topics');

// ✅ AFTER: Single call with response
const response = await fetch('/user/topic-engagement/language', {
  method: 'PUT',
  body: JSON.stringify({ topicId: 12, language: 'JAVA', timeSpentSeconds: 300 })
});
const mainTopicEngagement = await response.json();
// Immediately update UI with aggregated main topic data!
```

### **3. Data Consistency**
- ✅ **Transactional:** All updates happen in single transaction
- ✅ **Always Fresh:** Returns data immediately after aggregation
- ✅ **No Race Conditions:** No gap between update and fetch

---

## 📋 Response Fields Explained

| Field | Type | Description |
|-------|------|-------------|
| `mainTopicId` | Integer | ID of the main topic (e.g., 1 for "Data Structures") |
| `mainTopicName` | String | Name of the main topic |
| `completed` | Boolean | True if ANY language is fully completed for this main topic |
| `javaCompleted` | Boolean | True if ALL subtopics visited in Java + MCQs completed |
| `pythonCompleted` | Boolean | True if ALL subtopics visited in Python + MCQs completed |
| `javascriptCompleted` | Boolean | True if ALL subtopics visited in JavaScript + MCQs completed |
| `typescriptCompleted` | Boolean | True if ALL subtopics visited in TypeScript + MCQs completed |
| `javaTimeSeconds` | Long | Total Java time across ALL subtopics |
| `pythonTimeSeconds` | Long | Total Python time across ALL subtopics |
| `javascriptTimeSeconds` | Long | Total JavaScript time across ALL subtopics |
| `typescriptTimeSeconds` | Long | Total TypeScript time across ALL subtopics |
| `totalTimeSeconds` | Integer | Sum of all language times |
| `lastActivityAt` | DateTime | Last activity timestamp for this main topic |

---

## 🎯 Language Completion Logic

A language is marked as **completed** for a main topic when:

1. **All subtopics visited** in that language (`languageVisited = true` for each subtopic)
2. **AND MCQ completed** for each subtopic (`mcqVisited = true`)

**Example:**
- Main Topic: "Data Structures" has 3 subtopics: Arrays, Linked Lists, Stacks
- Java is completed when:
  - User visited Arrays content in Java
  - User visited Linked Lists content in Java  
  - User visited Stacks content in Java
  - User completed MCQ for Arrays
  - User completed MCQ for Linked Lists
  - User completed MCQ for Stacks

---

## 🔄 Frontend Usage Pattern

### **Optimistic Update Pattern**
```javascript
// Update time and get main topic engagement
const mainTopicData = await updateLanguageTime(subtopicId, language, timeSpent);

// Immediately update UI with aggregated data
updateMainTopicProgressBar(mainTopicData);
updateLanguageBadges(mainTopicData);
updateSidebarProgress(mainTopicData);

// Show completion toast if language just completed
if (mainTopicData.javaCompleted && !previousJavaCompleted) {
  showToast('🎉 Java completed for ' + mainTopicData.mainTopicName);
}
```

### **Real-time Progress Display**
```javascript
function displayMainTopicProgress(data) {
  const languages = ['java', 'python', 'javascript', 'typescript'];
  
  languages.forEach(lang => {
    const completed = data[`${lang}Completed`];
    const time = data[`${lang}TimeSeconds`];
    
    updateLanguageCard(lang, {
      status: completed ? 'completed' : 'in-progress',
      timeSpent: formatTime(time),
      badge: completed ? '✅' : '🔄'
    });
  });
}
```

---

## 🧪 Testing

### **Test Case 1: Update Subtopic Time**
```bash
curl -X PUT http://localhost:8080/user/topic-engagement/language \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <token>" \
  -d '{
    "topicId": 12,
    "language": "JAVA",
    "timeSpentSeconds": 300
  }'
```

**Expected Response:**
```json
{
  "mainTopicId": 1,
  "mainTopicName": "Data Structures",
  "javaTimeSeconds": 3900,  // Aggregated from all subtopics
  "javaCompleted": true,
  "totalTimeSeconds": 7200,
  "lastActivityAt": "2025-11-07T15:30:00"
}
```

### **Test Case 2: Complete Last Subtopic**
When the last subtopic is visited and MCQ completed, the response should show:
```json
{
  "javaCompleted": true,  // ✅ Changed to true
  "completed": true       // ✅ Main topic completed (at least one language)
}
```

---

## 📌 Related Endpoints

| Endpoint | Method | Purpose | Returns |
|----------|--------|---------|---------|
| `/language` | PUT | Update subtopic time | **Main topic engagement** (NEW!) |
| `/all-main-topics-sub-topics` | GET | Get all main topics | All main topics with engagement |
| `/main-topic/{id}/engagement` | GET | Get single main topic | Main topic engagement |
| `/{topicId}` | GET | Get subtopic engagement | Subtopic engagement |
| `/{topicId}/mcq-visited` | PUT | Mark MCQ visited | Subtopic engagement |

---

## 🔍 Data Aggregation Details

### **Time Aggregation:**
```java
javaTimeSeconds (MainTopic) = 
    SUM(javaTimeSeconds) FROM user_topic_engagement 
    WHERE userId = ? AND topicId IN (subtopics of this main topic)
```

### **Completion Calculation:**
```java
javaCompleted (MainTopic) = 
    ALL subtopics have (javaVisited = true AND mcqVisited = true)
```

### **Overall Completion:**
```java
completed (MainTopic) = 
    ANY language is fully completed (javaCompleted OR pythonCompleted OR ...)
```

---

## ⚠️ Important Notes

1. **Transaction Safety:** All updates happen in a single `@Transactional` method
2. **Null Safety:** Main topic is validated before returning engagement
3. **Error Handling:** Throws `ResourceNotFoundException` if topic or main topic not found
4. **Performance:** Uses existing repository methods, no N+1 queries
5. **Data Freshness:** Response reflects the exact state after update

---

## 🚀 Migration Guide

### **Frontend Changes Required:**

**Before:**
```javascript
await api.put('/language', data); // 204 No Content
// Ignore response or fetch separately
```

**After:**
```javascript
const mainTopicEngagement = await api.put('/language', data).then(r => r.json());
// Use mainTopicEngagement to update UI immediately
```

---

**Status:** ✅ **COMPLETED**  
**Breaking Change:** ⚠️ **Minor** - Response changed from 204 to 200 with body  
**Backward Compatible:** ✅ Frontend can simply start using response data  

---

**Author:** GitHub Copilot  
**Approved:** Ready for frontend integration  

