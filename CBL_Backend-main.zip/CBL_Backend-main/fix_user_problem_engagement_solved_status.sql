-- SQL Script to fix UserProblemEngagement.isSolved flag for existing data
-- This updates the is_solved flag based on existing UserProblemReport data

UPDATE user_problem_engagement upe
SET is_solved = true
WHERE EXISTS (
    SELECT 1
    FROM user_problem_reports upr
    WHERE upr.user_id = upe.user_id
    AND upr.problem_id = upe.problem_id
    AND upr.is_solved = true
);

-- Verify the update
SELECT
    COUNT(*) as total_engagements,
    SUM(CASE WHEN is_solved = true THEN 1 ELSE 0 END) as solved_count,
    SUM(CASE WHEN is_solved = false THEN 1 ELSE 0 END) as unsolved_count
FROM user_problem_engagement;

