# Migration Guide: LearningPage_NEW.jsx to Modular Structure

## Overview

The original `LearningPage_NEW.jsx` file has been successfully split into multiple reusable components organized in the `LearningPage/` folder.

## What Was Done


### ✅ Created Files

1. **`LearningPage/index.jsx`** - Main component (entry point)
2. **`LearningPage/axiosConfig.js`** - Axios configuration with auth interceptors
3. **`LearningPage/constants.js`** - Shared constants
4. **`LearningPage/usePersistentTopicTimers.js`** - Timer management custom hook
5. **`LearningPage/TopicTimer.jsx`** - Timer display component
6. **`LearningPage/Sidebar.jsx`** - Navigation sidebar component
7. **`LearningPage/SessionContentsModal.jsx`** - Notebooks modal component
8. **`LearningPage/DataTypesTabs.jsx`** - Language tabs and content display
9. **`LearningPage/README.md`** - Component documentation

## How to Use the New Structure

### Option 1: Update Your Import (Recommended)

In your routing file (e.g., `App.jsx` or `Routes.jsx`), update the import:

**Before:**
```javascript
import LearningPage from "./LearningPage_NEW";
```

**After:**
```javascript
import LearningPage from "./LearningPage";
// or
import LearningPage from "./LearningPage/index";
```

### Option 2: Keep Using Old File (Temporary)

If you want to test first, you can keep the old `LearningPage_NEW.jsx` file temporarily and gradually migrate.

## File Structure

```
CBL Backend/
├── LearningPage_NEW.jsx (OLD - can be deleted after migration)
└── LearningPage/
    ├── index.jsx                    # Main component
    ├── axiosConfig.js               # Axios setup
    ├── constants.js                 # Constants
    ├── usePersistentTopicTimers.js  # Timer hook
    ├── TopicTimer.jsx               # Timer display
    ├── Sidebar.jsx                  # Sidebar navigation
    ├── SessionContentsModal.jsx     # Modal component
    ├── DataTypesTabs.jsx           # Content tabs
    └── README.md                    # Documentation
```

## Benefits of New Structure

### 1. **Better Organization**
- Each component has its own file
- Easier to find and modify specific functionality
- Clear separation of concerns

### 2. **Reusability**
- Components can be imported individually
- Timer hook can be reused in other pages
- Axios config is centralized

### 3. **Maintainability**
- Smaller files are easier to understand
- Changes to one component don't affect others
- Better for code reviews

### 4. **Testing**
- Each component can be tested independently
- Mock dependencies more easily
- Write focused unit tests

### 5. **Performance**
- Potential for code splitting
- Components can be lazy-loaded if needed

## Component Responsibilities

### `index.jsx` (Main Component)
- Fetches data from backend
- Manages selected topic/subtopic/language state
- Handles navigation and routing
- Orchestrates child components

### `usePersistentTopicTimers.js` (Custom Hook)
- Timer state management
- Syncs time to backend every 30 seconds
- Handles page refresh/close events
- Tracks completion status
- Manages localStorage persistence

### `Sidebar.jsx`
- Displays topic hierarchy
- Handles topic/subtopic navigation
- Shows completion checkmarks
- Collapsible topic sections

### `DataTypesTabs.jsx`
- Language tab switching
- Displays code examples
- Handles quiz navigation
- "Code Here" button functionality
- "Mark as Complete" button logic
- Tracks language visits

### `SessionContentsModal.jsx`
- Displays available notebooks
- Handles notebook downloads
- Shows language and file type badges

### `TopicTimer.jsx`
- Displays current timer in HH:MM:SS format
- Simple display component

### `axiosConfig.js`
- Configures axios with base URL
- Adds authentication token to all requests
- Centralized HTTP client setup

### `constants.js`
- `questionMap` - Maps languages to quiz types
- `PERSISTENT_KEYS` - LocalStorage key patterns
- `ALL_LANGUAGES` - Supported programming languages

## Breaking Changes

### None! 

The new structure is 100% compatible with the old one. The component has the same:
- Props interface
- State management
- API calls
- User interactions
- LocalStorage keys

## Testing the Migration

### 1. Verify Imports Work
```javascript
import LearningPage from "./LearningPage";
```

### 2. Test Key Functionality
- [ ] Page loads without errors
- [ ] Topics and subtopics display correctly
- [ ] Timer starts and increments
- [ ] Language tabs work
- [ ] Time syncs to backend
- [ ] Quiz navigation works
- [ ] Code Here button works
- [ ] Mark as Complete button works
- [ ] Session Contents modal opens
- [ ] Notebooks can be downloaded
- [ ] Page refresh preserves state
- [ ] Tab switching syncs time
- [ ] Language change tracked

### 3. Check Console
Look for any errors or warnings in the browser console.

### 4. Verify Backend Calls
Check network tab to ensure API calls are working:
- `/user/topic-engagement/all-main-topics-sub-topics`
- `/user/topic-engagement/language` (PUT)
- `/user/notebooks/{mainTopicId}`
- `/user/notebooks/download/{notebookId}`

## Rollback Plan

If you encounter issues, you can easily rollback:

1. Change import back to `LearningPage_NEW.jsx`
2. Keep the old file intact until fully tested
3. Report any issues found

## Next Steps

### Recommended Actions:

1. **Update imports** in your routing file
2. **Test thoroughly** in development
3. **Delete old file** after successful migration: `LearningPage_NEW.jsx`
4. **Update documentation** if you have any
5. **Consider adding tests** for individual components

### Future Enhancements:

- Add TypeScript types
- Extract inline styles to CSS modules
- Add unit tests for each component
- Consider using Context API for shared state
- Add error boundaries
- Implement skeleton loading states
- Add animations/transitions

## Troubleshooting

### Issue: Components not found
**Solution**: Ensure the import path is correct relative to your file location.

### Issue: Axios not adding token
**Solution**: Check that `js-cookie` package is installed and token exists in cookies.

### Issue: Timer not syncing
**Solution**: Check network tab for failed API calls. Verify backend endpoint is working.

### Issue: State not persisting
**Solution**: Check browser's localStorage to ensure keys are being saved.

### Issue: Module resolution errors
**Solution**: Restart your development server after creating new files.

## Support

If you encounter any issues during migration:
1. Check the console for error messages
2. Verify all imports are correct
3. Ensure all dependencies are installed
4. Check the README.md in the LearningPage folder

## Summary

✅ **Successfully split** 1500+ line file into 9 modular files  
✅ **No breaking changes** - 100% compatible  
✅ **Better organized** - Each file has single responsibility  
✅ **Fully documented** - README and inline comments  
✅ **Ready to use** - Just update imports  

The migration is complete and ready for testing!

