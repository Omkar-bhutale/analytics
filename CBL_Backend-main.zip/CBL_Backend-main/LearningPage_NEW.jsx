import React, { useState, useEffect, useRef, useCallback } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { FaCode } from "react-icons/fa";
import { TbBulb, TbCheck, TbDownload, TbX, TbNotebook } from "react-icons/tb";
import { FaChevronDown, FaChevronUp } from "react-icons/fa";
import Navbar from "../Components/Navbar";
import axios from "axios";
import toast, { Toaster } from 'react-hot-toast';
import Cookies from "js-cookie";

// Base URL for API calls
const BASE_URL = import.meta.env.VITE_API_BASE_URL;

// ✅ Configure axios to include token in all requests
// Clear any existing interceptors first to avoid duplicates
axios.interceptors.request.handlers = [];

axios.interceptors.request.use(
    (config) => {
        const token = Cookies.get('token');
        console.log('🔑 Axios Interceptor - Token:', token ? 'Found' : 'Not Found');
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
            console.log('✅ Authorization header set:', config.headers.Authorization);
        } else {
            console.warn('⚠️ No token found in cookies');
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

const questionMap = {
    Java: "java_intro",
    Python: "python_intro",
    JavaScript: "js_intro",
    TypeScript: "ts_intro",
};
const PERSISTENT_KEYS = ["::passed", "::subtopic_complete", "::main_topic_complete", "::Java", "::Python", "::JavaScript", "::TypeScript"];
export function usePersistentTopicTimers(selectedTopic, selectedSubtopic, selectedLanguage, fetchedData) {
    // Timer state: { 'topic::language': seconds, ... }
    const [timers, setTimers] = useState({});
    const timersInitialized = useRef(false);

    // ✅ Initialize timers from backend data as the source of truth
    useEffect(() => {
        if (fetchedData.length > 0 && !timersInitialized.current) {
            const initialTimers = {};
            const savedTimers = JSON.parse(localStorage.getItem("topicTimers") || "{}");

            fetchedData.forEach(topic => {
                const mainTopicName = topic.mainTopicName;
                // Initialize from backend data
                if (topic.javaTimeSeconds) initialTimers[`${mainTopicName}::Java`] = topic.javaTimeSeconds;
                if (topic.pythonTimeSeconds) initialTimers[`${mainTopicName}::Python`] = topic.pythonTimeSeconds;
                if (topic.javascriptTimeSeconds) initialTimers[`${mainTopicName}::JavaScript`] = topic.javascriptTimeSeconds;
                if (topic.typescriptTimeSeconds) initialTimers[`${mainTopicName}::TypeScript`] = topic.typescriptTimeSeconds;
            });

            // Merge with localStorage, giving precedence to backend data
            const finalTimers = { ...savedTimers, ...initialTimers };

            setTimers(finalTimers);
            // ✅ CRITICAL FIX: Initialize lastSyncTimeRef with the same values
            // This prevents sending the full cumulative time on the first sync.
            lastSyncTimeRef.current = { ...lastSyncTimeRef.current, ...initialTimers };
            timersInitialized.current = true;
            console.log("✅ Timers initialized from backend and localStorage:", finalTimers);
        }
    }, [fetchedData]);

    // Helper to load ALL completion keys
    const loadAllCompletedItems = () => {
        const saved = localStorage.getItem("completedQuizzes");
        return saved ? JSON.parse(saved) : [];
    }

    // Completion state: Tracks ALL completion keys
    const [completedItems, setCompletedItems] = useState(loadAllCompletedItems);

    const intervalRef = useRef(null);
    const lastSyncTimeRef = useRef({}); // Track last sync time for each topic::language

    //  REVISED TIMER KEY: Now scoped to TOPIC::LANGUAGE (Accumulates time across all subtopics)
    const currentTimerKey = selectedTopic && selectedLanguage
        ? `${selectedTopic}::${selectedLanguage}`
        : null;

    const isPersistentKey = (key) => {
        return PERSISTENT_KEYS.some(suffix => key.endsWith(suffix));
    };


    //  Save timers and ALL relevant completed items
    useEffect(() => {
        localStorage.setItem("topicTimers", JSON.stringify(timers));
    }, [timers]);

    useEffect(() => {
        // Filter to only save keys that end with a recognised persistent suffix
        const keysToSave = completedItems.filter(isPersistentKey);
        localStorage.setItem("completedQuizzes", JSON.stringify(keysToSave));
    }, [completedItems]);

    //  CRITICAL FIX: Listen for both storage event (other tabs) and custom event (same tab)
    useEffect(() => {
        const updateFromStorage = () => {
            const savedItems = loadAllCompletedItems();
            setCompletedItems(savedItems);
            const savedTimers = localStorage.getItem("topicTimers");
            if (savedTimers) setTimers(JSON.parse(savedTimers));
        };

        // Listener for storage changes from other tabs
        window.addEventListener("storage", updateFromStorage);

        // Listener for custom event dispatched by McqPage in the same tab/window
        window.addEventListener("completedQuizzesUpdated", updateFromStorage);

        return () => {
            window.removeEventListener("storage", updateFromStorage);
            window.removeEventListener("completedQuizzesUpdated", updateFromStorage);
        };
    }, [setCompletedItems]);
    const isLanguageCompletedForTopic = completedItems.includes(currentTimerKey);

    //  Timer logic: run only for the currently active language and if not completed
    useEffect(() => {
        clearInterval(intervalRef.current);
        if (!currentTimerKey) return;

        //  REVISED: Use Topic-level completion check
        if (isLanguageCompletedForTopic) return; // Stop timer if the current language for the topic is completed

        // Start the timer
        intervalRef.current = setInterval(() => {
            setTimers(prev => ({
                ...prev,
                [currentTimerKey]: (prev[currentTimerKey] || 0) + 1,
            }));
        }, 1000);

        return () => clearInterval(intervalRef.current);

    }, [currentTimerKey, isLanguageCompletedForTopic]);

    // Helper to find the topicId for the current subtopic
    const findTopicId = useCallback((topic, subtopic) => {
        const topicData = fetchedData.find(t => t.mainTopicName === topic);
        const subtopicData = topicData?.subTopics?.find(s => s.title === subtopic);
        // The topicId in the subTopics array (like 12 in the image) is what the API uses
        return subtopicData?.topicId;
    }, [fetchedData]);

    //  ✅ UPDATED: Periodic sync - send time ONLY for current subtopic being viewed
    useEffect(() => {
        if (!currentTimerKey || isLanguageCompletedForTopic || !selectedSubtopic) return;

        const syncTime = () => {
            const [topic, language] = currentTimerKey.split('::');
            const currentTime = timers[currentTimerKey] || 0;
            const lastSyncTime = lastSyncTimeRef.current[currentTimerKey] || 0;
            const timeSinceLastSync = currentTime - lastSyncTime;

            // Only sync if at least 1 second has passed since last sync
            if (timeSinceLastSync > 0) {
                const currentSubtopicId = findTopicId(topic, selectedSubtopic);

                if (currentSubtopicId) {
                    const payload = {
                        topicId: currentSubtopicId,
                        language: language.toUpperCase(),
                        timeSpentSeconds: timeSinceLastSync,
                    };

                    // Use fetch with keepalive for reliability on page unload
                    const token = Cookies.get('token');
                    fetch(`${BASE_URL}/user/topic-engagement/language`, {
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json',
                            ...(token && { 'Authorization': `Bearer ${token}` })
                        },
                        body: JSON.stringify(payload),
                        keepalive: true
                    }).then(response => {
                        if (response.ok) {
                            console.log(`✅ Time synced: Subtopic ${currentSubtopicId} (${selectedSubtopic}) in ${language} - ${timeSinceLastSync}s`);
                            lastSyncTimeRef.current[currentTimerKey] = currentTime;
                        } else {
                            console.error(`❌ Failed to sync time for Subtopic ${currentSubtopicId} (${language}) - Status: ${response.status}`);
                        }
                    }).catch(error => {
                        console.error(`❌ Failed to sync time for Subtopic ${currentSubtopicId} (${language})`, error);
                    });
                }
            }
        };

        const syncInterval = setInterval(() => {
            // Sync if at least 10 seconds have passed
            const currentTime = timers[currentTimerKey] || 0;
            const lastSyncTime = lastSyncTimeRef.current[currentTimerKey] || 0;
            if (currentTime - lastSyncTime >= 10) {
                syncTime();
            }
        }, 30000); // Periodic check every 30 seconds

        // Sync when tab visibility changes (e.g., user switches tabs)
        const handleVisibilityChange = () => {
            if (document.visibilityState === 'hidden') {
                syncTime();
            }
        };

        window.addEventListener('visibilitychange', handleVisibilityChange);

        return () => {
            clearInterval(syncInterval);
            window.removeEventListener('visibilitychange', handleVisibilityChange);
            // Final sync on cleanup
            syncTime();
        };
    }, [currentTimerKey, isLanguageCompletedForTopic, selectedSubtopic, findTopicId]);

    // ✅ NEW: Send final time on page unload (refresh/close) or tab switch
    useEffect(() => {
        const syncFinalTime = () => {
            // This logic is now inside the main sync effect's cleanup.
            // We can trigger it from here if needed, but let's consolidate.
        };

        const handleVisibilityChange = () => {
            if (document.visibilityState === 'hidden') {
                // The main sync effect already handles this.
                // We can trigger its sync function if we extract it.
            }
        };

        window.addEventListener('visibilitychange', handleVisibilityChange);
        // 'pagehide' is more reliable than 'beforeunload' for this purpose.
        window.addEventListener('pagehide', syncFinalTime);

        return () => {
            window.removeEventListener('visibilitychange', handleVisibilityChange);
            window.removeEventListener('pagehide', syncFinalTime);
        };
    }, [currentTimerKey, selectedSubtopic, findTopicId, timers]);

    const prevSubtopicRef = useRef(selectedSubtopic);

    useEffect(() => {
        // Check if the subtopic has actually changed
        if (prevSubtopicRef.current !== selectedSubtopic) {
            const prevSubtopic = prevSubtopicRef.current;
            const prevTimerKey = currentTimerKey; // This is based on the *current* topic/language

            if (prevTimerKey && prevSubtopic) {
                const [topic, language] = prevTimerKey.split('::');
                const currentTime = timers[prevTimerKey] || 0;
                const lastSyncTime = lastSyncTimeRef.current[prevTimerKey] || 0;
                const timeToSync = currentTime - lastSyncTime;

                if (timeToSync > 0) {
                    const subtopicId = findTopicId(topic, prevSubtopic);
                    if (subtopicId) {
                        const payload = {
                            topicId: subtopicId,
                            language: language.toUpperCase(),
                            timeSpentSeconds: timeToSync,
                        };

                        // Use fetch with keepalive for reliability
                        const token = Cookies.get('token');
                        fetch(`${BASE_URL}/user/topic-engagement/language`, {
                            method: 'PUT',
                            headers: {
                                'Content-Type': 'application/json',
                                ...(token && { 'Authorization': `Bearer ${token}` })
                            },
                            body: JSON.stringify(payload),
                            keepalive: true
                        }).then(() => {
                            console.log(`✅ Subtopic Switch Sync: Sent ${timeToSync}s for Subtopic ${subtopicId} (${prevSubtopic})`);
                            lastSyncTimeRef.current[prevTimerKey] = currentTime;
                        }).catch(err => {
                            console.error(`❌ Subtopic Switch Sync failed for Subtopic ${subtopicId}`, err);
                        });
                    }
                }
            }

            // After syncing, update the ref to the new current subtopic
            prevSubtopicRef.current = selectedSubtopic;
        }
    }, [selectedSubtopic, currentTimerKey, findTopicId, timers]);


    //  ✅ REMOVED cleanup effect for switching subtopics/languages as it's now handled by the main sync effect.
    //  The main sync effect's cleanup function will now handle all cases.

    //  Send final time when language is marked complete
    useEffect(() => {
        const newlyCompletedKeys = completedItems.filter(key =>
            key.split('::').length === 2 && // Topic::Language (2 parts)
            PERSISTENT_KEYS.some(suffix => key.endsWith(suffix))
        );

        newlyCompletedKeys.forEach(key => {
            const [topic, language] = key.split('::');
            const topicData = fetchedData.find(t => t.mainTopicName === topic);
            const subtopics = topicData?.subTopics || [];
            const totalTime = timers[key] || 0;
            const lastSyncTime = lastSyncTimeRef.current[key] || 0;
            const remainingTime = totalTime - lastSyncTime;

            // Only send if there's unsent time
            if (remainingTime > 0 && subtopics.length > 0) {
                const timePerSubtopic = Math.floor(remainingTime / subtopics.length);

                subtopics.forEach(subtopic => {
                    const topicId = subtopic.topicId;

                    const payload = {
                        topicId: topicId,
                        language: language.toUpperCase(),
                        timeSpentSeconds: timePerSubtopic,
                    };

                    axios.put(`${BASE_URL}/user/topic-engagement/language`, payload)
                        .then(response => {
                            console.log(` Final time tracked: Topic ${topicId} (${language}) - ${timePerSubtopic}s`, response.data);
                            lastSyncTimeRef.current[key] = totalTime;
                        })
                        .catch(error => {
                            console.error(`❌ Failed to update final engagement for Topic ${topicId} (${language})`, error);
                        });
                });
            }
        });

    }, [completedItems, timers, fetchedData]);
    const checkSubtopicAndTopicCompletion = useCallback((topic, subtopic, updatedItems) => {
        const allLangsCompleteForTopic = ['Java', 'Python', 'JavaScript', 'TypeScript'].every(
            lang => updatedItems.includes(`${topic}::${lang}`)
        );
        const isQuizPassedForSubtopic = updatedItems.includes(`${topic}::${subtopic}::passed`);

        //  Step 1: Mark subtopic complete only after explicit quiz + all langs complete
        if (allLangsCompleteForTopic && isQuizPassedForSubtopic) {
            const subtopicCompleteKey = `${topic}::${subtopic}::subtopic_complete`;
            if (!updatedItems.includes(subtopicCompleteKey)) {
                updatedItems.push(subtopicCompleteKey);
            }
        }

        //  Step 2: Mark main topic complete only when all subtopics are done
        const topicData = fetchedData.find(t => t.mainTopicName === topic);
        const allSubtopicsComplete = topicData?.subTopics.every(sub => {
            const subKey = `${topic}::${sub.title}::subtopic_complete`;
            return updatedItems.includes(subKey);
        });

        if (allSubtopicsComplete) {
            const mainTopicCompleteKey = `${topic}::main_topic_complete`;
            if (!updatedItems.includes(mainTopicCompleteKey)) {
                updatedItems.push(mainTopicCompleteKey);
            }
        }

        return updatedItems;
    }, []);

    // Function to mark a language as complete and check for subtopic/topic completion
    const markLanguageComplete = useCallback((topic, subtopic, language) => {
        //  REVISED LANGUAGE KEY: Now at Topic level: 'Topic::Language'
        const languageKey = `${topic}::${language}`;

        setCompletedItems(prevItems => {
            if (prevItems.includes(languageKey)) {
                return prevItems;
            }

            const newItems = [...prevItems, languageKey];
            let updatedItems = newItems;
            const topicData = fetchedData.find(t => t.mainTopicName === topic);

            topicData?.subTopics.forEach(sub => {
                updatedItems = checkSubtopicAndTopicCompletion(topic, sub.title, updatedItems);
            });

            //  Call backend validation API for this specific language only once
            if (topicData?.mainTopicId) {
                axios.put(`${BASE_URL}/user/user-main-topic-engagement/${topicData.mainTopicId}/validate-completion?language=${language.toUpperCase()}`)
                    .then(response => {
                        console.log(` Main topic completion validated for ${topic} (${language})`, response.data);

                        // Show success message to user
                        if (response.data?.success) {
                            toast.success(response.data.message || `${language} completed successfully for ${topic}!`);
                        }
                    })
                    .catch(error => {
                        console.error(`❌ Failed to validate main topic completion for ${topic} (${language})`, error);

                        // Show error message to user if validation failed
                        const errorMessage = error.response?.data?.message ||
                            `Could not mark ${language} as complete. Please ensure you have:\n` +
                            `1. Visited all subtopics in ${language}\n` +
                            `2. Completed all MCQs\n` +
                            `3. Spent at least 2 minutes or solved the Code Here problem in ${language}`;

                        toast.error(errorMessage);

                        // Remove the language key from completed items since validation failed
                        setCompletedItems(prev => prev.filter(item => item !== languageKey));
                    });
            }

            return updatedItems;
        });
    }, [checkSubtopicAndTopicCompletion, fetchedData]);
    // Function to mark a quiz as passed and check for subtopic/topic completion
    const markQuizPassed = useCallback((topic, subtopic, language) => {
        const quizKey = `${topic}::${subtopic}::passed`;
        setCompletedItems(prevItems => {
            // CRITICAL CHECK: Don't re-run logic if already passed
            if (prevItems.includes(quizKey)) {
                return prevItems;
            }
            const newItems = [...prevItems, quizKey];

            // ✅ UPDATED: Send MCQ visited status to backend WITH LANGUAGE PARAMETER
            const topicData = fetchedData.find(t => t.mainTopicName === topic);
            const subtopicData = topicData?.subTopics?.find(s => s.title === subtopic);
            if (subtopicData?.topicId && language) {
                axios.put(`${BASE_URL}/user/topic-engagement/${subtopicData.topicId}/mcq-visited`, null, {
                    params: { language: language.toUpperCase() }
                })
                    .then(response => {
                        console.log(`✅ MCQ marked as visited for topic ${subtopicData.topicId} in ${language}`, response.data);
                        toast.success(`${language} MCQ completed for ${subtopic}!`);
                    })
                    .catch(error => {
                        console.error(`❌ Failed to mark MCQ as visited for topic ${subtopicData.topicId}`, error);
                        toast.error(`Failed to save MCQ completion for ${language}`);
                    });
            }

            // Check completion for the specific subtopic where the quiz was passed
            return checkSubtopicAndTopicCompletion(topic, subtopic, newItems);
        });
    }, [checkSubtopicAndTopicCompletion, fetchedData]);

    return {
        timers,
        completedItems,
        setCompletedItems,
        markLanguageComplete,
        markQuizPassed,
    };
}

// Session Contents Modal Component
export function SessionContentsModal({ isOpen, onClose, selectedTopic, fetchedData }) {
    const [notebooks, setNotebooks] = useState([]);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (!isOpen || !selectedTopic) return;

        const fetchNotebooks = async () => {
            setLoading(true);
            try {
                const topicData = fetchedData.find(t => t.mainTopicName === selectedTopic);
                if (!topicData?.mainTopicId) {
                    toast.error("Topic ID not found");
                    return;
                }

                const response = await axios.get(`${BASE_URL}/user/notebooks/${topicData.mainTopicId}`);
                setNotebooks(response.data || []);
            } catch (error) {
                console.error("Error fetching notebooks:", error);
                toast.error("Failed to fetch session contents");
                setNotebooks([]);
            } finally {
                setLoading(false);
            }
        };

        fetchNotebooks();
    }, [isOpen, selectedTopic, fetchedData]);

    const handleDownload = async (notebookId, title, fileType) => {
        try {
            toast.loading(`Downloading ${title}...`, { id: `download-${notebookId}` });

            const response = await axios.get(`${BASE_URL}/user/notebooks/download/${notebookId}`, {
                responseType: 'blob',
            });

            // Get the filename from Content-Disposition header or use title with extension
            let fileName = title;
            const contentDisposition = response.headers['content-disposition'];
            if (contentDisposition) {
                const fileNameMatch = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/);
                if (fileNameMatch && fileNameMatch[1]) {
                    fileName = fileNameMatch[1].replace(/['"]/g, '');
                }
            } else {
                // Add extension based on fileType if not in title
                const extension = fileType === 'PDF' ? '.pdf' : '.ipynb';
                if (!fileName.toLowerCase().endsWith(extension)) {
                    fileName += extension;
                }
            }

            // Create blob URL and trigger download
            const blob = new Blob([response.data], {
                type: response.headers['content-type'] || 'application/octet-stream'
            });
            const url = window.URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', fileName);
            document.body.appendChild(link);
            link.click();

            // Cleanup
            link.remove();
            window.URL.revokeObjectURL(url);

            toast.success(`Downloaded ${fileName}`, { id: `download-${notebookId}` });
        } catch (error) {
            console.error("Error downloading notebook:", error);
            toast.error("Failed to download notebook", { id: `download-${notebookId}` });
        }
    };

    if (!isOpen) return null;

    return (
        <div
            style={{
                position: "fixed",
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                backgroundColor: "rgba(0, 0, 0, 0.5)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                zIndex: 1000,
            }}
            onClick={onClose}
        >
            <div
                style={{
                    backgroundColor: "#fff",
                    borderRadius: "12px",
                    padding: "24px",
                    minWidth: "500px",
                    maxWidth: "700px",
                    maxHeight: "80vh",
                    overflowY: "auto",
                    boxShadow: "0 10px 40px rgba(0, 0, 0, 0.2)",
                }}
                onClick={(e) => e.stopPropagation()}
            >
                {/* Header */}
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
                    <h2 style={{ margin: 0, color: "#09122C", fontSize: "24px", fontWeight: "bold" }}>
                        Session Contents - {selectedTopic}
                    </h2>
                    <button
                        onClick={onClose}
                        style={{
                            background: "none",
                            border: "none",
                            cursor: "pointer",
                            fontSize: "24px",
                            color: "#666",
                        }}
                    >
                        <TbX />
                    </button>
                </div>

                {/* Content */}
                {loading ? (
                    <div style={{ textAlign: "center", padding: "40px", color: "#666" }}>
                        Loading notebooks...
                    </div>
                ) : notebooks.length === 0 ? (
                    <div style={{ textAlign: "center", padding: "40px", color: "#666" }}>
                        No notebooks available for this topic yet.
                    </div>
                ) : (
                    <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                        {notebooks.map((notebook) => (
                            <div
                                key={notebook.notebookId}
                                style={{
                                    display: "flex",
                                    justifyContent: "space-between",
                                    alignItems: "center",
                                    padding: "16px",
                                    backgroundColor: "#f6f7fb",
                                    borderRadius: "8px",
                                    border: "1px solid #e0e0e0",
                                }}
                            >
                                <div style={{ flex: 1 }}>
                                    <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "4px" }}>
                                        <TbNotebook style={{ color: "#DD6B20", fontSize: "20px" }} />
                                        <h4 style={{ margin: 0, color: "#09122C", fontSize: "16px" }}>
                                            {notebook.title}
                                        </h4>
                                    </div>
                                    <div style={{ display: "flex", gap: "12px", fontSize: "13px", color: "#666" }}>
                                        <span style={{
                                            backgroundColor: "#DD6B20",
                                            color: "#fff",
                                            padding: "2px 8px",
                                            borderRadius: "4px",
                                            fontSize: "12px"
                                        }}>
                                            {notebook.language}
                                        </span>
                                        <span style={{
                                            backgroundColor: "#09122C",
                                            color: "#fff",
                                            padding: "2px 8px",
                                            borderRadius: "4px",
                                            fontSize: "12px"
                                        }}>
                                            {notebook.fileType}
                                        </span>
                                    </div>
                                </div>
                                <button
                                    onClick={() => handleDownload(notebook.notebookId, notebook.title, notebook.fileType)}
                                    style={{
                                        backgroundColor: "#09122C",
                                        color: "#fff",
                                        border: "none",
                                        borderRadius: "6px",
                                        padding: "10px 16px",
                                        cursor: "pointer",
                                        display: "flex",
                                        alignItems: "center",
                                        gap: "6px",
                                        fontSize: "14px",
                                        fontWeight: "500",
                                        transition: "background-color 0.2s",
                                    }}
                                    onMouseEnter={(e) => e.target.style.backgroundColor = "#1a2444"}
                                    onMouseLeave={(e) => e.target.style.backgroundColor = "#09122C"}
                                >
                                    <TbDownload style={{ fontSize: "18px" }} />
                                    Download
                                </button>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}

export function TopicTimer({ currentTimerKey, timers }) {
    const seconds = timers[currentTimerKey] || 0;
    const formatTime = (s) => {
        const h = String(Math.floor(s / 3600)).padStart(2, "0");
        const m = String(Math.floor((s % 3600) / 60)).padStart(2, "0");
        const sec = String(s % 60).padStart(2, "0");
        return `${h}:${m}:${sec}`;
    };
    return (
        <div
            style={{
                background: "#09122C",
                color: "#fff",
                padding: "8px 16px",
                borderRadius: "6px",
                fontSize: "16px",
                fontWeight: "bold",
                display: "inline-block",
                minWidth: "110px",
                textAlign: "center",
            }}
        >
            {formatTime(seconds)}
        </div>
    );
}
export function Sidebar({
                            topics,
                            selectedTopic,
                            setSelectedTopic,
                            selectedSubtopic,
                            setSelectedSubtopic,
                            completedItems
                        }) {
    const [openTopic, setOpenTopic] = useState(selectedTopic);

    useEffect(() => setOpenTopic(selectedTopic), [selectedTopic]);

    const toggleTopic = (title) => {
        const newOpenTopic = openTopic === title ? null : title;
        setSelectedTopic(title); // Always update the selectedTopic

        setOpenTopic(newOpenTopic);

        const topicEntry = topics.find(t => t.mainTopicName === title);
        if (newOpenTopic === title && topicEntry && topicEntry.subTopics.length > 0) {
            const isCurrentSubtopicValid = topicEntry.subTopics.some(sub => sub.title === selectedSubtopic);
            if (!isCurrentSubtopicValid) {
                setSelectedSubtopic(topicEntry.subTopics[0].title);
            }
        }
    };

    const selectSubtopic = (subTitle) => {
        // Find the main topic for the selected subtopic
        const newTopic = topics.find(t => t.subTopics.some(s => s.title === subTitle))?.mainTopicName;

        // If the main topic is different, update both topic and openTopic state
        if (newTopic && newTopic !== selectedTopic) {
            setSelectedTopic(newTopic);
            setOpenTopic(newTopic);
        }

        // Always set the new subtopic
        setSelectedSubtopic(subTitle);
    };

    // Checks for subtopic completion (all languages + quiz passed)
    const isSubtopicCompleted = (mainTopicName, subTitle) =>
        completedItems.includes(`${mainTopicName}::${subTitle}::subtopic_complete`);

    // Checks for main topic completion (all subtopics complete)
    const isMainTopicCompleted = (mainTopicName) => {
        const topicData = topics.find(t => t.mainTopicName === mainTopicName);
        if (!topicData) return false;

        // Get all subtopics of this main topic
        const allSubtopics = topicData.subTopics || [];

        // The languages that must be marked as complete by the user
        const allLanguages = ["Java", "Python", "JavaScript", "TypeScript"];

        // Each subtopic must have ALL languages marked complete
        const isEverySubtopicFullyCompleted = allSubtopics.every(sub =>
            allLanguages.every(lang =>
                completedItems.includes(`${mainTopicName}::${lang}`)
            )
        );

        // Return true only if all subtopics across all languages are marked complete
        return isEverySubtopicFullyCompleted;
    };

    return (
        <div
            style={{
                width: 220,
                background: "#09122C",
                color: "#fff",
                position: "sticky",
                top: 0,
                height: "100vh",
                overflowY: "auto",
                scrollBehavior: "smooth",
                fontFamily: "sans-serif",
                padding: "10px 0",
                boxSizing: "border-box",
            }}
        >
            <div
                style={{
                    fontWeight: "bold",
                    marginLeft: 70,
                    fontSize: 20,
                    marginBottom: 10,
                }}
            >
                Topics
            </div>

            <ul style={{ listStyle: "none", padding: 0, margin: "16px 0" }}>
                {topics.map((mainTopic) => {
                    const mainTopicCompleted = isMainTopicCompleted(mainTopic.mainTopicName);
                    return (
                        <li style={{ marginBottom: 14 }} key={mainTopic.mainTopicId}>
                            {/* Main Topic */}
                            <div
                                style={{
                                    marginLeft: 13,
                                    fontWeight: 600,
                                    cursor: "pointer",
                                    transition: "all 0.2s ease",
                                    backgroundColor: selectedTopic === mainTopic.mainTopicName ? "transparent" : "transparent",
                                    fontSize: selectedTopic === mainTopic.mainTopicName ? "1.1rem" : "1rem",
                                    borderRadius: "4px",
                                    padding: "6px 8px",
                                    marginBottom: 6,
                                    marginTop: 20,
                                    display: "flex",
                                    justifyContent: "space-between",
                                    alignItems: "center",
                                }}
                                onClick={() => toggleTopic(mainTopic.mainTopicName)}
                            >
                                <span>{mainTopic.mainTopicName}</span>

                                <div style={{ display: "flex", alignItems: "center", gap: "5px" }}>
                                    {mainTopicCompleted && <TbCheck style={{ color: "#fff" }} />}
                                    {openTopic === mainTopic.mainTopicName ? (
                                        <FaChevronUp style={{ color: "#fff" }} />
                                    ) : (
                                        <FaChevronDown style={{ color: "#fff" }} />
                                    )}
                                </div>

                            </div>

                            {/* Subtopics */}
                            {openTopic === mainTopic.mainTopicName && mainTopic.subTopics.length > 0 && (
                                <ul style={{ listStyle: "none", margin: 0, paddingLeft: 26 }}>
                                    {mainTopic.subTopics.map((subTopic) => {
                                        const completed = isSubtopicCompleted(
                                            mainTopic.mainTopicName,
                                            subTopic.title
                                        );
                                        return (
                                            <li
                                                key={subTopic.topicId}
                                                style={{
                                                    fontWeight: 400,
                                                    marginTop: 3,
                                                    cursor: "pointer",
                                                    backgroundColor:
                                                        selectedSubtopic === subTopic.title ? "#DD6B20" : "transparent",
                                                    fontSize:
                                                        selectedSubtopic === subTopic.title ? "1.05rem" : "1rem",
                                                    borderRadius: "4px",
                                                    padding: "3px 6px",
                                                    transition: "all 0.2s ease",
                                                    display: "flex",
                                                    justifyContent: "space-between",
                                                    alignItems: "center",
                                                }}
                                                onClick={() => selectSubtopic(subTopic.title)}
                                            >
                                                <span>{subTopic.title}</span>
                                                {completed && <TbCheck style={{ color: "#fff", marginLeft: 5 }} />}
                                            </li>
                                        );
                                    })}
                                </ul>
                            )}
                        </li>
                    );
                })}
            </ul>
        </div>

    );
}

export function DataTypesTabs({
                                  selectedTopic,
                                  selectedSubtopic,
                                  completedItems,
                                  fetchedData,
                                  markLanguageComplete,
                                  setSelectedLanguage,
                                  setCompletedItems, // NEW prop
                                  navigate
                              }) {
    const topicData = fetchedData.find(t => t.mainTopicName === selectedTopic);
    const subtopicData = topicData?.subTopics?.find(s => s.title === selectedSubtopic);
    const subtopicIndex = topicData?.subTopics.findIndex(s => s.title === selectedSubtopic);
    const isLastSubtopic = subtopicIndex === (topicData?.subTopics.length - 1);
    const [questionId, setQuestionId] = useState(1);

    const languages =
        subtopicData?.content?.language_details?.map(d => d.language) ||
        ["Java", "Python", "JavaScript", "TypeScript"];

    // Use localStorage to persist the selected language tab
    const [tab, setTab] = useState(() => {
        const savedLang = localStorage.getItem('selectedLanguageTab');
        if (savedLang && languages.includes(savedLang)) {
            return savedLang;
        }
        return languages[0] || "Java";
    });

    // Helper: read visited keys array from localStorage
    const readVisited = () => JSON.parse(localStorage.getItem("visitedLanguages") || "[]");

    // When the tab (language) changes we persist selected language and mark visited for this (topic, subtopic, language)
    useEffect(() => {
        setSelectedLanguage(tab);
        localStorage.setItem('selectedLanguageTab', tab); // save tab selection

        // NEW: Use per-subtopic-per-language visited key
        // Format: `${topic}::${subtopic}::${language}::visited`
        if (!selectedTopic || !selectedSubtopic || !tab) return;

        const langVisitedKey = `${selectedTopic}::${selectedSubtopic}::${tab}::visited`;

        const visitedLanguages = readVisited();

        if (!visitedLanguages.includes(langVisitedKey)) {
            const updatedVisited = [...visitedLanguages, langVisitedKey];
            localStorage.setItem("visitedLanguages", JSON.stringify(updatedVisited));

            // Dispatch event so tick marks update everywhere
            window.dispatchEvent(new Event("visitedLanguagesUpdated"));

            // After recording this visit, check: have all languages for THIS subtopic been visited?
            const allLangsVisitedForThisSubtopic = languages.every(lang =>
                updatedVisited.includes(`${selectedTopic}::${selectedSubtopic}::${lang}::visited`)
            );

            if (allLangsVisitedForThisSubtopic) {
                const subtopicCompleteKey = `${selectedTopic}::${selectedSubtopic}::subtopic_complete`;
                setCompletedItems(prev => {
                    if (prev.includes(subtopicCompleteKey)) return prev;
                    const next = [...prev, subtopicCompleteKey];

                    // After adding this subtopic completion, optionally auto-mark main topic if all subtopics are complete
                    const allSubtopicsComplete = (topicData?.subTopics || []).every(sub =>
                        next.includes(`${selectedTopic}::${sub.title}::subtopic_complete`)
                    );
                    if (allSubtopicsComplete) {
                        const mainTopicCompleteKey = `${selectedTopic}::main_topic_complete`;
                        if (!next.includes(mainTopicCompleteKey)) next.push(mainTopicCompleteKey);
                    }

                    return next;
                });
            }
        }
    }, [tab, selectedTopic, selectedSubtopic, setSelectedLanguage, setCompletedItems, topicData, languages]);

    // Update tab when subtopic changes (no logic changes, but kept)
    useEffect(() => {
        const savedLang = localStorage.getItem('selectedLanguageTab');
        if (languages.length > 0) {
            if (savedLang && languages.includes(savedLang)) {
                setTab(savedLang);
            } else if (!languages.includes(tab)) {
                setTab(languages[0]);
            }
        }
    }, [selectedSubtopic, languages, tab]);

    const currentLangDetail = subtopicData?.content?.language_details?.find(
        d => d.language === tab
    );

    const currentData = {
        content: subtopicData?.content?.explaination || "Explanation not available.",
        code: currentLangDetail?.example || "Example code not available.",
        note:
            subtopicData?.content?.code_difference_explaination ||
            "No difference note provided.",
    };

    const quizKey = `${selectedTopic}::${selectedSubtopic}`;
    const isQuizCompleted = completedItems.includes(`${quizKey}::passed`);

    // Language completion check at Topic level (when user has explicitly "marked as complete")
    const isLangCompletedForTopic = completedItems.includes(`${selectedTopic}::${tab}`);

    // Helper: read visited array (local)
    const visitedLanguages = readVisited();

    // Determine if the current language has been visited for ALL subtopics of the current topic
    const allSubtopicsVisitedForThisLang = (topicData?.subTopics || []).every(sub =>
        visitedLanguages.includes(`${selectedTopic}::${sub.title}::${tab}::visited`)
    );

    // For UI tab tick: show tick if language is marked complete OR user has visited this language across all subtopics
    const isLanguageTicked = (lang) => {
        const langCompleteKey = `${selectedTopic}::${lang}`;
        const isExplicitComplete = completedItems.includes(langCompleteKey);
        const allVisited = (topicData?.subTopics || []).every(sub =>
            visitedLanguages.includes(`${selectedTopic}::${sub.title}::${lang}::visited`)
        );
        return isExplicitComplete || allVisited;
    };

    // Enable "Mark as Complete" only if:
    // 1) This is last subtopic (already enforced where button renders)
    // 2) The current language has visits for every subtopic (allSubtopicsVisitedForThisLang)
    // 3) The quiz for the LAST subtopic is passed
    const lastSubtopicTitle = topicData?.subTopics?.[topicData.subTopics.length - 1]?.title;
    const isLastQuizPassed = lastSubtopicTitle ? completedItems.includes(`${selectedTopic}::${lastSubtopicTitle}::passed`) : false;
    //  Updated: Enable Mark as Complete only if ALL subtopics in ALL languages are visited & quiz passed
    const allLanguages = ["Java", "Python", "JavaScript", "TypeScript"];

    // Check if ALL subtopics across ALL languages have been visited
    const allSubtopicsVisitedInAllLanguages = (topicData?.subTopics || []).every(sub =>
        allLanguages.every(lang =>
            visitedLanguages.includes(`${selectedTopic}::${sub.title}::${lang}::visited`)
        )
    );

    // Enable button only when ALL subtopics across all languages are visited AND last quiz is passed
    //  Enable "Mark as Complete" only when all subtopics in the current language are visited
    const canMarkLanguageComplete = allSubtopicsVisitedForThisLang;
    const handleTopicwiseQuestionFetch = async () => {
        try {
            // Get the mainTopicId from the current selected topic
            if (!topicData?.mainTopicId) {
                toast.error("Main Topic ID not found");
                console.error("Main Topic ID not found for:", selectedTopic);
                return;
            }

            console.log(`🔍 Fetching problem for ${selectedTopic} (mainTopicId: ${topicData.mainTopicId})`);

            // The axios interceptor will automatically add the Authorization header.
            const response = await axios.get(
                `${BASE_URL}/user/problem-submissions/main-topic`,
                {
                    params: { mainTopicId: topicData.mainTopicId },
                }
            );

            if (response.data && response.data.problemDTO) {
                const fetchedProblemId = response.data.problemDTO.problemId;
                setQuestionId(fetchedProblemId);
                console.log(`✅ Fetched Problem ID for ${selectedTopic} (mainTopicId: ${topicData.mainTopicId}):`, fetchedProblemId);
                toast.success("Problem loaded successfully! Redirecting...");

                // ✅ Navigate to compiler with the newly fetched ID
                navigate(`/compiler/${fetchedProblemId}`, {
                    state: {
                        selectedTopic: selectedTopic,
                        selectedSubTopic: selectedSubtopic,
                        subtopics: topicData?.subTopics?.map(s => s.title) || []
                    }
                });

            } else {
                console.error("Invalid API response structure:", response.data);
                toast.error("Failed to load problem");
            }
        } catch (error) {
            console.error("Error fetching main topic problem:", error);
            if (error.response?.status === 401 || error.response?.status === 403) {
                toast.error("Authentication failed. Please login again.");
            } else {
                toast.error("Failed to fetch problem. Please try again.");
            }
        }
    };

    const handleMarkComplete = () => {
        if (!isLangCompletedForTopic && canMarkLanguageComplete) {
            //  Mark this language as complete in your app logic
            markLanguageComplete(selectedTopic, selectedSubtopic, tab);

            //  Move to next language if needed
            const currentIndex = languages.indexOf(tab);
            const nextIndex = currentIndex + 1;
            if (nextIndex < languages.length) {
                setTab(languages[nextIndex]);
            }
        }
    };
    return (
        <div>
            {/* Language Tabs */}
            <div style={{ display: "flex", margin: "0 0 15px 0", gap: 30 }}>
                {languages.map((lang) => {
                    const isThisLangCompleted = isLanguageTicked(lang);
                    return (
                        <button
                            key={lang}
                            onClick={() => setTab(lang)}
                            style={{
                                padding: "8px 24px",
                                background: tab === lang ? "#09122C" : "#DD6B20",
                                border: "none",
                                fontWeight: tab === lang ? "bold" : "normal",
                                cursor: "pointer",
                                fontSize: 17,
                                color: "#fff",
                                marginBottom: 23,
                                marginTop: 25,
                            }}
                        >
                            {lang}{" "}
                            {isThisLangCompleted && (
                                <TbCheck style={{ color: "#fff", marginLeft: 5 }} />
                            )}
                        </button>
                    );
                })}
            </div>

            {/* Content Section */}
            <div style={{ marginTop: 8, padding: 8 }}>
                <h3 style={{ marginBottom: 8 }}>{`${selectedSubtopic} in ${tab}`}</h3>
                <p style={{ marginBottom: 8 }}>{currentData.content}</p>
                <pre
                    style={{
                        background: "#fff",
                        color: "#333",
                        padding: 16,
                        fontSize: 15,
                        borderRadius: 6,
                        marginBottom: 10,
                    }}
                >
                    {currentData.code}
                </pre>

                <small style={{ color: "#333", fontSize: 14 }}>
                    <b>Note:</b> {currentData.note}
                </small>

                <div style={{ marginTop: 12, display: "flex", gap: "20px" }}>
                    {/* Take Quiz Button */}
                    <Link
                        to={!isQuizCompleted ? `/mcq_page/${questionMap[tab] || 'default'}` : "#"}
                        state={{ mainTopic: selectedTopic, subtopic: selectedSubtopic }}
                        style={{ textDecoration: "none" }}
                        onClick={(e) => isQuizCompleted && e.preventDefault()}
                    >
                        <button
                            style={{
                                padding: "6px 14px",
                                fontSize: "14px",
                                borderRadius: "6px",
                                cursor: isQuizCompleted ? "not-allowed" : "pointer",
                                background: isQuizCompleted ? "#DD6B20" : "#09122C",
                                color: "#fff",
                                border: "none",
                                display: "flex",
                                alignItems: "center",
                            }}
                        >
                            <TbBulb style={{ marginRight: "10px" }} />
                            {isQuizCompleted ? "Quiz Completed" : "Take Quiz"}
                        </button>
                    </Link>

                    {/* Code Here Button - Visible ONLY on the last subtopic */}
                    {isLastSubtopic && (
                        <div style={{ textDecoration: "none" }}>
                            <button
                                onClick={handleTopicwiseQuestionFetch}
                                style={{
                                    padding: "6px 14px",
                                    fontSize: "14px",
                                    borderRadius: "6px",
                                    cursor: "pointer",
                                    background: "#09122C",
                                    color: "#fff",
                                    border: "none",
                                    display: "flex",
                                    alignItems: "center",
                                }
                                }
                            >
                                <FaCode style={{ marginRight: "10px" }} />
                                Code here
                            </button>
                        </div>
                    )}

                    {/* Mark as Complete Button - Only on last subtopic */}
                    {isLastSubtopic && (
                        <button
                            onClick={handleMarkComplete}
                            disabled={isLangCompletedForTopic || !canMarkLanguageComplete}
                            style={{
                                padding: "6px 14px",
                                fontSize: "14px",
                                borderRadius: "6px",
                                cursor: (isLangCompletedForTopic || !canMarkLanguageComplete) ? "not-allowed" : "pointer",
                                background: (isLangCompletedForTopic || !canMarkLanguageComplete) ? "#09122C" : "#DD6B20",
                                color: "#fff",
                                border: "none",
                                display: "flex",
                                alignItems: "center",
                                order: 99,
                                marginLeft: 'auto'
                            }}
                        >
                            <TbCheck style={{ marginRight: "10px" }} />
                            {isLangCompletedForTopic ? `Completed (${tab})` : "Mark as Complete"}
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
}
export default function LearningPage({ onLogout }) {
    const location = useLocation();
    const navigate = useNavigate();
    const [fetchedData, setFetchedData] = useState([]);
    const [isDataLoading, setIsDataLoading] = useState(true);
    const [dataError, setDataError] = useState(null);
    const [isModalOpen, setIsModalOpen] = useState(false);

    // Helper to read state from localStorage
    const getInitialState = (key, defaultValue) => {
        try {
            const saved = localStorage.getItem(key);
            // Handle explicit "null" string used for clearing persistent subtopic
            if (saved === "null") return null;
            return saved !== null ? saved : defaultValue;
        } catch (error) {
            console.error(`Error reading ${key} from localStorage:`, error);
            return defaultValue;
        }
    };

    const [selectedLanguage, setSelectedLanguage] = useState(
        getInitialState("selectedLanguage", "Java")
    );

    //  Fetch all main topics & subtopics from backend
    useEffect(() => {
        const fetchLearningContent = async () => {
            try {
                const url = `${BASE_URL}/user/topic-engagement/all-main-topics-sub-topics`;
                const response = await axios.get(url);

                let apiTopics = Array.isArray(response.data)
                    ? response.data
                    : Array.isArray(response.data?.[0])
                        ? response.data[0]
                        : [];

                if (apiTopics.length === 0 && response.data?.[0]?.mainTopicName)
                    apiTopics = [response.data[0]];

                localStorage.setItem("fetchedAPIData", JSON.stringify(response.data));
                setFetchedData(apiTopics);
            } catch (error) {
                console.error("API Fetch Error:", error);
                setDataError("Failed to fetch learning content from API.");
            } finally {
                setIsDataLoading(false);
            }
        };
        fetchLearningContent();

    }, []);

    const subtopicFromQuiz = location.state?.subtopic || null;
    const quizPassed = location.state?.quizPassed || false;

    // Get persisted values early
    const persistedTopic = getInitialState("selectedTopic", null);
    const persistedSubtopic = getInitialState("selectedSubtopic", null);
    const initialDefaultTopic = subtopicFromQuiz
        ? null // Will be resolved by validation effect
        : persistedTopic || null;

    const initialDefaultSubtopic = subtopicFromQuiz
        ? subtopicFromQuiz
        : persistedSubtopic || null;

    // We will let the validation effect determine the *actual* initial state after data loads.
    const [selectedTopic, setSelectedTopic] = useState(initialDefaultTopic);
    const [selectedSubtopic, setSelectedSubtopic] = useState(initialDefaultSubtopic);

    //  Use our custom timer hook
    const { timers, completedItems, setCompletedItems, markLanguageComplete, markQuizPassed } =
        usePersistentTopicTimers(selectedTopic, selectedSubtopic, selectedLanguage, fetchedData);


    //  Persistence effect for Topic and Subtopic
    useEffect(() => {
        if (selectedTopic) {
            localStorage.setItem("selectedTopic", selectedTopic);
        }
        if (selectedSubtopic) {
            localStorage.setItem("selectedSubtopic", selectedSubtopic);
        } else {
            localStorage.setItem("selectedSubtopic", "null"); // Explicitly set "null" string for clearing
        }
    }, [selectedTopic, selectedSubtopic]);

    //  Persistence effect for Language
    useEffect(() => {
        localStorage.setItem("selectedLanguage", selectedLanguage);
    }, [selectedLanguage]);
    useEffect(() => {
        // Only run if quiz was passed and navigation state is present
        if (quizPassed && location.state.mainTopic && location.state.subtopic) {
            const { mainTopic, subtopic } = location.state;

            // 1. ✅ UPDATED: Mark the quiz as passed with current language
            markQuizPassed(mainTopic, subtopic, selectedLanguage);

            // 2. Set the selected topic/subtopic to the one the quiz was for.
            setSelectedTopic(mainTopic);
            setSelectedSubtopic(subtopic);

            // 3. Clear the navigation state immediately after processing
            navigate(location.pathname, { replace: true, state: {} });
        }
    }, [quizPassed, location.state, navigate, markQuizPassed, selectedLanguage]);
    useEffect(() => {
        if (isDataLoading || fetchedData.length === 0) return;
        let newTopic = selectedTopic;
        let newSubtopic = selectedSubtopic;
        if (!newTopic || !fetchedData.some(t => t.mainTopicName === newTopic)) {
            const topicForSub = fetchedData.find(t => t.subTopics.some(s => s.title === newSubtopic))?.mainTopicName;

            newTopic = topicForSub || fetchedData[0]?.mainTopicName || null;
        }
        const currentTopicData = fetchedData.find(t => t.mainTopicName === newTopic);
        // --- 2. Resolve Subtopic ---
        const subtopicExistsInTopic = currentTopicData?.subTopics?.some(s => s.title === newSubtopic);
        // If subtopic is null OR invalid for the resolved topic, set to the first subtopic of the topic.
        if (!newSubtopic || !subtopicExistsInTopic) {
            newSubtopic = currentTopicData?.subTopics?.[0]?.title || null;
        }
        // Apply state updates only if they've changed
        if (newTopic !== selectedTopic) {
            setSelectedTopic(newTopic);
        }
        if (newSubtopic !== selectedSubtopic) {
            setSelectedSubtopic(newSubtopic);
        }

        // Dependencies: runs after data loads and whenever topic/subtopic state changes to re-validate.
    }, [isDataLoading, fetchedData, selectedTopic, selectedSubtopic]);

    //  REVISED TIMER KEY: Now scoped to TOPIC::LANGUAGE
    const currentTimerKey = selectedTopic && selectedLanguage
        ? `${selectedTopic}::${selectedLanguage}`
        : null;

    //  Render logic
    if (isDataLoading)
        return <div style={{ textAlign: 'center', marginTop: '50px' }}>Loading course content...</div>;
    if (dataError)
        return <div style={{ textAlign: 'center', marginTop: '50px', color: 'red' }}>{dataError}</div>;
    if (fetchedData.length === 0 || !selectedTopic || !selectedSubtopic)
        return <div style={{ textAlign: 'center', marginTop: '50px' }}>No content available.</div>;

    return (
        <div style={{ height: "100vh", overflow: "visible", display: "flex", flexDirection: "column" }}>
            <Toaster
                position="top-right"
                toastOptions={{
                    success: {
                        duration: 4000,
                        style: {
                            background: '#10B981',
                            color: '#fff',
                        },
                    },
                    error: {
                        duration: 5000,
                        style: {
                            background: '#EF4444',
                            color: '#fff',
                        },
                    },
                }}
            />
            <Navbar onLogout={onLogout} />
            <div style={{ display: "flex", flex: 1, fontFamily: "sans-serif", overflow: "visible" }}>
                {/* Sidebar */}
                <Sidebar
                    topics={fetchedData}
                    selectedTopic={selectedTopic}
                    setSelectedTopic={setSelectedTopic}
                    selectedSubtopic={selectedSubtopic}
                    setSelectedSubtopic={setSelectedSubtopic}
                    completedItems={completedItems}
                />

                {/* Main content area */}
                <div
                    style={{
                        flex: 1,
                        padding: "0px 30px",
                        height: "100%",
                        overflowY: "auto",
                        background: "#f6f7fb",

                    }}
                >
                    {/* Header with topic name, timer & session contents button */}
                    <div
                        style={{
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            marginBottom: 20,
                        }}
                    >
                        <div>
                            <h1 style={{ margin: 0, fontWeight: "bold", fontSize: "48px" }}>
                                {selectedTopic}
                            </h1>
                            <h3 style={{ marginTop: 35, color: "#09122C" }}>{selectedSubtopic}</h3>
                        </div>
                        <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
                            {/* Session Contents Button */}
                            <button
                                onClick={() => setIsModalOpen(true)}
                                style={{
                                    background: "#DD6B20",
                                    color: "#fff",
                                    padding: "8px 16px",
                                    borderRadius: "6px",
                                    fontSize: "14px",
                                    fontWeight: "500",
                                    border: "none",
                                    cursor: "pointer",
                                    display: "flex",
                                    alignItems: "center",
                                    gap: "8px",
                                }}
                            >
                                <TbNotebook style={{ fontSize: "18px" }} />
                                Session Contents
                            </button>
                            {/* Timer */}
                            <TopicTimer currentTimerKey={currentTimerKey} timers={timers} />
                        </div>
                    </div>

                    <p>Learn about {selectedSubtopic} in {selectedTopic} across languages.</p>

                    {/* Tabs for explanation + quiz */}
                    <DataTypesTabs
                        selectedTopic={selectedTopic}
                        selectedSubtopic={selectedSubtopic}
                        completedItems={completedItems}
                        fetchedData={fetchedData}
                        markLanguageComplete={markLanguageComplete}
                        setSelectedLanguage={setSelectedLanguage}
                        setCompletedItems={setCompletedItems}
                        navigate={navigate}
                    />

                </div>
            </div>

            {/* Session Contents Modal */}
            <SessionContentsModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                selectedTopic={selectedTopic}
                fetchedData={fetchedData}
            />
        </div>

    );
}
