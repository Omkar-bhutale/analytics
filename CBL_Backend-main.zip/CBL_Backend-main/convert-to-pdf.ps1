# Script to convert API documentation to PDF
# This script provides multiple options to convert the Markdown to PDF

Write-Host "====================================" -ForegroundColor Cyan
Write-Host "CBL API Documentation PDF Converter" -ForegroundColor Cyan
Write-Host "====================================" -ForegroundColor Cyan
Write-Host ""

$mdFile = "CBL_API_DOCUMENTATION.md"
$pdfFile = "CBL_API_DOCUMENTATION.pdf"

Write-Host "Options to convert Markdown to PDF:" -ForegroundColor Yellow
Write-Host ""

Write-Host "Option 1: Using Pandoc (Recommended)" -ForegroundColor Green
Write-Host "  1. Install Pandoc: https://pandoc.org/installing.html"
Write-Host "  2. Install MiKTeX (for LaTeX): https://miktex.org/download"
Write-Host "  3. Run: pandoc $mdFile -o $pdfFile --pdf-engine=xelatex"
Write-Host ""

Write-Host "Option 2: Using VS Code Extension" -ForegroundColor Green
Write-Host "  1. Install 'Markdown PDF' extension in VS Code"
Write-Host "  2. Open $mdFile"
Write-Host "  3. Right-click > 'Markdown PDF: Export (pdf)'"
Write-Host ""

Write-Host "Option 3: Using Online Converter" -ForegroundColor Green
Write-Host "  1. Visit: https://www.markdowntopdf.com/"
Write-Host "  2. Upload $mdFile"
Write-Host "  3. Download the generated PDF"
Write-Host ""

Write-Host "Option 4: Using Chrome/Edge Browser" -ForegroundColor Green
Write-Host "  1. Install 'Markdown Viewer' extension"
Write-Host "  2. Open $mdFile in browser"
Write-Host "  3. Press Ctrl+P > Save as PDF"
Write-Host ""

# Try to check if pandoc is installed
try {
    $pandocVersion = pandoc --version 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✓ Pandoc is installed!" -ForegroundColor Green
        Write-Host ""
        $response = Read-Host "Would you like to convert now using Pandoc? (y/n)"
        
        if ($response -eq 'y' -or $response -eq 'Y') {
            Write-Host "Converting..." -ForegroundColor Yellow
            pandoc $mdFile -o $pdfFile --pdf-engine=xelatex -V geometry:margin=1in
            
            if ($LASTEXITCODE -eq 0) {
                Write-Host "✓ PDF created successfully: $pdfFile" -ForegroundColor Green
            } else {
                Write-Host "✗ Conversion failed. Make sure LaTeX is installed." -ForegroundColor Red
            }
        }
    }
} catch {
    Write-Host "✗ Pandoc is not installed" -ForegroundColor Red
    Write-Host "  Install from: https://pandoc.org/installing.html" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Documentation file location:" -ForegroundColor Cyan
Write-Host "  $(Get-Location)\$mdFile" -ForegroundColor White
Write-Host ""
