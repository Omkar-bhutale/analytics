# Mark as Complete Button - Constraints & Logic

## Overview
The "Mark as Complete" button appears ONLY on the **last subtopic** of a main topic and allows users to mark a specific language as completed for that topic.

## Visual Location
- Appears at the bottom right of the content area
- Only visible when viewing the last subtopic
- One button per language tab

## Constraints for Enabling the Button

### ✅ Button is ENABLED when:

1. **All Subtopics Visited in Current Language**
   - User must have visited every subtopic in the currently selected language
   - Tracked via localStorage key: `${topic}::${subtopic}::${language}::visited`
   - Example: `Data Types::Variables::Java::visited`

2. **User is on Last Subtopic**
   - Button only appears on the last subtopic of the topic
   - Automatically hidden on all other subtopics

3. **Language Not Already Completed**
   - The current language hasn't been marked as complete yet
   - Checked via: `completedItems.includes('${topic}::${language}')`

### ❌ Button is DISABLED when:

1. **Not All Subtopics Visited**
   - Missing visits to one or more subtopics in current language
   - Visual feedback: Button appears grayed out

2. **Language Already Completed**
   - User already marked this language as complete for this topic
   - Button shows: "Completed (Java)" or similar

3. **Backend Validation Fails**
   - If validation API call fails, the completion is reverted
   - User sees error toast with requirements

## Visual States

### State 1: Enabled (Ready to Complete)
```
Background: #DD6B20 (Orange)
Text: "Mark as Complete"
Cursor: pointer
Action: Click to mark language as complete
```

### State 2: Disabled (Not Ready)
```
Background: #09122C (Dark Blue)
Text: "Mark as Complete"
Cursor: not-allowed
Reason: Not all subtopics visited yet
```

### State 3: Completed
```
Background: #09122C (Dark Blue)
Text: "Completed (Java)" / "Completed (Python)" etc.
Cursor: not-allowed
Icon: Check mark
```

## Backend Validation

When button is clicked, the following happens:

### 1. Frontend Check
```javascript
canMarkLanguageComplete = allSubtopicsVisitedForThisLang
```

### 2. API Call
```
PUT /user/user-main-topic-engagement/{mainTopicId}/validate-completion?language={LANGUAGE}
```

### 3. Backend Requirements (Validated by API)
The backend checks:
- ✅ All subtopics visited in the language
- ✅ All MCQs completed
- ✅ Either:
  - Minimum 2 minutes spent on the topic, OR
  - Code Here problem solved

### 4. Success Response
```json
{
  "success": true,
  "message": "Java completed successfully for Data Types!"
}
```
- Language marked as complete
- Checkmark appears on language tab
- Button changes to "Completed (Java)"
- Success toast notification shown

### 5. Failure Response
```json
{
  "success": false,
  "message": "Requirements not met"
}
```
- Completion is reverted
- Error toast shown with requirements
- User must fulfill missing requirements

## User Workflow Example

### Scenario: Completing Java for "Data Types" Topic

#### Step 1: Visit All Subtopics
- Navigate to each subtopic (Variables, Numbers, Strings, etc.)
- View content in Java language tab
- Automatic tracking of visits

#### Step 2: Complete MCQs (Optional but Recommended)
- Click "Take Quiz" button on each subtopic
- Pass the quiz (tracked as `${topic}::${subtopic}::passed`)

#### Step 3: Navigate to Last Subtopic
- Go to the last subtopic in the list
- Switch to Java tab (if not already on it)

#### Step 4: Check Button State
- If button is orange and says "Mark as Complete" → Ready!
- If button is dark blue → Check which subtopics you haven't visited

#### Step 5: Click "Mark as Complete"
- Button sends validation request to backend
- Backend verifies all requirements
- If pass: Language marked complete ✓
- If fail: Error message explains what's missing

#### Step 6: Continue to Next Language
- Button automatically switches to next language tab
- Repeat process for Python, JavaScript, TypeScript

## Code Location

### File: `LearningPage/DataTypesTabs.jsx`

### Key Variables:
```javascript
// Check if all subtopics visited in current language
const allSubtopicsVisitedForThisLang = (topicData?.subTopics || []).every(sub =>
    visitedLanguages.includes(`${selectedTopic}::${sub.title}::${tab}::visited`)
);

// Enable button logic
const canMarkLanguageComplete = allSubtopicsVisitedForThisLang;

// Already completed check
const isLangCompletedForTopic = completedItems.includes(`${selectedTopic}::${tab}`);
```

### Button JSX:
```jsx
{isLastSubtopic && (
    <button
        onClick={handleMarkComplete}
        disabled={isLangCompletedForTopic || !canMarkLanguageComplete}
        style={{
            padding: "6px 14px",
            fontSize: "14px",
            borderRadius: "6px",
            cursor: (isLangCompletedForTopic || !canMarkLanguageComplete) ? "not-allowed" : "pointer",
            background: (isLangCompletedForTopic || !canMarkLanguageComplete) ? "#09122C" : "#DD6B20",
            // ... more styles
        }}
    >
        <TbCheck style={{ marginRight: "10px" }} />
        {isLangCompletedForTopic ? `Completed (${tab})` : "Mark as Complete"}
    </button>
)}
```

## Tips for Users

### To Enable the Button:
1. **Visit Every Subtopic** in the language you want to complete
2. **Stay on each subtopic** for at least a second (auto-tracked)
3. **Go to the last subtopic** to see the button
4. **Ensure 2+ minutes** spent OR solve the Code Here problem
5. **Complete all MCQs** (recommended)

### Visual Feedback:
- **Checkmark on tab** = All subtopics visited for that language
- **Orange button** = Ready to mark complete
- **Gray button** = Requirements not met
- **"Completed" text** = Already marked complete

## LocalStorage Keys

### Visit Tracking:
```
visitedLanguages: [
  "Data Types::Variables::Java::visited",
  "Data Types::Variables::Python::visited",
  "Data Types::Numbers::Java::visited",
  ...
]
```

### Completion Tracking:
```
completedQuizzes: [
  "Data Types::Java",              // Language complete
  "Data Types::Variables::passed",  // Quiz passed
  "Data Types::subtopic_complete",  // Subtopic complete
  ...
]
```

## Troubleshooting

### Button is Gray (Disabled)

**Check 1:** Have you visited all subtopics in this language?
- Navigate through each subtopic with the current language tab selected

**Check 2:** Are you on the last subtopic?
- Button only appears on the last subtopic

**Check 3:** Is the language already completed?
- Look for checkmark on the language tab

### Button Click Fails

**Error:** "Requirements not met"
- Ensure 2+ minutes spent OR Code Here problem solved
- Complete all MCQs for the topic
- Visit all subtopics in the language

**Error:** "Authentication failed"
- User session expired
- Login again

**Error:** "Main Topic ID not found"
- Data loading issue
- Refresh the page

## Summary

| Requirement | Check Method | Status Indicator |
|-------------|--------------|------------------|
| All subtopics visited | LocalStorage check | Checkmark on language tab |
| On last subtopic | Index check | Button visible |
| Not already complete | CompletedItems check | Button shows "Mark as Complete" |
| Time/Problem requirement | Backend validation | API response on click |
| All MCQs complete | Backend validation | API response on click |

**Key Takeaway:** The button intelligently guides users through the completion process with clear visual feedback and backend validation to ensure quality learning engagement.

