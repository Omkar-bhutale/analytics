package com.ignite.CBL.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Table(name = "pseudocode_submissions")
public class PseudocodeSubmission {

    @Id
    @Column(name = "pseudocode_submission_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer pseudocodeSubmissionId;

    @Column(name = "content", columnDefinition = "text")
    private String content;


    @Column(name = "version",nullable = false)
    @Version
    private int version = 0;

    @Column(name = "submitted_at",nullable = false)
    private LocalDateTime submittedAt;

    @Column(name = "total_second_spent", columnDefinition = "integer default 0")
    private Integer totalSecondSpent;

    @PrePersist
    private void prePersist() {
        submittedAt = LocalDateTime.now();
    }
    @PreUpdate
    private void preUpdate() {
        submittedAt = LocalDateTime.now();
    }

    @Column(name = "is_correct",nullable = false)
    private Boolean isCorrect = false;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id",nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "problem_id", nullable = false)
    @JsonBackReference("problem-pseudocode")
    private Problem problem;
}
