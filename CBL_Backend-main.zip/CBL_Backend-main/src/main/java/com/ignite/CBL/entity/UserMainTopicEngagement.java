package com.ignite.CBL.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "user_main_topic_engagement")
@Getter
@Setter
public class UserMainTopicEngagement {

    @EmbeddedId
    private UserMainTopicEngagementId userTopicEngagementId;

    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("userId")
    @JoinColumn(name = "user_id", updatable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("mainTopicId")
    @JoinColumn(name = "main_topic_id", updatable = false)
    @JsonBackReference("main-topic-engagements")
    private MainTopic mainTopic;

    @Column(name = "total_seconds_spent", nullable = false)
    private int totalTimeSpent = 0;

    @Column(name = "last_activity_at", nullable = false)
    private LocalDateTime lastActivityAt;


    @Column(name = "java_time_seconds")
    private Long javaTimeSeconds = 0L;

    @Column(name = "python_time_seconds")
    private Long pythonTimeSeconds = 0L;

    @Column(name = "javascript_time_seconds")
    private Long javascriptTimeSeconds = 0L;

    @Column(name = "typescript_time_seconds")
    private Long typescriptTimeSeconds = 0L;

    @Column(name = "java_completed")
    private Boolean javaCompleted = false;

    @Column(name = "python_completed")
    private Boolean pythonCompleted = false;

    @Column(name = "javascript_completed")
    private Boolean javascriptCompleted = false;

    @Column(name = "typescript_completed")
    private Boolean typescriptCompleted = false;

    @Column(name = "is_completed", nullable = false)
    private boolean isCompleted = false;
}
