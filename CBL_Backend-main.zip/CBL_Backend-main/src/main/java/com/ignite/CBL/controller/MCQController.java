package com.ignite.CBL.controller;

import com.ignite.CBL.dto.MCQDTO;
import com.ignite.CBL.service.MCQService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/mcq")
public class MCQController {

    private MCQService mcqService;

    public MCQController(MCQService mcqService) {
        this.mcqService = mcqService;
    }

    @GetMapping("/topic/{topicId}")
    public List<MCQDTO> findAllByTopicId(@PathVariable Integer topicId) {
        return mcqService.findAllByTopicId(topicId);
    }


}
