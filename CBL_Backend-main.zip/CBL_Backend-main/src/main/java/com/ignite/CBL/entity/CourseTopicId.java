package com.ignite.CBL.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Data;

import java.io.Serializable;

@Data
@Embeddable
public class CourseTopicId implements Serializable {

    @Column(name="course_id")
    private Integer courseId;
    @Column(name = "topic_id")
    private Integer topicId;


}