package com.ignite.CBL.repository;

import com.ignite.CBL.entity.Problem;
import com.ignite.CBL.entity.Difficulty;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

public interface ProblemRepository extends JpaRepository<Problem, Integer> {
    List<Problem> findByTopic_TopicId(Integer topicTopicId);

    @Query("SELECT p FROM Problem p WHERE p.mainTopic.mainTopicId = :mainTopicId")
    Optional<Problem> findProblemByMainTopicId(@Param("mainTopicId") Integer mainTopicId);




    @Query("SELECT p FROM Problem p WHERE p.topic.topicId = :topicId AND p.mainTopic IS NULL")
    List<Problem> findByTopicIdAndNotMainTopic(@Param("topicId") Integer topicId);


}
