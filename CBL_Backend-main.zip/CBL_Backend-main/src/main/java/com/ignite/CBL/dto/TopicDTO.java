package com.ignite.CBL.dto;

import com.ignite.CBL.entity.CourseTopicInfo;
import com.ignite.CBL.entity.TopicContent;
import com.ignite.CBL.entity.User;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TopicDTO {
    private Integer topicId;
    private String title;
    private TopicContent content;
    private LocalDateTime createdAt;
}
