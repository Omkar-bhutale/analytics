package com.ignite.CBL.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Data;

import java.io.Serializable;

@Embeddable
@Data
public class UserMainTopicEngagementId implements Serializable {
    @Column(name = "user_id")
    private String userId;
    @Column(name = "main_topic_id")
    private Integer mainTopicId;
}
