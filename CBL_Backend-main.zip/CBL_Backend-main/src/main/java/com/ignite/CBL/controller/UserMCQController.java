    package com.ignite.CBL.controller;

    import com.ignite.CBL.dto.MCQDTO;
    import com.ignite.CBL.service.MCQService;
    import io.swagger.v3.oas.annotations.Operation;
    import io.swagger.v3.oas.annotations.tags.Tag;
    import lombok.RequiredArgsConstructor;
    import org.springframework.http.ResponseEntity;
    import org.springframework.web.bind.annotation.*;

    import java.util.List;

    @RestController
    @RequestMapping("/user/mcqs")
    @RequiredArgsConstructor
    @Tag(name = "User MCQ Management", description = "APIs for users to access MCQs")
    public class UserMCQController {

        private final MCQService mcqService;

        @Operation(summary = "Get MCQ by ID")
        @GetMapping("/{id}")
        public ResponseEntity<MCQDTO> getMCQById(@PathVariable Integer id) {
            return mcqService.findMCQById(id)
                    .map(ResponseEntity::ok)
                    .orElse(ResponseEntity.notFound().build());
        }

        @Operation(summary = "Get all MCQs by topic ID")
        @GetMapping("/topic/{topicId}")
        public ResponseEntity<List<MCQDTO>> getAllMCQsByTopicId(@PathVariable Integer topicId) {
            return ResponseEntity.ok(mcqService.findAllMCQByTopicId(topicId));
        }

        @Operation(summary = "Count MCQs by topic ID")
        @GetMapping("/topic/{topicId}/count")
        public ResponseEntity<Long> countByTopicId(@PathVariable Integer topicId) {
            return ResponseEntity.ok(mcqService.countByTopicId(topicId));
        }

        @Operation(summary = "Get all MCQs by topic ID and language")
        @GetMapping("/topic/{topicId}/language/{language}")
        public ResponseEntity<List<MCQDTO>> getAllMCQsByTopicIdAndLanguage(
                @PathVariable Integer topicId,
                @PathVariable com.ignite.CBL.entity.Language language) {
            return ResponseEntity.ok(mcqService.findAllMCQByTopicIdAndLanguage(topicId, language));
        }

        @Operation(summary = "Count MCQs by topic ID and language")
        @GetMapping("/topic/{topicId}/language/{language}/count")
        public ResponseEntity<Long> countByTopicIdAndLanguage(
                @PathVariable Integer topicId,
                @PathVariable com.ignite.CBL.entity.Language language) {
            return ResponseEntity.ok(mcqService.countByTopicIdAndLanguage(topicId, language));
        }
    }
