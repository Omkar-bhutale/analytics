package com.ignite.CBL.service.impl;

import com.ignite.CBL.dto.MainTopicEngagementResponseDTO;
import com.ignite.CBL.dto.TopicEngagementResponseDTO;
import com.ignite.CBL.dto.TopicLanguageEngagementRequestDTO;
import com.ignite.CBL.entity.*;
import com.ignite.CBL.exception.ResourceNotFoundException;
import com.ignite.CBL.repository.TopicRepository;
import com.ignite.CBL.repository.UserRepository;
import com.ignite.CBL.repository.UserTopicEngagementRepository;
import com.ignite.CBL.repository.UserMainTopicEngagementRepository;
import com.ignite.CBL.service.UserTopicEngagementService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserTopicEngagementServiceImpl implements UserTopicEngagementService {

    private final UserTopicEngagementRepository engagementRepository;
    private final TopicRepository topicRepository;
    private final UserRepository userRepository;
    private final UserMainTopicEngagementRepository userMainTopicEngagementRepository;

    @Value("${user.id}")
    private String userId;

    @Override
    @Transactional
    public MainTopicEngagementResponseDTO updateLanguageWiseEngagement(TopicLanguageEngagementRequestDTO request) {
        log.info("Updating engagement for topic {}, language: {}", request.getTopicId(), request.getLanguage());

        Topic topic = topicRepository.findById(request.getTopicId())
                .orElseThrow(() -> new ResourceNotFoundException("Topic not found with id: " + request.getTopicId()));

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));

        UserTopicEngagement engagement = engagementRepository
                .findByUser_UserIdAndTopic_TopicId(userId, request.getTopicId())
                .orElseGet(() -> createNewEngagement(user, topic));

        //  Update time & completion based on language
        switch (request.getLanguage()) {
            case JAVA -> {

                engagement.setJavaTimeSeconds(
                        (engagement.getJavaTimeSeconds() == null ? 0 : engagement.getJavaTimeSeconds()) + request.getTimeSpentSeconds());
                engagement.setJavaVisited(true);
            }
            case PYTHON -> {

                engagement.setPythonTimeSeconds(
                        (engagement.getPythonTimeSeconds() == null ? 0 : engagement.getPythonTimeSeconds()) + request.getTimeSpentSeconds());
                engagement.setPythonVisited(true);
            }
            case JAVASCRIPT -> {


                engagement.setJavascriptTimeSeconds(
                        (engagement.getJavascriptTimeSeconds() == null ? 0 : engagement.getJavascriptTimeSeconds()) + request.getTimeSpentSeconds());
                engagement.setJavascriptVisited(true);
            }
            case TYPESCRIPT -> {

                engagement.setTypescriptTimeSeconds(
                        (engagement.getTypescriptTimeSeconds() == null ? 0 : engagement.getTypescriptTimeSeconds()) + request.getTimeSpentSeconds());
                engagement.setTypescriptVisited(true);
            }
        }

        //  Recalculate total time
        long totalTime = (engagement.getJavaTimeSeconds() == null ? 0 : engagement.getJavaTimeSeconds()) +
                (engagement.getPythonTimeSeconds() == null ? 0 : engagement.getPythonTimeSeconds()) +
                (engagement.getJavascriptTimeSeconds() == null ? 0 : engagement.getJavascriptTimeSeconds()) +
                (engagement.getTypescriptTimeSeconds() == null ? 0 : engagement.getTypescriptTimeSeconds());
        engagement.setTotalTimeSpent((int) totalTime);

        engagement.setLastActivityAt(LocalDateTime.now());

        engagementRepository.save(engagement);
        log.info("Engagement updated successfully for topic {} by user {}", topic.getTopicId(), userId);

        // 🔥 Update MainTopic cumulative engagement and return it
        updateMainTopicEngagement(topic, user);

        // Get the main topic ID and return the main topic engagement
        MainTopic mainTopic = topic.getMainTopic();
        if (mainTopic == null) {
            throw new ResourceNotFoundException("Main topic not found for topic id: " + request.getTopicId());
        }

        return getMainTopicEngagement(mainTopic.getMainTopicId());
    }

    @Override
    @Transactional
    public TopicEngagementResponseDTO getTopicEngagement(Integer topicId) {

        Topic topic = topicRepository.findById(topicId)
                .orElseThrow(() -> new ResourceNotFoundException("Topic not found with id: " + topicId));

        // Fetch user
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));

        // Find existing or create new engagement with default values
        UserTopicEngagement engagement = engagementRepository
                .findByUser_UserIdAndTopic_TopicId(userId, topicId)
                .orElseGet(() -> {
                    UserTopicEngagement newEngagement = new UserTopicEngagement();
                    UserTopicEngagementId id = new UserTopicEngagementId();
                    id.setUserId(userId);
                    id.setTopicId(topicId);
                    newEngagement.setUserTopicEngagementId(id);
                    newEngagement.setUser(user);
                    newEngagement.setTopic(topic);
                    newEngagement.setLastActivityAt(LocalDateTime.now());

                    // 🕒 Set default values
                    newEngagement.setTotalTimeSpent(0);
                    newEngagement.setJavaTimeSeconds(0L);
                    newEngagement.setPythonTimeSeconds(0L);
                    newEngagement.setJavascriptTimeSeconds(0L);
                    newEngagement.setTypescriptTimeSeconds(0L);

                    newEngagement.setJavaVisited(false);
                    newEngagement.setPythonVisited(false);
                    newEngagement.setJavascriptVisited(false);
                    newEngagement.setTypescriptVisited(false);

                    newEngagement.setCompleted(false);

                    // Save to DB immediately
                    return engagementRepository.save(newEngagement);
                });

        return mapToDTO(engagement);
    }

    @Override
    @Transactional
    public TopicEngagementResponseDTO markMcqAsVisited(Integer topicId, String language) {
        log.info("Marking MCQ as visited for topic {} in language {} by user {}", topicId, language, userId);

        Topic topic = topicRepository.findById(topicId)
                .orElseThrow(() -> new ResourceNotFoundException("Topic not found with id: " + topicId));

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));

        UserTopicEngagement engagement = engagementRepository
                .findByUser_UserIdAndTopic_TopicId(userId, topicId)
                .orElseGet(() -> createNewEngagement(user, topic));

        // Set language-specific MCQ visited flag
        switch (language.toUpperCase()) {
            case "JAVA" -> engagement.setJavaMcqVisited(true);
            case "PYTHON" -> engagement.setPythonMcqVisited(true);
            case "JAVASCRIPT" -> engagement.setJavascriptMcqVisited(true);
            case "TYPESCRIPT" -> engagement.setTypescriptMcqVisited(true);
            default -> throw new IllegalArgumentException("Invalid language: " + language);
        }

        // Also set the generic mcqVisited flag for backward compatibility
        engagement.setMcqVisited(true);
        engagement.setLastActivityAt(LocalDateTime.now());

        UserTopicEngagement saved = engagementRepository.save(engagement);
        log.info("MCQ marked as visited successfully for topic {} in language {} by user {}", topicId, language, userId);

        return mapToDTO(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public MainTopicEngagementResponseDTO getMainTopicEngagement(Integer mainTopicId) {
        log.info("Fetching main topic engagement for mainTopicId: {}", mainTopicId);

        // Find main topic to validate it exists
        MainTopic mainTopic = topicRepository.findMainTopicById(mainTopicId)
                .orElseThrow(() -> new ResourceNotFoundException("Main topic not found with id: " + mainTopicId));

        // Get or create engagement record
        UserMainTopicEngagement engagement = userMainTopicEngagementRepository
                .findByUser_UserIdAndMainTopic_MainTopicId(userId, mainTopicId)
                .orElseGet(() -> {
                    User user = userRepository.findById(userId)
                            .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));

                    UserMainTopicEngagement newEngagement = new UserMainTopicEngagement();
                    UserMainTopicEngagementId id = new UserMainTopicEngagementId();
                    id.setUserId(userId);
                    id.setMainTopicId(mainTopicId);
                    newEngagement.setUserTopicEngagementId(id);
                    newEngagement.setUser(user);
                    newEngagement.setMainTopic(mainTopic);
                    newEngagement.setLastActivityAt(LocalDateTime.now());

                    // Initialize fields
                    newEngagement.setTotalTimeSpent(0);
                    newEngagement.setJavaTimeSeconds(0L);
                    newEngagement.setPythonTimeSeconds(0L);
                    newEngagement.setJavascriptTimeSeconds(0L);
                    newEngagement.setTypescriptTimeSeconds(0L);
                    newEngagement.setJavaCompleted(false);
                    newEngagement.setPythonCompleted(false);
                    newEngagement.setJavascriptCompleted(false);
                    newEngagement.setTypescriptCompleted(false);
                    newEngagement.setCompleted(false);

                    return userMainTopicEngagementRepository.save(newEngagement);
                });

        // Map entity to DTO
        return MainTopicEngagementResponseDTO.builder()
                .mainTopicId(engagement.getMainTopic().getMainTopicId())
                .mainTopicName(engagement.getMainTopic().getTitle())
                .completed(engagement.isCompleted())
                .javaCompleted(engagement.getJavaCompleted())
                .pythonCompleted(engagement.getPythonCompleted())
                .javascriptCompleted(engagement.getJavascriptCompleted())
                .typescriptCompleted(engagement.getTypescriptCompleted())
                .javaTimeSeconds(engagement.getJavaTimeSeconds())
                .pythonTimeSeconds(engagement.getPythonTimeSeconds())
                .javascriptTimeSeconds(engagement.getJavascriptTimeSeconds())
                .typescriptTimeSeconds(engagement.getTypescriptTimeSeconds())
                .totalTimeSeconds(engagement.getTotalTimeSpent())
                .lastActivityAt(engagement.getLastActivityAt())
                .build();
    }

    private void updateMainTopicEngagement(Topic topic, User user) {
        MainTopic mainTopic = topic.getMainTopic();
        if (mainTopic == null) {
            log.warn("Topic {} has no associated MainTopic, skipping main topic engagement update", topic.getTopicId());
            return;
        }

        // Get all subtopics for this main topic
        List<Topic> subtopics = topicRepository.findAllByMainTopicIdComplete(mainTopic.getMainTopicId());

        // Fetch or create main topic engagement
        UserMainTopicEngagement mainEngagement = userMainTopicEngagementRepository
                .findByUser_UserIdAndMainTopic_MainTopicId(userId, mainTopic.getMainTopicId())
                .orElseGet(() -> createNewMainTopicEngagement(user, mainTopic));

        // Calculate cumulative time for each language across all subtopics
        Map<Language, Long> languageTimeMap = calculateLanguageTimesForMainTopic(subtopics);

        // Update main topic engagement times
        mainEngagement.setJavaTimeSeconds(languageTimeMap.getOrDefault(Language.JAVA, 0L));
        mainEngagement.setPythonTimeSeconds(languageTimeMap.getOrDefault(Language.PYTHON, 0L));
        mainEngagement.setJavascriptTimeSeconds(languageTimeMap.getOrDefault(Language.JAVASCRIPT, 0L));
        mainEngagement.setTypescriptTimeSeconds(languageTimeMap.getOrDefault(Language.TYPESCRIPT, 0L));

        // Calculate total time
        long totalTime = languageTimeMap.values().stream().mapToLong(Long::longValue).sum();
        mainEngagement.setTotalTimeSpent((int) totalTime);

        // Note: Completion status is NOT automatically calculated here
        // Users must explicitly click "Mark as Complete" button to mark languages as completed
        // The completion flags (javaCompleted, pythonCompleted, etc.) are set via separate API

        mainEngagement.setLastActivityAt(LocalDateTime.now());
        userMainTopicEngagementRepository.save(mainEngagement);
        log.info("Updated main topic engagement for mainTopicId: {}", mainTopic.getMainTopicId());
    }

    private Map<Language, Long> calculateLanguageTimesForMainTopic(List<Topic> subtopics) {
        Map<Language, Long> languageTimeMap = new EnumMap<>(Language.class);

        for (Topic subtopic : subtopics) {
            UserTopicEngagement engagement = engagementRepository
                    .findByUser_UserIdAndTopic_TopicId(userId, subtopic.getTopicId())
                    .orElse(null);

            if (engagement != null) {
                // Aggregate time for each language
                languageTimeMap.merge(Language.JAVA,
                    engagement.getJavaTimeSeconds() != null ? engagement.getJavaTimeSeconds() : 0L, Long::sum);
                languageTimeMap.merge(Language.PYTHON,
                    engagement.getPythonTimeSeconds() != null ? engagement.getPythonTimeSeconds() : 0L, Long::sum);
                languageTimeMap.merge(Language.JAVASCRIPT,
                    engagement.getJavascriptTimeSeconds() != null ? engagement.getJavascriptTimeSeconds() : 0L, Long::sum);
                languageTimeMap.merge(Language.TYPESCRIPT,
                    engagement.getTypescriptTimeSeconds() != null ? engagement.getTypescriptTimeSeconds() : 0L, Long::sum);
            }
        }

        return languageTimeMap;
    }


    private UserMainTopicEngagement createNewMainTopicEngagement(User user, MainTopic mainTopic) {
        UserMainTopicEngagement newMainEngagement = new UserMainTopicEngagement();
        UserMainTopicEngagementId id = new UserMainTopicEngagementId();
        id.setUserId(user.getUserId());
        id.setMainTopicId(mainTopic.getMainTopicId());
        newMainEngagement.setUserTopicEngagementId(id);
        newMainEngagement.setUser(user);
        newMainEngagement.setMainTopic(mainTopic);
        newMainEngagement.setLastActivityAt(LocalDateTime.now());

        // Initialize cumulative fields
        newMainEngagement.setTotalTimeSpent(0);
        newMainEngagement.setJavaTimeSeconds(0L);
        newMainEngagement.setPythonTimeSeconds(0L);
        newMainEngagement.setJavascriptTimeSeconds(0L);
        newMainEngagement.setTypescriptTimeSeconds(0L);
        newMainEngagement.setJavaCompleted(false);
        newMainEngagement.setPythonCompleted(false);
        newMainEngagement.setJavascriptCompleted(false);
        newMainEngagement.setTypescriptCompleted(false);
        newMainEngagement.setCompleted(false);

        return userMainTopicEngagementRepository.save(newMainEngagement);
    }

    private UserTopicEngagement createNewEngagement(User user, Topic topic) {
        UserTopicEngagement engagement = new UserTopicEngagement();
        UserTopicEngagementId id = new UserTopicEngagementId();
        id.setUserId(user.getUserId());
        id.setTopicId(topic.getTopicId());

        engagement.setUserTopicEngagementId(id);
        engagement.setUser(user);
        engagement.setTopic(topic);
        engagement.setLastActivityAt(LocalDateTime.now());

        // Initialize all time fields to prevent null issues
        engagement.setTotalTimeSpent(0);
        engagement.setJavaTimeSeconds(0L);
        engagement.setPythonTimeSeconds(0L);
        engagement.setJavascriptTimeSeconds(0L);
        engagement.setTypescriptTimeSeconds(0L);

        // Initialize visited flags
        engagement.setJavaVisited(false);
        engagement.setPythonVisited(false);
        engagement.setJavascriptVisited(false);
        engagement.setTypescriptVisited(false);
        engagement.setMcqVisited(false);

        engagement.setCompleted(false);

        return engagement;
    }

    private TopicEngagementResponseDTO mapToDTO(UserTopicEngagement engagement) {
        return TopicEngagementResponseDTO.builder()
                .topicId(engagement.getTopic().getTopicId())
                .topicTitle(engagement.getTopic().getTitle())
                .totalTimeSpent(engagement.getTotalTimeSpent())
                .lastActivityAt(engagement.getLastActivityAt())
                .languageStats(Map.of(
                        "java", Map.of(
                                "timeSeconds", engagement.getJavaTimeSeconds(),
                                "completed", engagement.getJavaVisited()
                        ),
                        "python", Map.of(
                                "timeSeconds", engagement.getPythonTimeSeconds(),
                                "completed", engagement.getPythonVisited()
                        ),
                        "javascript", Map.of(
                                "timeSeconds", engagement.getJavascriptTimeSeconds(),
                                "completed", engagement.getJavascriptVisited()
                        ),
                        "typescript", Map.of(
                                "timeSeconds", engagement.getTypescriptTimeSeconds(),
                                "completed", engagement.getTypescriptVisited()
                        )
                ))
                .build();
    }
}
