package com.ignite.CBL.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ignite.CBL.dto.*;
import com.ignite.CBL.entity.*;
import com.ignite.CBL.exception.ResourceNotFoundException;
import com.ignite.CBL.repository.*;
import com.ignite.CBL.service.UserDashboardService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional
@RequiredArgsConstructor
public class UserDashboardServiceImpl implements UserDashboardService {
    @Value("${user.id}")
    private String userId;

    private final UserRepository userRepository;
    private final UserProblemReportRepository userProblemReportRepository;
    private final ProblemSubmissionRepository problemSubmissionRepository;
    private final AdminDashboardRepository adminDashboardRepository;

    private final ProblemRepository problemRepository;




    @Override
    public List<UserDashboardResponceDTO> getAllUsersDashboard() {
        // Get all users
        List<User> allUsers = userRepository.findAll();

        return allUsers.stream()
                .map(user -> {
                    // Get all problem reports for the user
                    List<UserProblemReport> userProblemReports = userProblemReportRepository.findByUser_UserId(user.getUserId());

                    // Create and populate the response DTO
                    UserDashboardResponceDTO userDashboard = new UserDashboardResponceDTO();
                    userDashboard.setUserId(user.getUserId());
                    userDashboard.setUserName(user.getName());
                    userDashboard.setBatchName("Ignite Batch");

                    // Convert problem reports to DTOs with submissions
                    List<UserProblemReportDTO> problemReportDTOs = userProblemReports.stream()
                            .map(report -> {
                                UserProblemReportDTO dto = convertToUserProblemReportDTO(report);

                                // Get all submissions for this report
                                List<ProblemSubmission> submissions = problemSubmissionRepository
                                        .findByUserProblemReport_UserProblemReportIdOrderBySubmittedAtDesc(report.getUserProblemReportId());

                                // Convert submissions to DTOs
                                List<ProblemSubmissionResponceDTO> submissionDTOs = submissions.stream()
                                        .map(this::convertToProblemSubmissionDTO)
                                        .collect(Collectors.toList());

                                dto.setSubmissions(submissionDTOs);
                                return dto;
                            })
                            .collect(Collectors.toList());

                    userDashboard.setUserProblemReportDTOS(problemReportDTOs);
                    return userDashboard;
                })
                .collect(Collectors.toList());
    }

    @Override
    public UserDashboardResponceDTO getUserDashboard() {
        // Get user details
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + userId));

        // Get user's problem reports
        List<UserProblemReport> userProblemReports = userProblemReportRepository.findByUser_UserId(userId);

        // Create response DTO
        UserDashboardResponceDTO response = new UserDashboardResponceDTO();
        response.setUserId(userId);
        response.setUserName(user.getName());
        response.setBatchName("Ignite Batch");

        // Convert each problem report to DTO with its submissions
        List<UserProblemReportDTO> problemReportDTOs = userProblemReports.stream()
                .map(report -> {
                    // Convert report to DTO
                    UserProblemReportDTO dto = convertToUserProblemReportDTO(report);

                    // Get all submissions for this report
                    List<ProblemSubmission> submissions = problemSubmissionRepository
                            .findByUserProblemReport_UserProblemReportIdOrderBySubmittedAtDesc(report.getUserProblemReportId());

                    // Convert submissions to DTOs and set to the report DTO
                    List<ProblemSubmissionResponceDTO> submissionDTOs = submissions.stream()
                            .map(this::convertToProblemSubmissionDTO)
                            .collect(Collectors.toList());

                    dto.setSubmissions(submissionDTOs);
                    return dto;
                })
                .collect(Collectors.toList());

        response.setUserProblemReportDTOS(problemReportDTOs);

        return response;
    }

    private UserProblemReportDTO convertToUserProblemReportDTO(UserProblemReport report) {
        UserProblemReportDTO dto = new UserProblemReportDTO();
        dto.setSolved(report.isSolved());
        dto.setTotalAttempts(report.getTotalAttempts());
        dto.setLanguagesUsed(report.getLanguagesUsed());

        if (report.getProblem() != null) {
            ProblemDTO problemDTO = new ProblemDTO();
            problemDTO.setProblemId(report.getProblem().getProblemId());
            problemDTO.setTitle(report.getProblem().getTitle());
            problemDTO.setDifficulty(report.getProblem().getDifficulty());
            problemDTO.setDescription(report.getProblem().getDescription());
            dto.setProblem(problemDTO);

        }

        return dto;
    }

    private ProblemSubmissionResponceDTO convertToProblemSubmissionDTO(ProblemSubmission submission) {
        return ProblemSubmissionResponceDTO.builder()
                .problemId(submission.getProblem().getProblemId())
                .language(submission.getLanguage().name())
                .code(submission.getCode())
                .isCorrect(submission.getIsSolved())
                .totalTestCasesPassed(submission.getPassedTestCases())
                .totalTestCases(submission.getTotalTestCases())
                .insights(submission.getInsights())
                .build();
    }


    @Override
    public Map<String, Object> getUserDashboardStats() {
        return getUserDashboardStats(userId);
    }

    @Override
    public Map<String, Object> getUserDashboardStats(String userId){
        return adminDashboardRepository.findUserDetailedStats(userId)
                .map(stats -> {
                    Map<String, Object> result = new HashMap<>();

                    // Basic Info
                    result.put("userId", stats.getUserId());
                    result.put("userName", stats.getUserName());
                    result.put("email", stats.getUserEmail());

                    // Problem Counts
                    Map<String, Object> total = new HashMap<>();
                    total.put("total", stats.getTotalProblems());
                    total.put("solved", stats.getTotalSolved());
                    total.put("percentage", Math.round(stats.getTotalSolvedPercentage() * 100.0) / 100.0);
                    result.put("totalProblems", total);

                    // Difficulty Stats
                    Map<String, Object> difficultyStats = new HashMap<>();

                    Map<String, Object> easy = new HashMap<>();
                    easy.put("total", stats.getEasyTotal());
                    easy.put("solved", stats.getEasySolved());
                    easy.put("percentage", Math.round(stats.getEasySolvedPercentage() * 100.0) / 100.0);
                    difficultyStats.put("easy", easy);

                    Map<String, Object> medium = new HashMap<>();
                    medium.put("total", stats.getMediumTotal());
                    medium.put("solved", stats.getMediumSolved());
                    medium.put("percentage", Math.round(stats.getMediumSolvedPercentage() * 100.0) / 100.0);
                    difficultyStats.put("medium", medium);

                    Map<String, Object> hard = new HashMap<>();
                    hard.put("total", stats.getHardTotal());
                    hard.put("solved", stats.getHardSolved());
                    hard.put("percentage", Math.round(stats.getHardSolvedPercentage() * 100.0) / 100.0);
                    difficultyStats.put("hard", hard);

                    result.put("difficultyStats", difficultyStats);

                    // Language Stats
                    Map<String, Object> languageStats = new HashMap<>();
                    languageStats.put("java", stats.getJavaSolved());
                    languageStats.put("python", stats.getPythonSolved());
                    languageStats.put("javascript", stats.getJavascriptSolved());
                    languageStats.put("typescript", stats.getTypescriptSolved());
                    result.put("languageStats", languageStats);

                    // Parse and add AI-generated insights
                    ObjectMapper objectMapper = new ObjectMapper();
                    try {
                        JsonNode jsonNode = objectMapper.readTree(stats.getUserInsights());
                        result.put("insights", jsonNode);
                    } catch (Exception e) {
                        result.put("insights", null);
                    }

                    return result;
                })
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));
    }

    public List<UserProblemStats> getAllUsersWithProblemStats() {
        return adminDashboardRepository.findAllUsersWithProblemStats();


    }


}
