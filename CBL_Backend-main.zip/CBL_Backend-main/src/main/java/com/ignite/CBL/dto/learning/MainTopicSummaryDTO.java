package com.ignite.CBL.dto.learning;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for main topic summary (sidebar display)
 * Response for: GET /api/user/learning/main-topics
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MainTopicSummaryDTO {
    private Integer mainTopicId;
    private String name;
}

