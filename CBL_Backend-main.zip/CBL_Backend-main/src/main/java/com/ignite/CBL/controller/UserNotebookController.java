package com.ignite.CBL.controller;

import com.ignite.CBL.dto.NotebookResponseDTO;
import com.ignite.CBL.service.UserNotebookService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

@RestController
@RequestMapping("/user/notebooks")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "User Notebook Management", description = "APIs for users to view and download Jupyter notebooks uploaded by SME")
public class UserNotebookController {

    private final UserNotebookService userNotebookService;

    // -------------------------------------------------------------
    // 1 Get all notebooks for a specific MainTopic
    // -------------------------------------------------------------
    @Operation(
            summary = "Get all Jupyter notebooks for a MainTopic",
            description = "Returns a list of all uploaded notebooks for a given MainTopic, including title, language, and download URL."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "List of notebooks fetched successfully",
                    content = @Content(schema = @Schema(implementation = NotebookResponseDTO.class))),
            @ApiResponse(responseCode = "404", description = "No notebooks found for given MainTopic ID")
    })
    @GetMapping("/{mainTopicId}")
    public ResponseEntity<List<NotebookResponseDTO>> getNotebooksByMainTopic(@PathVariable Integer mainTopicId) {
        log.info("Fetching notebooks for MainTopic ID: {}", mainTopicId);
        List<NotebookResponseDTO> response = userNotebookService.getNotebooksByMainTopic(mainTopicId);
        return ResponseEntity.ok(response);
    }


    @Operation(
            summary = "Download a Jupyter notebook",
            description = "Allows a user to download the notebook file uploaded by SME."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Notebook file downloaded successfully"),
            @ApiResponse(responseCode = "404", description = "Notebook file not found on server")
    })
    @GetMapping("/download/{notebookId}")
    public ResponseEntity<Resource> downloadNotebook(@PathVariable Integer notebookId) {
        log.info("Downloading notebook with ID: {}", notebookId);

        Resource resource = userNotebookService.downloadNotebook(notebookId);
        String fileName = resource.getFilename();

        String contentType = "application/octet-stream";
        try {
            Path filePath = resource.getFile().toPath();
            contentType = Files.probeContentType(filePath);
        } catch (Exception e) {
            log.warn("Could not determine file type, using default content type.");
        }

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(contentType != null ? contentType : "application/octet-stream"))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"")
                .body(resource);
    }
}
