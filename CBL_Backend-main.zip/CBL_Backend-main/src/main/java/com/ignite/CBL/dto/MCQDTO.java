package com.ignite.CBL.dto;

import com.ignite.CBL.entity.McqOptions;
import com.ignite.CBL.entity.Topic;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MCQDTO {

    private Integer mcqId;

    private String question;

    private McqOptions options;

}
