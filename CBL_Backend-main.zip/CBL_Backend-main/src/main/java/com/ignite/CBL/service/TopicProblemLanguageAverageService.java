package com.ignite.CBL.service;

import com.ignite.CBL.dto.TopicProblemLanguageAverageDTO;

import java.util.List;

public interface TopicProblemLanguageAverageService {

    /**
     * Get average time spent on each language for all topic-level (non-mandatory) problems
     */
    List<TopicProblemLanguageAverageDTO> getTopicProblemLanguageAverages();

    /**
     * Get average time spent on each language for topic-level problems in a specific main topic
     */
    List<TopicProblemLanguageAverageDTO> getTopicProblemLanguageAveragesByMainTopic(Integer mainTopicId);

    /**
     * Get average time spent on each language for topic-level problems in a specific topic
     */
    List<TopicProblemLanguageAverageDTO> getTopicProblemLanguageAveragesByTopic(Integer topicId);

    /**
     * Get average time spent on each language for topic-level problems of a specific difficulty
     */
    List<TopicProblemLanguageAverageDTO> getTopicProblemLanguageAveragesByDifficulty(String difficulty);
}
