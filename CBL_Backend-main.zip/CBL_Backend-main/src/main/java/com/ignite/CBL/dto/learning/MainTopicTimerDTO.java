package com.ignite.CBL.dto.learning;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for main topic timer (displays time per language)
 * Response for: GET /api/user/learning/time-tracking/main-topic/{mainTopicId}
 *
 * Aggregates time from all subtopics under this main topic
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MainTopicTimerDTO {
    private Long javaSeconds;
    private Long pythonSeconds;
    private Long javascriptSeconds;
    private Long typescriptSeconds;
}

