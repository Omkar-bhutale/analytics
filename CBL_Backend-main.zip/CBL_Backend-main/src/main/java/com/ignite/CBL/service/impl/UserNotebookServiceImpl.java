package com.ignite.CBL.service.impl;

import com.ignite.CBL.dto.NotebookResponseDTO;
import com.ignite.CBL.entity.Notebook;
import com.ignite.CBL.exception.ResourceNotFoundException;
import com.ignite.CBL.repository.NotebookRepository;
import com.ignite.CBL.service.UserNotebookService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserNotebookServiceImpl implements UserNotebookService {

    private final NotebookRepository notebookRepository;

    @Override
    public List<NotebookResponseDTO> getNotebooksByMainTopic(Integer mainTopicId) {
        log.info("Fetching notebooks for MainTopic ID: {}", mainTopicId);

        List<Notebook> notebooks = notebookRepository.findByMainTopic_MainTopicId(mainTopicId);

        if (notebooks.isEmpty()) {
            throw new ResourceNotFoundException("No notebooks found for MainTopic ID: " + mainTopicId);
        }

        return notebooks.stream()
                .map(nb -> NotebookResponseDTO.builder()
                        .notebookId(nb.getNotebookId())
                        .title(nb.getTitle())
                        .language(nb.getLanguage().name())
                        .fileType(nb.getFileType())
                        .uploadedBy(nb.getUploadedBy())
                        .uploadedAt(nb.getUploadedAt())
                        .downloadUrl("/user/notebooks/download/" + nb.getNotebookId())
                        .build())
                .collect(Collectors.toList());
    }

    @Override
    public Resource downloadNotebook(Integer notebookId) {
        log.info("Downloading notebook with ID: {}", notebookId);

        Notebook notebook = notebookRepository.findById(notebookId)
                .orElseThrow(() -> new ResourceNotFoundException("Notebook not found with ID: " + notebookId));

        File file = new File(notebook.getFilePath());
        if (!file.exists()) {
            throw new ResourceNotFoundException("Notebook file not found on server.");
        }

        return new FileSystemResource(file);
    }
}
