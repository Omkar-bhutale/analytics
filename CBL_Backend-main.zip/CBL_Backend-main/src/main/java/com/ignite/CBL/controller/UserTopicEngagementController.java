package com.ignite.CBL.controller;

import com.ignite.CBL.dto.MainTopicSubTopicsResponceDTO;
import com.ignite.CBL.dto.MainTopicEngagementResponseDTO;
import com.ignite.CBL.dto.TopicEngagementResponseDTO;
import com.ignite.CBL.dto.TopicLanguageEngagementRequestDTO;
import com.ignite.CBL.service.TopicService;
import com.ignite.CBL.service.UserTopicEngagementService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user/topic-engagement")
@RequiredArgsConstructor
@Tag(
        name = "User Topic Engagement",
        description = "APIs for tracking user's topic engagement, language-wise progress, and total completion"
)
public class UserTopicEngagementController {

    private final UserTopicEngagementService userTopicEngagementService;
    private final TopicService topicService;

    @GetMapping("/all-main-topics-sub-topics")
    @Operation(
            summary = "Get all main topics with their subtopics and engagement data",
            description = """
            Returns a list of all main topics with their subtopics and the current user's engagement data.
            Includes language-wise completion status and time spent on each main topic.
            """
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Main topics with subtopics and engagement data retrieved successfully",
                    content = @Content(schema = @Schema(implementation = MainTopicSubTopicsResponceDTO.class),
                            examples = @ExampleObject(
                                    name = "Example Success Response",
                                    value = """
                    [
                      {
                        "mainTopicId": 1,
                        "mainTopicName": "Data Structures",
                        "mainTopicDescription": "Learn about arrays, linked lists, stacks, and queues",
                        "subTopics": [
                          {
                            "topicId": 1,
                            "title": "Arrays",
                            "content": {...}
                          },
                          {
                            "topicId": 2,
                            "title": "Linked Lists",
                            "content": {...}
                          }
                        ],
                        "completed": false,
                        "javaCompleted": true,
                        "pythonCompleted": false,
                        "javascriptCompleted": false,
                        "typescriptCompleted": false,
                        "javaTimeSeconds": 3600,
                        "pythonTimeSeconds": 1800,
                        "javascriptTimeSeconds": 900,
                        "typescriptTimeSeconds": 600,
                        "totalTimeSeconds": 6900,
                        "lastActivityAt": "2025-11-07T10:30:00"
                      }
                    ]
                    """
                            ))),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    public ResponseEntity<List<MainTopicSubTopicsResponceDTO>> getAllMainTopicSubTopics() {
        List<MainTopicSubTopicsResponceDTO> mainTopicSubTopics = topicService.findAllMainTopicSubTopics();
        return ResponseEntity.ok(mainTopicSubTopics);
    }


    /**
     * Update or save time spent and completion status for a specific topic and language.
     * <p>
     * - Frontend can call this when a user spends time coding or marks a subtopic as completed. <br>
     * - This API updates the user's engagement record for a specific topic and programming language. <br>
     * - It automatically recalculates total time and checks if the user completed all languages.
     * </p>
     *
     * **Example Request (JSON)**:
     * ```json
     * {
     *   "topicId": 12,
     *   "language": "JAVA",
     *   "timeSpentSeconds": 300,
     *   "isCompleted": true
     * }
     * ```
     *
     * **Example Response (JSON)**:
     * ```json
     * {
     *   "topicId": 12,
     *   "topicTitle": "Spring Boot Basics",
     *   "totalTimeSpent": 1800,
     *   "isCompleted": false,
     *   "lastActivityAt": "2025-10-21T19:48:12",
     *   "languageStats": {
     *     "java": { "timeSeconds": 900, "completed": true },
     *     "python": { "timeSeconds": 300, "completed": false },
     *     "javascript": { "timeSeconds": 400, "completed": false },
     *     "typescript": { "timeSeconds": 200, "completed": false }
     *   }
     * }
     * ```
     */
    @PutMapping("/language")
    @Operation(
            summary = "Update user engagement for a topic (language-wise)",
            description = """
            Updates the user's time spent and completion status for a given topic and language.
            Automatically recalculates total time and determines if all languages are completed.
            """,
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    description = "Payload containing topicId, language, time spent, and completion status.",
                    content = @Content(
                            schema = @Schema(implementation = TopicLanguageEngagementRequestDTO.class),
                            examples = @ExampleObject(
                                    name = "Example Payload",
                                    value = """
                        {
                          "topicId": 12,
                          "language": "JAVA",
                          "timeSpentSeconds": 300,
                     
                        }
                        """
                            )
                    )
            )
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Engagement updated successfully, returns main topic engagement",
                    content = @Content(schema = @Schema(implementation = MainTopicEngagementResponseDTO.class),
                            examples = @ExampleObject(
                                    name = "Example Success Response",
                                    value = """
                    {
                      "mainTopicId": 1,
                      "mainTopicName": "Data Structures",
                      "completed": false,
                      "javaCompleted": true,
                      "pythonCompleted": false,
                      "javascriptCompleted": false,
                      "typescriptCompleted": false,
                      "javaTimeSeconds": 3600,
                      "pythonTimeSeconds": 1800,
                      "javascriptTimeSeconds": 900,
                      "typescriptTimeSeconds": 600,
                      "totalTimeSeconds": 6900,
                      "lastActivityAt": "2025-11-07T10:30:00"
                    }
                    """
                            ))),
            @ApiResponse(responseCode = "404", description = "Topic or User not found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    public ResponseEntity<MainTopicEngagementResponseDTO> updateLanguageEngagement(
            @RequestBody TopicLanguageEngagementRequestDTO requestDTO) {
        MainTopicEngagementResponseDTO response = userTopicEngagementService.updateLanguageWiseEngagement(requestDTO);
        return ResponseEntity.ok(response);
    }

    /**
     * Get user's engagement details for a specific topic.
     *
     * This endpoint returns:
     * - Total time spent across all languages  
     * - Per-language progress (time + completion)  
     * - Overall completion status  
     */
    @GetMapping("/{topicId}")
    @Operation(
            summary = "Get user engagement details for a specific topic",
            description = """
            Returns topic progress for the logged-in user, including per-language time spent,
            completion status, and total time spent across all languages.
            """,
            parameters = {
                    @Parameter(
                            name = "topicId",
                            description = "ID of the topic to fetch engagement for",
                            example = "12"
                    )
            }
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Engagement data retrieved successfully",
                    content = @Content(schema = @Schema(implementation = TopicEngagementResponseDTO.class),
                            examples = @ExampleObject(
                                    name = "Example Success Response",
                                    value = """
                    {
                      "topicId": 12,
                      "topicTitle": "Spring Boot Basics",
                      "totalTimeSpent": 1800,
                      "lastActivityAt": "2025-10-21T19:48:12",
                      "languageStats": {
                        "java": { "timeSeconds": 900, "completed": true },
                        "python": { "timeSeconds": 300, "completed": false },
                        "javascript": { "timeSeconds": 400, "completed": false },
                        "typescript": { "timeSeconds": 200, "completed": false }
                      }
                    }
                    """
                            ))),
            @ApiResponse(responseCode = "404", description = "Engagement not found for the given topic ID"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    public ResponseEntity<TopicEngagementResponseDTO> getEngagement(
            @PathVariable Integer topicId) {
        return ResponseEntity.ok(userTopicEngagementService.getTopicEngagement(topicId));
    }

    /**
     * Get engagement details for a specific main topic.
     *
     * This endpoint returns the engagement information for a main topic, including:
     * - Total time spent by the user on this main topic across all its subtopics
     * - Language-specific time tracking
     * - Completion status per language
     * - Overall completion status
     */
    @GetMapping("/main-topic/{mainTopicId}/engagement")
    @Operation(
            summary = "Get engagement details for a specific main topic",
            description = """
            Returns main topic progress for the logged-in user, including:
            - Total time spent across all subtopics and languages
            - Per-language time tracking and completion status
            - Overall completion status for the main topic
            """,
            parameters = {
                    @Parameter(
                            name = "mainTopicId",
                            description = "ID of the main topic to fetch engagement for",
                            required = true,
                            example = "1"
                    )
            }
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Main topic engagement data retrieved successfully",
                    content = @Content(schema = @Schema(implementation = MainTopicEngagementResponseDTO.class),
                            examples = @ExampleObject(
                                    name = "Example Success Response",
                                    value = """
                    {
                      "mainTopicId": 1,
                      "mainTopicName": "Data Structures",
                      "completed": false,
                      "javaCompleted": true,
                      "pythonCompleted": false,
                      "javascriptCompleted": false,
                      "typescriptCompleted": false,
                      "javaTimeSeconds": 3600,
                      "pythonTimeSeconds": 1800,
                      "javascriptTimeSeconds": 900,
                      "typescriptTimeSeconds": 600,
                      "totalTimeSeconds": 6900,
                      "lastActivityAt": "2025-11-07T10:30:00"
                    }
                    """
                            ))),
            @ApiResponse(responseCode = "404", description = "Main topic engagement not found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    public ResponseEntity<MainTopicEngagementResponseDTO> getMainTopicEngagement(
            @PathVariable Integer mainTopicId) {
        MainTopicEngagementResponseDTO engagement = userTopicEngagementService.getMainTopicEngagement(mainTopicId);
        return ResponseEntity.ok(engagement);
    }

    /**
     * Mark MCQ as visited for a specific topic in a specific language.
     *
     * This endpoint is used to track MCQ completion progress for a specific topic and language by the user.
     * Language-specific MCQ tracking is required for marking main topics as complete.
     */
    @PutMapping("/{topicId}/mcq-visited")
    @Operation(
            summary = "Mark MCQ as visited for a specific topic and language",
            description = """
            Marks the MCQ as completed for the given subtopic in the specified language.
            This is required for validating main topic completion per language.
            """,
            parameters = {
                    @Parameter(
                            name = "topicId",
                            description = "ID of the subtopic",
                            required = true,
                            example = "1"
                    ),
                    @Parameter(
                            name = "language",
                            description = "Programming language for the MCQ (JAVA, PYTHON, JAVASCRIPT, TYPESCRIPT)",
                            required = true,
                            example = "JAVA"
                    )
            }
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "MCQ marked as visited successfully",
                    content = @Content(schema = @Schema(implementation = TopicEngagementResponseDTO.class))),
            @ApiResponse(responseCode = "404", description = "Topic not found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    public ResponseEntity<TopicEngagementResponseDTO> markMcqAsVisited(
            @PathVariable Integer topicId,
            @RequestParam String language) {
        TopicEngagementResponseDTO response = userTopicEngagementService.markMcqAsVisited(topicId, language);
        return ResponseEntity.ok(response);
    }
}

