package com.ignite.CBL.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.ignite.CBL.entity.Difficulty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashSet;
import java.util.Set;

// ProblemDTO.java
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProblemInfoDTO {

    private Integer id;
    private String title;
    private Boolean javaCompleted;
    private Boolean pythonCompleted;
    private Boolean javascriptCompleted;
    private Boolean typescriptCompleted;

    // Constructor for backward compatibility
    public ProblemInfoDTO(Integer id, String title) {
        this.id = id;
        this.title = title;
        this.javaCompleted = false;
        this.pythonCompleted = false;
        this.javascriptCompleted = false;
        this.typescriptCompleted = false;
    }
}