package com.ignite.CBL.dto;

import lombok.Data;
import lombok.ToString;

import java.time.LocalDateTime;
import java.util.List;

@Data
@ToString
public class MainTopicSubTopicsResponceDTO {
    private Integer mainTopicId;
    private String mainTopicName;
    private String mainTopicDescription;
    private List<TopicDTO> subTopics;

    // Engagement data
    private Boolean completed;
    private Boolean javaCompleted;
    private Boolean pythonCompleted;
    private Boolean javascriptCompleted;
    private Boolean typescriptCompleted;
    private Long javaTimeSeconds;
    private Long pythonTimeSeconds;
    private Long javascriptTimeSeconds;
    private Long typescriptTimeSeconds;
    private Integer totalTimeSeconds;
    private LocalDateTime lastActivityAt;
}
