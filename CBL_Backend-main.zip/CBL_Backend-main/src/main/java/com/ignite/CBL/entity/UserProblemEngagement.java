package com.ignite.CBL.entity;


import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.sql.SQLType;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Table(name = "user_problem_engagement")
public class UserProblemEngagement {

    @EmbeddedId
    private UserProblemEngagementId id;

    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("userId")
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("problemId")
    @JoinColumn(name = "problem_id")
    @JsonBackReference("problem-engagements")
    private Problem problem;

    @Column(name = "total_seconds_spent", nullable = false)
    private int totalSecondsSpent = 0;
    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "saved_codes")
    private SavedCodes savedCodes;

    @Column(name = "is_solved",nullable = false)
    private Boolean isSolved = false;

    @Column(name = "total_attempts", nullable = false)
    @Version
    private Integer totalAttempts;

    @Column(name = "last_activity_at", nullable = false)
    private LocalDateTime lastActivityAt;


    @Column(name = "java_time_seconds")
    private Long javaTimeSeconds = 0L;

    @Column(name = "python_time_seconds")
    private Long pythonTimeSeconds = 0L;

    @Column(name = "javascript_time_seconds")
    private Long javascriptTimeSeconds = 0L;

    @Column(name = "typescript_time_seconds")
    private Long typescriptTimeSeconds = 0L;

    @Column(name = "java_completed")
    private Boolean javaCompleted = false;

    @Column(name = "python_completed")
    private Boolean pythonCompleted = false;

    @Column(name = "javascript_completed")
    private Boolean javascriptCompleted = false;

    @Column(name = "typescript_completed")
    private Boolean typescriptCompleted = false;



    @PrePersist
    public void prePersist() {
        this.lastActivityAt = LocalDateTime.now();
        this.totalAttempts = 0;
        this.totalSecondsSpent = 0;
        this.savedCodes = new SavedCodes();
    }

    @PreUpdate
    public void preUpdate() {
        this.lastActivityAt = LocalDateTime.now();
    }
}