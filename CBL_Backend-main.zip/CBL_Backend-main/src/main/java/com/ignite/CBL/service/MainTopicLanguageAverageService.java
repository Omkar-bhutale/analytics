
package com.ignite.CBL.service;

import com.ignite.CBL.dto.MainTopicLanguageAverageDTO;
import java.util.List;

public interface MainTopicLanguageAverageService {
    List<MainTopicLanguageAverageDTO> getMainTopicLanguageAverages();
}