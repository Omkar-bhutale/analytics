


package com.ignite.CBL.repository;

import com.ignite.CBL.dto.MCQDTO;
import com.ignite.CBL.entity.MCQ;
import jakarta.transaction.Transactional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


@Repository
public interface MCQRepository extends JpaRepository<MCQ, Integer> {

    @Query("SELECT new com.ignite.CBL.dto.MCQDTO(m.mcqId, m.content, m.topic.topicId, m.language) " +
            "FROM MCQ m WHERE m.topic.topicId = :topicId")
    Page<MCQDTO> findPaginatedByTopicId(@Param("topicId") Integer topicId, Pageable pageable);

    @Query("SELECT new com.ignite.CBL.dto.MCQDTO(m.mcqId, m.content, m.topic.topicId, m.language) " +
            "FROM MCQ m WHERE m.topic.topicId = :topicId")
    List<MCQDTO> findAllByTopicId(@Param("topicId") Integer topicId);

    @Query("SELECT new com.ignite.CBL.dto.MCQDTO(m.mcqId, m.content, m.topic.topicId, m.language) " +
            "FROM MCQ m WHERE m.mcqId = :mcqId")
    Optional<MCQDTO> findMCQDTOById(@Param("mcqId") Integer mcqId);


    @Query("DELETE FROM MCQ m WHERE m.topic.topicId = :topicId")
    @Modifying
    @Transactional
    int deleteAllByTopicId(@Param("topicId") Integer topicId);


    boolean existsByMcqId(Integer mcqId);

    @Query("SELECT new com.ignite.CBL.dto.MCQDTO(m.mcqId, m.content, m.topic.topicId, m.language) " +
            "FROM MCQ m WHERE m.topic.topicId = :topicId AND m.language = :language")
    List<MCQDTO> findAllByTopicIdAndLanguage(@Param("topicId") Integer topicId,
                                             @Param("language") com.ignite.CBL.entity.Language language);

    @Query("SELECT COUNT(m) FROM MCQ m WHERE m.topic.topicId = :topicId AND m.language = :language")
    long countByTopicIdAndLanguage(@Param("topicId") Integer topicId,
                                   @Param("language") com.ignite.CBL.entity.Language language);

    long countByTopic_TopicId(Integer topicId);
}

