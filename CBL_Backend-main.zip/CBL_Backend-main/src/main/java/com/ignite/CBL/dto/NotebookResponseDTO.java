package com.ignite.CBL.dto;

import lombok.Builder;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@Builder
public class NotebookResponseDTO {
    private Integer notebookId;
    private String title;
    private String language;
    private String fileType; // "PDF" or "IPYNB"
    private String uploadedBy;
    private LocalDateTime uploadedAt;
    private String downloadUrl;
}
