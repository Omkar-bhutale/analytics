package com.ignite.CBL.controller;

import com.ignite.CBL.dto.TopicDTO;
import com.ignite.CBL.entity.Topic;
import com.ignite.CBL.service.TopicService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/topic")
public class TopicController {
    private TopicService topicService;

    public TopicController(TopicService topicService) {
        this.topicService = topicService;
    }

    @GetMapping("/allByCourseId/{courseId}")
    public ResponseEntity<List<TopicDTO>> findAllByCourseId(@PathVariable Integer courseId) {
        return ResponseEntity.ok(topicService.findAllByCourseId(courseId));
    }

    @GetMapping("/byTitle/{title}")
    public ResponseEntity<TopicDTO> findByTitle(@PathVariable String title) {
        return ResponseEntity.ok(topicService.findByTitle(title));
    }

    @GetMapping("/allByTopicId/{topicId}")
    public ResponseEntity<TopicDTO> findByTopicId(@PathVariable Integer topicId) {
        return ResponseEntity.ok(topicService.findByTopicId(topicId));
    }
}
