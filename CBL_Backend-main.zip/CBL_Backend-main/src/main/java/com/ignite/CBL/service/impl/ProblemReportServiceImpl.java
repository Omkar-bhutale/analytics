package com.ignite.CBL.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ignite.CBL.dto.ProblemInsightRequestDTO;
import com.ignite.CBL.entity.*;
import com.ignite.CBL.exception.ResourceNotFoundException;
import com.ignite.CBL.repository.*;
import com.ignite.CBL.service.ProblemReportService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProblemReportServiceImpl implements ProblemReportService {

    private final UserProblemReportRepository reportRepository;
    private final AlgorithmSubmissionRepository algorithmSubmissionRepository;
    private final PseudocodeSubmissionRepository pseudocodeSubmissionRepository;
    private final ProblemSubmissionRepository problemSubmissionRepository;

    private final ObjectMapper mapper = new ObjectMapper();

    @Value("${llm.api.url}")
    private String llmApiUrl; // e.g. http://localhost:8000/generate-insight

    @Async
    @Transactional
    @Override
    public void generateInsightAsync(User user, Problem problem) {
        try {
            log.info(" Generating LLM insight for user={}, problem={}", user.getUserId(), problem.getProblemId());


            String algorithm = algorithmSubmissionRepository.findByProblem_ProblemIdAndUser_UserId( problem.getProblemId(),user.getUserId())
                    .orElseThrow(()->new ResourceNotFoundException("Algorithm steps not found")).getContent();
            String pseudocode = pseudocodeSubmissionRepository.findByProblem_ProblemIdAndUser_UserId( problem.getProblemId(),user.getUserId())
                    .orElseThrow(()->new ResourceNotFoundException("Pseudocode not found")).getContent();


            List<ProblemSubmission> submissions = problemSubmissionRepository
                    .findByProblem_ProblemIdAndUser_UserId(problem.getProblemId(), user.getUserId());


            ProblemInsightRequestDTO requestDTO = ProblemInsightRequestDTO.builder()
                    .question(problem.getDescription())
                    .user_algorithm(algorithm)
                    .user_pseudocode(pseudocode)
                    .attempts(submissions.stream()
                            .map(s -> ProblemInsightRequestDTO.LanguageAttemptDTO.builder()
                                    .language(s.getLanguage().name().toLowerCase())
                                    .code(s.getCode())
                                    .time_taken((long) s.getPassedTestCases() * 100) // Example conversion
                                    .is_test_cases_passed(s.getPassedTestCases())
                                    .total_no_test_cases(s.getTotalTestCases())
                                    .build())
                            .collect(Collectors.toList()))
                    .build();

            // 4Call the LLM FastAPI;
            log.info("Calling llm api to get insight");
            RestTemplate restTemplate = new RestTemplate();
            JsonNode responseNode = restTemplate.postForObject(llmApiUrl, requestDTO, JsonNode.class);

            // 5️ Save insights in UserProblemReport
            UserProblemReport report = reportRepository.findByUser_UserIdAndProblem_ProblemId(
                    user.getUserId(), problem.getProblemId()
            ).orElseThrow(() -> new ResourceNotFoundException("UserProblemReport not found"));

            report.setInsight(responseNode);
            reportRepository.save(report);

            log.info(" LLM insights saved successfully for user={}, problem={}", user.getUserId(), problem.getProblemId());

        } catch (Exception e) {
            log.error(" Failed to generate LLM insight for user={}, problem={}: {}", user.getUserId(), problem.getProblemId(), e.getMessage(), e);
        }
    }
}