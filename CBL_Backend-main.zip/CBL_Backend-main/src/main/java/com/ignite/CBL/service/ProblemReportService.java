package com.ignite.CBL.service;

import com.ignite.CBL.entity.Problem;
import com.ignite.CBL.entity.User;

public interface ProblemReportService {
    void generateInsightAsync(User user, Problem problem);
}