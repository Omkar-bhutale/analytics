package com.ignite.CBL.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "course_topic_info")
public class CourseTopicInfo {

    @EmbeddedId

    private CourseTopicId courseTopicId;

    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("courseId")
    @JoinColumn(name = "course_id")
    private Course course;

    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("topicId")
    @JoinColumn(name = "topic_id")
    private Topic topic;

    @Column(name = "topic_status")
    private Boolean topicStats = false;


    @Column(name = "index_value")
    private Integer indexValue;


}
