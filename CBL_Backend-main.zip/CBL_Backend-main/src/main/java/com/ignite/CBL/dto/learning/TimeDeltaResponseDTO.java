package com.ignite.CBL.dto.learning;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for time delta response
 * Response for: POST /api/user/learning/time-tracking/delta
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TimeDeltaResponseDTO {
    private Boolean success;
    private Long newTotal;  // New total time for this subtopic+language
}

