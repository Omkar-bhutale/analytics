package com.ignite.CBL.service;

import com.ignite.CBL.dto.MCQDTO;

import java.util.List;

public interface MCQService {
    List<MCQDTO> findAllByTopicId(Integer topicId);
}
