package com.ignite.CBL.service;

import com.ignite.CBL.dto.MCQDTO;
import com.ignite.CBL.entity.Language;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;


public interface MCQService {
    

    Optional<MCQDTO> findMCQById(Integer mcqId);
    

    List<MCQDTO> findAllMCQByTopicId(Integer topicId);
    

    Page<MCQDTO> findPaginatedMCQByTopicId(Integer topicId, Pageable pageable);

    MCQDTO createMCQ(Integer topicId, MCQDTO mcqDTO);

    int createMCQs(Integer topicId, List<MCQDTO> mcqDTOs);

    Optional<MCQDTO> updateMCQ(Integer mcqId, MCQDTO mcqDTO);
    

    boolean deleteMCQById(Integer mcqId);

    int deleteAllMCQByTopicId(Integer topicId);

    long countByTopicId(Integer topicId);

    boolean existsById(Integer mcqId);
     List<MCQDTO> findAllMCQByTopicIdAndLanguage(Integer topicId, Language language);
     long countByTopicIdAndLanguage(Integer topicId, Language language);
}
