package com.ignite.CBL.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.annotations.Type;
import org.hibernate.type.SqlTypes;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "problems")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Problem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "problem_id")
    private Integer problemId;

    @Column(name = "title",columnDefinition = "TEXT")
    private String title;


    @Column(name = "description",nullable = false,columnDefinition = "TEXT")

    private String description;

    @Enumerated(EnumType.STRING)
    @Column(name = "difficulty",nullable = false)
    private Difficulty difficulty;

    @OneToOne(mappedBy = "mainProblem", fetch = FetchType.LAZY)
    @JsonBackReference("main-topic-problem")
    private MainTopic mainTopic;


    @Column(name="created_using")
    public String createdUsing;


    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "hint", columnDefinition = "jsonb")
    private JsonNode hint;

//    private

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "topic_id", nullable = false)
    @JsonBackReference("topic-problems")
    private Topic topic;

    @OneToMany(mappedBy = "problem", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("problem-testcases")
    private Set<ProblemTestCase> testCases = new HashSet<>();

    @OneToMany(mappedBy = "problem", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("problem-algorithm")
    private Set<AlgorithmSubmission> algorithmSubmissions = new HashSet<>();

    @OneToMany(mappedBy = "problem", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("problem-submissions")
    private Set<ProblemSubmission> problemSubmissions = new HashSet<>();
    
    @OneToMany(mappedBy = "problem", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("problem-pseudocode")
    private Set<PseudocodeSubmission> pseudocodeSubmissions = new HashSet<>();
    
    @OneToMany(mappedBy = "problem", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("problem-reports")
    private Set<UserProblemReport> userProblemReports = new HashSet<>();

    @OneToMany(mappedBy = "problem", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("problem-engagements")
    private Set<UserProblemEngagement> userProblemEngagements = new HashSet<>();

    public void addTestCase(ProblemTestCase testCase){
        this.testCases.add(testCase);
        testCase.setProblem(this);
    }

    public void removeTestCase(ProblemTestCase testCase){
        this.testCases.remove(testCase);
        testCase.setProblem(null);
    }




}
