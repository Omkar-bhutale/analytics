package com.ignite.CBL.repository;

import com.ignite.CBL.entity.Language;
import com.ignite.CBL.entity.Notebook;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NotebookRepository extends JpaRepository<Notebook, Integer> {
    List<Notebook> findByMainTopic_MainTopicId(Integer mainTopicId);
    List<Notebook> findByMainTopic_MainTopicIdAndLanguage(Integer mainTopicId, Language language);
}
