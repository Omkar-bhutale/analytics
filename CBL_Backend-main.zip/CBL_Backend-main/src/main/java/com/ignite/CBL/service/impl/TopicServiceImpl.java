package com.ignite.CBL.service.impl;

import com.ignite.CBL.dto.TopicDTO;
import com.ignite.CBL.entity.Topic;
import com.ignite.CBL.repository.TopicRepository;
import com.ignite.CBL.service.TopicService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TopicServiceImpl implements TopicService {

    private TopicRepository topicRepository;
    private ModelMapper modelMapper;

    public TopicServiceImpl(TopicRepository topicRepository) {
        modelMapper = new ModelMapper();
        this.topicRepository = topicRepository;
    }

    @Override
    public List<TopicDTO> findAllByCourseId(Integer courseId) {
        return topicRepository.findAllByCourseId(courseId);



    }

    @Override
    public TopicDTO findByTopicId(Integer topicId) {
        return topicRepository.findByTopicId(topicId);
    }

    @Override
    public TopicDTO findByTitle(String title) {
        return topicRepository.findByTitle(title);
    }
}
