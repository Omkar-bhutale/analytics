
package com.ignite.CBL.service.impl;

import com.ignite.CBL.dto.MainTopicLanguageAverageDTO;
import com.ignite.CBL.entity.view.MainTopicLanguageAverageView;
import com.ignite.CBL.repository.MainTopicLanguageAverageViewRepository;
import com.ignite.CBL.service.MainTopicLanguageAverageService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class MainTopicLanguageAverageServiceImpl implements MainTopicLanguageAverageService {

    private final MainTopicLanguageAverageViewRepository repository;

    @Override
    public List<MainTopicLanguageAverageDTO> getMainTopicLanguageAverages() {
        return repository.findAll().stream()
                .map(v -> MainTopicLanguageAverageDTO.builder()
                        .mainTopicId(v.getMainTopicId())
                        .mainTopicTitle(v.getMainTopicTitle())
                        .avgJavaTime(v.getAvgJavaTime())
                        .avgPythonTime(v.getAvgPythonTime())
                        .avgJavascriptTime(v.getAvgJavascriptTime())
                        .avgTypescriptTime(v.getAvgTypescriptTime())
                        .avgTotalTime(v.getAvgTotalTime())
                        .build())
                .collect(Collectors.toList());
    }
}