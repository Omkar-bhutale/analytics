package com.ignite.CBL.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MainTopicEngagementResponseDTO {
    private Integer mainTopicId;
    private String mainTopicName;
    private Boolean completed;
    private Boolean javaCompleted;
    private Boolean pythonCompleted;
    private Boolean javascriptCompleted;
    private Boolean typescriptCompleted;
    private Long javaTimeSeconds;
    private Long pythonTimeSeconds;
    private Long javascriptTimeSeconds;
    private Long typescriptTimeSeconds;
    private Integer totalTimeSeconds;
    private LocalDateTime lastActivityAt;
}

