package com.ignite.CBL.service;

import com.ignite.CBL.dto.NotebookResponseDTO;
import org.springframework.core.io.Resource;

import java.util.List;

public interface UserNotebookService {

    // Get list of notebooks for a MainTopic
    List<NotebookResponseDTO> getNotebooksByMainTopic(Integer mainTopicId);

    // Download a specific notebook
    Resource downloadNotebook(Integer notebookId);
}
