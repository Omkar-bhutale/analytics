package com.ignite.CBL.service.impl;


import com.ignite.CBL.dto.MCQDTO;
import com.ignite.CBL.repository.MCQRepository;
import com.ignite.CBL.service.MCQService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MCQServiceImpl implements MCQService {

    private MCQRepository mcqRepository;

    public MCQServiceImpl(MCQRepository mcqRepository) {
        this.mcqRepository = mcqRepository;
    }



    @Override
    public List<MCQDTO> findAllByTopicId(Integer topicId) {
        return mcqRepository.findAllByTopicId(topicId);
    }
}
