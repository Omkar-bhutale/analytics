package com.ignite.CBL.service;

import com.ignite.CBL.dto.learning.*;
import com.ignite.CBL.entity.*;
import com.ignite.CBL.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Service for Learning Page operations
 * Handles topics, subtopics, time tracking, and progress management
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class LearningPageService {

    private final UserRepository userRepository;
    private final MainTopicRepository mainTopicRepository;
    private final TopicRepository topicRepository;
    private final UserTopicEngagementRepository userTopicEngagementRepository;
    private final UserMainTopicEngagementRepository userMainTopicEngagementRepository;

    // ========== A. TOPIC & CONTENT APIs ==========

    /**
     * Get all main topics for sidebar
     */
    public List<MainTopicSummaryDTO> getAllMainTopics(String username) {
        log.info("Fetching all main topics for user: {}", username);

        List<MainTopic> mainTopics = mainTopicRepository.findAll();

        return mainTopics.stream()
                .map(mt -> new MainTopicSummaryDTO(mt.getMainTopicId(), mt.getTitle()))
                .collect(Collectors.toList());
    }

    /**
     * Get all subtopics for a main topic
     */
    public List<SubtopicSummaryDTO> getSubtopicsByMainTopic(Integer mainTopicId, String username) {
        log.info("Fetching subtopics for mainTopicId: {} and user: {}", mainTopicId, username);

        List<Topic> topics = topicRepository.findAllByMainTopicIdWithMainTopic(mainTopicId);

        return topics.stream()
                .map(topic -> new SubtopicSummaryDTO(topic.getTopicId(), topic.getTitle()))
                .collect(Collectors.toList());
    }

    /**
     * Get subtopic content with all languages and MCQ status
     */
    public SubtopicContentDTO getSubtopicContent(Integer subtopicId, String username) {
        log.info("Fetching subtopic content for subtopicId: {} and user: {}", subtopicId, username);

        User user = userRepository.findByUserId(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Topic topic = topicRepository.findByIdWithMainTopic(subtopicId)
                .orElseThrow(() -> new RuntimeException("Topic not found with id: " + subtopicId));

        // Get MCQ status for all languages
        McqStatusDTO mcqStatus = getMcqStatus(subtopicId, username);

        // Determine if this is last subtopic
        List<Topic> allSubtopics = topicRepository.findAllByMainTopicIdWithMainTopic(
                topic.getMainTopic().getMainTopicId()
        );
        boolean isLastSubtopic = allSubtopics.stream()
                .mapToInt(Topic::getTopicId)
                .max()
                .orElse(0) == subtopicId;

        // Build DTO with raw JSON content
        SubtopicContentDTO contentDTO = new SubtopicContentDTO();
        contentDTO.setSubtopicId(topic.getTopicId());
        contentDTO.setName(topic.getTitle());
        contentDTO.setMainTopicId(topic.getMainTopic().getMainTopicId());
        contentDTO.setContent(topic.getContent()); // Send raw JSON directly
        contentDTO.setMcqStatus(mcqStatus);
        contentDTO.setIsLastSubtopic(isLastSubtopic);

        return contentDTO;
    }

    // ========== B. TIMER APIs ==========

    /**
     * Get timer data for main topic (from UserMainTopicEngagement)
     */
    public MainTopicTimerDTO getMainTopicTimer(Integer mainTopicId, String username) {
        log.info("Fetching timer for mainTopicId: {} and user: {}", mainTopicId, username);

        User user = userRepository.findByUserId(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        MainTopic mainTopic = mainTopicRepository.findById(mainTopicId)
                .orElseThrow(() -> new RuntimeException("Main topic not found with id: " + mainTopicId));

        // Find or create UserMainTopicEngagement
        UserMainTopicEngagement mainEngagement = userMainTopicEngagementRepository
                .findByUser_UserIdAndMainTopic_MainTopicId(username, mainTopicId)
                .orElseGet(() -> {
                    // Create new engagement with default values
                    UserMainTopicEngagement newEngagement = createNewMainTopicEngagement(user, mainTopic);
                    return userMainTopicEngagementRepository.save(newEngagement);
                });

        // Build and return timer DTO
        MainTopicTimerDTO timer = new MainTopicTimerDTO();
        timer.setJavaSeconds(mainEngagement.getJavaTimeSeconds() != null ? mainEngagement.getJavaTimeSeconds() : 0L);
        timer.setPythonSeconds(mainEngagement.getPythonTimeSeconds() != null ? mainEngagement.getPythonTimeSeconds() : 0L);
        timer.setJavascriptSeconds(mainEngagement.getJavascriptTimeSeconds() != null ? mainEngagement.getJavascriptTimeSeconds() : 0L);
        timer.setTypescriptSeconds(mainEngagement.getTypescriptTimeSeconds() != null ? mainEngagement.getTypescriptTimeSeconds() : 0L);

        return timer;
    }

    /**
     * Update time delta for subtopic + language
     */
    @Transactional
    public TimeDeltaResponseDTO updateTimeDelta(TimeDeltaRequestDTO request, String username) {
        log.info("Updating time delta for subtopicId: {}, language: {}, delta: {}s",
                request.getSubtopicId(), request.getLanguage(), request.getDeltaSeconds());

        User user = userRepository.findByUserId(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Topic topic = topicRepository.findById(request.getSubtopicId())
                .orElseThrow(() -> new RuntimeException("Topic not found with id: " + request.getSubtopicId()));

        // Find or create UserTopicEngagement
        UserTopicEngagement engagement = userTopicEngagementRepository
                .findByUser_UserIdAndTopic_TopicId(username, request.getSubtopicId())
                .orElseGet(() -> createNewEngagement(user, topic));

        // Update language-specific time using helper method
        updateLanguageTime(engagement, request.getLanguage(), request.getDeltaSeconds());

        // Save engagement
        userTopicEngagementRepository.save(engagement);

        // Also update main topic engagement
        updateMainTopicEngagement(topic, user);

        // Get new total for this language
        Long newTotal = getLanguageTime(engagement, request.getLanguage());

        TimeDeltaResponseDTO response = new TimeDeltaResponseDTO();
        response.setSuccess(true);
        response.setNewTotal(newTotal);

        return response;
    }

    // ========== C. PROGRESS/COMPLETION APIs ==========

    /**
     * Get status for "Mark as Complete" button
     */
    public MarkCompleteStatusDTO getMarkCompleteStatus(Integer mainTopicId, String language, String username) {
        log.info("Checking mark complete status for mainTopicId: {}, language: {}, user: {}",
                mainTopicId, language, username);

        User user = userRepository.findByUserId(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Get all subtopics under this main topic
        List<Topic> subtopics = topicRepository.findAllByMainTopicIdWithMainTopic(mainTopicId);

        if (subtopics.isEmpty()) {
            return new MarkCompleteStatusDTO(false, "No subtopics found for this main topic");
        }

        // Validate all subtopics
        for (int i = 0; i < subtopics.size(); i++) {
            Topic subtopic = subtopics.get(i);
            UserTopicEngagement engagement = userTopicEngagementRepository
                    .findByUser_UserIdAndTopic_TopicId(username, subtopic.getTopicId())
                    .orElse(null);

            // Check if engagement exists
            if (engagement == null) {
                return new MarkCompleteStatusDTO(false,
                    "Subtopic '" + subtopic.getTitle() + "' not visited yet");
            }

            // Check if language time > 60 seconds
            Long langTime = getLanguageTime(engagement, language);
            if (langTime == null || langTime < 60) {
                return new MarkCompleteStatusDTO(false,
                    language + " time (" + (langTime != null ? langTime : 0) + "s) is less than required 60s for subtopic '" + subtopic.getTitle() + "'");
            }

            // Check if MCQ is completed for the specific language being marked complete
            boolean languageMcqCompleted = false;
            switch (language.toUpperCase()) {
                case "JAVA":
                    languageMcqCompleted = engagement.getJavaMcqVisited() != null && engagement.getJavaMcqVisited();
                    break;
                case "PYTHON":
                    languageMcqCompleted = engagement.getPythonMcqVisited() != null && engagement.getPythonMcqVisited();
                    break;
                case "JAVASCRIPT":
                    languageMcqCompleted = engagement.getJavascriptMcqVisited() != null && engagement.getJavascriptMcqVisited();
                    break;
                case "TYPESCRIPT":
                    languageMcqCompleted = engagement.getTypescriptMcqVisited() != null && engagement.getTypescriptMcqVisited();
                    break;
            }

            if (!languageMcqCompleted) {
                return new MarkCompleteStatusDTO(false,
                    "MCQ not completed for " + language + " in subtopic '" + subtopic.getTitle() + "'");
            }

            // Check if previous subtopics have time > 0 (sequential completion)
            if (i > 0) {
                Topic prevSubtopic = subtopics.get(i - 1);
                UserTopicEngagement prevEngagement = userTopicEngagementRepository
                        .findByUser_UserIdAndTopic_TopicId(username, prevSubtopic.getTopicId())
                        .orElse(null);

                if (prevEngagement == null || prevEngagement.getTotalTimeSpent() <= 0) {
                    return new MarkCompleteStatusDTO(false,
                        "Previous subtopic '" + prevSubtopic.getTitle() + "' not completed");
                }
            }
        }

        // All validations passed
        return new MarkCompleteStatusDTO(true, "All constraints met");
    }

    /**
     * Mark main topic as complete for a language
     */
    @Transactional
    public CompletionResponseDTO markTopicComplete(Integer mainTopicId, String language, String username) {
        log.info("Marking mainTopicId: {} as complete for language: {}, user: {}",
                mainTopicId, language, username);

        User user = userRepository.findByUserId(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // 1. Validate constraints
        MarkCompleteStatusDTO validationStatus = getMarkCompleteStatus(mainTopicId, language, username);

        if (!validationStatus.getCanMarkComplete()) {
            // Validation failed, return error
            CompletionResponseDTO response = new CompletionResponseDTO();
            response.setSuccess(false);
            response.setMessage(validationStatus.getReason());
            return response;
        }

        // 2. Validation passed, update UserMainTopicEngagement
        MainTopic mainTopic = mainTopicRepository.findById(mainTopicId)
                .orElseThrow(() -> new RuntimeException("Main topic not found with id: " + mainTopicId));

        // Find or create main topic engagement
        UserMainTopicEngagement mainEngagement = userMainTopicEngagementRepository
                .findByUser_UserIdAndMainTopic_MainTopicId(username, mainTopicId)
                .orElseGet(() -> createNewMainTopicEngagement(user, mainTopic));

        // Set language-specific completion flag
        switch (language.toUpperCase()) {
            case "JAVA":
                mainEngagement.setJavaCompleted(true);
                break;
            case "PYTHON":
                mainEngagement.setPythonCompleted(true);
                break;
            case "JAVASCRIPT":
                mainEngagement.setJavascriptCompleted(true);
                break;
            case "TYPESCRIPT":
                mainEngagement.setTypescriptCompleted(true);
                break;
            default:
                throw new IllegalArgumentException("Invalid language: " + language);
        }

        // Check if all languages are completed
        boolean allCompleted = mainEngagement.getJavaCompleted() &&
                              mainEngagement.getPythonCompleted() &&
                              mainEngagement.getJavascriptCompleted() &&
                              mainEngagement.getTypescriptCompleted();

        mainEngagement.setCompleted(allCompleted);
        mainEngagement.setLastActivityAt(LocalDateTime.now());

        // Save changes
        userMainTopicEngagementRepository.save(mainEngagement);
        log.info("Main topic {} marked as complete for language {} by user {}", mainTopicId, language, username);

        // Return success response
        CompletionResponseDTO response = new CompletionResponseDTO();
        response.setSuccess(true);
        response.setMessage(language + " completed successfully for this main topic!");

        return response;
    }

    /**
     * Get MCQ status for subtopic (all languages)
     */
    public McqStatusDTO getMcqStatus(Integer subtopicId, String username) {
        log.info("Fetching MCQ status for subtopicId: {} and user: {}", subtopicId, username);

        User user = userRepository.findByUserId(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Find UserTopicEngagement
        UserTopicEngagement engagement = userTopicEngagementRepository
                .findByUser_UserIdAndTopic_TopicId(username, subtopicId)
                .orElse(null);

        McqStatusDTO status = new McqStatusDTO();

        if (engagement != null) {
            status.setJava(engagement.getJavaMcqVisited() != null && engagement.getJavaMcqVisited());
            status.setPython(engagement.getPythonMcqVisited() != null && engagement.getPythonMcqVisited());
            status.setJavascript(engagement.getJavascriptMcqVisited() != null && engagement.getJavascriptMcqVisited());
            status.setTypescript(engagement.getTypescriptMcqVisited() != null && engagement.getTypescriptMcqVisited());
        } else {
            // No engagement exists, all false
            status.setJava(false);
            status.setPython(false);
            status.setJavascript(false);
            status.setTypescript(false);
        }

        return status;
    }

    /**
     * Mark MCQ as visited for subtopic + language
     */
    @Transactional
    public CompletionResponseDTO markMcqVisited(Integer subtopicId, String language, String username) {
        log.info("Marking MCQ as visited for subtopicId: {}, language: {}, user: {}",
                subtopicId, language, username);

        User user = userRepository.findByUserId(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Topic topic = topicRepository.findById(subtopicId)
                .orElseThrow(() -> new RuntimeException("Topic not found with id: " + subtopicId));

        // Find or create UserTopicEngagement
        UserTopicEngagement engagement = userTopicEngagementRepository
                .findByUser_UserIdAndTopic_TopicId(username, subtopicId)
                .orElseGet(() -> createNewEngagement(user, topic));

        // Update language-specific MCQ flag
        updateLanguageMcqFlag(engagement, language);
        engagement.setMcqVisited(true); // Also set generic flag
        engagement.setLastActivityAt(LocalDateTime.now());

        // Save entity
        userTopicEngagementRepository.save(engagement);

        CompletionResponseDTO response = new CompletionResponseDTO();
        response.setSuccess(true);
        response.setMessage("MCQ marked as visited for " + language);

        return response;
    }

    // ========== HELPER METHODS ==========

    /**
     * Helper: Update language-specific time in UserTopicEngagement
     */
    private void updateLanguageTime(UserTopicEngagement engagement, String language, Long deltaSeconds) {
        switch (language.toUpperCase()) {
            case "JAVA":
                engagement.setJavaTimeSeconds(engagement.getJavaTimeSeconds() + deltaSeconds);
                engagement.setJavaVisited(true);
                break;
            case "PYTHON":
                engagement.setPythonTimeSeconds(engagement.getPythonTimeSeconds() + deltaSeconds);
                engagement.setPythonVisited(true);
                break;
            case "JAVASCRIPT":
                engagement.setJavascriptTimeSeconds(engagement.getJavascriptTimeSeconds() + deltaSeconds);
                engagement.setJavascriptVisited(true);
                break;
            case "TYPESCRIPT":
                engagement.setTypescriptTimeSeconds(engagement.getTypescriptTimeSeconds() + deltaSeconds);
                engagement.setTypescriptVisited(true);
                break;
            default:
                throw new IllegalArgumentException("Invalid language: " + language);
        }

        engagement.setTotalTimeSpent(engagement.getTotalTimeSpent() + deltaSeconds.intValue());
        engagement.setLastActivityAt(LocalDateTime.now());
    }

    /**
     * Helper: Update language-specific MCQ flag in UserTopicEngagement
     */
    private void updateLanguageMcqFlag(UserTopicEngagement engagement, String language) {
        switch (language.toUpperCase()) {
            case "JAVA":
                engagement.setJavaMcqVisited(true);
                break;
            case "PYTHON":
                engagement.setPythonMcqVisited(true);
                break;
            case "JAVASCRIPT":
                engagement.setJavascriptMcqVisited(true);
                break;
            case "TYPESCRIPT":
                engagement.setTypescriptMcqVisited(true);
                break;
            default:
                throw new IllegalArgumentException("Invalid language: " + language);
        }
    }

    /**
     * Helper: Get time for specific language from UserTopicEngagement
     */
    private Long getLanguageTime(UserTopicEngagement engagement, String language) {
        switch (language.toUpperCase()) {
            case "JAVA":
                return engagement.getJavaTimeSeconds();
            case "PYTHON":
                return engagement.getPythonTimeSeconds();
            case "JAVASCRIPT":
                return engagement.getJavascriptTimeSeconds();
            case "TYPESCRIPT":
                return engagement.getTypescriptTimeSeconds();
            default:
                throw new IllegalArgumentException("Invalid language: " + language);
        }
    }

    /**
     * Helper: Create new UserTopicEngagement with default values
     */
    private UserTopicEngagement createNewEngagement(User user, Topic topic) {
        UserTopicEngagement newEngagement = new UserTopicEngagement();
        UserTopicEngagementId id = new UserTopicEngagementId();
        id.setUserId(user.getUserId());
        id.setTopicId(topic.getTopicId());
        newEngagement.setUserTopicEngagementId(id);
        newEngagement.setUser(user);
        newEngagement.setTopic(topic);
        newEngagement.setLastActivityAt(LocalDateTime.now());

        // Set default values
        newEngagement.setTotalTimeSpent(0);
        newEngagement.setJavaTimeSeconds(0L);
        newEngagement.setPythonTimeSeconds(0L);
        newEngagement.setJavascriptTimeSeconds(0L);
        newEngagement.setTypescriptTimeSeconds(0L);

        newEngagement.setJavaVisited(false);
        newEngagement.setPythonVisited(false);
        newEngagement.setJavascriptVisited(false);
        newEngagement.setTypescriptVisited(false);

        newEngagement.setJavaMcqVisited(false);
        newEngagement.setPythonMcqVisited(false);
        newEngagement.setJavascriptMcqVisited(false);
        newEngagement.setTypescriptMcqVisited(false);

        newEngagement.setMcqVisited(false);
        newEngagement.setCompleted(false);

        log.info("Created new UserTopicEngagement for user {} and topic {}", user.getUserId(), topic.getTopicId());
        return newEngagement;
    }

    /**
     * Helper: Create new UserMainTopicEngagement with default values
     */
    private UserMainTopicEngagement createNewMainTopicEngagement(User user, MainTopic mainTopic) {
        UserMainTopicEngagement newEngagement = new UserMainTopicEngagement();
        UserMainTopicEngagementId id = new UserMainTopicEngagementId();
        id.setUserId(user.getUserId());
        id.setMainTopicId(mainTopic.getMainTopicId());
        newEngagement.setUserTopicEngagementId(id);
        newEngagement.setUser(user);
        newEngagement.setMainTopic(mainTopic);
        newEngagement.setLastActivityAt(LocalDateTime.now());

        // Initialize fields
        newEngagement.setTotalTimeSpent(0);
        newEngagement.setJavaTimeSeconds(0L);
        newEngagement.setPythonTimeSeconds(0L);
        newEngagement.setJavascriptTimeSeconds(0L);
        newEngagement.setTypescriptTimeSeconds(0L);
        newEngagement.setJavaCompleted(false);
        newEngagement.setPythonCompleted(false);
        newEngagement.setJavascriptCompleted(false);
        newEngagement.setTypescriptCompleted(false);
        newEngagement.setCompleted(false);



        log.info("Created new UserMainTopicEngagement for user {} and mainTopic {}",
                user.getUserId(), mainTopic.getMainTopicId());
        return newEngagement;
    }

    /**
     * Helper: Update main topic engagement based on subtopics
     */
    private void updateMainTopicEngagement(Topic topic, User user) {
        MainTopic mainTopic = topic.getMainTopic();
        if (mainTopic == null) {
            log.warn("Topic {} has no associated MainTopic, skipping main topic engagement update",
                    topic.getTopicId());
            return;
        }

        // Get all subtopics for this main topic
        List<Topic> subtopics = topicRepository.findAllByMainTopicIdWithMainTopic(mainTopic.getMainTopicId());

        // Fetch or create main topic engagement
        UserMainTopicEngagement mainEngagement = userMainTopicEngagementRepository
                .findByUser_UserIdAndMainTopic_MainTopicId(user.getUserId(), mainTopic.getMainTopicId())
                .orElseGet(() -> createNewMainTopicEngagement(user, mainTopic));

        // Calculate cumulative time for each language across all subtopics
        long totalJava = 0;
        long totalPython = 0;
        long totalJavascript = 0;
        long totalTypescript = 0;

        for (Topic subtopic : subtopics) {
            UserTopicEngagement engagement = userTopicEngagementRepository
                    .findByUser_UserIdAndTopic_TopicId(user.getUserId(), subtopic.getTopicId())
                    .orElse(null);

            if (engagement != null) {
                totalJava += (engagement.getJavaTimeSeconds() != null ? engagement.getJavaTimeSeconds() : 0);
                totalPython += (engagement.getPythonTimeSeconds() != null ? engagement.getPythonTimeSeconds() : 0);
                totalJavascript += (engagement.getJavascriptTimeSeconds() != null ? engagement.getJavascriptTimeSeconds() : 0);
                totalTypescript += (engagement.getTypescriptTimeSeconds() != null ? engagement.getTypescriptTimeSeconds() : 0);
            }
        }

        // Update main topic engagement times
        mainEngagement.setJavaTimeSeconds(totalJava);
        mainEngagement.setPythonTimeSeconds(totalPython);
        mainEngagement.setJavascriptTimeSeconds(totalJavascript);
        mainEngagement.setTypescriptTimeSeconds(totalTypescript);

        // Calculate total time
        long totalTime = totalJava + totalPython + totalJavascript + totalTypescript;
        mainEngagement.setTotalTimeSpent((int) totalTime);

        mainEngagement.setLastActivityAt(LocalDateTime.now());
        userMainTopicEngagementRepository.save(mainEngagement);
        log.info("Updated main topic engagement for mainTopicId: {}", mainTopic.getMainTopicId());
    }
}

