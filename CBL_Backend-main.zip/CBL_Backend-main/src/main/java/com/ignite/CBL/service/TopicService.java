package com.ignite.CBL.service;

import com.ignite.CBL.dto.TopicDTO;
import com.ignite.CBL.entity.Topic;

import java.util.List;

public interface TopicService {

    List<TopicDTO> findAllByCourseId(Integer courseId);
    TopicDTO findByTopicId(Integer topicId);
    TopicDTO findByTitle(String title);

}
