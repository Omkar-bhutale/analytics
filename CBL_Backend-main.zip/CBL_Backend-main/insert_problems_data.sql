-- ============================================================================
-- CBL Backend - Problems Data Insertion Script (Part 1 / 4)
-- Covers topic_id 1–7
-- ============================================================================
INSERT INTO problems (title, description, difficulty, created_using, hint, topic_id)
VALUES
-- =========================================================
-- 🧩 topic_id = 1: Primitive Data Types
-- =========================================================
('Identify the Data Type', 'Write a program to read a user input and print its primitive data type.', 'EASY', 'SME',
 '{"hint1": "Use type() in Python or instanceof in Java.", "hint2": "Remember all input starts as String.", "hint3": "Compare with int, float, and boolean types."}'::jsonb, 1),
('String to Integer Conversion', 'Convert a string containing numeric characters to an integer and print it.', 'EASY', 'LLM',
 '{"hint1": "Use int() in Python or Integer.parseInt() in Java.", "hint2": "Handle invalid input gracefully.", "hint3": "Use exception handling."}'::jsonb, 1),
('Find Range of Data Types', 'Print the range of int, float, and double types supported in the language.', 'MEDIUM', 'SME',
 '{"hint1": "Use Integer.MIN_VALUE, MAX_VALUE in Java.", "hint2": "Use sys.float_info in Python.", "hint3": "Compare ranges visually."}'::jsonb, 1),
('Type Casting Demonstration', 'Show implicit and explicit type conversion between primitive types.', 'MEDIUM', 'LLM',
 '{"hint1": "Try widening and narrowing conversions.", "hint2": "Convert int to float and vice versa.", "hint3": "Print intermediate values."}'::jsonb, 1),
('Dynamic Type Classifier', 'Analyze a list of values and classify each into its primitive data type.', 'HARD', 'SME',
 '{"hint1": "Loop through each item.", "hint2": "Use conditional type checks.", "hint3": "Display classification summary."}'::jsonb, 1),
('Precision and Overflow Test', 'Demonstrate overflow and precision issues with large numeric values.', 'HARD', 'LLM',
 '{"hint1": "Use large integer or floating-point values.", "hint2": "Show overflow behavior.", "hint3": "Use BigDecimal or Decimal for accuracy."}'::jsonb, 1),

-- =========================================================
-- 🧩 topic_id = 2: Operators and Expressions
-- =========================================================
('Arithmetic Operators Practice', 'Perform basic arithmetic operations on two numbers entered by the user.', 'EASY', 'SME',
 '{"hint1": "Use +, -, *, /, % operators.", "hint2": "Take two inputs from user.", "hint3": "Print all results clearly."}'::jsonb, 2),
('Comparison Operator Test', 'Write a program to compare two numbers using relational operators.', 'EASY', 'LLM',
 '{"hint1": "Use >, <, >=, <=, ==, !=.", "hint2": "Handle equal and unequal conditions.", "hint3": "Use meaningful print messages."}'::jsonb, 2),
('Logical Operator Evaluator', 'Create a truth table for AND, OR, and NOT operators.', 'MEDIUM', 'SME',
 '{"hint1": "Use Boolean inputs.", "hint2": "Combine conditions.", "hint3": "Display all possible combinations."}'::jsonb, 2),
('Expression Evaluator', 'Build a program to evaluate a mathematical expression entered by the user.', 'MEDIUM', 'LLM',
 '{"hint1": "Use eval() in Python or ScriptEngine in Java.", "hint2": "Handle invalid expressions safely.", "hint3": "Print evaluated result."}'::jsonb, 2),
('Bitwise Operations Demo', 'Demonstrate bitwise AND, OR, XOR, and shift operations.', 'HARD', 'SME',
 '{"hint1": "Use binary literals.", "hint2": "Display intermediate binary values.", "hint3": "Explain output behavior."}'::jsonb, 2),
('Operator Precedence Analyzer', 'Show how operator precedence affects expression results.', 'HARD', 'LLM',
 '{"hint1": "Use parentheses to override precedence.", "hint2": "Try mixed expressions.", "hint3": "Compare outputs with/without brackets."}'::jsonb, 2),

-- =========================================================
-- 🧩 topic_id = 3: Type Conversion and Casting
-- =========================================================
('Implicit Conversion', 'Demonstrate automatic type promotion in expressions.', 'EASY', 'SME',
 '{"hint1": "Use int + float.", "hint2": "Observe result type.", "hint3": "Print intermediate conversions."}'::jsonb, 3),
('Explicit Casting', 'Convert a floating-point number into an integer manually.', 'EASY', 'LLM',
 '{"hint1": "Use (int) or int().", "hint2": "Check for data loss.", "hint3": "Display both before and after values."}'::jsonb, 3),
('Widening Conversion Chain', 'Write a program showing implicit conversions from byte → short → int → float → double.', 'MEDIUM', 'SME',
 '{"hint1": "Assign small type to bigger type variable.", "hint2": "Observe no error during widening.", "hint3": "Print step by step result."}'::jsonb, 3),
('Narrowing Conversion Practice', 'Demonstrate data loss during narrowing conversions.', 'MEDIUM', 'LLM',
 '{"hint1": "Cast double to int.", "hint2": "Print truncated results.", "hint3": "Use large decimal values."}'::jsonb, 3),
('Mixed-Type Arithmetic', 'Write an expression mixing int, double, and char values to observe implicit conversions.', 'HARD', 'SME',
 '{"hint1": "Add numeric and character values.", "hint2": "Check ASCII impact on result.", "hint3": "Display final data type."}'::jsonb, 3),
('Custom Type Converter', 'Implement a custom method to convert string input into any primitive type dynamically.', 'HARD', 'LLM',
 '{"hint1": "Use generics or reflection.", "hint2": "Parse value using type name.", "hint3": "Handle exceptions safely."}'::jsonb, 3),

-- =========================================================
-- 🧩 topic_id = 4: Variables and Scope
-- =========================================================
('Global vs Local Variable', 'Demonstrate difference between global and local variable scope.', 'EASY', 'SME',
 '{"hint1": "Define variables inside and outside functions.", "hint2": "Access them in different scopes.", "hint3": "Observe scope errors."}'::jsonb, 4),
('Constant Declaration', 'Create and use constants in your program.', 'EASY', 'LLM',
 '{"hint1": "Use final in Java or const in Python 3.8+.", "hint2": "Assign constant values properly.", "hint3": "Try reassigning to test immutability."}'::jsonb, 4),
('Shadowing Demonstration', 'Show how local variables can shadow global variables.', 'MEDIUM', 'SME',
 '{"hint1": "Use same variable name in nested scopes.", "hint2": "Print both values.", "hint3": "Observe which value is accessed."}'::jsonb, 4),
('Static vs Instance Variables', 'Differentiate between static and instance variables in a class.', 'MEDIUM', 'LLM',
 '{"hint1": "Use class-level and object-level variables.", "hint2": "Access using class and object references.", "hint3": "Compare memory usage."}'::jsonb, 4),
('Scope Lifetime Tracker', 'Track creation and destruction of variables in function calls.', 'HARD', 'SME',
 '{"hint1": "Use print statements at entry/exit.", "hint2": "Observe garbage collection.", "hint3": "Compare function vs global lifetime."}'::jsonb, 4),
('Memory Reference Challenge', 'Write a program to demonstrate pass-by-value and pass-by-reference behavior.', 'HARD', 'LLM',
 '{"hint1": "Use mutable and immutable types.", "hint2": "Modify values inside functions.", "hint3": "Observe effects on original variables."}'::jsonb, 4),

-- =========================================================
-- 🧩 topic_id = 5: If-Else Statements
-- =========================================================
('Check Even or Odd', 'Write a program to check if a number is even or odd.', 'EASY', 'SME',
 '{"hint1": "Use % operator.", "hint2": "If remainder is 0, it’s even.", "hint3": "Handle negative numbers."}'::jsonb, 5),
('Find Maximum of Two Numbers', 'Compare two numbers using if-else and print the greater one.', 'EASY', 'LLM',
 '{"hint1": "Use > and <.", "hint2": "Handle equality case.", "hint3": "Test with equal numbers."}'::jsonb, 5),
('Positive, Negative, or Zero', 'Check if a number is positive, negative, or zero.', 'MEDIUM', 'SME',
 '{"hint1": "Use if-elif-else ladder.", "hint2": "Handle zero separately.", "hint3": "Print descriptive messages."}'::jsonb, 5),
('Grade Calculator', 'Determine grade based on marks entered by user.', 'MEDIUM', 'LLM',
 '{"hint1": "Use range checks with if-else.", "hint2": "Validate marks range.", "hint3": "Assign grade letters accordingly."}'::jsonb, 5),
('Nested If Example', 'Demonstrate nested if-else by finding the largest among three numbers.', 'HARD', 'SME',
 '{"hint1": "Use nested conditions.", "hint2": "Compare stepwise.", "hint3": "Handle all equal scenario."}'::jsonb, 5),
('Eligibility Checker', 'Write a program that checks eligibility for voting, driving, and drinking.', 'HARD', 'LLM',
 '{"hint1": "Take age as input.", "hint2": "Use chained if statements.", "hint3": "Print all applicable privileges."}'::jsonb, 5),

-- =========================================================
-- 🧩 topic_id = 6: Switch Statements
-- =========================================================
('Weekday Finder', 'Given a number (1-7), print the corresponding weekday.', 'EASY', 'SME',
 '{"hint1": "Use switch or match-case.", "hint2": "Map numbers to days.", "hint3": "Handle invalid inputs."}'::jsonb, 6),
('Calculator using Switch', 'Build a simple calculator using switch/case structure.', 'EASY', 'LLM',
 '{"hint1": "Use char for operator (+, -, *, /).", "hint2": "Perform matching operation.", "hint3": "Handle division by zero."}'::jsonb, 6),
('Vowel or Consonant', 'Check if a given character is a vowel or consonant using switch.', 'MEDIUM', 'SME',
 '{"hint1": "Use lowercase input.", "hint2": "List all vowels as cases.", "hint3": "Use default for consonants."}'::jsonb, 6),
('Month Days Calculator', 'Given month number, print how many days it has.', 'MEDIUM', 'LLM',
 '{"hint1": "Use grouped cases for 30 and 31 days.", "hint2": "Handle February separately.", "hint3": "Validate input range."}'::jsonb, 6),
('Menu-Driven Program', 'Create a menu-driven program using switch statements.', 'HARD', 'SME',
 '{"hint1": "Display numbered options.", "hint2": "Perform action for each case.", "hint3": "Use default for invalid choice."}'::jsonb, 6),
('Character Category Identifier', 'Identify whether a character is a digit, letter, or symbol using switch.', 'HARD', 'LLM',
 '{"hint1": "Use char classification logic.", "hint2": "Combine ranges in cases.", "hint3": "Display appropriate message."}'::jsonb, 6),

-- =========================================================
-- 🧩 topic_id = 7: For Loops
-- =========================================================
('Print 1 to N', 'Print numbers from 1 to N using for loop.', 'EASY', 'SME',
 '{"hint1": "Use range or counter variable.", "hint2": "Increment by 1 each iteration.", "hint3": "Print each number on new line."}'::jsonb, 7),
('Sum of Natural Numbers', 'Calculate sum of first N natural numbers.', 'EASY', 'LLM',
 '{"hint1": "Use loop accumulator variable.", "hint2": "Start from 1 till N.", "hint3": "Display final sum."}'::jsonb, 7),
('Multiplication Table', 'Print multiplication table of a given number.', 'MEDIUM', 'SME',
 '{"hint1": "Use for loop up to 10.", "hint2": "Multiply index with number.", "hint3": "Format output clearly."}'::jsonb, 7),
('Factorial Finder', 'Compute factorial of a number using for loop.', 'MEDIUM', 'LLM',
 '{"hint1": "Initialize result=1.", "hint2": "Multiply sequentially till N.", "hint3": "Handle 0 and 1 separately."}'::jsonb, 7),
('Prime Numbers in Range', 'Find all prime numbers between 1 and N.', 'HARD', 'SME',
 '{"hint1": "Use nested loops.", "hint2": "Check divisibility up to sqrt(n).", "hint3": "Print primes in same line."}'::jsonb, 7),
('Pattern Printer', 'Print a pyramid pattern using for loops.', 'HARD', 'LLM',
 '{"hint1": "Use nested for loops.", "hint2": "Outer loop for rows, inner for spaces/stars.", "hint3": "Align the output symmetrically."}'::jsonb, 7);
-- ============================================================================
-- CBL Backend - Problems Data Insertion Script (Part 2 / 4)
-- Covers topic_id 8–14
-- ============================================================================
INSERT INTO problems (title, description, difficulty, created_using, hint, topic_id)
VALUES
-- =========================================================
-- 🧩 topic_id = 8: While and Do-While Loops
-- =========================================================
('Sum Until Zero', 'Read numbers from user until 0 is entered, then display the sum.', 'EASY', 'SME',
 '{"hint1": "Use while loop with condition != 0.", "hint2": "Initialize sum=0.", "hint3": "Add each input to sum."}'::jsonb, 8),
('Countdown Timer', 'Print numbers from N down to 1 using while loop.', 'EASY', 'LLM',
 '{"hint1": "Initialize counter = N.", "hint2": "Decrement inside loop.", "hint3": "Stop when counter == 0."}'::jsonb, 8),
('Digit Counter', 'Count number of digits in an integer using while loop.', 'MEDIUM', 'SME',
 '{"hint1": "Divide number by 10 each iteration.", "hint2": "Use counter variable.", "hint3": "Handle zero case separately."}'::jsonb, 8),
('Reverse Number', 'Reverse a given integer using while loop.', 'MEDIUM', 'LLM',
 '{"hint1": "Use %10 to get last digit.", "hint2": "Multiply reversed by 10 each time.", "hint3": "Divide number by 10 per iteration."}'::jsonb, 8),
('Menu-Driven While Program', 'Implement a calculator that runs until user chooses exit.', 'HARD', 'SME',
 '{"hint1": "Use while(true) loop.", "hint2": "Provide menu options.", "hint3": "Break on user command."}'::jsonb, 8),
('Do-While Authentication', 'Simulate a login system using do-while loop that repeats until password is correct.', 'HARD', 'LLM',
 '{"hint1": "Check password inside loop.", "hint2": "Use do-while to run at least once.", "hint3": "Validate string match."}'::jsonb, 8),

-- =========================================================
-- 🧩 topic_id = 9: Function Declaration and Invocation
-- =========================================================
('Simple Function Call', 'Create a function that prints a welcome message.', 'EASY', 'SME',
 '{"hint1": "Define function with no parameters.", "hint2": "Call function in main.", "hint3": "Keep it simple for beginners."}'::jsonb, 9),
('Add Two Numbers Function', 'Write a function that takes two integers and returns their sum.', 'EASY', 'LLM',
 '{"hint1": "Use return statement.", "hint2": "Accept two parameters.", "hint3": "Print result after call."}'::jsonb, 9),
('Area Calculator', 'Create a function that calculates area of circle, rectangle, or triangle.', 'MEDIUM', 'SME',
 '{"hint1": "Use conditional logic inside function.", "hint2": "Return computed value.", "hint3": "Pass shape type and dimensions."}'::jsonb, 9),
('Palindrome Checker', 'Implement a function that checks if a given string is palindrome.', 'MEDIUM', 'LLM',
 '{"hint1": "Compare string and its reverse.", "hint2": "Return boolean result.", "hint3": "Ignore case and spaces."}'::jsonb, 9),
('Prime Checker', 'Write a function to determine if a number is prime.', 'HARD', 'SME',
 '{"hint1": "Use loop till sqrt(n).", "hint2": "Return True/False.", "hint3": "Handle 1 and 2 separately."}'::jsonb, 9),
('Fibonacci Generator', 'Create a function that returns N Fibonacci numbers.', 'HARD', 'LLM',
 '{"hint1": "Use loop or recursion.", "hint2": "Store values in list.", "hint3": "Return final sequence."}'::jsonb, 9),

-- =========================================================
-- 🧩 topic_id = 10: Parameters and Return Values
-- =========================================================
('Square a Number', 'Write a function that takes a number and returns its square.', 'EASY', 'SME',
 '{"hint1": "Use return keyword.", "hint2": "Multiply number by itself.", "hint3": "Print return value."}'::jsonb, 10),
('Greeting Function', 'Write a function that takes name as parameter and prints personalized greeting.', 'EASY', 'LLM',
 '{"hint1": "Use string concatenation.", "hint2": "Accept name as parameter.", "hint3": "Return or print greeting."}'::jsonb, 10),
('Average Calculator', 'Write a function that takes a list of numbers and returns average.', 'MEDIUM', 'SME',
 '{"hint1": "Use len() for count.", "hint2": "Sum all elements.", "hint3": "Return float value."}'::jsonb, 10),
('Find Max and Min', 'Create a function that returns both maximum and minimum from list.', 'MEDIUM', 'LLM',
 '{"hint1": "Use built-in max/min or loop.", "hint2": "Return as tuple or object.", "hint3": "Handle empty list case."}'::jsonb, 10),
('Custom Power Function', 'Implement your own power(base, exponent) function without using built-ins.', 'HARD', 'SME',
 '{"hint1": "Use for loop multiplication.", "hint2": "Handle exponent=0 case.", "hint3": "Use recursion for challenge."}'::jsonb, 10),
('Multi-Return Function', 'Return multiple values like sum, average, and product in one function.', 'HARD', 'LLM',
 '{"hint1": "Return tuple/dict.", "hint2": "Perform operations in one function.", "hint3": "Print results after unpacking."}'::jsonb, 10),

-- =========================================================
-- 🧩 topic_id = 11: Function Scope and Closures
-- =========================================================
('Variable Scope Demo', 'Show local and global variable usage inside functions.', 'EASY', 'SME',
 '{"hint1": "Define same variable inside and outside function.", "hint2": "Print both values.", "hint3": "Use global keyword if needed."}'::jsonb, 11),
('Nested Function', 'Define a function inside another and call the inner one.', 'EASY', 'LLM',
 '{"hint1": "Define inner() inside outer().", "hint2": "Call inner() from outer().", "hint3": "Test scope of variables."}'::jsonb, 11),
('Closure Example', 'Write a closure that remembers a variable from enclosing scope.', 'MEDIUM', 'SME',
 '{"hint1": "Return inner function.", "hint2": "Capture variable from parent scope.", "hint3": "Call returned function."}'::jsonb, 11),
('Counter Closure', 'Build a closure-based counter function that increments each call.', 'MEDIUM', 'LLM',
 '{"hint1": "Use nonlocal keyword in Python.", "hint2": "Initialize count inside outer function.", "hint3": "Return increment function."}'::jsonb, 11),
('Scope Resolution Experiment', 'Print variable lookup order using LEGB rule (Local → Enclosing → Global → Built-in).', 'HARD', 'SME',
 '{"hint1": "Define nested scopes.", "hint2": "Print variable from different levels.", "hint3": "Use built-in variable shadowing."}'::jsonb, 11),
('Function Object Inspector', 'Inspect attributes of function objects at runtime.', 'HARD', 'LLM',
 '{"hint1": "Use dir() or reflection.", "hint2": "Print function name and docstring.", "hint3": "Modify attributes dynamically."}'::jsonb, 11),

-- =========================================================
-- 🧩 topic_id = 12: Recursion and Higher-Order Functions
-- =========================================================
('Factorial Using Recursion', 'Find factorial of a number using recursive function.', 'EASY', 'SME',
 '{"hint1": "Base case when n==0 or 1.", "hint2": "Recursive call with n-1.", "hint3": "Return n*factorial(n-1)."}'::jsonb, 12),
('Sum of Digits Recursively', 'Find sum of digits using recursion.', 'EASY', 'LLM',
 '{"hint1": "Base case when number==0.", "hint2": "Use %10 and //10.", "hint3": "Return digit + recursive call."}'::jsonb, 12),
('Fibonacci Recursion', 'Generate Nth Fibonacci term using recursion.', 'MEDIUM', 'SME',
 '{"hint1": "Base case for 0 and 1.", "hint2": "Return fib(n-1)+fib(n-2).", "hint3": "Avoid redundant calls using memoization."}'::jsonb, 12),
('Recursive List Sum', 'Sum elements of a list recursively.', 'MEDIUM', 'LLM',
 '{"hint1": "Base case when list empty.", "hint2": "Return first + sum(rest).", "hint3": "Slice list in recursive call."}'::jsonb, 12),
('Lambda Map Filter Demo', 'Demonstrate higher-order functions like map, filter, reduce.', 'HARD', 'SME',
 '{"hint1": "Use lambda expressions.", "hint2": "Apply map/filter to lists.", "hint3": "Show reduce usage for sum/product."}'::jsonb, 12),
('Recursive Permutations', 'Generate all permutations of string using recursion.', 'HARD', 'LLM',
 '{"hint1": "Swap characters recursively.", "hint2": "Use backtracking.", "hint3": "Print all combinations."}'::jsonb, 12),

-- =========================================================
-- 🧩 topic_id = 13: Lists and Arrays
-- =========================================================
('Sum of List Elements', 'Find sum of all elements in a list or array.', 'EASY', 'SME',
 '{"hint1": "Use for loop.", "hint2": "Initialize sum=0.", "hint3": "Add each element to sum."}'::jsonb, 13),
('Find Largest Element', 'Find largest number in an array.', 'EASY', 'LLM',
 '{"hint1": "Initialize max=first element.", "hint2": "Compare each element.", "hint3": "Update max when found larger."}'::jsonb, 13),
('Second Largest Finder', 'Find second largest number in array without sorting.', 'MEDIUM', 'SME',
 '{"hint1": "Track two variables: max and secondMax.", "hint2": "Update both as needed.", "hint3": "Handle duplicates."}'::jsonb, 13),
('Array Rotation', 'Rotate an array by K positions.', 'MEDIUM', 'LLM',
 '{"hint1": "Use slicing or temp array.", "hint2": "Use modulo for K.", "hint3": "Preserve order after rotation."}'::jsonb, 13),
('Merge Two Sorted Arrays', 'Merge two sorted arrays into one sorted array.', 'HARD', 'SME',
 '{"hint1": "Use two pointers.", "hint2": "Compare elements sequentially.", "hint3": "Append remaining elements."}'::jsonb, 13),
('Subarray Sum Finder', 'Find contiguous subarray with maximum sum (Kadane’s Algorithm).', 'HARD', 'LLM',
 '{"hint1": "Track current and max sum.", "hint2": "Reset current sum when negative.", "hint3": "Return max sum found."}'::jsonb, 13),

-- =========================================================
-- 🧩 topic_id = 14: Sets and Unique Collections
-- =========================================================
('Remove Duplicates', 'Remove duplicate elements from a list using set.', 'EASY', 'SME',
 '{"hint1": "Convert list to set.", "hint2": "Convert back to list.", "hint3": "Compare lengths before and after."}'::jsonb, 14),
('Set Operations', 'Perform union, intersection, and difference of two sets.', 'EASY', 'LLM',
 '{"hint1": "Use |, &, - operators.", "hint2": "Print all results clearly.", "hint3": "Try sets with overlaps."}'::jsonb, 14),
('Find Common Elements', 'Find common items between two lists using sets.', 'MEDIUM', 'SME',
 '{"hint1": "Convert lists to sets.", "hint2": "Use intersection().", "hint3": "Return result as list."}'::jsonb, 14),
('Unique Word Counter', 'Count unique words in a text paragraph.', 'MEDIUM', 'LLM',
 '{"hint1": "Split paragraph by space.", "hint2": "Convert list to set.", "hint3": "Print count of unique words."}'::jsonb, 14),
('Subset Checker', 'Check if one set is subset of another.', 'HARD', 'SME',
 '{"hint1": "Use issubset() or containsAll().", "hint2": "Test multiple pairs.", "hint3": "Print boolean result."}'::jsonb, 14),
('Set Difference Application', 'Given two datasets, print items unique to first set.', 'HARD', 'LLM',
 '{"hint1": "Use difference() method.", "hint2": "Handle empty sets.", "hint3": "Show counts as well."}'::jsonb, 14);
-- ============================================================================
-- CBL Backend - Problems Data Insertion Script (Part 3 / 4)
-- Covers topic_id 15–21
-- ============================================================================
INSERT INTO problems (title, description, difficulty, created_using, hint, topic_id)
VALUES
-- =========================================================
-- 🧩 topic_id = 15: Maps and Dictionaries
-- =========================================================
('Basic Dictionary Creation', 'Create a map to store student names and their grades, then print them.', 'EASY', 'SME',
 '{"hint1": "Use HashMap or dict.", "hint2": "Store key-value pairs.", "hint3": "Iterate and print all entries."}'::jsonb, 15),
('Key Existence Check', 'Check if a given key exists in a map or dictionary.', 'EASY', 'LLM',
 '{"hint1": "Use containsKey() or in operator.", "hint2": "Handle absent keys safely.", "hint3": "Print corresponding message."}'::jsonb, 15),
('Word Frequency Counter', 'Count occurrences of each word in a sentence using map/dict.', 'MEDIUM', 'SME',
 '{"hint1": "Split string into words.", "hint2": "Update frequency count.", "hint3": "Use dictionary comprehension."}'::jsonb, 15),
('Invert Dictionary', 'Swap keys and values in a dictionary.', 'MEDIUM', 'LLM',
 '{"hint1": "Iterate over items.", "hint2": "Assign value as key.", "hint3": "Handle duplicate values carefully."}'::jsonb, 15),
('Merge Two Maps', 'Merge two dictionaries and sum values for matching keys.', 'HARD', 'SME',
 '{"hint1": "Loop through both maps.", "hint2": "Check if key exists.", "hint3": "Add values for duplicates."}'::jsonb, 15),
('JSON Parser Simulation', 'Parse a simple JSON-like string into a dictionary.', 'HARD', 'LLM',
 '{"hint1": "Remove braces and split by commas.", "hint2": "Use split by colon for key-value.", "hint3": "Trim whitespace and quotes."}'::jsonb, 15),

-- =========================================================
-- 🧩 topic_id = 16: Collection Operations and Iteration
-- =========================================================
('Iterate Over List', 'Print all elements of a list using for-each loop.', 'EASY', 'SME',
 '{"hint1": "Use for-each or enhanced for loop.", "hint2": "Access elements directly.", "hint3": "Print one per line."}'::jsonb, 16),
('Sum of Collection', 'Find total sum of all integers in a collection.', 'EASY', 'LLM',
 '{"hint1": "Use for loop to iterate.", "hint2": "Add elements to accumulator.", "hint3": "Initialize sum=0 before loop."}'::jsonb, 16),
('Remove Duplicates from List', 'Remove duplicate entries using collection operations.', 'MEDIUM', 'SME',
 '{"hint1": "Convert list to set.", "hint2": "Convert back to list.", "hint3": "Compare lengths before and after."}'::jsonb, 16),
('Filter Even Numbers', 'Filter even numbers from a list using functional operations.', 'MEDIUM', 'LLM',
 '{"hint1": "Use filter() or stream().", "hint2": "Check num%2==0 condition.", "hint3": "Collect and print result."}'::jsonb, 16),
('Sort Custom Objects', 'Sort a list of objects by a specific attribute.', 'HARD', 'SME',
 '{"hint1": "Use comparator or lambda.", "hint2": "Sort by name or age.", "hint3": "Print sorted list."}'::jsonb, 16),
('Nested Collection Iterator', 'Iterate through a list of lists or map of lists and print all values.', 'HARD', 'LLM',
 '{"hint1": "Use nested loops.", "hint2": "Access inner lists.", "hint3": "Format output properly."}'::jsonb, 16),

-- =========================================================
-- 🧩 topic_id = 17: Class Declaration and Object Creation
-- =========================================================
('Simple Class Example', 'Create a class Student with name and age attributes and print details.', 'EASY', 'SME',
 '{"hint1": "Define class with two fields.", "hint2": "Use constructor or setter methods.", "hint3": "Print object attributes."}'::jsonb, 17),
('Multiple Object Creation', 'Create multiple objects of same class and store in a list.', 'EASY', 'LLM',
 '{"hint1": "Use array or list to store objects.", "hint2": "Iterate to print details.", "hint3": "Access attributes using getters."}'::jsonb, 17),
('Class with Behavior', 'Add a method to class Employee that computes annual salary.', 'MEDIUM', 'SME',
 '{"hint1": "Use instance variable for monthly salary.", "hint2": "Multiply by 12.", "hint3": "Return result from method."}'::jsonb, 17),
('Bank Account Class', 'Implement a class with deposit and withdraw methods.', 'MEDIUM', 'LLM',
 '{"hint1": "Maintain balance as instance variable.", "hint2": "Check balance before withdrawal.", "hint3": "Update balance after operations."}'::jsonb, 17),
('Copy Constructor Example', 'Demonstrate how to copy an object using constructor.', 'HARD', 'SME',
 '{"hint1": "Accept object as parameter.", "hint2": "Copy field values manually.", "hint3": "Print both to verify independence."}'::jsonb, 17),
('Object Comparison', 'Override equals() method to compare two objects by their attributes.', 'HARD', 'LLM',
 '{"hint1": "Compare fields inside equals().", "hint2": "Return boolean result.", "hint3": "Also override hashCode()."}'::jsonb, 17),

-- =========================================================
-- 🧩 topic_id = 18: Constructors and Initialization
-- =========================================================
('Default Constructor Example', 'Demonstrate use of default constructor to initialize variables.', 'EASY', 'SME',
 '{"hint1": "Use no-argument constructor.", "hint2": "Assign default values.", "hint3": "Print initialized values."}'::jsonb, 18),
('Parameterized Constructor', 'Create a parameterized constructor to assign custom values.', 'EASY', 'LLM',
 '{"hint1": "Use arguments in constructor.", "hint2": "Assign to instance variables.", "hint3": "Print values in method."}'::jsonb, 18),
('Constructor Overloading', 'Show how multiple constructors can initialize objects differently.', 'MEDIUM', 'SME',
 '{"hint1": "Use same name with different parameters.", "hint2": "Call appropriate one during creation.", "hint3": "Print which one executed."}'::jsonb, 18),
('Chained Constructor Calls', 'Use this() or super() to chain constructor calls.', 'MEDIUM', 'LLM',
 '{"hint1": "Call another constructor inside one.", "hint2": "Use this() to reuse initialization logic.", "hint3": "Avoid recursive calls."}'::jsonb, 18),
('Static Block Initialization', 'Initialize class-level data using static block.', 'HARD', 'SME',
 '{"hint1": "Use static block before main.", "hint2": "Initialize static variable.", "hint3": "Print message to confirm execution order."}'::jsonb, 18),
('Object Initialization Order', 'Demonstrate initialization order: static → instance → constructor.', 'HARD', 'LLM',
 '{"hint1": "Add print statements in each section.", "hint2": "Observe order of execution.", "hint3": "Create object to trigger flow."}'::jsonb, 18),

-- =========================================================
-- 🧩 topic_id = 19: Encapsulation and Access Modifiers
-- =========================================================
('Private Variable Example', 'Declare private variables and use getters and setters to access them.', 'EASY', 'SME',
 '{"hint1": "Use private keyword.", "hint2": "Provide public getter/setter.", "hint3": "Test by setting and getting values."}'::jsonb, 19),
('Access Modifier Scope', 'Demonstrate difference between public, private, and protected members.', 'EASY', 'LLM',
 '{"hint1": "Use same package and different package classes.", "hint2": "Try accessing members.", "hint3": "Observe access results."}'::jsonb, 19),
('Read-Only Property', 'Create a class with read-only property.', 'MEDIUM', 'SME',
 '{"hint1": "Omit setter method.", "hint2": "Assign via constructor only.", "hint3": "Try modifying value externally."}'::jsonb, 19),
('Encapsulation in Banking System', 'Design a BankAccount class demonstrating encapsulation.', 'MEDIUM', 'LLM',
 '{"hint1": "Keep balance private.", "hint2": "Expose deposit/withdraw methods.", "hint3": "Prevent direct modification."}'::jsonb, 19),
('Custom Access Control', 'Use package-private modifier to restrict access.', 'HARD', 'SME',
 '{"hint1": "Default access = package-private.", "hint2": "Test with another package.", "hint3": "Observe compiler errors."}'::jsonb, 19),
('Immutable Class Design', 'Create an immutable class with private final fields.', 'HARD', 'LLM',
 '{"hint1": "Use private final fields.", "hint2": "No setters provided.", "hint3": "Initialize in constructor only."}'::jsonb, 19),

-- =========================================================
-- 🧩 topic_id = 20: Methods and Instance Variables
-- =========================================================
('Method Definition Example', 'Define and call a simple method that prints a message.', 'EASY', 'SME',
 '{"hint1": "Use void return type.", "hint2": "Call method inside main.", "hint3": "Use public modifier."}'::jsonb, 20),
('Method Overloading Example', 'Demonstrate method overloading with different parameter types.', 'EASY', 'LLM',
 '{"hint1": "Define methods with same name but different parameters.", "hint2": "Call them with different argument types.", "hint3": "Observe which is called."}'::jsonb, 20),
('Return Value Method', 'Create method that returns calculated result.', 'MEDIUM', 'SME',
 '{"hint1": "Use return keyword.", "hint2": "Store result in variable.", "hint3": "Print final output."}'::jsonb, 20),
('Instance Variable Updater', 'Modify instance variable values through methods.', 'MEDIUM', 'LLM',
 '{"hint1": "Define instance variable in class.", "hint2": "Modify inside method.", "hint3": "Print updated value."}'::jsonb, 20),
('Static vs Instance Method', 'Show difference between static and instance methods.', 'HARD', 'SME',
 '{"hint1": "Call static via class name.", "hint2": "Call instance via object.", "hint3": "Observe memory usage."}'::jsonb, 20),
('Method Chaining', 'Implement method chaining in a class.', 'HARD', 'LLM',
 '{"hint1": "Return this from methods.", "hint2": "Call multiple methods in one statement.", "hint3": "Ensure fluent design pattern."}'::jsonb, 20),

-- =========================================================
-- 🧩 topic_id = 21: Try-Catch-Finally Blocks
-- =========================================================
('Basic Exception Handling', 'Write a program that catches divide-by-zero error.', 'EASY', 'SME',
 '{"hint1": "Use try-catch around division.", "hint2": "Catch ArithmeticException or ZeroDivisionError.", "hint3": "Print error message."}'::jsonb, 21),
('Multiple Catch Blocks', 'Demonstrate multiple catch blocks for different exceptions.', 'EASY', 'LLM',
 '{"hint1": "Use try with multiple catches.", "hint2": "Handle different error types.", "hint3": "Use finally for cleanup."}'::jsonb, 21),
('File Reading Exception', 'Handle FileNotFound and IOException during file reading.', 'MEDIUM', 'SME',
 '{"hint1": "Use try-catch-finally.", "hint2": "Close file in finally.", "hint3": "Use FileReader or open()."}'::jsonb, 21),
('Custom Exception Creation', 'Create and throw a custom exception when condition fails.', 'MEDIUM', 'LLM',
 '{"hint1": "Extend Exception class.", "hint2": "Throw with new keyword.", "hint3": "Catch it in main method."}'::jsonb, 21),
('Nested Try Example', 'Use nested try-catch to handle multiple operations.', 'HARD', 'SME',
 '{"hint1": "Try inside another try.", "hint2": "Handle inner exceptions first.", "hint3": "Use meaningful print messages."}'::jsonb, 21),
('Finally Block Validation', 'Show that finally always executes regardless of exception.', 'HARD', 'LLM',
 '{"hint1": "Add return statement in try.", "hint2": "Observe finally still executes.", "hint3": "Print messages in each block."}'::jsonb, 21);
-- ============================================================================
-- CBL Backend - Problems Data Insertion Script (Part 4 / 4)
-- Covers topic_id 22–28
-- ============================================================================
INSERT INTO problems (title, description, difficulty, created_using, hint, topic_id)
VALUES
-- =========================================================
-- 🧩 topic_id = 22: Exception Types and Hierarchy
-- =========================================================
('Checked vs Unchecked Demo', 'Write a program that distinguishes between checked and unchecked exceptions.', 'EASY', 'SME',
 '{"hint1": "Throw IOException and ArithmeticException.", "hint2": "Observe which require try-catch.", "hint3": "Print class hierarchy."}'::jsonb, 22),
('Handle NullPointerException', 'Demonstrate handling NullPointerException safely.', 'EASY', 'LLM',
 '{"hint1": "Create a null reference.", "hint2": "Use try-catch block.", "hint3": "Print error message."}'::jsonb, 22),
('Custom Exception Chain', 'Show how multiple exceptions can be chained using cause.', 'MEDIUM', 'SME',
 '{"hint1": "Use initCause() or raise from.", "hint2": "Catch outer exception.", "hint3": "Print both messages."}'::jsonb, 22),
('Exception Propagation', 'Demonstrate how exceptions propagate through function calls.', 'MEDIUM', 'LLM',
 '{"hint1": "Throw exception in inner method.", "hint2": "Catch in caller.", "hint3": "Print call stack info."}'::jsonb, 22),
('Runtime Exception Example', 'Write code that triggers and handles common runtime exceptions.', 'HARD', 'SME',
 '{"hint1": "Use divide by zero, array index out of bounds.", "hint2": "Handle using try-catch.", "hint3": "Print which block executed."}'::jsonb, 22),
('Error vs Exception', 'Differentiate between Error and Exception classes in Java.', 'HARD', 'LLM',
 '{"hint1": "Print superclasses of both.", "hint2": "Trigger OutOfMemoryError safely (optional).", "hint3": "Log differences."}'::jsonb, 22),

-- =========================================================
-- 🧩 topic_id = 23: Throwing and Creating Custom Exceptions
-- =========================================================
('Throw Keyword Example', 'Manually throw an ArithmeticException when denominator is zero.', 'EASY', 'SME',
 '{"hint1": "Use throw new ArithmeticException().", "hint2": "Catch in main.", "hint3": "Print custom message."}'::jsonb, 23),
('User Defined Exception', 'Create a simple custom exception class and throw it.', 'EASY', 'LLM',
 '{"hint1": "Extend Exception or RuntimeException.", "hint2": "Use super(message).", "hint3": "Catch it in try-catch."}'::jsonb, 23),
('Validate Age Exception', 'Throw exception if entered age is less than 18.', 'MEDIUM', 'SME',
 '{"hint1": "Create InvalidAgeException class.", "hint2": "Throw when age<18.", "hint3": "Print custom error message."}'::jsonb, 23),
('File Validation Exception', 'Throw a custom exception if file format is invalid.', 'MEDIUM', 'LLM',
 '{"hint1": "Accept file name as input.", "hint2": "Check extension with endswith().", "hint3": "Throw exception if invalid."}'::jsonb, 23),
('Custom Stack Overflow Simulation', 'Simulate stack overflow using recursive call and handle it.', 'HARD', 'SME',
 '{"hint1": "Use deep recursion intentionally.", "hint2": "Catch StackOverflowError carefully.", "hint3": "Print limit reached."}'::jsonb, 23),
('Bank Exception System', 'Create multiple custom exceptions like InsufficientBalance and InvalidTransaction.', 'HARD', 'LLM',
 '{"hint1": "Define separate classes.", "hint2": "Throw based on condition.", "hint3": "Catch and handle accordingly."}'::jsonb, 23),

-- =========================================================
-- 🧩 topic_id = 24: Best Practices and Error Recovery
-- =========================================================
('Resource Cleanup Example', 'Demonstrate resource cleanup using finally or try-with-resources.', 'EASY', 'SME',
 '{"hint1": "Use file or scanner resource.", "hint2": "Close in finally.", "hint3": "Try with try-with-resources alternative."}'::jsonb, 24),
('Multiple Exception Catch', 'Use multi-catch to handle multiple exceptions in one block.', 'EASY', 'LLM',
 '{"hint1": "Use catch(IOException | SQLException e).", "hint2": "Print common message.", "hint3": "Avoid code duplication."}'::jsonb, 24),
('Logging in Exception Handling', 'Implement proper logging inside catch blocks.', 'MEDIUM', 'SME',
 '{"hint1": "Use logging framework or printStackTrace().", "hint2": "Include timestamps.", "hint3": "Write logs to file."}'::jsonb, 24),
('Recovery from Failure', 'Implement a retry mechanism after an operation fails.', 'MEDIUM', 'LLM',
 '{"hint1": "Use loop with limited retries.", "hint2": "Catch exceptions inside loop.", "hint3": "Stop after max retries."}'::jsonb, 24),
('Chained Error Logging', 'Handle one exception and log related secondary exceptions.', 'HARD', 'SME',
 '{"hint1": "Use suppressed exceptions.", "hint2": "Log original and suppressed ones.", "hint3": "Ensure none are lost."}'::jsonb, 24),
('Graceful Exit Program', 'Handle all uncaught exceptions globally and exit gracefully.', 'HARD', 'LLM',
 '{"hint1": "Use global handler or sys.excepthook.", "hint2": "Print friendly message.", "hint3": "Exit safely with cleanup."}'::jsonb, 24),

-- =========================================================
-- 🧩 topic_id = 25: Inheritance and Base Classes
-- =========================================================
('Simple Inheritance Demo', 'Create a base class Animal and derived class Dog to show inheritance.', 'EASY', 'SME',
 '{"hint1": "Use extends or class inheritance.", "hint2": "Call base class method.", "hint3": "Print both class outputs."}'::jsonb, 25),
('Single vs Multilevel Inheritance', 'Demonstrate single and multilevel inheritance.', 'EASY', 'LLM',
 '{"hint1": "Create classes A->B->C.", "hint2": "Call grandparent method from child.", "hint3": "Print order of constructor calls."}'::jsonb, 25),
('Constructor Chaining with Super', 'Call superclass constructor using super keyword.', 'MEDIUM', 'SME',
 '{"hint1": "Call super() inside child constructor.", "hint2": "Pass parameters upward.", "hint3": "Observe execution order."}'::jsonb, 25),
('Override Parent Method', 'Override method from parent class to change behavior.', 'MEDIUM', 'LLM',
 '{"hint1": "Define same method name in child.", "hint2": "Use @Override annotation if Java.", "hint3": "Compare outputs."}'::jsonb, 25),
('Hierarchical Inheritance Example', 'Show multiple child classes inheriting from single parent.', 'HARD', 'SME',
 '{"hint1": "Create base Vehicle and derive Car, Bike.", "hint2": "Add unique features in each.", "hint3": "Call all show() methods."}'::jsonb, 25),
('Diamond Problem Exploration', 'Demonstrate diamond problem using multiple inheritance concepts.', 'HARD', 'LLM',
 '{"hint1": "Use interfaces or virtual inheritance.", "hint2": "Print constructor order.", "hint3": "Explain resolution mechanism."}'::jsonb, 25),

-- =========================================================
-- 🧩 topic_id = 26: Method Overriding and Super Keyword
-- =========================================================
('Simple Override Example', 'Create parent and child classes where child overrides display().', 'EASY', 'SME',
 '{"hint1": "Define same method name.", "hint2": "Print custom message in each.", "hint3": "Call both versions."}'::jsonb, 26),
('Using Super to Call Parent', 'Use super keyword to call parent version of overridden method.', 'EASY', 'LLM',
 '{"hint1": "Inside overridden method, call super.methodName().", "hint2": "Print order of execution.", "hint3": "Observe behavior."}'::jsonb, 26),
('Polymorphic Call Example', 'Store child object in parent reference and call overridden method.', 'MEDIUM', 'SME',
 '{"hint1": "Use Animal a = new Dog();", "hint2": "Call speak().", "hint3": "Observe runtime binding."}'::jsonb, 26),
('Dynamic Method Dispatch', 'Show how runtime method dispatch works using multiple child classes.', 'MEDIUM', 'LLM',
 '{"hint1": "Call overridden methods via parent reference.", "hint2": "Add multiple derived classes.", "hint3": "Compare outputs."}'::jsonb, 26),
('Super Constructor Invocation', 'Call parent constructor using super().', 'HARD', 'SME',
 '{"hint1": "Pass parameters to super().", "hint2": "Observe constructor execution order.", "hint3": "Add print statements."}'::jsonb, 26),
('Method Override with Exception', 'Demonstrate overriding method with compatible exception signature.', 'HARD', 'LLM',
 '{"hint1": "Throw narrower exception type in override.", "hint2": "Handle properly in main.", "hint3": "Explain compile-time rules."}'::jsonb, 26),

-- =========================================================
-- 🧩 topic_id = 27: Polymorphism and Dynamic Binding
-- =========================================================
('Runtime Polymorphism Demo', 'Demonstrate runtime polymorphism using base and derived class.', 'EASY', 'SME',
 '{"hint1": "Create reference of base holding derived object.", "hint2": "Call overridden method.", "hint3": "Observe behavior at runtime."}'::jsonb, 27),
('Compile Time vs Runtime Polymorphism', 'Show difference between method overloading and overriding.', 'EASY', 'LLM',
 '{"hint1": "Use same method name with diff params.", "hint2": "Override in subclass.", "hint3": "Compare call results."}'::jsonb, 27),
('Polymorphic Array Example', 'Create array of base class objects holding derived objects.', 'MEDIUM', 'SME',
 '{"hint1": "Use array of type Base[].", "hint2": "Assign derived objects.", "hint3": "Iterate and call methods."}'::jsonb, 27),
('Dynamic Binding Example', 'Use polymorphism to execute correct method at runtime.', 'MEDIUM', 'LLM',
 '{"hint1": "Call method using parent reference.", "hint2": "Print which version runs.", "hint3": "Demonstrate late binding."}'::jsonb, 27),
('Abstract Class Polymorphism', 'Use abstract class reference to call implemented methods.', 'HARD', 'SME',
 '{"hint1": "Define abstract base with abstract method.", "hint2": "Extend and implement method.", "hint3": "Call via base reference."}'::jsonb, 27),
('Interface Polymorphism', 'Implement multiple interfaces and show polymorphic behavior.', 'HARD', 'LLM',
 '{"hint1": "Use interface references.", "hint2": "Override all methods.", "hint3": "Call using both interface references."}'::jsonb, 27),

-- =========================================================
-- 🧩 topic_id = 28: Abstract Classes and Interfaces
-- =========================================================
('Abstract Method Example', 'Create an abstract class with one abstract method and implement it.', 'EASY', 'SME',
 '{"hint1": "Use abstract keyword.", "hint2": "Implement in subclass.", "hint3": "Create object of subclass only."}'::jsonb, 28),
('Interface Implementation', 'Implement an interface with multiple methods.', 'EASY', 'LLM',
 '{"hint1": "Use implements keyword.", "hint2": "Provide body for each method.", "hint3": "Call using interface reference."}'::jsonb, 28),
('Abstract Class Constructor', 'Show that abstract class can have constructors.', 'MEDIUM', 'SME',
 '{"hint1": "Add constructor in abstract class.", "hint2": "Call via subclass constructor.", "hint3": "Print message to confirm."}'::jsonb, 28),
('Multiple Interface Implementation', 'Implement multiple interfaces in one class.', 'MEDIUM', 'LLM',
 '{"hint1": "Use comma separated interfaces.", "hint2": "Implement all abstract methods.", "hint3": "Demonstrate multiple inheritance of type."}'::jsonb, 28),
('Template Method Pattern', 'Use abstract class to implement template method pattern.', 'HARD', 'SME',
 '{"hint1": "Define skeleton in base class.", "hint2": "Override steps in subclass.", "hint3": "Call template method from main."}'::jsonb, 28),
('Interface Default Methods', 'Use default and static methods in interface (Java 8+).', 'HARD', 'LLM',
 '{"hint1": "Define default method in interface.", "hint2": "Override optionally.", "hint3": "Call static method using interface name."}'::jsonb, 28);
