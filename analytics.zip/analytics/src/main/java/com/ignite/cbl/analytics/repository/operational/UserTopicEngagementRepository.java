package com.ignite.cbl.analytics.repository.operational;

import com.ignite.cbl.analytics.entity.operational.UserTopicEngagement;
import com.ignite.cbl.analytics.entity.operational.UserTopicEngagementId;
import com.ignite.cbl.analytics.model.TopicEngagementStats;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface UserTopicEngagementRepository extends JpaRepository<UserTopicEngagement, UserTopicEngagementId> {
    @Query("SELECT new com.ignite.cbl.analytics.model.TopicEngagementStats(AVG(ute.totalSecondsSpent), COUNT(ute.userId)) FROM UserTopicEngagement ute WHERE ute.topicId = :topicId")
    Optional<TopicEngagementStats> getEngagementStatsByTopicId(Integer topicId);
}