package com.ignite.cbl.analytics.service;

import com.ignite.cbl.analytics.entity.analytics.TopicPerformanceReport;
import com.ignite.cbl.analytics.model.TopicDurationInput;
import com.ignite.cbl.analytics.processor.TopicReportProcessor;
import com.ignite.cbl.analytics.repository.analytics.TopicPerformanceReportRepository;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Service
public class SyncReportService {

    @Autowired
    private TopicReportProcessor processor;

    @Autowired
    private TopicPerformanceReportRepository reportRepository;

    public List<TopicPerformanceReport> processReportFileSync(MultipartFile file) throws Exception {
        List<TopicDurationInput> inputs = parseExcel(file.getInputStream());
        List<TopicPerformanceReport> reports = new ArrayList<>();

        for (TopicDurationInput input : inputs) {
            TopicPerformanceReport report = processor.process(input);
            if (report != null) {
                reports.add(report);
            }
        }

        if (!reports.isEmpty()) {
            reportRepository.saveAll(reports);
        }

        return reports;
    }

    private List<TopicDurationInput> parseExcel(InputStream inputStream) throws IOException {
        List<TopicDurationInput> inputs = new ArrayList<>();
        Workbook workbook = new XSSFWorkbook(inputStream);
        Sheet sheet = workbook.getSheetAt(0);
        Iterator<Row> rows = sheet.iterator();

        // Skip header row
        if (rows.hasNext()) {
            rows.next();
        }

        while (rows.hasNext()) {
            Row currentRow = rows.next();
            TopicDurationInput input = new TopicDurationInput();
            input.setCourseName(currentRow.getCell(0).getStringCellValue());
            input.setTopicName(currentRow.getCell(1).getStringCellValue());
            input.setExpectedDurationHours(currentRow.getCell(2).getNumericCellValue());
            inputs.add(input);
        }

        workbook.close();
        return inputs;
    }
}
