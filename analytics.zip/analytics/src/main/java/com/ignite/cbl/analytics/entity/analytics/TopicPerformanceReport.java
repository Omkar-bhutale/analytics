package com.ignite.cbl.analytics.entity.analytics;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.time.OffsetDateTime;

@Entity
//@Table(name = "topic_performance_reports", schema = "analytics")
@Getter
@Table(name = "topic_performance_reports")
@Setter
public class TopicPerformanceReport {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "report_id")
    private Integer reportId;

    @Column(name = "course_title", nullable = false)
    private String courseTitle;

    @Column(name = "topic_title", nullable = false)
    private String topicTitle;

    @Column(name = "expected_duration_seconds", nullable = false)
    private int expectedDurationSeconds;

    @Column(name = "average_actual_duration_seconds", nullable = false)
    private int averageActualDurationSeconds;

    @Column(name = "variance_seconds", nullable = false)
    private int varianceSeconds;

    @Column(name = "user_count", nullable = false)
    private int userCount;

    @Column(name = "processed_at", nullable = false)
    private OffsetDateTime processedAt;

    @PrePersist
    protected void onPrePersist() {
        processedAt = OffsetDateTime.now();
    }
}