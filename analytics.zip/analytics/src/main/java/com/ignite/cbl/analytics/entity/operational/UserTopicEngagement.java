package com.ignite.cbl.analytics.entity.operational;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
//@Table(name = "user_topic_engagement", schema = "public")
@Table(name = "user_topic_engagement")
@Getter
@Setter
@IdClass(UserTopicEngagementId.class)
public class UserTopicEngagement {
    @Id
    @Column(name = "user_id")
    private String userId;

    @Id
    @Column(name = "topic_id")
    private Integer topicId;

    @Column(name = "total_time_spent")
    private int totalSecondsSpent;
}