package com.ignite.cbl.analytics.config;

import com.ignite.cbl.analytics.entity.analytics.TopicPerformanceReport;
import com.ignite.cbl.analytics.model.TopicDurationInput;
import com.ignite.cbl.analytics.processor.TopicReportProcessor;
import com.ignite.cbl.analytics.repository.analytics.TopicPerformanceReportRepository;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.TaskExecutorJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.data.RepositoryItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
public class BatchJobConfig {

    @Bean
    @StepScope
    public FlatFileItemReader<TopicDurationInput> itemReader(@Value("#{jobParameters['fullPathFileName']}") String pathToFile) {
        return new FlatFileItemReaderBuilder<TopicDurationInput>()
               .name("csvReader")
               .resource(new FileSystemResource(pathToFile))
               .delimited()
               .names("CourseName", "TopicName", "ExpectedDurationHours")
               .targetType(TopicDurationInput.class)
               .linesToSkip(1) // Skip header row
               .build();
    }

    @Bean
    public ItemProcessor<TopicDurationInput, TopicPerformanceReport> itemProcessor() {
        return new TopicReportProcessor();
    }

    @Bean
    public ItemWriter<TopicPerformanceReport> itemWriter(TopicPerformanceReportRepository repository) {
        RepositoryItemWriter<TopicPerformanceReport> writer = new RepositoryItemWriter<>();
        writer.setRepository(repository);
        writer.setMethodName("save");
        return writer;
    }

    @Bean
    public Step reportGenerationStep(JobRepository jobRepository, PlatformTransactionManager transactionManager,
                                     ItemReader<TopicDurationInput> reader, ItemProcessor<TopicDurationInput, TopicPerformanceReport> processor,
                                     ItemWriter<TopicPerformanceReport> writer) {
        return new StepBuilder("etl-step", jobRepository)
               .<TopicDurationInput, TopicPerformanceReport>chunk(10, transactionManager)
               .reader(reader)
               .processor(processor)
               .writer(writer)
               .build();
    }

    @Bean(name = "reportGenerationJob")
    public Job reportGenerationJob(JobRepository jobRepository, Step reportGenerationStep) {
        return new JobBuilder("report-generation-job", jobRepository)
               .start(reportGenerationStep)
               .build();
    }

    @Bean(name = "asyncJobLauncher")
    public JobLauncher asyncJobLauncher(JobRepository jobRepository) throws Exception {
        TaskExecutorJobLauncher jobLauncher = new TaskExecutorJobLauncher();
        jobLauncher.setJobRepository(jobRepository);
        jobLauncher.setTaskExecutor(new SimpleAsyncTaskExecutor());
        jobLauncher.afterPropertiesSet();
        return jobLauncher;
    }
}