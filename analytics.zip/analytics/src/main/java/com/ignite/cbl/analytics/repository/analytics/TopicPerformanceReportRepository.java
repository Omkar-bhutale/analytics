package com.ignite.cbl.analytics.repository.analytics;

import com.ignite.cbl.analytics.entity.analytics.TopicPerformanceReport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TopicPerformanceReportRepository extends JpaRepository<TopicPerformanceReport, Integer> {}