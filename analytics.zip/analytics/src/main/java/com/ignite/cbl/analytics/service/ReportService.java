package com.ignite.cbl.analytics.service;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

@Service
public class ReportService {

    private final Path fileStorageLocation;
    private final JobLauncher asyncJobLauncher;
    private final Job reportGenerationJob;

    @Autowired
    public ReportService(@Qualifier("asyncJobLauncher") JobLauncher asyncJobLauncher,
                         @Qualifier("reportGenerationJob") Job reportGenerationJob) {
        this.fileStorageLocation = Paths.get("./temp-uploads").toAbsolutePath().normalize();
        this.asyncJobLauncher = asyncJobLauncher;
        this.reportGenerationJob = reportGenerationJob;

        try {
            Files.createDirectories(this.fileStorageLocation);
        } catch (Exception ex) {
            throw new RuntimeException("Could not create the directory where the uploaded files will be stored.", ex);
        }
    }

    public void processReportFile(MultipartFile file) throws IOException, JobParametersInvalidException, JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException {
        String originalFileName = file.getOriginalFilename();
        Path targetLocation = this.fileStorageLocation.resolve(originalFileName);
        Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);

        JobParameters jobParameters = new JobParametersBuilder()
               .addString("fullPathFileName", targetLocation.toAbsolutePath().toString())
               .addLong("startAt", System.currentTimeMillis()) // Ensures each job instance is unique
               .toJobParameters();

        asyncJobLauncher.run(reportGenerationJob, jobParameters);
    }
}