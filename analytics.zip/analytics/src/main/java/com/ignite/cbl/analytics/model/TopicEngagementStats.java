package com.ignite.cbl.analytics.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TopicEngagementStats {
    private Double averageDuration;
    private long userCount;

    public TopicEngagementStats(Double averageDuration, long userCount) {
        this.averageDuration = averageDuration;
        this.userCount = userCount;
    }
}