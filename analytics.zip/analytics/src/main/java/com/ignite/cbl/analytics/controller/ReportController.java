package com.ignite.cbl.analytics.controller;

import com.ignite.cbl.analytics.entity.analytics.TopicPerformanceReport;
import com.ignite.cbl.analytics.service.ReportService;
import com.ignite.cbl.analytics.service.SyncReportService;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/reports")
public class ReportController {

    private final ReportService reportService;
    private final SyncReportService syncReportService;

    @Autowired
    public ReportController(ReportService reportService, SyncReportService syncReportService) {
        this.reportService = reportService;
        this.syncReportService = syncReportService;
    }

    @PostMapping("/upload")
    public ResponseEntity<String> uploadAndTriggerReport(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return ResponseEntity.badRequest().body("Please upload a file.");
        }

        try {
            reportService.processReportFile(file);
            return ResponseEntity.ok("File uploaded successfully. Report generation has been triggered asynchronously.");
        } catch (IOException e) {
            return ResponseEntity.status(500).body("Failed to store file: " + e.getMessage());
        } catch (JobParametersInvalidException | JobExecutionAlreadyRunningException | JobRestartException |
                 JobInstanceAlreadyCompleteException e) {
            return ResponseEntity.status(500).body("Failed to start the batch job: " + e.getMessage());
        }
    }

    @PostMapping("/upload-sync")
    public ResponseEntity<?> uploadAndProcessReportSync(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return ResponseEntity.badRequest().body("Please upload a file.");
        }

        try {
            List<TopicPerformanceReport> reports = syncReportService.processReportFileSync(file);
            return ResponseEntity.ok(reports);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Failed to process file: " + e.getMessage());
        }
    }
}