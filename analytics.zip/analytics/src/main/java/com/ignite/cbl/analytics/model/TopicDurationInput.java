package com.ignite.cbl.analytics.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TopicDurationInput {
    private String courseName;
    private String topicName;
    private double expectedDurationHours;
}