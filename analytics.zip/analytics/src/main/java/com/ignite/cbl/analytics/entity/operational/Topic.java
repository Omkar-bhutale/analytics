package com.ignite.cbl.analytics.entity.operational;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
//@Table(name = "topics", schema = "public")
@Table(name = "topics")
@Getter
@Setter
public class Topic {
    @Id
    @Column(name = "topic_id")
    private Integer topicId;

    @Column(name = "title")
    private String title;
}