package com.ignite.cbl.analytics.processor;

import com.ignite.cbl.analytics.entity.analytics.TopicPerformanceReport;
import com.ignite.cbl.analytics.entity.operational.Topic;
import com.ignite.cbl.analytics.model.TopicDurationInput;
import com.ignite.cbl.analytics.model.TopicEngagementStats;
import com.ignite.cbl.analytics.repository.operational.TopicRepository;
import com.ignite.cbl.analytics.repository.operational.UserTopicEngagementRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Optional;

public class TopicReportProcessor implements ItemProcessor<TopicDurationInput, TopicPerformanceReport> {
    Logger logger = LoggerFactory.getLogger(TopicReportProcessor.class);

    @Autowired
    private TopicRepository topicRepository;

    @Autowired
    private UserTopicEngagementRepository engagementRepository;

    @Override
    public TopicPerformanceReport process(TopicDurationInput item) throws Exception {
        Optional<Topic> topicOpt = topicRepository.findByTitle(item.getTopicName());
        if (topicOpt.isEmpty()) {
            logger.info("Skipping item. Topic not found in DB: " + item.getTopicName());
            return null;
        }
        Topic topic = topicOpt.get();

        Optional<TopicEngagementStats> statsOpt = engagementRepository.getEngagementStatsByTopicId(topic.getTopicId());
        if (statsOpt.isEmpty() || statsOpt.get().getUserCount() == 0 || statsOpt.get().getAverageDuration() == null) {
            logger.info("Skipping item. No engagement data for topic: " + item.getTopicName());
            return null;
        }
        TopicEngagementStats stats = statsOpt.get();

        TopicPerformanceReport report = new TopicPerformanceReport();
        report.setCourseTitle(item.getCourseName());
        report.setTopicTitle(item.getTopicName());

        int expectedSeconds = (int) (item.getExpectedDurationHours() * 3600);
        int actualSeconds = stats.getAverageDuration().intValue();

        report.setExpectedDurationSeconds(expectedSeconds);
        report.setAverageActualDurationSeconds(actualSeconds);
        report.setVarianceSeconds(actualSeconds - expectedSeconds);
        report.setUserCount((int) stats.getUserCount());

        return report;
    }
}