package com.ignite.cbl.analytics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnalyticsApplicationTests {

    @Test
    void contextLoads() {
    }

}
