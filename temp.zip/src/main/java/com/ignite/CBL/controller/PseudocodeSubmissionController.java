package com.ignite.CBL.controller;

import com.ignite.CBL.dto.PseudoCodeRequestDTO;
import com.ignite.CBL.dto.PseudocodeResponceDTO;
import com.ignite.CBL.service.PseudocodeSubmissionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user/pseudocode-submissions")
@RequiredArgsConstructor
@Tag(name = "Pseudocode Submission", description = "Pseudocode submission management APIs")
public class PseudocodeSubmissionController {

    private final PseudocodeSubmissionService pseudocodeSubmissionService;

    @Value("${user.id}")
    private String userId;

    @PostMapping
    @Operation(summary = "Create or update pseudocode submission", 
               description = "Save or update a pseudocode submission for a problem. Requires a correct algorithm submission to exist first.")
    public ResponseEntity<PseudocodeResponceDTO> saveOrUpdatePseudocode(
            @Valid @RequestBody PseudoCodeRequestDTO pseudoCodeRequestDTO) {
        PseudocodeResponceDTO response = pseudocodeSubmissionService.saveOrUpdatePseudocode(pseudoCodeRequestDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/problem/{problemId}")
    @Operation(summary = "Get pseudocode by problem ID", description = "Retrieve pseudocode submission for a specific problem")
    public ResponseEntity<PseudocodeResponceDTO> getPseudocodeByProblemId(
            @PathVariable Integer problemId) {
        PseudocodeResponceDTO response = pseudocodeSubmissionService.getPseudocodeByProblemId(problemId);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/problem/{problemId}/exists")
    @Operation(summary = "Check if pseudocode exists", description = "Check if a pseudocode submission exists for a problem and user")
    public ResponseEntity<Boolean> existsByProblemId(
            @PathVariable Integer problemId) {
        Boolean exists = pseudocodeSubmissionService.existByProblemId(problemId);
        return ResponseEntity.ok(exists);
    }

    @GetMapping("/problem/{problemId}/is-correct")
    @Operation(summary = "Check if pseudocode is correct", description = "Check if the pseudocode submission is marked as correct")
    public ResponseEntity<Boolean> isPseudocodeCorrect(
            @PathVariable Integer problemId) {
        Boolean isCorrect = pseudocodeSubmissionService.isPseudocodeCorrect(problemId);
        return ResponseEntity.ok(isCorrect);
    }
}
