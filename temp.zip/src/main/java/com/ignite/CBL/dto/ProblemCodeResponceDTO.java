package com.ignite.CBL.dto;

import com.ignite.CBL.entity.SavedCodes;
import lombok.Data;

@Data
public class ProblemCodeResponceDTO {
    private ProblemDTO problemDTO;
    private SavedCodes savedCodes;//this is for if the code already exist in problem submission for particular  language
    private Integer totalSecondsSpent;
}
