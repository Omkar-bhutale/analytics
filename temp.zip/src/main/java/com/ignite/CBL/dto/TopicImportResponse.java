package com.ignite.CBL.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TopicImportResponse {
    private int totalProcessed;
    private int mainTopicsCreated;
    private int topicsCreated;
    private List<MainTopicWithTopicsDTO> mainTopics;
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MainTopicWithTopicsDTO {
        private Integer mainTopicId;
        private String mainTopicTitle;
        private List<TopicDTO> topics;
    }
}
