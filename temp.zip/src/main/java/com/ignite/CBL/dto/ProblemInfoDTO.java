package com.ignite.CBL.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

// ProblemDTO.java
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProblemInfoDTO {
    private Long id;
    private String title;
}