package com.ignite.CBL.dto;

import lombok.Data;
import lombok.ToString;

import java.util.List;

@Data
@ToString
public class MainTopicSubTopicsResponceDTO {
    private Integer mainTopicId;
    private String mainTopicName;
    private String mainTopicDescription;
    private List<TopicDTO> subTopics;
}
