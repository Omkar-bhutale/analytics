package com.ignite.CBL.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

// MainTopicWithSubtopicsDTO.java
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MainTopicWithTopicsDTO {
    private Long mainTopicId;
    private String mainTopicName;
    private List<TopicWithProblemsInfoDTO> subtopics;
}


