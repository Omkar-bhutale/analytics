package com.ignite.CBL.service;

import com.ignite.CBL.dto.*;
import com.ignite.CBL.entity.Difficulty;
import com.ignite.CBL.entity.ProblemSubmission;

import java.util.List;
import java.util.Optional;

public interface ProblemSubmissionService {

    public ProblemCodeResponceDTO getProblemToSolve(Integer problemId);
    public void saveCodeAndTime(SaveCodeAndTimeRequest SaveCodeAndTimeRequest);
    public boolean saveSubmission(ProblemSubmissionRequestDTO problemSubmissionRequestDTO);

    ProblemCodeResponceDTO getRandomProblem(Integer topicId, Difficulty difficulty);

    public List<ProblemSubmissionResponceDTO> getAllSubmissions(Integer problemId);
    
    List<MainTopicSubTopicsResponceDTO> getAllProblems();
}
