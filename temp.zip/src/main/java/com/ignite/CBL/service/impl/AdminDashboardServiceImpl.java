package com.ignite.CBL.service.impl;

import com.ignite.CBL.repository.AdminDashboardRepository;
import com.ignite.CBL.repository.ProblemRepository;
import com.ignite.CBL.repository.ProblemSubmissionRepository;
import com.ignite.CBL.repository.UserRepository;
import com.ignite.CBL.service.AdminDashboardService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AdminDashboardServiceImpl implements AdminDashboardService {

    private final AdminDashboardRepository adminDashboardRepository;
    private final UserRepository userRepository;
    private final ProblemRepository problemRepository;
    private final ProblemSubmissionRepository problemSubmissionRepository;

    @Override
    public long countTotalSolvedInJava() {
        return adminDashboardRepository.countProblemsSolvedByLanguage("JAVA");
    }

    @Override
    public long countTotalSolvedPython() {
        return adminDashboardRepository.countProblemsSolvedByLanguage("PYTHON");
    }

    @Override
    public long countTotalSolvedJavaScript() {
        return adminDashboardRepository.countProblemsSolvedByLanguage("JAVASCRIPT");
    }

    @Override
    public long countTotalSolvedTypeScript() {
        return adminDashboardRepository.countProblemsSolvedByLanguage("TYPESCRIPT");
    }
    @Override
    public long countTotalUsers() {
        return userRepository.count();
    }

    @Override
    public long countTotalProblems() {
        return problemRepository.count();
    }

    @Override
    public long countTotalSubmissions() {
        return problemSubmissionRepository.count();
    }

}