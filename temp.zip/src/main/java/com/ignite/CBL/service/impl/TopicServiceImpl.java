package com.ignite.CBL.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ignite.CBL.dto.MainTopicSubTopicsResponceDTO;
import com.ignite.CBL.dto.TopicDTO;
import com.ignite.CBL.dto.TopicImportResponse;
import com.ignite.CBL.entity.MainTopic;
import com.ignite.CBL.entity.Topic;
import com.ignite.CBL.entity.User;
import com.ignite.CBL.exception.ResourceNotFoundException;
import com.ignite.CBL.repository.MainTopicRepository;
import com.ignite.CBL.repository.TopicRepository;
import com.ignite.CBL.repository.UserRepository;
import com.ignite.CBL.service.TopicService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;

@Slf4j
@Service
@RequiredArgsConstructor
public class TopicServiceImpl implements TopicService {
    @Value("${user.id}")
    private String userId;

    private final TopicRepository topicRepository;
    private final MainTopicRepository mainTopicRepository;
    private final ModelMapper modelMapper;
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final UserRepository userRepository;
    @Override
    public Optional<TopicDTO> findTopicById(Integer topicId) {
        log.debug("Finding topic by id: {}", topicId);
        return topicRepository.findTopicDTOById(topicId);
    }

    @Override
    public Optional<TopicDTO> findTopicByTitle(String title) {
        log.debug("Finding topic by title: {}", title);
        return topicRepository.findTopicDTOByTitle(title);
    }

    @Override
    public List<MainTopicSubTopicsResponceDTO> findAllMainTopicSubTopics() {
        log.debug("Fetching all main topics with their subtopics");

        // Fetch all main topics
        List<MainTopic> mainTopics = mainTopicRepository.findAll();

        return mainTopics.stream().map(mainTopic -> {
            MainTopicSubTopicsResponceDTO dto = new MainTopicSubTopicsResponceDTO();
            dto.setMainTopicId(mainTopic.getMainTopicId());
            dto.setMainTopicName(mainTopic.getTitle());
            dto.setMainTopicDescription(mainTopic.getDescription());

            // Map topics to TopicDTOs
            // Map topics to TopicDTOs and sort by topicId
            if (mainTopic.getTopics() != null && !mainTopic.getTopics().isEmpty()) {
                List<TopicDTO> topicDTOs = mainTopic.getTopics().stream()
                        .sorted(Comparator.comparing(Topic::getTopicId))  // Sort subtopics by ID
                        .map(topic -> {
                            TopicDTO topicDTO = new TopicDTO();
                            topicDTO.setTopicId(topic.getTopicId());
                            topicDTO.setTitle(topic.getTitle());
                            topicDTO.setContent(topic.getContent());
                            return topicDTO;
                        })
                        .collect(Collectors.toList());
                dto.setSubTopics(topicDTOs);
            } else {
                dto.setSubTopics(Collections.emptyList());
            }

            return dto;
        }).collect(Collectors.toList());
    }


    @Override
    public List<TopicDTO> findAllByMainTopicId(Integer mainTopicId) {
        log.debug("Finding all topics for main topic id: {}", mainTopicId);
        if (!mainTopicRepository.existsById(mainTopicId)) {
            throw new ResourceNotFoundException("MainTopic not found with id: " + mainTopicId);
        }
        return topicRepository.findAllByMainTopicId(mainTopicId);
    }

    @Override
    public List<TopicDTO> findPaginatedByMainTopicId(Integer mainTopicId) {
        log.debug("Finding paginated topics for main topic id: {}", mainTopicId);
        if (!mainTopicRepository.existsById(mainTopicId)) {
            throw new ResourceNotFoundException("MainTopic not found with id: " + mainTopicId);
        }
        return topicRepository.findByMainTopicId(mainTopicId);
    }

    @Override
    @Transactional
    public TopicDTO createTopic(Integer mainTopicId, TopicDTO topicDTO) {
        log.debug("Creating new topic for main topic id: {}", mainTopicId);
        MainTopic mainTopic = mainTopicRepository.findById(mainTopicId)
                .orElseThrow(() -> new ResourceNotFoundException("MainTopic not found with id: " + mainTopicId));

        if (topicRepository.existsByTitle(topicDTO.getTitle())) {
            throw new IllegalArgumentException("Topic with title '" + topicDTO.getTitle() + "' already exists");
        }

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));

        Topic topic = Topic.builder()
                .title(topicDTO.getTitle())
                .createdBy(user)
                .content(topicDTO.getContent())
                .mainTopic(mainTopic)
                .createdAt(LocalDateTime.now())
                .build();

        Topic savedTopic = topicRepository.save(topic);
        log.info("Created new topic with id: {}", savedTopic.getTopicId());
        return convertToDTO(savedTopic);
    }

    @Override
    @Transactional
    public int createTopics(Integer mainTopicId, List<TopicDTO> topicDTOs) {
        log.debug("Creating {} topics for main topic id: {}", topicDTOs.size(), mainTopicId);
        MainTopic mainTopic = mainTopicRepository.findById(mainTopicId)
                .orElseThrow(() -> new ResourceNotFoundException("MainTopic not found with id: " + mainTopicId));

        if (topicDTOs == null || topicDTOs.isEmpty()) {
            return 0;
        }
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));
        List<Topic> topics = topicDTOs.stream()
                .filter(dto -> !topicRepository.existsByTitle(dto.getTitle()))
                .map(dto -> Topic.builder()
                        .title(dto.getTitle())
                        .content(dto.getContent())
                        .createdBy(user)
                        .mainTopic(mainTopic)
                        .createdAt(LocalDateTime.now())
                        .build())
                .collect(Collectors.toList());

        if (!topics.isEmpty()) {
            topicRepository.saveAll(topics);
            log.info("Created {} new topics for main topic id: {}", topics.size(), mainTopicId);
        }

        return topics.size();
    }

    @Override
    @Transactional
    public Optional<TopicDTO> updateTopic(Integer topicId, TopicDTO topicDTO) {
        log.debug("Updating topic with id: {}", topicId);
        return topicRepository.findById(topicId)
                .map(existingTopic -> {
                    if (topicDTO.getTitle() != null && !topicDTO.getTitle().equals(existingTopic.getTitle())) {
                        if (topicRepository.existsByTitle(topicDTO.getTitle())) {
                            throw new IllegalArgumentException("Topic with title '" + topicDTO.getTitle() + "' already exists");
                        }
                        existingTopic.setTitle(topicDTO.getTitle());
                    }
                    
                    if (topicDTO.getContent() != null) {
                        existingTopic.setContent(topicDTO.getContent());
                    }
                    
                    Topic updatedTopic = topicRepository.save(existingTopic);
                    log.info("Updated topic with id: {}", topicId);
                    return convertToDTO(updatedTopic);
                });
    }

    @Override
    @Transactional
    public boolean deleteTopicById(Integer topicId) {
        log.debug("Deleting topic with id: {}", topicId);
        if (!topicRepository.existsById(topicId)) {
            return false;
        }
        topicRepository.deleteById(topicId);
        log.info("Deleted topic with id: {}", topicId);
        return true;
    }

    @Override
    @Transactional
    public int deleteAllByMainTopicId(Integer mainTopicId) {
        log.debug("Deleting all topics for main topic id: {}", mainTopicId);
        if (!mainTopicRepository.existsById(mainTopicId)) {
            log.error("MainTopic not found with id: {}", mainTopicId);
            throw new ResourceNotFoundException("MainTopic not found with id: " + mainTopicId);
        }
        return topicRepository.deleteByMainTopicId(mainTopicId);
    }

    @Override
    @Transactional
    public void deleteAll() {
        log.debug("Deleting all topics");
        topicRepository.deleteAll();
        log.info("Deleted all topics");
    }

    @Override
    public boolean existsByTitle(String title) {
        return topicRepository.existsByTitle(title);
    }
    
    @Override
    @Transactional
    public TopicImportResponse importFromExcel(MultipartFile file, String userId) {
        log.info("Starting import of topics from Excel file: {}", file.getOriginalFilename());
        
        if (file.isEmpty()) {
            throw new IllegalArgumentException("File is empty");
        }
        
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));
                
        Map<String, MainTopic> mainTopicCache = new HashMap<>();
        List<TopicImportResponse.MainTopicWithTopicsDTO> result = new ArrayList<>();
        int totalProcessed = 0;
        AtomicInteger mainTopicsCreated = new AtomicInteger();
        int topicsCreated = 0;
        
        try (Workbook workbook = new XSSFWorkbook(file.getInputStream())) {
            Sheet sheet = workbook.getSheetAt(0); // Get first sheet
            Iterator<Row> rowIterator = sheet.iterator();
            // Skip header row
            if (rowIterator.hasNext()) {
                rowIterator.next();
            }
            
            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
                totalProcessed++;
                
                String mainTopicTitle = getCellValueAsString(row.getCell(0));
                String topicTitle = getCellValueAsString(row.getCell(1));
                
                if (mainTopicTitle == null || mainTopicTitle.trim().isEmpty()) {
                    log.warn("Skipping row {}: Main topic title is empty", row.getRowNum() + 1);
                    continue;
                }
                
                if (topicTitle == null || topicTitle.trim().isEmpty()) {
                    log.warn("Skipping row {}: Topic title is empty", row.getRowNum() + 1);
                    continue;
                }
                
                // Process MainTopic
                MainTopic mainTopic = mainTopicCache.computeIfAbsent(mainTopicTitle, title -> {
                    Optional<MainTopic> existing = mainTopicRepository.findByTitle(title);
                    if (existing.isPresent()) {
                        return existing.get();
                    } else {
                        MainTopic newMainTopic = new MainTopic();
                        newMainTopic.setTitle(title);
                        newMainTopic.setCreatedBy(user);
                        newMainTopic.setCreatedAt(LocalDateTime.now());
                        MainTopic saved = mainTopicRepository.save(newMainTopic);
                        mainTopicsCreated.incrementAndGet();
                        log.info("Created new MainTopic: {} with id: {}", title, saved.getMainTopicId());
                        return saved;
                    }
                });
                
                // Process Topic
                if (!topicRepository.existsByTitleAndMainTopicId(topicTitle, mainTopic.getMainTopicId())) {
                    Topic newTopic = new Topic();
                    newTopic.setTitle(topicTitle);
                    newTopic.setMainTopic(mainTopic);
                    newTopic.setCreatedBy(user);
                    newTopic.setCreatedAt(LocalDateTime.now());
                    // Set default empty content
                    newTopic.setContent(objectMapper.createObjectNode());
                    
                    Topic savedTopic = topicRepository.save(newTopic);
                    topicsCreated++;
                    log.info("Created new Topic: {} with id: {}", topicTitle, savedTopic.getTopicId());
                }
            }
            
            // Build response
            for (Map.Entry<String, MainTopic> entry : mainTopicCache.entrySet()) {
                MainTopic mt = entry.getValue();
                List<TopicDTO> topicDTOs = topicRepository.findAllByMainTopicId(mt.getMainTopicId());
//                List<TopicDTO> topicDTOs = topics.stream()
//                        .map(topic -> convertToDTO(topic))
//                        .collect(Collectors.toList());
                        
                result.add(TopicImportResponse.MainTopicWithTopicsDTO.builder()
                        .mainTopicId(mt.getMainTopicId())
                        .mainTopicTitle(mt.getTitle())
                        .topics(topicDTOs)
                        .build());
            }
            
            log.info("Successfully imported {} rows from Excel. Created {} main topics and {} topics", 
                    totalProcessed, mainTopicsCreated, topicsCreated);
                    
            return TopicImportResponse.builder()
                    .totalProcessed(totalProcessed)
                    .mainTopicsCreated(mainTopicsCreated.get())
                    .topicsCreated(topicsCreated)
                    .mainTopics(result)
                    .build();
                    
        } catch (IOException e) {
            log.error("Error processing Excel file: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to process Excel file: " + e.getMessage(), e);
        }
    }
    
    private String getCellValueAsString(Cell cell) {
        if (cell == null) {
            return null;
        }
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue().trim();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getLocalDateTimeCellValue().toString();
                } else {
                    // Convert numeric to string without decimal if it's an integer
                    double value = cell.getNumericCellValue();
                    if (value == (long) value) {
                        return String.format("%d", (long) value);
                    } else {
                        return String.format("%s", value);
                    }
                }
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case FORMULA:
                return cell.getCellFormula();
            default:
                return "";
        }
    }

    private TopicDTO convertToDTO(Topic topic) {
        return modelMapper.map(topic, TopicDTO.class);
    }
}
