package com.ignite.CBL.service;

public interface AdminDashboardService {
    long countTotalSolvedInJava();
    long  countTotalSolvedPython();
    long countTotalSolvedJavaScript();
    long countTotalSolvedTypeScript();
    long countTotalUsers();
    long countTotalProblems();
    long countTotalSubmissions();
}
