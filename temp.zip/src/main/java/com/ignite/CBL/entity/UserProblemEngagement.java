package com.ignite.CBL.entity;


import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.sql.SQLType;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Table(name = "user_problem_engagement")
public class UserProblemEngagement {

    @EmbeddedId
    private UserProblemEngagementId id;

    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("userId")
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("problemId")
    @JoinColumn(name = "problem_id")
    @JsonBackReference("problem-engagements")
    private Problem problem;

    @Column(name = "total_seconds_spent", nullable = false)
    private int totalSecondsSpent = 0;
    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "saved_codes")
    private SavedCodes savedCodes;

    @Column(name = "is_solved",nullable = false)
    private Boolean isSolved = false;

    @Column(name = "total_attempts", nullable = false)
    @Version
    private Integer totalAttempts;

    @Column(name = "last_activity_at", nullable = false)
    private LocalDateTime lastActivityAt;

    @PrePersist
    public void prePersist() {
        this.lastActivityAt = LocalDateTime.now();
        this.totalAttempts = 0;
        this.totalSecondsSpent = 0;
        this.savedCodes = new SavedCodes();
    }

    @PreUpdate
    public void preUpdate() {
        this.lastActivityAt = LocalDateTime.now();
    }
}