package com.ignite.CBL.entity;

public enum Difficulty {
    EASY,
    MEDIUM,
    HARD
}
