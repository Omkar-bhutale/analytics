package com.ignite.CBL.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "problem_test_cases")
@Getter
@Setter
public class ProblemTestCase {
    @Id
    @Column(name = "test_case_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer testCaseId;


    @Column(name = "input", columnDefinition = "text")
    private String input;


    @Column(name = "expected_output", columnDefinition = "text")
    private String expectedOutput;

    @Column(name = "is_public", nullable = false)
    Boolean isPublic = true;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "problem_id", nullable = false)
    @JsonBackReference("problem-testcases")
    private Problem problem;



}
