package com.ignite.CBL.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.LocalDateTime;

@Entity
@Table(name = "problem_submissions",uniqueConstraints = {
        @UniqueConstraint(columnNames = {"problem_id", "user_id", "language"})
    })
@Getter
@Setter

public class ProblemSubmission {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "submission_id")
    private Integer submissionId;

    @Column(name = "language",nullable = false)
    @Enumerated(EnumType.STRING)
    private Language language;

    @Column(name = "code", nullable = false, columnDefinition = "text")
    private String code;

    @Column(name = "submitted_at",nullable = false)
    private LocalDateTime submittedAt;
    @PrePersist
    private void prePersist() {
        submittedAt = LocalDateTime.now();
    }
    @PreUpdate
    private void preUpdate() {
        submittedAt = LocalDateTime.now();
    }

    @Column(name = "version",nullable = false)
    @Version
    private Integer version;
    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "insights",columnDefinition = "jsonb")
    private JsonNode insights;

    @Column(name = "total_test_cases",columnDefinition = "integer default 0")
    private int totalTestCases;
    @Column(name = "passed_test_cases",columnDefinition = "integer default 0")
    private int passedTestCases;



    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "problem_id", nullable = false)
    @JsonBackReference("problem-submissions")
    private Problem problem;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id",nullable = false)
    private User user;

    @Column(name = "is_solved")
    private Boolean isSolved;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_problem_report_id",nullable = false)
    private UserProblemReport userProblemReport;



}
