package com.ignite.CBL.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "main_topics")
@Getter
@Setter
@JsonIdentityInfo(
    generator = ObjectIdGenerators.PropertyGenerator.class,
    property = "mainTopicId"
)
public class MainTopic {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "main_topic_id")
    private Integer mainTopicId;

    @Column(name = "title", nullable = false)
    private String title;

    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "creator_id", nullable = false)
    private User createdBy;

    @OneToMany(
        mappedBy = "mainTopic",
        cascade = CascadeType.ALL,
        orphanRemoval = true,
        fetch = FetchType.LAZY
    )
    @JsonManagedReference("main-topic-topics")
    private Set<Topic> topics = new HashSet<>();

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
        name = "course_main_topics",
        joinColumns = @JoinColumn(name = "main_topic_id"),
        inverseJoinColumns = @JoinColumn(name = "course_id")
    )
    @JsonBackReference("course-main-topics")
    private Set<Course> courses = new HashSet<>();

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    // Helper methods for bidirectional relationship management
    public void addTopic(Topic topic) {
        topics.add(topic);
        topic.setMainTopic(this);
    }

    public void removeTopic(Topic topic) {
        topics.remove(topic);
        topic.setMainTopic(null);
    }

    public void addCourse(Course course) {
        courses.add(course);
        course.getMainTopics().add(this);
    }

    public void removeCourse(Course course) {
        courses.remove(course);
        course.getMainTopics().remove(this);
    }
}
