-- Additional 8 Algorithm Submissions for User 5284917 (correct ones) with VALID problem IDs
INSERT INTO algorithm_submissions (algorithm_id, user_id, problem_id, content, is_correct, version, submitted_at) VALUES
                                                                                                                      (51, '5284917', 54, 'Algorithm for Text Formatter:
1. Start
2. Read text and format type
3. If format type = "uppercase": convert to uppercase
4. Else if format type = "trim": remove spaces
5. Else if format type = "title": capitalize words
6. Return formatted text
7. End', true, 1, CURRENT_TIMESTAMP - INTERVAL '14 days'),
                                                                                                                      (52, '5284917', 58, 'Algorithm for String Sorting:
1. Start
2. Read array of strings
3. Sort array alphabetically
4. Display sorted array
5. End', true, 1, CURRENT_TIMESTAMP - INTERVAL '12 days'),
                                                                                                                      (53, '5284917', 62, 'Algorithm for Array Element Access:
1. Start
2. Read array and index
3. If index is valid: return element at index
4. Else: return "Invalid index"
5. End', true, 1, CURRENT_TIMESTAMP - INTERVAL '10 days'),
                                                                                                                      (54, '5284917', 66, 'Algorithm for Element Search:
1. Start
2. Read array and target element
3. For each element in array:
   3.1 If element equals target: return index
4. If not found: return "Not found"
5. End', true, 1, CURRENT_TIMESTAMP - INTERVAL '8 days'),
                                                                                                                      (55, '5284917', 70, 'Algorithm for Matrix Operations:
1. Start
2. Read two matrices
3. Perform addition/subtraction based on operation
4. Return result matrix
5. End', true, 1, CURRENT_TIMESTAMP - INTERVAL '6 days'),
                                                                                                                      (56, '5284917', 74, 'Algorithm for Grade to GPA Converter:
1. Start
2. Read letter grade
3. Use switch case to map grade to GPA:
   3.1 A → 4.0, B → 3.0, C → 2.0, D → 1.0, F → 0.0
4. Return GPA value
5. End', true, 1, CURRENT_TIMESTAMP - INTERVAL '4 days'),
                                                                                                                      (57, '5284917', 78, 'Algorithm for Simple Calculator:
1. Start
2. Read num1, operator, num2
3. Based on operator:
   3.1 "+": result = num1 + num2
   3.2 "-": result = num1 - num2
   3.3 "*": result = num1 * num2
   3.4 "/": result = num1 / num2
4. Return result
5. End', true, 1, CURRENT_TIMESTAMP - INTERVAL '2 days'),
                                                                                                                      (58, '5284917', 82, 'Algorithm for Temperature Converter:
1. Start
2. Read temperature in Celsius
3. Apply formula: F = (C × 9/5) + 32
4. Return temperature in Fahrenheit
5. End', true, 1, CURRENT_TIMESTAMP - INTERVAL '1 day');

-- Additional 8 Pseudocode Submissions for User 5284917 with VALID problem IDs
INSERT INTO pseudocode_submissions (pseudocode_submission_id, user_id, problem_id, content, is_correct, version, submitted_at) VALUES
                                                                                                                                   (41, '5284917', 54, 'BEGIN
    READ text, format_type
    IF format_type = "uppercase" THEN
        RETURN UPPERCASE(text)
    ELSE IF format_type = "trim" THEN
        RETURN TRIM(text)
    ELSE IF format_type = "title" THEN
        RETURN TITLECASE(text)
    ELSE
        RETURN "Invalid format"
    END IF
END', true, 1, CURRENT_TIMESTAMP - INTERVAL '13 days'),
                                                                                                                                   (42, '5284917', 58, 'BEGIN
    READ string_array
    SET sorted_array = SORT(string_array)
    RETURN sorted_array
END', true, 1, CURRENT_TIMESTAMP - INTERVAL '11 days'),
                                                                                                                                   (43, '5284917', 62, 'BEGIN
    READ array, index
    IF index >= 0 AND index < LENGTH(array) THEN
        RETURN array[index]
    ELSE
        RETURN "Invalid index"
    END IF
END', true, 1, CURRENT_TIMESTAMP - INTERVAL '9 days'),
                                                                                                                                   (44, '5284917', 66, 'BEGIN
    READ array, target
    FOR i FROM 0 TO LENGTH(array)-1 DO
        IF array[i] = target THEN
            RETURN i
        END IF
    END FOR
    RETURN "Not found"
END', true, 1, CURRENT_TIMESTAMP - INTERVAL '7 days'),
                                                                                                                                   (45, '5284917', 70, 'BEGIN
    READ matrix1, matrix2, operation
    CREATE result_matrix
    FOR i FROM 0 TO ROWS-1 DO
        FOR j FROM 0 TO COLS-1 DO
            IF operation = "add" THEN
                result_matrix[i][j] = matrix1[i][j] + matrix2[i][j]
            ELSE IF operation = "subtract" THEN
                result_matrix[i][j] = matrix1[i][j] - matrix2[i][j]
            END IF
        END FOR
    END FOR
    RETURN result_matrix
END', true, 1, CURRENT_TIMESTAMP - INTERVAL '5 days'),
                                                                                                                                   (46, '5284917', 74, 'BEGIN
    READ grade
    SWITCH grade
        CASE "A": gpa = 4.0
        CASE "B": gpa = 3.0
        CASE "C": gpa = 2.0
        CASE "D": gpa = 1.0
        CASE "F": gpa = 0.0
        DEFAULT: gpa = "Invalid"
    END SWITCH
    RETURN gpa
END', true, 1, CURRENT_TIMESTAMP - INTERVAL '3 days'),
                                                                                                                                   (47, '5284917', 78, 'BEGIN
    READ num1, operator, num2
    SWITCH operator
        CASE "+": result = num1 + num2
        CASE "-": result = num1 - num2
        CASE "*": result = num1 * num2
        CASE "/": result = num1 / num2
        DEFAULT: result = "Invalid operator"
    END SWITCH
    RETURN result
END', true, 1, CURRENT_TIMESTAMP - INTERVAL '2 days'),
                                                                                                                                   (48, '5284917', 82, 'BEGIN
    READ celsius
    SET fahrenheit = (celsius * 9/5) + 32
    RETURN fahrenheit
END', true, 1, CURRENT_TIMESTAMP - INTERVAL '1 day');

-- Additional 8 Problem Submissions in Different Languages for User 5284917 with VALID problem IDs
INSERT INTO problem_submissions (submission_id, user_id, problem_id, code, language, is_solved, passed_test_cases, total_test_cases, version, submitted_at, user_problem_report_id, insights) VALUES
                                                                                                                                                                                                  (41, '5284917', 54, 'public class TextFormatter {
    public static String formatText(String text, String formatType) {
        switch (formatType) {
            case "uppercase":
                return text.toUpperCase();
            case "trim":
                return text.trim();
            case "title":
                return toTitleCase(text);
            default:
                return "Invalid format";
        }
    }
    
    private static String toTitleCase(String text) {
        String[] words = text.split(" ");
        StringBuilder result = new StringBuilder();
        for (String word : words) {
            if (!word.isEmpty()) {
                result.append(Character.toUpperCase(word.charAt(0)))
                      .append(word.substring(1).toLowerCase())
                      .append(" ");
            }
        }
        return result.toString().trim();
    }
    
    public static void main(String[] args) {
        java.util.Scanner scanner = new java.util.Scanner(System.in);
        String text = scanner.nextLine();
        String formatType = scanner.nextLine();
        System.out.println(formatText(text, formatType));
    }
}', 'JAVA', true, 4, 4, 1, CURRENT_TIMESTAMP - INTERVAL '13 days', 41, '{"execution_time": "42ms", "memory_used": "13MB", "code_quality": "excellent"}'),
                                                                                                                                                                                                  (42, '5284917', 58, 'def string_sorting():
    strings = input().strip().split()
    sorted_strings = sorted(strings)
    return " ".join(sorted_strings)

print(string_sorting())', 'PYTHON', true, 4, 4, 1, CURRENT_TIMESTAMP - INTERVAL '11 days', 42, '{"execution_time": "26ms", "memory_used": "8MB", "code_quality": "good"}'),
                                                                                                                                                                                                  (43, '5284917', 62, 'function arrayElementAccess() {
    const input = prompt().split(" ").map(Number);
    const index = parseInt(prompt());
    
    if (index >= 0 && index < input.length) {
        console.log(input[index]);
    } else {
        console.log("Invalid index");
    }
}

arrayElementAccess();', 'JAVASCRIPT', true, 4, 4, 1, CURRENT_TIMESTAMP - INTERVAL '9 days', 43, '{"execution_time": "31ms", "memory_used": "7MB", "code_quality": "good"}'),
                                                                                                                                                                                                  (44, '5284917', 66, 'function elementSearch(): void {
    const input: string = prompt() || "";
    const array: number[] = input.split(" ").map(Number);
    const target: number = parseFloat(prompt() || "0");
    
    for (let i = 0; i < array.length; i++) {
        if (array[i] === target) {
            console.log(i);
            return;
        }
    }
    console.log("Not found");
}

elementSearch();', 'TYPESCRIPT', true, 4, 4, 1, CURRENT_TIMESTAMP - INTERVAL '7 days', 44, '{"execution_time": "36ms", "memory_used": "9MB", "code_quality": "excellent"}'),
                                                                                                                                                                                                  (45, '5284917', 70, 'public class MatrixOperations {
    public static int[][] matrixOperation(int[][] matrix1, int[][] matrix2, String operation) {
        int rows = matrix1.length;
        int cols = matrix1[0].length;
        int[][] result = new int[rows][cols];
        
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                if (operation.equals("add")) {
                    result[i][j] = matrix1[i][j] + matrix2[i][j];
                } else if (operation.equals("subtract")) {
                    result[i][j] = matrix1[i][j] - matrix2[i][j];
                }
            }
        }
        return result;
    }
    
    public static void main(String[] args) {
        // Example usage with predefined matrices
        int[][] matrix1 = {{1,2},{3,4}};
        int[][] matrix2 = {{5,6},{7,8}};
        int[][] result = matrixOperation(matrix1, matrix2, "add");
        System.out.println(java.util.Arrays.deepToString(result));
    }
}', 'JAVA', true, 4, 4, 1, CURRENT_TIMESTAMP - INTERVAL '5 days', 45, '{"execution_time": "48ms", "memory_used": "15MB", "code_quality": "excellent"}'),
                                                                                                                                                                                                  (46, '5284917', 74, 'def grade_to_gpa_converter():
    grade = input().strip().upper()
    
    if grade == "A":
        return 4.0
    elif grade == "B":
        return 3.0
    elif grade == "C":
        return 2.0
    elif grade == "D":
        return 1.0
    elif grade == "F":
        return 0.0
    else:
        return "Invalid grade"

print(grade_to_gpa_converter())', 'PYTHON', true, 4, 4, 1, CURRENT_TIMESTAMP - INTERVAL '3 days', 46, '{"execution_time": "25ms", "memory_used": "7MB", "code_quality": "good"}'),
                                                                                                                                                                                                  (47, '5284917', 78, 'function simpleCalculator() {
    const num1 = parseFloat(prompt());
    const operator = prompt();
    const num2 = parseFloat(prompt());
    
    let result;
    switch (operator) {
        case "+":
            result = num1 + num2;
            break;
        case "-":
            result = num1 - num2;
            break;
        case "*":
            result = num1 * num2;
            break;
        case "/":
            result = num1 / num2;
            break;
        default:
            result = "Invalid operator";
    }
    
    console.log(result);
}

simpleCalculator();', 'JAVASCRIPT', true, 4, 4, 1, CURRENT_TIMESTAMP - INTERVAL '2 days', 47, '{"execution_time": "30ms", "memory_used": "8MB", "code_quality": "good"}'),
                                                                                                                                                                                                  (48, '5284917', 82, 'function temperatureConverter(celsius: number): number {
    return (celsius * 9/5) + 32;
}

const celsius: number = parseFloat(prompt() || "0");
console.log(temperatureConverter(celsius));', 'TYPESCRIPT', true, 4, 4, 1, CURRENT_TIMESTAMP - INTERVAL '1 day', 48, '{"execution_time": "28ms", "memory_used": "8MB", "code_quality": "excellent"}');

-- Additional 8 User Problem Engagement records for User 5284917 with VALID problem IDs
INSERT INTO user_problem_engagement (user_id, problem_id, is_solved, total_attempts, total_seconds_spent, last_activity_at, saved_codes) VALUES
                                                                                                                                             ('5284917', 54, true, 1, 950, CURRENT_TIMESTAMP - INTERVAL '13 days', '{"java": "public class TextFormatter { public static String formatText(String text, String formatType) { switch (formatType) { case \\\"uppercase\\\": return text.toUpperCase(); case \\\"trim\\\": return text.trim(); case \\\"title\\\": return toTitleCase(text); default: return \\\"Invalid format\\\"; } } }", "python": "", "javascript": "", "typescript": ""}'),
                                                                                                                                             ('5284917', 58, true, 1, 700, CURRENT_TIMESTAMP - INTERVAL '11 days', '{"java": "", "python": "def string_sorting(): strings = input().strip().split() sorted_strings = sorted(strings) return \\\" \\\".join(sorted_strings)", "javascript": "", "typescript": ""}'),
                                                                                                                                             ('5284917', 62, true, 1, 800, CURRENT_TIMESTAMP - INTERVAL '9 days', '{"java": "", "python": "", "javascript": "function arrayElementAccess() { const input = prompt().split(\\\" \\\").map(Number); const index = parseInt(prompt()); if (index >= 0 && index < input.length) { console.log(input[index]); } else { console.log(\\\"Invalid index\\\"); } }", "typescript": ""}'),
                                                                                                                                             ('5284917', 66, true, 1, 900, CURRENT_TIMESTAMP - INTERVAL '7 days', '{"java": "", "python": "", "javascript": "", "typescript": "function elementSearch(): void { const input: string = prompt() || \\\"\\\"; const array: number[] = input.split(\\\" \\\").map(Number); const target: number = parseFloat(prompt() || \\\"0\\\"); for (let i = 0; i < array.length; i++) { if (array[i] === target) { console.log(i); return; } } console.log(\\\"Not found\\\"); }"}'),
                                                                                                                                             ('5284917', 70, true, 2, 1200, CURRENT_TIMESTAMP - INTERVAL '5 days', '{"java": "public class MatrixOperations { public static int[][] matrixOperation(int[][] matrix1, int[][] matrix2, String operation) { int rows = matrix1.length; int cols = matrix1[0].length; int[][] result = new int[rows][cols]; for (int i = 0; i < rows; i++) { for (int j = 0; j < cols; j++) { if (operation.equals(\\\"add\\\")) { result[i][j] = matrix1[i][j] + matrix2[i][j]; } else if (operation.equals(\\\"subtract\\\")) { result[i][j] = matrix1[i][j] - matrix2[i][j]; } } } return result; } }", "python": "", "javascript": "", "typescript": ""}'),
                                                                                                                                             ('5284917', 74, true, 1, 600, CURRENT_TIMESTAMP - INTERVAL '3 days', '{"java": "", "python": "def grade_to_gpa_converter(): grade = input().strip().upper() if grade == \\\"A\\\": return 4.0 elif grade == \\\"B\\\": return 3.0 elif grade == \\\"C\\\": return 2.0 elif grade == \\\"D\\\": return 1.0 elif grade == \\\"F\\\": return 0.0 else: return \\\"Invalid grade\\\"", "javascript": "", "typescript": ""}'),
                                                                                                                                             ('5284917', 78, true, 1, 850, CURRENT_TIMESTAMP - INTERVAL '2 days', '{"java": "", "python": "", "javascript": "function simpleCalculator() { const num1 = parseFloat(prompt()); const operator = prompt(); const num2 = parseFloat(prompt()); let result; switch (operator) { case \\\"+\\\": result = num1 + num2; break; case \\\"-\\\": result = num1 - num2; break; case \\\"*\\\": result = num1 * num2; break; case \\\"/\\\": result = num1 / num2; break; default: result = \\\"Invalid operator\\\"; } console.log(result); }", "typescript": ""}'),
                                                                                                                                             ('5284917', 82, true, 1, 700, CURRENT_TIMESTAMP - INTERVAL '1 day', '{"java": "", "python": "", "javascript": "", "typescript": "function temperatureConverter(celsius: number): number { return (celsius * 9/5) + 32; } const celsius: number = parseFloat(prompt() || \\\"0\\\"); console.log(temperatureConverter(celsius));"}');

-- Additional 8 User Problem Reports for User 5284917 with VALID problem IDs
INSERT INTO user_problem_reports (user_problem_report_id, user_id, problem_id, is_solved, total_attempts, insights, languages_used) VALUES
                                                                                                                                        (41, '5284917', 54, true, 1, '{"difficulty": "medium", "concepts_mastered": ["string_manipulation", "switch_cases", "text_formatting"], "time_spent_pattern": "single_attempt_950s", "common_errors": ["case_handling"], "improvement_areas": ["efficiency"]}', '["JAVA"]'),
                                                                                                                                        (42, '5284917', 58, true, 1, '{"difficulty": "easy", "concepts_mastered": ["sorting_algorithms", "array_operations", "string_joining"], "time_spent_pattern": "single_attempt_700s", "common_errors": ["sorting_logic"], "improvement_areas": ["custom_sorting"]}', '["PYTHON"]'),
                                                                                                                                        (43, '5284917', 62, true, 1, '{"difficulty": "easy", "concepts_mastered": ["array_access", "index_validation", "boundary_checking"], "time_spent_pattern": "single_attempt_800s", "common_errors": ["index_handling"], "improvement_areas": ["error_messages"]}', '["JAVASCRIPT"]'),
                                                                                                                                        (44, '5284917', 66, true, 1, '{"difficulty": "medium", "concepts_mastered": ["linear_search", "array_iteration", "early_returns"], "time_spent_pattern": "single_attempt_900s", "common_errors": ["type_safety"], "improvement_areas": ["algorithm_efficiency"]}', '["TYPESCRIPT"]'),
                                                                                                                                        (45, '5284917', 70, true, 2, '{"difficulty": "hard", "concepts_mastered": ["matrix_operations", "nested_loops", "2d_array_handling"], "time_spent_pattern": "first_attempt_800s_second_400s", "common_errors": ["dimension_matching", "index_calculation"], "improvement_areas": ["input_validation"]}', '["JAVA"]'),
                                                                                                                                        (46, '5284917', 74, true, 1, '{"difficulty": "easy", "concepts_mastered": ["grade_mapping", "conditional_chains", "return_values"], "time_spent_pattern": "single_attempt_600s", "common_errors": ["case_sensitivity"], "improvement_areas": ["dictionary_usage"]}', '["PYTHON"]'),
                                                                                                                                        (47, '5284917', 78, true, 1, '{"difficulty": "medium", "concepts_mastered": ["operator_handling", "switch_cases", "arithmetic_operations"], "time_spent_pattern": "single_attempt_850s", "common_errors": ["operator_precedence"], "improvement_areas": ["error_handling"]}', '["JAVASCRIPT"]'),
                                                                                                                                        (48, '5284917', 82, true, 1, '{"difficulty": "easy", "concepts_mastered": ["mathematical_formulas", "type_safety", "function_returns"], "time_spent_pattern": "single_attempt_700s", "common_errors": ["formula_accuracy"], "improvement_areas": ["precision_handling"]}', '["TYPESCRIPT"]');