package com.ignite.CBL.repository;

import com.ignite.CBL.entity.Language;
import com.ignite.CBL.entity.ProblemSubmission;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ProblemSubmissionRepository extends JpaRepository<ProblemSubmission, Integer> {
    Optional<ProblemSubmission> findByProblem_ProblemIdAndUser_UserIdAndLanguage(Integer problemId, String userId, Language language);
    List<ProblemSubmission> findByProblem_ProblemIdAndUser_UserId(Integer problemId, String userId);
    List<ProblemSubmission> findByUserProblemReport_UserProblemReportIdOrderBySubmittedAtDesc(Integer userProblemReportId);
}
