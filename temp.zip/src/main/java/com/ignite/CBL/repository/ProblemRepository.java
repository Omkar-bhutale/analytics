package com.ignite.CBL.repository;

import com.ignite.CBL.entity.Problem;
import com.ignite.CBL.entity.Difficulty;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

public interface ProblemRepository extends JpaRepository<Problem, Integer> {
    List<Problem> findByTopic_TopicId(Integer topicTopicId);

    @Query(value = "SELECT p.problem_id FROM problems p " +
            "WHERE p.difficulty = :difficulty AND p.topic_id = :topicId " +
            "ORDER BY RANDOM() LIMIT 1",
            nativeQuery = true)
    Optional<Integer> findRandomProblemIdByDifficultyAndTopicId(
            @Param("difficulty") String difficulty,
            @Param("topicId") Integer topicId
    );

}
