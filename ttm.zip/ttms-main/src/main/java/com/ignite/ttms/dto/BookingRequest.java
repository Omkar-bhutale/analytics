package com.ignite.ttms.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookingRequest {
    @NotNull(message = "Customer ID is required")
    private Long customerId;

    @NotBlank(message = "Train number is required")
    private String trainNumber;

    @NotBlank(message = "Origin station is required")
    private String originStation;

    @NotBlank(message = "Destination station is required")
    private String destinationStation;

    @NotNull(message = "Travel date is required")
    private LocalDate travelDate;

    @NotBlank(message = "Travel class is required")
    private String travelClass;

    @NotNull(message = "Number of seats is required")
    @Min(value = 1, message = "At least 1 seat must be booked")
    @Max(value = 6, message = "Cannot book more than 6 seats in one session")
    private Integer numberOfSeats;
}
