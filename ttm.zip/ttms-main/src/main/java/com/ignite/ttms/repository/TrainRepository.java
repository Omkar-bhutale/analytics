package com.ignite.ttms.repository;

import com.ignite.ttms.entity.Train;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface TrainRepository extends JpaRepository<Train, Long> {
    Optional<Train> findByTrainNumber(String trainNumber);

    boolean existsByTrainNumber(String trainNumber);

    @Query("SELECT t FROM Train t WHERE t.originStation = :origin AND t.destinationStation = :destination")
    List<Train> findByRoute(@Param("origin") String origin, @Param("destination") String destination);

    @Query("SELECT CASE WHEN COUNT(t) > 0 THEN true ELSE false END FROM Train t " +
           "WHERE t.originStation = :origin AND t.destinationStation = :destination " +
           "AND t.departureTime = :departure AND t.arrivalTime = :arrival AND t.id != :trainId")
    boolean existsScheduleConflict(@Param("origin") String origin,
                                   @Param("destination") String destination,
                                   @Param("departure") LocalDateTime departure,
                                   @Param("arrival") LocalDateTime arrival,
                                   @Param("trainId") Long trainId);
}

