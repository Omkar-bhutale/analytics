package com.ignite.ttms.controller;

import com.ignite.ttms.dto.LoginRequest;
import com.ignite.ttms.dto.LoginResponse;
import com.ignite.ttms.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {
    private final AuthService authService;

    @PostMapping("/admin/login")
    public ResponseEntity<LoginResponse> adminLogin(@Valid @RequestBody LoginRequest request) {
        LoginResponse response = authService.adminLogin(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/customer/login")
    public ResponseEntity<LoginResponse> customerLogin(@Valid @RequestBody LoginRequest request) {
        LoginResponse response = authService.customerLogin(request);
        return ResponseEntity.ok(response);
    }
}

