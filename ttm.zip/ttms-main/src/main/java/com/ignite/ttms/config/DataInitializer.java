package com.ignite.ttms.config;

import com.ignite.ttms.entity.Admin;
import com.ignite.ttms.repository.AdminRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {
    private final AdminRepository adminRepository;

    @Override
    public void run(String... args) throws Exception {
        // Create default admin user if not exists
        if (adminRepository.count() == 0) {
            Admin admin = new Admin();
            admin.setUsername("admin");
            admin.setPassword("admin123");
            adminRepository.save(admin);
            System.out.println("Default admin user created - Username: admin, Password: admin123");
        }
    }
}

