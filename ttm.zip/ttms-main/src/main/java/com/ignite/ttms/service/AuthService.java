package com.ignite.ttms.service;

import com.ignite.ttms.dto.LoginRequest;
import com.ignite.ttms.dto.LoginResponse;
import com.ignite.ttms.entity.Admin;
import com.ignite.ttms.entity.Customer;
import com.ignite.ttms.repository.AdminRepository;
import com.ignite.ttms.repository.CustomerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class AuthService {
    private final AdminRepository adminRepository;
    private final CustomerRepository customerRepository;

    public LoginResponse adminLogin(LoginRequest request) {
        Optional<Admin> admin = adminRepository.findByUsernameAndPassword(
                request.getUsername(),
                request.getPassword()
        );

        if (admin.isPresent()) {
            return new LoginResponse(true, "Login successful", admin.get().getId(), "ADMIN");
        } else {
            return new LoginResponse(false, "Please Enter Correct UserName and Password", null, null);
        }
    }

    public LoginResponse customerLogin(LoginRequest request) {
        Optional<Customer> customer = customerRepository.findByEmailAndPassword(
                request.getUsername(),
                request.getPassword()
        );

        if (customer.isPresent()) {
            if (!customer.get().getIsActive()) {
                return new LoginResponse(false, "Account is deactivated", null, null);
            }
            return new LoginResponse(true, "Login successful", customer.get().getId(), "CUSTOMER");
        } else {
            return new LoginResponse(false, "Please Enter Correct UserName and Password", null, null);
        }
    }
}

