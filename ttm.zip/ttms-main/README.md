# TTMS - Train Ticket Management System

A complete REST API-based Train Ticket Management System built with Spring Boot, JPA, and H2 Database.

## Features
- ✅ RESTful API architecture
- ✅ Admin and Customer authentication
- ✅ Train management (CRUD operations)
- ✅ Ticket booking and cancellation
- ✅ Seat availability management
- ✅ Swagger/OpenAPI documentation
- ✅ H2 in-memory database
- ✅ Input validation and exception handling

## Technology Stack
- Java 17
- Spring Boot 3.5.7
- Spring Data JPA
- H2 Database
- Swagger/OpenAPI
- Lombok
- Maven

## Quick Start

### Prerequisites
- Java 17 or higher
- Maven

### Running the Application
```bash
# Clone the repository
git clone https://github.com/Omkar-bhutale/ttms.git
cd ttms

# Build and run
.\mvnw.cmd clean package -DskipTests
.\mvnw.cmd spring-boot:run
```

The application will start at: **http://localhost:8080**

## API Documentation

### Swagger UI
Once the application is running, access the interactive API documentation at:
- **Swagger UI**: http://localhost:8080/swagger-ui.html
- **API Docs**: http://localhost:8080/api-docs

### H2 Database Console
- **URL**: http://localhost:8080/h2-console
- **JDBC URL**: `jdbc:h2:mem:ttmsdb`
- **Username**: `sa`
- **Password**: (leave empty)

## Default Credentials
- **Admin Login**
  - Username: `admin`
  - Password: `admin123`

## API Endpoints

### Authentication
- `POST /api/auth/admin/login` - Admin login
- `POST /api/auth/customer/login` - Customer login

### Customer Management
- `POST /api/customers/register` - Register new customer
- `GET /api/customers/{id}` - Get customer details
- `PUT /api/customers/{id}` - Update customer
- `DELETE /api/customers/{id}` - Deactivate customer

### Train Management (Admin)
- `POST /api/admin/trains` - Register new train
- `GET /api/admin/trains` - Get all trains
- `PUT /api/admin/trains/{trainNumber}` - Update train
- `DELETE /api/admin/trains/{trainNumber}` - Delete train

### Train Search (Public)
- `POST /api/trains/search` - Search trains by route
- `GET /api/trains` - Get all trains

### Booking Management
- `POST /api/bookings` - Book ticket
- `POST /api/bookings/cancel` - Cancel ticket
- `GET /api/bookings/customer/{customerId}` - Get booking history

## Project Structure
```
src/main/java/com/ignite/ttms/
├── config/          # Configuration classes
├── controller/      # REST API controllers
├── dto/            # Data Transfer Objects
├── entity/         # JPA entities
├── exception/      # Exception handlers
├── repository/     # Data access layer
└── service/        # Business logic layer
```

## Documentation Files
- `API_DOCUMENTATION.md` - Complete API documentation
- `QUICK_START.md` - Quick start guide
- `PROJECT_SUMMARY.md` - Project overview
- `TTMS_Postman_Collection.json` - Postman collection for testing

## License
This project is licensed under the Apache License 2.0.

## Contact
For support or queries, please open an issue on GitHub.

