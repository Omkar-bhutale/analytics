// DataTypesTabs.jsx
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { TbBulb, TbCheck } from "react-icons/tb";
import { FaCode } from "react-icons/fa";
import { questionMap } from './constants.js';
import { fetchMainTopicProblem } from './learningApi.js';
import toast from 'react-hot-toast';

export function DataTypesTabs({
    selectedTopic, selectedSubtopic, completedItems, fetchedData,
    markLanguageComplete, setSelectedLanguage, setCompletedItems, navigate
}) {
    const topicData = fetchedData.find(t => t.mainTopicName === selectedTopic);
    const subtopicData = topicData?.subTopics?.find(s => s.title === selectedSubtopic);
    const subtopicIndex = topicData?.subTopics.findIndex(s => s.title === selectedSubtopic);
    const isLastSubtopic = subtopicIndex === (topicData?.subTopics.length - 1);
    const [questionId, setQuestionId] = useState(1);

    const languages = subtopicData?.content?.language_details?.map(d => d.language) || ["Java", "Python", "JavaScript", "TypeScript"];
    const [tab, setTab] = useState(() => {
        const saved = localStorage.getItem('selectedLanguageTab');
        return saved && languages.includes(saved) ? saved : languages[0];
    });

    const readVisited = () => JSON.parse(localStorage.getItem("visitedLanguages") || "[]");

    useEffect(() => {
        setSelectedLanguage(tab);
        localStorage.setItem('selectedLanguageTab', tab);
        if (!selectedTopic || !selectedSubtopic || !tab) return;
        const key = `${selectedTopic}::${selectedSubtopic}::${tab}::visited`;
        const visited = readVisited();
        if (!visited.includes(key)) {
            const updated = [...visited, key];
            localStorage.setItem("visitedLanguages", JSON.stringify(updated));
            window.dispatchEvent(new Event("visitedLanguagesUpdated"));
            const allVisited = languages.every(l => updated.includes(`${selectedTopic}::${selectedSubtopic}::${l}::visited`));
            if (allVisited) {
                const compKey = `${selectedTopic}::${selectedSubtopic}::subtopic_complete`;
                setCompletedItems(prev => {
                    if (prev.includes(compKey)) return prev;
                    const next = [...prev, compKey];
                    const allSubComp = (topicData?.subTopics || []).every(s => next.includes(`${selectedTopic}::${s.title}::subtopic_complete`));
                    if (allSubComp) next.push(`${selectedTopic}::main_topic_complete`);
                    return next;
                });
            }
        }
    }, [tab, selectedTopic, selectedSubtopic, setSelectedLanguage, setCompletedItems, topicData, languages]);

    useEffect(() => {
        const saved = localStorage.getItem('selectedLanguageTab');
        if (languages.length > 0 && (!saved || !languages.includes(saved)) && !languages.includes(tab)) {
            setTab(languages[0]);
        }
    }, [selectedSubtopic, languages, tab]);

    const currentLangDetail = subtopicData?.content?.language_details?.find(d => d.language === tab);
    const currentData = {
        content: subtopicData?.content?.explaination || "Explanation not available.",
        code: currentLangDetail?.example || "Example code not available.",
        note: subtopicData?.content?.code_difference_explaination || "No difference note provided.",
    };

    const isQuizCompleted = completedItems.includes(`${selectedTopic}::${selectedSubtopic}::passed`);
    const isLangCompletedForTopic = completedItems.includes(`${selectedTopic}::${tab}`);

    const visitedLanguages = readVisited();
    const allSubtopicsVisitedForThisLang = (topicData?.subTopics || []).every(sub =>
        visitedLanguages.includes(`${selectedTopic}::${sub.title}::${tab}::visited`)
    );

    const isLanguageTicked = (lang) => {
        const complete = completedItems.includes(`${selectedTopic}::${lang}`);
        const allVisited = (topicData?.subTopics || []).every(sub =>
            visitedLanguages.includes(`${selectedTopic}::${sub.title}::${lang}::visited`)
        );
        return complete || allVisited;
    };

    const lastSubtopicTitle = topicData?.subTopics?.[topicData.subTopics.length - 1]?.title;
    const isLastQuizPassed = lastSubtopicTitle ? completedItems.includes(`${selectedTopic}::${lastSubtopicTitle}::passed`) : false;

    const canMarkLanguageComplete = allSubtopicsVisitedForThisLang;

    const handleTopicwiseQuestionFetch = async () => {
        try {
            if (!topicData?.mainTopicId) throw new Error("Main Topic ID not found");
            const res = await fetchMainTopicProblem(topicData.mainTopicId);
            if (res.data?.problemDTO) {
                setQuestionId(res.data.problemDTO.problemId);
                toast.success("Problem loaded!");
                navigate(`/compiler/${res.data.problemDTO.problemId}`, {
                    state: { selectedTopic, selectedSubTopic: selectedSubtopic, subtopics: topicData.subTopics.map(s => s.title) }
                });
            } else {
                toast.error("Failed to load problem");
            }
        } catch (err) {
            toast.error("Failed to fetch problem");
        }
    };

    const handleMarkComplete = () => {
        if (!isLangCompletedForTopic && canMarkLanguageComplete) {
            markLanguageComplete(selectedTopic, selectedSubtopic, tab);
            const idx = languages.indexOf(tab);
            if (idx < languages.length - 1) setTab(languages[idx + 1]);
        }
    };

    return (
        <div>
            <div style={{ display: "flex", margin: "0 0 15px 0", gap: 30 }}>
                {languages.map(lang => {
                    const ticked = isLanguageTicked(lang);
                    return (
                        <button key={lang} onClick={() => setTab(lang)} style={{
                            padding: "8px 24px", background: tab === lang ? "#09122C" : "#DD6B20", border: "none",
                            fontWeight: tab === lang ? "bold" : "normal", cursor: "pointer", fontSize: 17, color: "#fff", margin: "25px 0 23px"
                        }}>
                            {lang} {ticked && <TbCheck style={{ marginLeft: 5 }} />}
                        </button>
                    );
                })}
            </div>
            <div style={{ marginTop: 8, padding: 8 }}>
                <h3 style={{ marginBottom: 8 }}>{selectedSubtopic} in {tab}</h3>
                <p style={{ marginBottom: 8 }}>{currentData.content}</p>
                <pre style={{ background: "#fff", color: "#333", padding: 16, fontSize: 15, borderRadius: 6, marginBottom: 10 }}>{currentData.code}</pre>
                <small style={{ color: "#333", fontSize: 14 }}><b>Note:</b> {currentData.note}</small>
                <div style={{ marginTop: 12, display: "flex", gap: "20px" }}>
                    <Link to={!isQuizCompleted ? `/mcq_page/${questionMap[tab] || 'default'}` : "#"} state={{ mainTopic: selectedTopic, subtopic: selectedSubtopic }} style={{ textDecoration: "none" }} onClick={e => isQuizCompleted && e.preventDefault()}>
                        <button style={{
                            padding: "6px 14px", fontSize: 14, borderRadius: 6, cursor: isQuizCompleted ? "not-allowed" : "pointer",
                            background: isQuizCompleted ? "#DD6B20" : "#09122C", color: "#fff", border: "none", display: "flex", alignItems: "center"
                        }}>
                            <TbBulb style={{ marginRight: 10 }} />
                            {isQuizCompleted ? "Quiz Completed" : "Take Quiz"}
                        </button>
                    </Link>
                    {isLastSubtopic && (
                        <button onClick={handleTopicwiseQuestionFetch} style={{
                            padding: "6px 14px", fontSize: 14, borderRadius: 6, cursor: "pointer",
                            background: "#09122C", color: "#fff", border: "none", display: "flex", alignItems: "center"
                        }}>
                            <FaCode style={{ marginRight: 10 }} /> Code here
                        </button>
                    )}
                    {isLastSubtopic && (
                        <button onClick={handleMarkComplete} disabled={isLangCompletedForTopic || !canMarkLanguageComplete} style={{
                            padding: "6px 14px", fontSize: 14, borderRadius: 6,
                            cursor: (isLangCompletedForTopic || !canMarkLanguageComplete) ? "not-allowed" : "pointer",
                            background: (isLangCompletedForTopic || !canMarkLanguageComplete) ? "#09122C" : "#DD6B20",
                            color: "#fff", border: "none", display: "flex", alignItems: "center", marginLeft: "auto"
                        }}>
                            <TbCheck style={{ marginRight: 10 }} />
                            {isLangCompletedForTopic ? `Completed (${tab})` : "Mark as Complete"}
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
}