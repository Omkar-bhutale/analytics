// TopicTimer.jsx
export function TopicTimer({ currentTimerKey, timers }) {
    const seconds = timers[currentTimerKey] || 0;
    const formatTime = (s) => {
        const h = String(Math.floor(s / 3600)).padStart(2, "0");
        const m = String(Math.floor((s % 3600) / 60)).padStart(2, "0");
        const sec = String(s % 60).padStart(2, "0");
        return `${h}:${m}:${sec}`;
    };

    return (
        <div style={{
            background: "#09122C",
            color: "#fff",
            padding: "8px 16px",
            borderRadius: "6px",
            fontSize: "16px",
            fontWeight: "bold",
            display: "inline-block",
            minWidth: "110px",
            textAlign: "center",
        }}>
            {formatTime(seconds)}
        </div>
    );
}