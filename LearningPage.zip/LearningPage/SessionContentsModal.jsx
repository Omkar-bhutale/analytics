// SessionContentsModal.jsx
import { useState, useEffect } from "react";
import { TbNotebook, TbDownload, TbX } from "react-icons/tb";
import toast from 'react-hot-toast';
import { fetchNotebooks, downloadNotebook } from './learningApi.js';

export function SessionContentsModal({ isOpen, onClose, selectedTopic, fetchedData }) {
    const [notebooks, setNotebooks] = useState([]);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (!isOpen || !selectedTopic) return;
        const load = async () => {
            setLoading(true);
            try {
                const topicData = fetchedData.find(t => t.mainTopicName === selectedTopic);
                if (!topicData?.mainTopicId) throw new Error("Topic ID missing");
                const res = await fetchNotebooks(topicData.mainTopicId);
                setNotebooks(res.data || []);
            } catch (err) {
                toast.error("Failed to fetch notebooks");
                setNotebooks([]);
            } finally {
                setLoading(false);
            }
        };
        load();
    }, [isOpen, selectedTopic, fetchedData]);

    const handleDownload = async (notebookId, title, fileType) => {
        try {
            toast.loading(`Downloading ${title}...`, { id: `dl-${notebookId}` });
            const res = await downloadNotebook(notebookId);
            let fileName = title;
            const cd = res.headers['content-disposition'];
            if (cd) {
                const match = cd.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/);
                if (match?.[1]) fileName = match[1].replace(/['"]/g, '');
            } else {
                const ext = fileType === 'PDF' ? '.pdf' : '.ipynb';
                if (!fileName.toLowerCase().endsWith(ext)) fileName += ext;
            }
            const blob = new Blob([res.data], { type: res.headers['content-type'] || 'application/octet-stream' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = fileName;
            a.click();
            window.URL.revokeObjectURL(url);
            toast.success(`Downloaded ${fileName}`, { id: `dl-${notebookId}` });
        } catch (err) {
            toast.error("Download failed", { id: `dl-${notebookId}` });
        }
    };

    if (!isOpen) return null;

    return (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.5)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000 }} onClick={onClose}>
            <div style={{ background: "#fff", borderRadius: 12, padding: 24, minWidth: 500, maxWidth: 700, maxHeight: "80vh", overflowY: "auto", boxShadow: "0 10px 40px rgba(0,0,0,0.2)" }} onClick={e => e.stopPropagation()}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
                    <h2 style={{ margin: 0, color: "#09122C", fontSize: 24, fontWeight: "bold" }}>
                        Session Contents - {selectedTopic}
                    </h2>
                    <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 24, color: "#666" }}>
                        <TbX />
                    </button>
                </div>
                {loading ? (
                    <div style={{ textAlign: "center", padding: 40, color: "#666" }}>Loading notebooks...</div>
                ) : notebooks.length === 0 ? (
                    <div style={{ textAlign: "center", padding: 40, color: "#666" }}>No notebooks available.</div>
                ) : (
                    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                        {notebooks.map(nb => (
                            <div key={nb.notebookId} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: 16, background: "#f6f7fb", borderRadius: 8, border: "1px solid #e0e0e0" }}>
                                <div style={{ flex: 1 }}>
                                    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                                        <TbNotebook style={{ color: "#DD6B20", fontSize: 20 }} />
                                        <h4 style={{ margin: 0, color: "#09122C", fontSize: 16 }}>{nb.title}</h4>
                                    </div>
                                    <div style={{ display: "flex", gap: 12, fontSize: 13, color: "#666" }}>
                                        <span style={{ background: "#DD6B20", color: "#fff", padding: "2px 8px", borderRadius: 4, fontSize: 12 }}>{nb.language}</span>
                                        <span style={{ background: "#09122C", color: "#fff", padding: "2px 8px", borderRadius: 4, fontSize: 12 }}>{nb.fileType}</span>
                                    </div>
                                </div>
                                <button onClick={() => handleDownload(nb.notebookId, nb.title, nb.fileType)} style={{
                                    background: "#09122C", color: "#fff", border: "none", borderRadius: 6, padding: "10px 16px", cursor: "pointer",
                                    display: "flex", alignItems: "center", gap: 6, fontSize: 14, fontWeight: 500
                                }} onMouseEnter={e => e.target.style.backgroundColor = "#1a2444"} onMouseLeave={e => e.target.style.backgroundColor = "#09122C"}>
                                    <TbDownload style={{ fontSize: 18 }} /> Download
                                </button>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}