// learningApi.js
import axios from './axiosConfig.js';
import { BASE_URL } from './constants.js';

export const fetchAllMainTopics = async () => {
    const url = `${BASE_URL}/user/topic-engagement/all-main-topics-sub-topics`;
    const response = await axios.get(url);
    return response.data;
};

export const fetchNotebooks = async (mainTopicId) => {
    return await axios.get(`${BASE_URL}/user/notebooks/${mainTopicId}`);
};

export const downloadNotebook = async (notebookId) => {
    return await axios.get(`${BASE_URL}/user/notebooks/download/${notebookId}`, {
        responseType: 'blob',
    });
};

export const fetchMainTopicProblem = async (mainTopicId) => {
    return await axios.get(`${BASE_URL}/user/problem-submissions/main-topic`, {
        params: { mainTopicId }
    });
};

export const markMcqVisited = async (topicId, language) => {
    return await axios.put(`${BASE_URL}/user/topic-engagement/${topicId}/mcq-visited`, null, {
        params: { language: language.toUpperCase() }
    });
};

export const validateMainTopicCompletion = async (mainTopicId, language) => {
    return await axios.put(`${BASE_URL}/user/user-main-topic-engagement/${mainTopicId}/validate-completion?language=${language.toUpperCase()}`);
};