// index.jsx
import { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Toaster } from 'react-hot-toast';
import Navbar from "../Components/Navbar";
import { Sidebar } from './Sidebar.jsx';
import { DataTypesTabs } from './DataTypesTabs.jsx';
import { SessionContentsModal } from './SessionContentsModal.jsx';
import { TopicTimer } from './TopicTimer.jsx';
import { usePersistentTopicTimers } from './usePersistentTopicTimers.js';
import { fetchAllMainTopics } from './learningApi.js';
import toast from 'react-hot-toast';

export default function LearningPage({ onLogout }) {
    const location = useLocation();
    const navigate = useNavigate();
    const [fetchedData, setFetchedData] = useState([]);
    const [isDataLoading, setIsDataLoading] = useState(true);
    const [dataError, setDataError] = useState(null);
    const [isModalOpen, setIsModalOpen] = useState(false);

    const getInitial = (key, def) => {
        try {
            const val = localStorage.getItem(key);
            return val === "null" ? null : val ?? def;
        } catch { return def; }
    };

    const [selectedLanguage, setSelectedLanguage] = useState(getInitial("selectedLanguage", "Java"));
    const subtopicFromQuiz = location.state?.subtopic || null;
    const quizPassed = location.state?.quizPassed || false;

    const persistedTopic = getInitial("selectedTopic", null);
    const persistedSubtopic = getInitial("selectedSubtopic", null);
    const initialTopic = subtopicFromQuiz ? null : persistedTopic || null;
    const initialSubtopic = subtopicFromQuiz ? subtopicFromQuiz : persistedSubtopic || null;

    const [selectedTopic, setSelectedTopic] = useState(initialTopic);
    const [selectedSubtopic, setSelectedSubtopic] = useState(initialSubtopic);

    const { timers, completedItems, setCompletedItems, markLanguageComplete, markQuizPassed } =
        usePersistentTopicTimers(selectedTopic, selectedSubtopic, selectedLanguage, fetchedData);

    useEffect(() => {
        const fetch = async () => {
            try {
                const data = await fetchAllMainTopics();
                let topics = Array.isArray(data) ? data : Array.isArray(data?.[0]) ? data[0] : [];
                if (topics.length === 0 && data?.[0]?.mainTopicName) topics = [data[0]];
                localStorage.setItem("fetchedAPIData", JSON.stringify(data));
                setFetchedData(topics);
            } catch (err) {
                setDataError("Failed to fetch content.");
            } finally {
                setIsDataLoading(false);
            }
        };
        fetch();
    }, []);

    useEffect(() => {
        if (selectedTopic) localStorage.setItem("selectedTopic", selectedTopic);
        localStorage.setItem("selectedSubtopic", selectedSubtopic ?? "null");
    }, [selectedTopic, selectedSubtopic]);

    useEffect(() => {
        localStorage.setItem("selectedLanguage", selectedLanguage);
    }, [selectedLanguage]);

    useEffect(() => {
        if (quizPassed && location.state?.mainTopic && location.state?.subtopic) {
            const { mainTopic, subtopic } = location.state;
            markQuizPassed(mainTopic, subtopic, selectedLanguage);
            setSelectedTopic(mainTopic);
            setSelectedSubtopic(subtopic);
            navigate(location.pathname, { replace: true, state: {} });
        }
    }, [quizPassed, location.state, navigate, markQuizPassed, selectedLanguage]);

    useEffect(() => {
        if (isDataLoading || fetchedData.length === 0) return;
        let topic = selectedTopic;
        let sub = selectedSubtopic;
        if (!topic || !fetchedData.some(t => t.mainTopicName === topic)) {
            const fromSub = fetchedData.find(t => t.subTopics.some(s => s.title === sub))?.mainTopicName;
            topic = fromSub || fetchedData[0]?.mainTopicName || null;
        }
        const topicData = fetchedData.find(t => t.mainTopicName === topic);
        const subExists = topicData?.subTopics?.some(s => s.title === sub);
        if (!sub || !subExists) {
            sub = topicData?.subTopics?.[0]?.title || null;
        }
        if (topic !== selectedTopic) setSelectedTopic(topic);
        if (sub !== selectedSubtopic) setSelectedSubtopic(sub);
    }, [isDataLoading, fetchedData, selectedTopic, selectedSubtopic]);

    const currentTimerKey = selectedTopic && selectedLanguage ? `${selectedTopic}::${selectedLanguage}` : null;

    if (isDataLoading) return <div style={{ textAlign: 'center', marginTop: 50 }}>Loading...</div>;
    if (dataError) return <div style={{ textAlign: 'center', marginTop: 50, color: 'red' }}>{dataError}</div>;
    if (fetchedData.length === 0 || !selectedTopic || !selectedSubtopic) return <div style={{ textAlign: 'center', marginTop: 50 }}>No content.</div>;

    return (
        <div style={{ height: "100vh", display: "flex", flexDirection: "column" }}>
            <Toaster position="top-right" toastOptions={{
                success: { duration: 4000, style: { background: '#10B981', color: '#fff' } },
                error: { duration: 5000, style: { background: '#EF4444', color: '#fff' } }
            }} />
            <Navbar onLogout={onLogout} />
            <div style={{ display: "flex", flex: 1 }}>
                <Sidebar topics={fetchedData} selectedTopic={selectedTopic} setSelectedTopic={setSelectedTopic}
                    selectedSubtopic={selectedSubtopic} setSelectedSubtopic={setSelectedSubtopic} completedItems={completedItems} />
                <div style={{ flex: 1, padding: "0 30px", background: "#f6f7fb", overflowY: "auto" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
                        <div>
                            <h1 style={{ margin: 0, fontWeight: "bold", fontSize: 48 }}>{selectedTopic}</h1>
                            <h3 style={{ marginTop: 35, color: "#09122C" }}>{selectedSubtopic}</h3>
                        </div>
                        <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                            <button onClick={() => setIsModalOpen(true)} style={{
                                background: "#DD6B20", color: "#fff", padding: "8px 16px", borderRadius: 6,
                                fontSize: 14, fontWeight: 500, border: "none", cursor: "pointer", display: "flex", alignItems: "center", gap: 8
                            }}>
                                Session Contents
                            </button>
                            <TopicTimer currentTimerKey={currentTimerKey} timers={timers} />
                        </div>
                    </div>
                    <p>Learn about {selectedSubtopic} in {selectedTopic} across languages.</p>
                    <DataTypesTabs
                        selectedTopic={selectedTopic} selectedSubtopic={selectedSubtopic} completedItems={completedItems}
                        fetchedData={fetchedData} markLanguageComplete={markLanguageComplete}
                        setSelectedLanguage={setSelectedLanguage} setCompletedItems={setCompletedItems} navigate={navigate}
                    />
                </div>
            </div>
            <SessionContentsModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} selectedTopic={selectedTopic} fetchedData={fetchedData} />
        </div>
    );
}