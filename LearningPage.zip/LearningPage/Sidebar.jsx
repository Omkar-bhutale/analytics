// Sidebar.jsx
import { useState, useEffect } from "react";
import { FaChevronDown, FaChevronUp } from "react-icons/fa";
import { TbCheck } from "react-icons/tb";

export function Sidebar({ topics, selectedTopic, setSelectedTopic, selectedSubtopic, setSelectedSubtopic, completedItems }) {
    const [openTopic, setOpenTopic] = useState(selectedTopic);

    useEffect(() => setOpenTopic(selectedTopic), [selectedTopic]);

    const toggleTopic = (title) => {
        const newOpen = openTopic === title ? null : title;
        setSelectedTopic(title);
        setOpenTopic(newOpen);
        const topicEntry = topics.find(t => t.mainTopicName === title);
        if (newOpen && topicEntry?.subTopics?.length > 0) {
            const valid = topicEntry.subTopics.some(s => s.title === selectedSubtopic);
            if (!valid) setSelectedSubtopic(topicEntry.subTopics[0].title);
        }
    };

    const selectSubtopic = (subTitle) => {
        const newTopic = topics.find(t => t.subTopics.some(s => s.title === subTitle))?.mainTopicName;
        if (newTopic && newTopic !== selectedTopic) {
            setSelectedTopic(newTopic);
            setOpenTopic(newTopic);
        }
        setSelectedSubtopic(subTitle);
    };

    const isSubtopicCompleted = (main, sub) => completedItems.includes(`${main}::${sub}::subtopic_complete`);
    const isMainTopicCompleted = (main) => {
        const topic = topics.find(t => t.mainTopicName === main);
        if (!topic) return false;
        const langs = ["Java", "Python", "JavaScript", "TypeScript"];
        return topic.subTopics.every(sub =>
            langs.every(lang => completedItems.includes(`${main}::${lang}`))
        );
    };

    return (
        <div style={{ width: 220, background: "#09122C", color: "#fff", position: "sticky", top: 0, height: "100vh", overflowY: "auto", padding: "10px 0", boxSizing: "border-box" }}>
            <div style={{ fontWeight: "bold", marginLeft: 70, fontSize: 20, marginBottom: 10 }}>Topics</div>
            <ul style={{ listStyle: "none", padding: 0, margin: "16px 0" }}>
                {topics.map(mainTopic => {
                    const completed = isMainTopicCompleted(mainTopic.mainTopicName);
                    return (
                        <li key={mainTopic.mainTopicId} style={{ marginBottom: 14 }}>
                            <div onClick={() => toggleTopic(mainTopic.mainTopicName)} style={{
                                marginLeft: 13, fontWeight: 600, cursor: "pointer", fontSize: selectedTopic === mainTopic.mainTopicName ? "1.1rem" : "1rem",
                                padding: "6px 8px", marginBottom: 6, marginTop: 20, display: "flex", justifyContent: "space-between", alignItems: "center"
                            }}>
                                <span>{mainTopic.mainTopicName}</span>
                                <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                                    {completed && <TbCheck />}
                                    {openTopic === mainTopic.mainTopicName ? <FaChevronUp /> : <FaChevronDown />}
                                </div>
                            </div>
                            {openTopic === mainTopic.mainTopicName && mainTopic.subTopics.length > 0 && (
                                <ul style={{ listStyle: "none", margin: 0, paddingLeft: 26 }}>
                                    {mainTopic.subTopics.map(sub => {
                                        const comp = isSubtopicCompleted(mainTopic.mainTopicName, sub.title);
                                        return (
                                            <li key={sub.topicId} onClick={() => selectSubtopic(sub.title)} style={{
                                                marginTop: 3, cursor: "pointer", background: selectedSubtopic === sub.title ? "#DD6B20" : "transparent",
                                                fontSize: selectedSubtopic === sub.title ? "1.05rem" : "1rem", borderRadius: 4, padding: "3px 6px",
                                                display: "flex", justifyContent: "space-between", alignItems: "center"
                                            }}>
                                                <span>{sub.title}</span>
                                                {comp && <TbCheck style={{ marginLeft: 5 }} />}
                                            </li>
                                        );
                                    })}
                                </ul>
                            )}
                        </li>
                    );
                })}
            </ul>
        </div>
    );
}