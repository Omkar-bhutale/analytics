// usePersistentTopicTimers.js
import { useState, useEffect, useRef, useCallback } from "react";
import { BASE_URL, PERSISTENT_KEYS } from './constants.js';
import Cookies from "js-cookie";

export function usePersistentTopicTimers(selectedTopic, selectedSubtopic, selectedLanguage, fetchedData) {
    const [timers, setTimers] = useState({});
    const timersInitialized = useRef(false);
    const [completedItems, setCompletedItems] = useState(loadAllCompletedItems);
    const intervalRef = useRef(null);
    const lastSyncTimeRef = useRef({});

    const currentTimerKey = selectedTopic && selectedLanguage
        ? `${selectedTopic}::${selectedLanguage}`
        : null;

    const isPersistentKey = (key) => PERSISTENT_KEYS.some(suffix => key.endsWith(suffix));

    // Initialize timers from backend
    useEffect(() => {
        if (fetchedData.length > 0 && !timersInitialized.current) {
            const initialTimers = {};
            const savedTimers = JSON.parse(localStorage.getItem("topicTimers") || "{}");
            fetchedData.forEach(topic => {
                const mainTopicName = topic.mainTopicName;
                if (topic.javaTimeSeconds) initialTimers[`${mainTopicName}::Java`] = topic.javaTimeSeconds;
                if (topic.pythonTimeSeconds) initialTimers[`${mainTopicName}::Python`] = topic.pythonTimeSeconds;
                if (topic.javascriptTimeSeconds) initialTimers[`${mainTopicName}::JavaScript`] = topic.javascriptTimeSeconds;
                if (topic.typescriptTimeSeconds) initialTimers[`${mainTopicName}::TypeScript`] = topic.typescriptTimeSeconds;
            });
            const finalTimers = { ...savedTimers, ...initialTimers };
            setTimers(finalTimers);
            lastSyncTimeRef.current = { ...lastSyncTimeRef.current, ...initialTimers };
            timersInitialized.current = true;
            console.log("Timers initialized:", finalTimers);
        }
    }, [fetchedData]);

    function loadAllCompletedItems() {
        const saved = localStorage.getItem("completedQuizzes");
        return saved ? JSON.parse(saved) : [];
    }

    useEffect(() => {
        localStorage.setItem("topicTimers", JSON.stringify(timers));
    }, [timers]);

    useEffect(() => {
        const keysToSave = completedItems.filter(isPersistentKey);
        localStorage.setItem("completedQuizzes", JSON.stringify(keysToSave));
    }, [completedItems]);

    useEffect(() => {
        const updateFromStorage = () => {
            setCompletedItems(loadAllCompletedItems());
            const savedTimers = localStorage.getItem("topicTimers");
            if (savedTimers) setTimers(JSON.parse(savedTimers));
        };
        window.addEventListener("storage", updateFromStorage);
        window.addEventListener("completedQuizzesUpdated", updateFromStorage);
        return () => {
            window.removeEventListener("storage", updateFromStorage);
            window.removeEventListener("completedQuizzesUpdated", updateFromStorage);
        };
    }, []);

    const isLanguageCompletedForTopic = completedItems.includes(currentTimerKey);

    useEffect(() => {
        clearInterval(intervalRef.current);
        if (!currentTimerKey || isLanguageCompletedForTopic) return;

        intervalRef.current = setInterval(() => {
            setTimers(prev => ({
                ...prev,
                [currentTimerKey]: (prev[currentTimerKey] || 0) + 1,
            }));
        }, 1000);
        return () => clearInterval(intervalRef.current);
    }, [currentTimerKey, isLanguageCompletedForTopic]);

    const findTopicId = useCallback((topic, subtopic) => {
        const topicData = fetchedData.find(t => t.mainTopicName === topic);
        const subtopicData = topicData?.subTopics?.find(s => s.title === subtopic);
        return subtopicData?.topicId;
    }, [fetchedData]);

    // Sync logic (periodic + visibility + unload)
    useEffect(() => {
        if (!currentTimerKey || isLanguageCompletedForTopic || !selectedSubtopic) return;

        const syncTime = () => {
            const [topic, language] = currentTimerKey.split('::');
            const currentTime = timers[currentTimerKey] || 0;
            const lastSyncTime = lastSyncTimeRef.current[currentTimerKey] || 0;
            const timeSinceLastSync = currentTime - lastSyncTime;

            if (timeSinceLastSync > 0) {
                const currentSubtopicId = findTopicId(topic, selectedSubtopic);
                if (currentSubtopicId) {
                    const payload = {
                        topicId: currentSubtopicId,
                        language: language.toUpperCase(),
                        timeSpentSeconds: timeSinceLastSync,
                    };
                    const token = Cookies.get('token');
                    fetch(`${BASE_URL}/user/topic-engagement/language`, {
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json',
                            ...(token && { 'Authorization': `Bearer ${token}` })
                        },
                        body: JSON.stringify(payload),
                        keepalive: true
                    }).then(r => {
                        if (r.ok) {
                            console.log(`Synced ${timeSinceLastSync}s for ${selectedSubtopic}`);
                            lastSyncTimeRef.current[currentTimerKey] = currentTime;
                        }
                    }).catch(console.error);
                }
            }
        };

        const syncInterval = setInterval(() => {
            const currentTime = timers[currentTimerKey] || 0;
            const lastSyncTime = lastSyncTimeRef.current[currentTimerKey] || 0;
            if (currentTime - lastSyncTime >= 10) syncTime();
        }, 30000);

        const handleVisibility = () => document.visibilityState === 'hidden' && syncTime();
        window.addEventListener('visibilitychange', handleVisibility);

        return () => {
            clearInterval(syncInterval);
            window.removeEventListener('visibilitychange', handleVisibility);
            syncTime();
        };
    }, [currentTimerKey, isLanguageCompletedForTopic, selectedSubtopic, findTopicId, timers]);

    // Subtopic switch sync
    const prevSubtopicRef = useRef(selectedSubtopic);
    useEffect(() => {
        if (prevSubtopicRef.current !== selectedSubtopic && prevSubtopicRef.current) {
            const prevKey = currentTimerKey;
            if (prevKey) {
                const [topic, language] = prevKey.split('::');
                const currentTime = timers[prevKey] || 0;
                const lastSyncTime = lastSyncTimeRef.current[prevKey] || 0;
                const timeToSync = currentTime - lastSyncTime;
                if (timeToSync > 0) {
                    const subtopicId = findTopicId(topic, prevSubtopicRef.current);
                    if (subtopicId) {
                        const payload = { topicId: subtopicId, language: language.toUpperCase(), timeSpentSeconds: timeToSync };
                        const token = Cookies.get('token');
                        fetch(`${BASE_URL}/user/topic-engagement/language`, {
                            method: 'PUT',
                            headers: { 'Content-Type': 'application/json', ...(token && { 'Authorization': `Bearer ${token}` }) },
                            body: JSON.stringify(payload),
                            keepalive: true
                        }).then(() => {
                            lastSyncTimeRef.current[prevKey] = currentTime;
                        }).catch(console.error);
                    }
                }
            }
        }
        prevSubtopicRef.current = selectedSubtopic;
    }, [selectedSubtopic, currentTimerKey, findTopicId, timers]);

    // Final sync on language completion
    useEffect(() => {
        const newlyCompleted = completedItems.filter(k => k.split('::').length === 2 && PERSISTENT_KEYS.some(s => k.endsWith(s)));
        newlyCompleted.forEach(key => {
            const [topic, language] = key.split('::');
            const topicData = fetchedData.find(t => t.mainTopicName === topic);
            const subtopics = topicData?.subTopics || [];
            const totalTime = timers[key] || 0;
            const lastSync = lastSyncTimeRef.current[key] || 0;
            const remaining = totalTime - lastSync;
            if (remaining > 0 && subtopics.length > 0) {
                const perSub = Math.floor(remaining / subtopics.length);
                subtopics.forEach(sub => {
                    fetch(`${BASE_URL}/user/topic-engagement/language`, {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ topicId: sub.topicId, language: language.toUpperCase(), timeSpentSeconds: perSub }),
                        keepalive: true
                    }).catch(console.error);
                });
                lastSyncTimeRef.current[key] = totalTime;
            }
        });
    }, [completedItems, timers, fetchedData]);

    const checkSubtopicAndTopicCompletion = useCallback((topic, subtopic, updatedItems) => {
        const allLangsComplete = ['Java', 'Python', 'JavaScript', 'TypeScript'].every(
            lang => updatedItems.includes(`${topic}::${lang}`)
        );
        const isQuizPassed = updatedItems.includes(`${topic}::${subtopic}::passed`);
        if (allLangsComplete && isQuizPassed) {
            const key = `${topic}::${subtopic}::subtopic_complete`;
            if (!updatedItems.includes(key)) updatedItems.push(key);
        }
        const topicData = fetchedData.find(t => t.mainTopicName === topic);
        const allSubComplete = topicData?.subTopics.every(s => updatedItems.includes(`${topic}::${s.title}::subtopic_complete`));
        if (allSubComplete) {
            const key = `${topic}::main_topic_complete`;
            if (!updatedItems.includes(key)) updatedItems.push(key);
        }
        return updatedItems;
    }, [fetchedData]);

    const markLanguageComplete = useCallback((topic, subtopic, language) => {
        const key = `${topic}::${language}`;
        setCompletedItems(prev => {
            if (prev.includes(key)) return prev;
            let updated = [...prev, key];
            const topicData = fetchedData.find(t => t.mainTopicName === topic);
            topicData?.subTopics.forEach(s => {
                updated = checkSubtopicAndTopicCompletion(topic, s.title, updated);
            });
            if (topicData?.mainTopicId) {
                fetch(`${BASE_URL}/user/user-main-topic-engagement/${topicData.mainTopicId}/validate-completion?language=${language.toUpperCase()}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' }
                }).then(r => r.json()).then(data => {
                    if (data?.success) {
                        window.toast?.success?.(data.message || `${language} completed!`);
                    }
                }).catch(err => {
                    setCompletedItems(p => p.filter(i => i !== key));
                    window.toast?.error?.(err.response?.data?.message || "Validation failed");
                });
            }
            return updated;
        });
    }, [checkSubtopicAndTopicCompletion, fetchedData]);

    const markQuizPassed = useCallback((topic, subtopic, language) => {
        const key = `${topic}::${subtopic}::passed`;
        setCompletedItems(prev => {
            if (prev.includes(key)) return prev;
            const updated = [...prev, key];
            const topicData = fetchedData.find(t => t.mainTopicName === topic);
            const subData = topicData?.subTopics?.find(s => s.title === subtopic);
            if (subData?.topicId && language) {
                fetch(`${BASE_URL}/user/topic-engagement/${subData.topicId}/mcq-visited?language=${language.toUpperCase()}`, {
                    method: 'PUT'
                }).then(() => {
                    window.toast?.success?.(`${language} MCQ completed!`);
                }).catch(() => {
                    window.toast?.error?.("Failed to save MCQ");
                });
            }
            return checkSubtopicAndTopicCompletion(topic, subtopic, updated);
        });
    }, [checkSubtopicAndTopicCompletion, fetchedData]);

    return {
        timers,
        completedItems,
        setCompletedItems,
        markLanguageComplete,
        markQuizPassed,
    };
}