// constants.js
export const BASE_URL = import.meta.env.VITE_API_BASE_URL;

export const questionMap = {
    Java: "java_intro",
    Python: "python_intro",
    JavaScript: "js_intro",
    TypeScript: "ts_intro",
};

export const PERSISTENT_KEYS = [
    "::passed",
    "::subtopic_complete",
    "::main_topic_complete",
    "::Java",
    "::Python",
    "::JavaScript",
    "::TypeScript"
];