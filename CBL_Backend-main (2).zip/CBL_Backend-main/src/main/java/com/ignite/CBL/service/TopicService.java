package com.ignite.CBL.service;

import com.ignite.CBL.dto.TopicDTO;
import com.ignite.CBL.entity.Topic;

import java.util.List;

public interface TopicService {


    TopicDTO findByTopicId(Integer topicId);
    TopicDTO findByTitle(String title);
    List<TopicDTO> findAllByMainTopicId(Integer mainTopicId);
    TopicDTO addTopic(Integer mainTopicId, TopicDTO topicDTO);
    Integer addTopics(Integer mainTopicId, List<TopicDTO> topicDTOs);
    void deleteTopicById(Integer topicId);
    void deleteAllByMainTopicId(Integer mainTopicId);
    void deleteAll();
}
