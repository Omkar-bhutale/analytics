package com.ignite.CBL.service.impl;


import com.ignite.CBL.dto.MCQDTO;
import com.ignite.CBL.entity.MCQ;
import com.ignite.CBL.entity.Topic;
import com.ignite.CBL.repository.MCQRepository;
import com.ignite.CBL.repository.TopicRepository;
import com.ignite.CBL.service.MCQService;
import jakarta.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MCQServiceImpl implements MCQService {

    private MCQRepository mcqRepository;
    private ModelMapper modelMapper;
    private TopicRepository topicRepository;

    public MCQServiceImpl(MCQRepository mcqRepository,TopicRepository topicRepository) {
        this.mcqRepository = mcqRepository;
        this.topicRepository = topicRepository;
    }



    @Override
    public List<MCQDTO> findAllMCQByTopicId(Integer topicId) {
        return mcqRepository.findAllByTopicId(topicId);
    }

    @Override
    public MCQDTO addMCQ(Integer topicId, MCQDTO mcqDTO) {

        Topic topic = topicRepository.findById(topicId)
                .orElseThrow(() -> new RuntimeException("Topic not found"));

        MCQ mcq = MCQ.builder()
                .question(mcqDTO.getQuestion())
                .options(mcqDTO.getOptions())
                .topic(topic)
                .build();
        mcqRepository.save(mcq);

        return  modelMapper.map(mcq, MCQDTO.class);
    }

    @Override
    public Integer addMCQs(Integer topicId, List<MCQDTO> mcqDTOs) {

        Topic topic = topicRepository.findById(topicId)
                .orElseThrow(() -> new RuntimeException("Topic not found"));

        for (MCQDTO mcqDTO : mcqDTOs) {
            MCQ mcq = MCQ.builder()
                    .question(mcqDTO.getQuestion())
                    .options(mcqDTO.getOptions())
                    .topic(topic)
                    .build();
            mcqRepository.save(mcq);
        }
        return mcqDTOs.size();
    }

    @Override
    @Transactional
    public void deleteAllMCQByTopicId(Integer topicId) {
        mcqRepository.deleteAllByTopic_TopicId(topicId);

    }

    @Override
    @Transactional
    public void deleteMCQById(Integer mcqId) {
        mcqRepository.deleteById(mcqId);
    }

    @Override
    @Transactional
    public void deleteAllMCQ() {
        mcqRepository.deleteAll();
    }
}


