package com.ignite.CBL.dto;

import com.fasterxml.jackson.databind.JsonNode;
import com.ignite.CBL.entity.TopicContent;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TopicDTO {
    private Integer topicId;
    private String title;
    private JsonNode content;
    private LocalDateTime createdAt;
}
