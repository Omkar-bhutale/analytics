package com.ignite.CBL.repository;

import com.ignite.CBL.dto.TopicDTO;
import com.ignite.CBL.entity.Topic;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface TopicRepository extends JpaRepository<Topic, Integer> {
    @Query("SELECT new com.ignite.CBL.dto.TopicDTO(t.topicId, t.title, t.content, t.createdAt) FROM Topic t WHERE t.topicId = :topicId")
    TopicDTO findByTopicId(Integer topicId);
    @Query("SELECT  new com.ignite.CBL.dto.TopicDTO(t.topicId, t.title, t.content, t.createdAt) FROM Topic t WHERE t.title = :title")
    TopicDTO findByTitle(String title);

    @Query("SELECT new com.ignite.CBL.dto.TopicDTO(t.topicId, t.title, t.content, t.createdAt) " +
            "FROM Topic t WHERE t.mainTopic.mainTopicId = :mainTopicId")
    List<TopicDTO> findAllByMainTopicId(@Param("mainTopicId") Integer mainTopicId);

    void deleteAllByMainTopic_MainTopicId(Integer mainTopicId);







}
