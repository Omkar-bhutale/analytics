package com.ignite.CBL.repository;

import com.ignite.CBL.dto.MCQDTO;
import com.ignite.CBL.entity.MCQ;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface MCQRepository extends JpaRepository<MCQ, Integer> {

    @Query("SELECT new com.ignite.CBL.dto.MCQDTO(m.mcqId, m.question, m.options) FROM MCQ m WHERE m.topic.topicId = :topicId")
    List<MCQDTO> findAllByTopicId(@Param("topicId") Integer topicId);

    void deleteAllByTopic_TopicId(Integer topicTopicId);

    


}
