package com.ignite.CBL.controller;

import com.ignite.CBL.dto.TopicDTO;
import com.ignite.CBL.entity.Topic;
import com.ignite.CBL.service.TopicService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/topic")
public class TopicController {
    private TopicService topicService;

    public TopicController(TopicService topicService) {
        this.topicService = topicService;
    }



    @GetMapping("/byTitle/{title}")
    public ResponseEntity<TopicDTO> findByTitle(@PathVariable String title) {
        return ResponseEntity.ok(topicService.findByTitle(title));
    }

    @GetMapping("/allByTopicId/{topicId}")
    public ResponseEntity<TopicDTO> findByTopicId(@PathVariable Integer topicId) {
        return ResponseEntity.ok(topicService.findByTopicId(topicId));
    }
    @GetMapping("/main/{mainTopicId}")
    public ResponseEntity<List<TopicDTO>> getTopicsByMainTopic(@PathVariable Integer mainTopicId) {
        return ResponseEntity.ok(topicService.findAllByMainTopicId(mainTopicId));
    }

    @PostMapping("/add/{mainTopicId}")
    public ResponseEntity<TopicDTO> addTopic(@PathVariable Integer mainTopicId, @RequestBody TopicDTO topicDTO) {
        return ResponseEntity.ok(topicService.addTopic(mainTopicId, topicDTO));
    }

    @PostMapping("/addMultiple/{mainTopicId}")
    public ResponseEntity<Integer> addTopics(@PathVariable Integer mainTopicId, @RequestBody List<TopicDTO> topicDTOs) {
        return ResponseEntity.ok(topicService.addTopics(mainTopicId, topicDTOs));
    }

    @DeleteMapping("/delete/{topicId}")
    public ResponseEntity<Void> deleteTopicById(@PathVariable Integer topicId) {
        topicService.deleteTopicById(topicId);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/delete-all-by-main/{mainTopicId}")
    public ResponseEntity<Void> deleteAllByMainTopic(@PathVariable Integer mainTopicId) {
        topicService.deleteAllByMainTopicId(mainTopicId);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/delete-all")
    public ResponseEntity<Void> deleteAllTopics() {
        topicService.deleteAll();
        return ResponseEntity.ok().build();
    }
}
