package com.ignite.CBL.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data

public class McqOptions {

    private List<String> optionList;

    private Integer correctOptionIndex;
    
    // Default constructor for JSON deserialization
    public McqOptions() {}
    
    public McqOptions(List<String> optionList, Integer correctOptionIndex) {
        this.optionList = optionList;
        this.correctOptionIndex = correctOptionIndex;
    }
}
