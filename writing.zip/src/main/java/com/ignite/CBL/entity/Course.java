package com.ignite.CBL.entity;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "Courses")
@Getter
@Setter
@JsonIdentityInfo(
    generator = ObjectIdGenerators.PropertyGenerator.class,
    property = "courseId"
)
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "course_id")
    private Integer courseId;

    @Column(name = "title", nullable = false)
    private String title;

    @Column(name = "description", columnDefinition = "text")
    private String description;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    // Many-to-One: Many courses can be created by one user.
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "creator_id")
    private User creator;



    // One-to-Many: One Course can be part of many Batch assignments.
    @OneToMany(
            mappedBy = "course",
            cascade = CascadeType.ALL,
            orphanRemoval = true
    )
    private Set<BatchCourseAssignment> batchAssignments = new HashSet<>();

    @ManyToMany(mappedBy = "courses")
    private Set<MainTopic> mainTopics = new HashSet<>();

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    // Helper methods for bidirectional relationship management
    public void addMainTopic(MainTopic mainTopic) {
        mainTopics.add(mainTopic);
        mainTopic.getCourses().add(this);
    }

    public void removeMainTopic(MainTopic mainTopic) {
        mainTopics.remove(mainTopic);
        mainTopic.getCourses().remove(this);
    }
}