package com.ignite.CBL.entity;

public enum Language {
    JAVA,
    PYTHON,
    JAVASCRIPT,
    TYPESCRIPT
}
