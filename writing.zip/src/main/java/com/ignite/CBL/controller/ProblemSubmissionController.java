package com.ignite.CBL.controller;

import com.ignite.CBL.dto.*;
import com.ignite.CBL.entity.Difficulty;
import com.ignite.CBL.service.ProblemSubmissionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user/problem-submissions")
@RequiredArgsConstructor
@Tag(name = "Problem Submission", description = "Problem submission and code execution APIs")
public class ProblemSubmissionController {

    private final ProblemSubmissionService problemSubmissionService;

    @GetMapping("/{problemId}")
    @Operation(summary = "Get problem to solve", description = "Retrieves problem details with saved code and time spent. Requires correct algorithm and pseudocode submissions.")
    public ResponseEntity<ProblemCodeResponceDTO> getProblemToSolve(@PathVariable Integer problemId) {
        ProblemCodeResponceDTO response = problemSubmissionService.getProblemToSolve(problemId);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/{problemId}/submissions")
    @Operation(summary = "Get all submissions for a problem", description = "Retrieves all problem submissions for a specific problem and user")
    public ResponseEntity<List<ProblemSubmissionResponceDTO>> getAllSubmissions(@PathVariable Integer problemId) {
        List<ProblemSubmissionResponceDTO> response = problemSubmissionService.getAllSubmissions(problemId);
        return ResponseEntity.ok(response);
    }

    @PutMapping("/submission")
    @Operation(summary = "Save problem submission", description = "Saves or updates a problem submission with code, test result")
    public ResponseEntity<Boolean> saveSubmission(@Valid @RequestBody ProblemSubmissionRequestDTO problemSubmissionRequestDTO) {
        boolean result = problemSubmissionService.saveSubmission(problemSubmissionRequestDTO);
        return ResponseEntity.ok(result);
    }
    
    @PutMapping("/save-code")
    @Operation(summary = "Save code and time", description = "Saves the current code and time spent on a problem")
    public ResponseEntity<Void> saveCodeAndTime(@Valid @RequestBody SaveCodeAndTimeRequest saveCodeAndTimeRequest) {
        problemSubmissionService.saveCodeAndTime(saveCodeAndTimeRequest);
        return ResponseEntity.ok().build();
    }
    @Operation(summary = "Get random problem",
            description = "Get a random problem ID by topic and difficulty")
    @GetMapping("/random")
    public ProblemCodeResponceDTO getRandomProblem(
            @Parameter(description = "ID of the topic") @RequestParam Integer topicId,
            @Parameter(description = "Difficulty level",
                    schema = @Schema(implementation = Difficulty.class))
            @RequestParam Difficulty difficulty) {
        return problemSubmissionService.getRandomProblem(topicId, difficulty);
    }
    
    @Operation(summary = "Get all problems",
            description = "Get a list of all problems with their topics")
    @GetMapping("/all")
    public ResponseEntity<List<MainTopicSubTopicsResponceDTO>> getAllProblems() {
        return ResponseEntity.ok(problemSubmissionService.getAllProblems());
    }
}