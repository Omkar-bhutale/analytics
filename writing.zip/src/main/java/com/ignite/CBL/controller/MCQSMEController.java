package com.ignite.CBL.controller;

import com.ignite.CBL.dto.MCQDTO;
import com.ignite.CBL.service.MCQService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/sme/mcqs")
@RequiredArgsConstructor
@Tag(name = "MCQ Management")
public class MCQSMEController {

    private final MCQService mcqService;

    @Operation(summary = "Get MCQ by ID")
    @GetMapping("/{id}")
    public ResponseEntity<MCQDTO> getMCQById(@PathVariable Integer id) {
        return mcqService.findMCQById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Get all MCQs by topic ID")
    @GetMapping("/topic/{topicId}")
    public ResponseEntity<List<MCQDTO>> getAllMCQsByTopicId(@PathVariable Integer topicId) {
        return ResponseEntity.ok(mcqService.findAllMCQByTopicId(topicId));
    }

//    @Operation(summary = "Get paginated MCQs by topic ID")
//    @GetMapping("/topic/{topicId}/page")
//    public ResponseEntity<Page<MCQDTO>> getPaginatedMCQsByTopicId(
//            @PathVariable Integer topicId,
//            @PageableDefault(size = 10) Pageable pageable) {
//        return ResponseEntity.ok(mcqService.findPaginatedMCQByTopicId(topicId, pageable));
//    }

    @Operation(summary = "Create a new MCQ")
    @PostMapping("/topic/{topicId}")
    public ResponseEntity<MCQDTO> createMCQ(
            @PathVariable Integer topicId,
            @RequestBody MCQDTO mcqDTO) {
        return new ResponseEntity<>(mcqService.createMCQ(topicId, mcqDTO), HttpStatus.CREATED);
    }

    @Operation(summary = "Create multiple MCQs")
    @PostMapping("/topic/{topicId}/batch")
    public ResponseEntity<Integer> createMCQs(
            @PathVariable Integer topicId,
            @RequestBody List<MCQDTO> mcqDTOs) {
        return new ResponseEntity<>(mcqService.createMCQs(topicId, mcqDTOs), HttpStatus.CREATED);
    }

    @Operation(summary = "Update an existing MCQ")
    @PutMapping("/{id}")
    public ResponseEntity<MCQDTO> updateMCQ(
            @PathVariable Integer id,
            @RequestBody MCQDTO mcqDTO) {
        return mcqService.updateMCQ(id, mcqDTO)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Delete an MCQ")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMCQ(@PathVariable Integer id) {
        return mcqService.deleteMCQById(id)
                ? ResponseEntity.noContent().build()
                : ResponseEntity.notFound().build();
    }

    @Operation(summary = "Delete all MCQs by topic ID")
    @DeleteMapping("/topic/{topicId}")
    public ResponseEntity<Void> deleteAllMCQsByTopicId(@PathVariable Integer topicId) {
        mcqService.deleteAllMCQByTopicId(topicId);
        return ResponseEntity.noContent().build();
    }

    @Operation(summary = "Count MCQs by topic ID")
    @GetMapping("/topic/{topicId}/count")
    public ResponseEntity<Long> countByTopicId(@PathVariable Integer topicId) {
        return ResponseEntity.ok(mcqService.countByTopicId(topicId));
    }

    @Operation(summary = "Check if MCQ exists")
    @GetMapping("/{id}/exists")
    public ResponseEntity<Boolean> existsById(@PathVariable Integer id) {
        return ResponseEntity.ok(mcqService.existsById(id));
    }
}
