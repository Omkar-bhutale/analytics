package com.ignite.CBL.controller;

import com.ignite.CBL.dto.UserDashboardResponceDTO;
import com.ignite.CBL.service.UserDashboardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user/dashboard")
public class UserDashboardController {

    private final UserDashboardService userDashboardService;

    @Autowired
    public UserDashboardController(UserDashboardService userDashboardService) {
        this.userDashboardService = userDashboardService;
    }

    @GetMapping
    public ResponseEntity<UserDashboardResponceDTO> getUserDashboard() {
        UserDashboardResponceDTO dashboardData = userDashboardService.getUserDashboard();
        return ResponseEntity.ok(dashboardData);
    }
}
