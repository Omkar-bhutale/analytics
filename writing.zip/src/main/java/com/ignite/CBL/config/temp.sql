-- Sample Users for Educational Platform
INSERT INTO users (user_id, email, name, created_at, insights) VALUES
                                                                   ('5284917', 'alice.johnson@email.com', 'alice_johnson', CURRENT_TIMESTAMP, '{"preferred_language": "JAVA", "learning_style": "visual"}'),
                                                                   ('1638429', 'bob.smith@email.com', 'bob_smith', CURRENT_TIMESTAMP, '{"preferred_language": "PYTHON", "learning_style": "hands_on"}'),
                                                                   ('7952031', 'carol.davis@email.com', 'carol_davis', CURRENT_TIMESTAMP, '{"preferred_language": "JAVASCRIPT", "learning_style": "theoretical"}'),
                                                                   ('4286754', 'david.wilson@email.com', 'david_wilson', CURRENT_TIMESTAMP, '{"preferred_language": "TYPESCRIPT", "learning_style": "practical"}'),
                                                                   ('9120385', 'emma.brown@email.com', 'emma_brown', CURRENT_TIMESTAMP, '{"preferred_language": "JAVA", "learning_style": "balanced"}'),
                                                                   ('3461892', 'frank.miller@email.com', 'frank_miller', CURRENT_TIMESTAMP, '{"preferred_language": "PYTHON", "learning_style": "fast_paced"}'),
                                                                   ('6704923', 'grace.taylor@email.com', 'grace_taylor', CURRENT_TIMESTAMP, '{"preferred_language": "JAVASCRIPT", "learning_style": "detailed"}'),
                                                                   ('2839156', 'henry.anderson@email.com', 'henry_anderson', CURRENT_TIMESTAMP, '{"preferred_language": "TYPESCRIPT", "learning_style": "structured"}'),
                                                                   ('5197280', 'isabella.martin@email.com', 'isabella_martin', CURRENT_TIMESTAMP, '{"preferred_language": "JAVA", "learning_style": "collaborative"}'),
                                                                   ('8743012', 'jack.thomas@email.com', 'jack_thomas', CURRENT_TIMESTAMP, '{"preferred_language": "PYTHON", "learning_style": "independent"}');


-- Create Courses by user 5284917 (Alice Johnson)
INSERT INTO courses (course_id, title, description, creator_id, created_at) VALUES
                                                                                (1, 'Java Programming Mastery', 'Comprehensive Java course covering from basics to advanced concepts including OOP, data structures, and algorithms', '5284917', CURRENT_TIMESTAMP),
                                                                                (2, 'Python Development Journey', 'Complete Python programming course focusing on practical applications, automation, and data handling', '5284917', CURRENT_TIMESTAMP),
                                                                                (3, 'Modern JavaScript Essentials', 'Full-stack JavaScript development covering ES6+, Node.js, and frontend frameworks', '5284917', CURRENT_TIMESTAMP),
                                                                                (4, 'TypeScript Professional Development', 'TypeScript mastery for scalable applications with type safety and modern development practices', '5284917', CURRENT_TIMESTAMP);


-- Create Main Topics for Java Programming Mastery (Course ID: 1)
INSERT INTO main_topics (main_topic_id, title, description, creator_id, created_at) VALUES
                                                                                        (1, 'Java Data Types & Variables', 'Learn about primitive data types, variables, type casting, and constants in Java', '5284917', CURRENT_TIMESTAMP),
                                                                                        (2, 'Conditional Statements', 'Master if, if-else, switch statements and logical operators for decision making', '5284917', CURRENT_TIMESTAMP),
                                                                                        (3, 'Loops & Iteration', 'Understand for, while, do-while loops and control flow statements', '5284917', CURRENT_TIMESTAMP),
                                                                                        (4, 'Methods & Functions', 'Learn to create, call methods, parameters, return types and method overloading', '5284917', CURRENT_TIMESTAMP),
                                                                                        (5, 'String Manipulation', 'Master String class methods, concatenation, comparison and common operations', '5284917', CURRENT_TIMESTAMP),
                                                                                        (6, 'Arrays & Collections', 'Understand array declaration, manipulation, multi-dimensional arrays and basic collections', '5284917', CURRENT_TIMESTAMP);

-- Link Main Topics to Java Course (Course ID: 1)
INSERT INTO course_main_topics (course_id, main_topic_id) VALUES
                                                              (1, 1), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6);






-- Topics for Main Topic 1: Java Data Types & Variables
INSERT INTO topics (main_topic_id, title, created_at, creator_id, content) VALUES
                                                                               (1, 'Primitive Data Types', CURRENT_TIMESTAMP, '5284917', '{
  "explaination": "Basic data types provided by Java language that store simple values directly in memory",
  "language_details": [
    {
      "language": "Java",
      "syntax": "byte, short, int, long, float, double, char, boolean",
      "example": "int age = 25;\ndouble salary = 50000.50;\nchar grade = ''A'';\nboolean isActive = true;"
    },
    {
      "language": "Python",
      "syntax": "int, float, str, bool",
      "example": "age = 25\nsalary = 50000.50\ngrade = ''A''\nis_active = True"
    },
    {
      "language": "JavaScript",
      "syntax": "Number, String, Boolean, undefined, null",
      "example": "let age = 25;\nlet salary = 50000.50;\nlet grade = ''A'';\nlet isActive = true;"
    },
    {
      "language": "TypeScript",
      "syntax": "number, string, boolean, undefined, null",
      "example": "let age: number = 25;\nlet salary: number = 50000.50;\nlet grade: string = ''A'';\nlet isActive: boolean = true;"
    }
  ],
  "code_difference_explaination": "Java has more specific numeric types (byte, short, int, long) while Python and JavaScript/TypeScript have more simplified type systems. Java requires explicit type declaration while others use type inference."
}'),
                                                                               (1, 'Variables Declaration', CURRENT_TIMESTAMP, '5284917', '{
  "explaination": "Ways to declare and initialize variables in different programming languages",
  "language_details": [
    {
      "language": "Java",
      "syntax": "dataType variableName = value;",
      "example": "int count = 10;\nString name = \"John\";\nfinal double PI = 3.14;"
    },
    {
      "language": "Python",
      "syntax": "variable_name = value",
      "example": "count = 10\nname = \"John\"\nPI = 3.14"
    },
    {
      "language": "JavaScript",
      "syntax": "let variableName = value; const constantName = value;",
      "example": "let count = 10;\nconst name = \"John\";\nconst PI = 3.14;"
    },
    {
      "language": "TypeScript",
      "syntax": "let variableName: type = value; const constantName: type = value;",
      "example": "let count: number = 10;\nconst name: string = \"John\";\nconst PI: number = 3.14;"
    }
  ],
  "code_difference_explaination": "Java requires explicit type declaration, Python uses dynamic typing, JavaScript uses let/const with type inference, and TypeScript adds static typing to JavaScript syntax."
}'),
                                                                               (1, 'Type Casting', CURRENT_TIMESTAMP, '5284917', '{
  "explaination": "Converting one data type to another, either implicitly or explicitly",
  "language_details": [
    {
      "language": "Java",
      "syntax": "(targetType) variable",
      "example": "double salary = 50000.75;\nint intSalary = (int) salary; // 50000\nString str = String.valueOf(100);"
    },
    {
      "language": "Python",
      "syntax": "target_type(variable)",
      "example": "salary = 50000.75\nint_salary = int(salary) # 50000\nstr_value = str(100)"
    },
    {
      "language": "JavaScript",
      "syntax": "Number(), String(), Boolean()",
      "example": "let salary = 50000.75;\nlet intSalary = parseInt(salary); // 50000\nlet strValue = String(100);"
    },
    {
      "language": "TypeScript",
      "syntax": "Number(), String(), Boolean() or as keyword",
      "example": "let salary: number = 50000.75;\nlet intSalary: number = parseInt(salary.toString());\nlet strValue: string = String(100);"
    }
  ],
  "code_difference_explaination": "Java uses explicit casting with parentheses, Python uses function-style casting, JavaScript uses built-in functions, and TypeScript combines JavaScript methods with type assertions."
}');

-- Topics for Main Topic 2: Conditional Statements
INSERT INTO topics (main_topic_id, title, created_at, creator_id, content) VALUES
                                                                               (2, 'If-Else Statements', CURRENT_TIMESTAMP, '5284917', '{
  "explaination": "Conditional execution of code blocks based on boolean expressions",
  "language_details": [
    {
      "language": "Java",
      "syntax": "if (condition) { // code } else { // code }",
      "example": "int score = 85;\nif (score >= 90) {\n    System.out.println(\"A grade\");\n} else if (score >= 75) {\n    System.out.println(\"B grade\");\n} else {\n    System.out.println(\"C grade\");\n}"
    },
    {
      "language": "Python",
      "syntax": "if condition: # code elif condition: # code else: # code",
      "example": "score = 85\nif score >= 90:\n    print(\"A grade\")\nelif score >= 75:\n    print(\"B grade\")\nelse:\n    print(\"C grade\")"
    },
    {
      "language": "JavaScript",
      "syntax": "if (condition) { // code } else if (condition) { // code } else { // code }",
      "example": "let score = 85;\nif (score >= 90) {\n    console.log(\"A grade\");\n} else if (score >= 75) {\n    console.log(\"B grade\");\n} else {\n    console.log(\"C grade\");\n}"
    },
    {
      "language": "TypeScript",
      "syntax": "if (condition) { // code } else if (condition) { // code } else { // code }",
      "example": "let score: number = 85;\nif (score >= 90) {\n    console.log(\"A grade\");\n} else if (score >= 75) {\n    console.log(\"B grade\");\n} else {\n    console.log(\"C grade\");\n}"
    }
  ],
  "code_difference_explaination": "All languages use similar if-else syntax. Java and JavaScript/TypeScript require parentheses around conditions and curly braces for code blocks, while Python uses colons and indentation."
}'),
                                                                               (2, 'Switch Statements', CURRENT_TIMESTAMP, '5284917', '{
  "explaination": "Multi-way branching statement that executes code based on matching cases",
  "language_details": [
    {
      "language": "Java",
      "syntax": "switch (expression) { case value: // code break; default: // code }",
      "example": "int day = 3;\nswitch (day) {\n    case 1: System.out.println(\"Monday\"); break;\n    case 2: System.out.println(\"Tuesday\"); break;\n    case 3: System.out.println(\"Wednesday\"); break;\n    default: System.out.println(\"Other day\");\n}"
    },
    {
      "language": "Python",
      "syntax": "match expression: case pattern: # code case _: # code",
      "example": "day = 3\nmatch day:\n    case 1: print(\"Monday\")\n    case 2: print(\"Tuesday\")\n    case 3: print(\"Wednesday\")\n    case _: print(\"Other day\")"
    },
    {
      "language": "JavaScript",
      "syntax": "switch (expression) { case value: // code break; default: // code }",
      "example": "let day = 3;\nswitch (day) {\n    case 1: console.log(\"Monday\"); break;\n    case 2: console.log(\"Tuesday\"); break;\n    case 3: console.log(\"Wednesday\"); break;\n    default: console.log(\"Other day\");\n}"
    },
    {
      "language": "TypeScript",
      "syntax": "switch (expression) { case value: // code break; default: // code }",
      "example": "let day: number = 3;\nswitch (day) {\n    case 1: console.log(\"Monday\"); break;\n    case 2: console.log(\"Tuesday\"); break;\n    case 3: console.log(\"Wednesday\"); break;\n    default: console.log(\"Other day\");\n}"
    }
  ],
  "code_difference_explaination": "Java, JavaScript and TypeScript use traditional switch statements with break. Python uses the newer match-case syntax (introduced in 3.10) which is more powerful and doesn''t require break statements."
}'),
                                                                               (2, 'Ternary Operator', CURRENT_TIMESTAMP, '5284917', '{
  "explaination": "Short-hand conditional operator that returns one of two values based on a condition",
  "language_details": [
    {
      "language": "Java",
      "syntax": "condition ? valueIfTrue : valueIfFalse",
      "example": "int age = 20;\nString status = (age >= 18) ? \"Adult\" : \"Minor\";\nSystem.out.println(status); // Adult"
    },
    {
      "language": "Python",
      "syntax": "value_if_true if condition else value_if_false",
      "example": "age = 20\nstatus = \"Adult\" if age >= 18 else \"Minor\"\nprint(status) # Adult"
    },
    {
      "language": "JavaScript",
      "syntax": "condition ? valueIfTrue : valueIfFalse",
      "example": "let age = 20;\nlet status = (age >= 18) ? \"Adult\" : \"Minor\";\nconsole.log(status); // Adult"
    },
    {
      "language": "TypeScript",
      "syntax": "condition ? valueIfTrue : valueIfFalse",
      "example": "let age: number = 20;\nlet status: string = (age >= 18) ? \"Adult\" : \"Minor\";\nconsole.log(status); // Adult"
    }
  ],
  "code_difference_explaination": "Java, JavaScript and TypeScript use the same ? : ternary operator syntax. Python uses a different but more readable syntax with the condition in the middle."
}');

-- Continue similarly for other main topics (Loops, Methods, Strings, Arrays)
-- Topics for Main Topic 3: Loops & Iteration
INSERT INTO topics (main_topic_id, title, created_at, creator_id, content) VALUES
                                                                               (3, 'For Loops', CURRENT_TIMESTAMP, '5284917', '{
  "explaination": "Iterate over a sequence or range for a specific number of times",
  "language_details": [
    {
      "language": "Java",
      "syntax": "for (initialization; condition; increment) { // code }",
      "example": "for (int i = 0; i < 5; i++) {\n    System.out.println(\"Count: \" + i);\n}\n// Output: Count: 0 to Count: 4"
    },
    {
      "language": "Python",
      "syntax": "for variable in sequence: # code",
      "example": "for i in range(5):\n    print(f\"Count: {i}\")\n# Output: Count: 0 to Count: 4"
    },
    {
      "language": "JavaScript",
      "syntax": "for (initialization; condition; increment) { // code }",
      "example": "for (let i = 0; i < 5; i++) {\n    console.log(\"Count: \" + i);\n}\n// Output: Count: 0 to Count: 4"
    },
    {
      "language": "TypeScript",
      "syntax": "for (initialization; condition; increment) { // code }",
      "example": "for (let i: number = 0; i < 5; i++) {\n    console.log(\"Count: \" + i);\n}\n// Output: Count: 0 to Count: 4"
    }
  ],
  "code_difference_explaination": "Java, JavaScript and TypeScript use C-style for loops with three expressions. Python uses for-in loops with ranges or iterables, which is more concise and readable."
}'),
                                                                               (3, 'While Loops', CURRENT_TIMESTAMP, '5284917', '{
  "explaination": "Execute code repeatedly as long as a condition remains true",
  "language_details": [
    {
      "language": "Java",
      "syntax": "while (condition) { // code }",
      "example": "int count = 0;\nwhile (count < 5) {\n    System.out.println(\"Count: \" + count);\n    count++;\n}\n// Output: Count: 0 to Count: 4"
    },
    {
      "language": "Python",
      "syntax": "while condition: # code",
      "example": "count = 0\nwhile count < 5:\n    print(f\"Count: {count}\")\n    count += 1\n# Output: Count: 0 to Count: 4"
    },
    {
      "language": "JavaScript",
      "syntax": "while (condition) { // code }",
      "example": "let count = 0;\nwhile (count < 5) {\n    console.log(\"Count: \" + count);\n    count++;\n}\n// Output: Count: 0 to Count: 4"
    },
    {
      "language": "TypeScript",
      "syntax": "while (condition) { // code }",
      "example": "let count: number = 0;\nwhile (count < 5) {\n    console.log(\"Count: \" + count);\n    count++;\n}\n// Output: Count: 0 to Count: 4"
    }
  ],
  "code_difference_explaination": "All languages have similar while loop syntax. The main difference is in the condition syntax (parentheses in Java/JavaScript/TypeScript vs no parentheses in Python) and code block delimiters."
}'),
                                                                               (3, 'For-Each Loops', CURRENT_TIMESTAMP, '5284917', '{
  "explaination": "Iterate over elements in collections or arrays without using indices",
  "language_details": [
    {
      "language": "Java",
      "syntax": "for (type variable : collection) { // code }",
      "example": "String[] fruits = {\"Apple\", \"Banana\", \"Orange\"};\nfor (String fruit : fruits) {\n    System.out.println(fruit);\n}\n// Output: Apple, Banana, Orange"
    },
    {
      "language": "Python",
      "syntax": "for variable in collection: # code",
      "example": "fruits = [\"Apple\", \"Banana\", \"Orange\"]\nfor fruit in fruits:\n    print(fruit)\n# Output: Apple, Banana, Orange"
    },
    {
      "language": "JavaScript",
      "syntax": "for (let variable of collection) { // code }",
      "example": "let fruits = [\"Apple\", \"Banana\", \"Orange\"];\nfor (let fruit of fruits) {\n    console.log(fruit);\n}\n// Output: Apple, Banana, Orange"
    },
    {
      "language": "TypeScript",
      "syntax": "for (let variable of collection) { // code }",
      "example": "let fruits: string[] = [\"Apple\", \"Banana\", \"Orange\"];\nfor (let fruit of fruits) {\n    console.log(fruit);\n}\n// Output: Apple, Banana, Orange"
    }
  ],
  "code_difference_explaination": "All languages support enhanced for loops. Java uses colon syntax, Python uses simple in keyword, JavaScript/TypeScript use for-of syntax. All provide cleaner iteration over collections without index management."
}');

-- Topics for Main Topic 4: Methods & Functions
INSERT INTO topics (main_topic_id, title, created_at, creator_id, content) VALUES
                                                                               (4, 'Function Declaration', CURRENT_TIMESTAMP, '5284917', '{
  "explaination": "Define reusable blocks of code that perform specific tasks",
  "language_details": [
    {
      "language": "Java",
      "syntax": "accessModifier returnType methodName(parameters) { // code }",
      "example": "public int addNumbers(int a, int b) {\n    return a + b;\n}\nint result = addNumbers(5, 3); // 8"
    },
    {
      "language": "Python",
      "syntax": "def function_name(parameters): # code",
      "example": "def add_numbers(a, b):\n    return a + b\n\nresult = add_numbers(5, 3) # 8"
    },
    {
      "language": "JavaScript",
      "syntax": "function functionName(parameters) { // code }",
      "example": "function addNumbers(a, b) {\n    return a + b;\n}\nlet result = addNumbers(5, 3); // 8"
    },
    {
      "language": "TypeScript",
      "syntax": "function functionName(parameters: type): returnType { // code }",
      "example": "function addNumbers(a: number, b: number): number {\n    return a + b;\n}\nlet result: number = addNumbers(5, 3); // 8"
    }
  ],
  "code_difference_explaination": "Java requires access modifiers and return types. Python uses def keyword with dynamic typing. JavaScript uses function keyword with dynamic typing. TypeScript adds type annotations to JavaScript functions."
}'),
                                                                               (4, 'Parameters & Return Types', CURRENT_TIMESTAMP, '5284917', '{
  "explaination": "Define inputs to functions and the type of value they return",
  "language_details": [
    {
      "language": "Java",
      "syntax": "public returnType methodName(paramType param1, paramType param2)",
      "example": "public String greetPerson(String name, int age) {\n    return \"Hello \" + name + \", you are \" + age + \" years old\";\n}\nString message = greetPerson(\"Alice\", 25);"
    },
    {
      "language": "Python",
      "syntax": "def function_name(param1, param2):",
      "example": "def greet_person(name, age):\n    return f\"Hello {name}, you are {age} years old\"\n\nmessage = greet_person(\"Alice\", 25)"
    },
    {
      "language": "JavaScript",
      "syntax": "function functionName(param1, param2) { }",
      "example": "function greetPerson(name, age) {\n    return `Hello ${name}, you are ${age} years old`;\n}\nlet message = greetPerson(\"Alice\", 25);"
    },
    {
      "language": "TypeScript",
      "syntax": "function functionName(param1: type, param2: type): returnType { }",
      "example": "function greetPerson(name: string, age: number): string {\n    return `Hello ${name}, you are ${age} years old`;\n}\nlet message: string = greetPerson(\"Alice\", 25);"
    }
  ],
  "code_difference_explaination": "Java and TypeScript require explicit parameter and return types. Python and JavaScript use dynamic typing. TypeScript provides optional static typing on top of JavaScript syntax."
}'),
                                                                               (4, 'Method Overloading', CURRENT_TIMESTAMP, '5284917', '{
  "explaination": "Define multiple methods with same name but different parameters",
  "language_details": [
    {
      "language": "Java",
      "syntax": "Multiple methods with same name, different parameters",
      "example": "public int add(int a, int b) { return a + b; }\npublic double add(double a, double b) { return a + b; }\npublic int add(int a, int b, int c) { return a + b + c; }"
    },
    {
      "language": "Python",
      "syntax": "Single function with default parameters or *args",
      "example": "def add(a, b, c=None):\n    if c is None:\n        return a + b\n    else:\n        return a + b + c\n\nadd(2, 3) # 5\nadd(2, 3, 4) # 9"
    },
    {
      "language": "JavaScript",
      "syntax": "Single function with conditional logic",
      "example": "function add(a, b, c) {\n    if (c === undefined) {\n        return a + b;\n    } else {\n        return a + b + c;\n    }\n}\nadd(2, 3); // 5\nadd(2, 3, 4); // 9"
    },
    {
      "language": "TypeScript",
      "syntax": "Function overloads with different signatures",
      "example": "function add(a: number, b: number): number;\nfunction add(a: number, b: number, c: number): number;\nfunction add(a: number, b: number, c?: number): number {\n    if (c) return a + b + c;\n    return a + b;\n}\nadd(2, 3); // 5\nadd(2, 3, 4); // 9"
    }
  ],
  "code_difference_explaination": "Java supports true method overloading. Python and JavaScript achieve similar functionality with default parameters and conditional logic. TypeScript supports function overload signatures with a single implementation."
}');

-- Topics for Main Topic 5: String Manipulation
INSERT INTO topics (main_topic_id, title, created_at, creator_id, content) VALUES
                                                                               (5, 'String Concatenation', CURRENT_TIMESTAMP, '5284917', '{
  "explaination": "Combine multiple strings into a single string",
  "language_details": [
    {
      "language": "Java",
      "syntax": "string1 + string2 or StringBuilder",
      "example": "String firstName = \"John\";\nString lastName = \"Doe\";\nString fullName = firstName + \" \" + lastName; // \"John Doe\"\n\nStringBuilder sb = new StringBuilder();\nsb.append(firstName).append(\" \").append(lastName);"
    },
    {
      "language": "Python",
      "syntax": "string1 + string2 or f-strings",
      "example": "first_name = \"John\"\nlast_name = \"Doe\"\nfull_name = first_name + \" \" + last_name # \"John Doe\"\nfull_name = f\"{first_name} {last_name}\" # \"John Doe\""
    },
    {
      "language": "JavaScript",
      "syntax": "string1 + string2 or template literals",
      "example": "let firstName = \"John\";\nlet lastName = \"Doe\";\nlet fullName = firstName + \" \" + lastName; // \"John Doe\"\nlet fullName2 = `${firstName} ${lastName}`; // \"John Doe\""
    },
    {
      "language": "TypeScript",
      "syntax": "string1 + string2 or template literals",
      "example": "let firstName: string = \"John\";\nlet lastName: string = \"Doe\";\nlet fullName: string = firstName + \" \" + lastName; // \"John Doe\"\nlet fullName2: string = `${firstName} ${lastName}`; // \"John Doe\""
    }
  ],
  "code_difference_explaination": "All languages support + operator for concatenation. Python f-strings and JavaScript/TypeScript template literals provide more readable string interpolation. Java uses StringBuilder for efficient multiple concatenations."
}'),
                                                                               (5, 'String Methods', CURRENT_TIMESTAMP, '5284917', '{
  "explaination": "Built-in methods to manipulate and query string values",
  "language_details": [
    {
      "language": "Java",
      "syntax": "string.length(), string.substring(), string.toUpperCase()",
      "example": "String text = \"Hello World\";\nint len = text.length(); // 11\nString sub = text.substring(0, 5); // \"Hello\"\nString upper = text.toUpperCase(); // \"HELLO WORLD\""
    },
    {
      "language": "Python",
      "syntax": "len(string), string[start:end], string.upper()",
      "example": "text = \"Hello World\"\nlength = len(text) # 11\nsub = text[0:5] # \"Hello\"\nupper = text.upper() # \"HELLO WORLD\""
    },
    {
      "language": "JavaScript",
      "syntax": "string.length, string.substring(), string.toUpperCase()",
      "example": "let text = \"Hello World\";\nlet len = text.length; // 11\nlet sub = text.substring(0, 5); // \"Hello\"\nlet upper = text.toUpperCase(); // \"HELLO WORLD\""
    },
    {
      "language": "TypeScript",
      "syntax": "string.length, string.substring(), string.toUpperCase()",
      "example": "let text: string = \"Hello World\";\nlet len: number = text.length; // 11\nlet sub: string = text.substring(0, 5); // \"Hello\"\nlet upper: string = text.toUpperCase(); // \"HELLO WORLD\""
    }
  ],
  "code_difference_explaination": "All languages provide similar string manipulation methods. Java and JavaScript use method calls, Python uses functions and methods, and TypeScript inherits JavaScript methods with type safety. Python uses slicing syntax for substrings."
}'),
                                                                               (5, 'String Comparison', CURRENT_TIMESTAMP, '5284917', '{
  "explaination": "Compare strings for equality or ordering",
  "language_details": [
    {
      "language": "Java",
      "syntax": "string1.equals(string2), string1.compareTo(string2)",
      "example": "String str1 = \"hello\";\nString str2 = \"HELLO\";\nboolean isEqual = str1.equals(str2); // false\nboolean isEqualIgnoreCase = str1.equalsIgnoreCase(str2); // true\nint comparison = str1.compareTo(\"world\"); // negative"
    },
    {
      "language": "Python",
      "syntax": "string1 == string2, string1 < string2",
      "example": "str1 = \"hello\"\nstr2 = \"HELLO\"\nis_equal = str1 == str2 # False\nis_equal_ignore_case = str1.lower() == str2.lower() # True\ncomparison = str1 < \"world\" # True"
    },
    {
      "language": "JavaScript",
      "syntax": "string1 === string2, string1.localeCompare(string2)",
      "example": "let str1 = \"hello\";\nlet str2 = \"HELLO\";\nlet isEqual = str1 === str2; // false\nlet isEqualIgnoreCase = str1.toLowerCase() === str2.toLowerCase(); // true\nlet comparison = str1.localeCompare(\"world\"); // negative"
    },
    {
      "language": "TypeScript",
      "syntax": "string1 === string2, string1.localeCompare(string2)",
      "example": "let str1: string = \"hello\";\nlet str2: string = \"HELLO\";\nlet isEqual: boolean = str1 === str2; // false\nlet isEqualIgnoreCase: boolean = str1.toLowerCase() === str2.toLowerCase(); // true\nlet comparison: number = str1.localeCompare(\"world\"); // negative"
    }
  ],
  "code_difference_explaination": "Java uses .equals() for content comparison and == for reference comparison. Python and JavaScript/TypeScript use ==/=== for content comparison. All languages provide methods for case-insensitive comparison and lexicographical ordering."
}');

-- Topics for Main Topic 6: Arrays & Collections
INSERT INTO topics (main_topic_id, title, created_at, creator_id, content) VALUES
                                                                               (6, 'Array Declaration', CURRENT_TIMESTAMP, '5284917', '{
  "explaination": "Create and initialize arrays to store multiple values",
  "language_details": [
    {
      "language": "Java",
      "syntax": "type[] arrayName = new type[size]; or type[] arrayName = {val1, val2};",
      "example": "int[] numbers = new int[5]; // [0, 0, 0, 0, 0]\nString[] fruits = {\"Apple\", \"Banana\", \"Orange\"};\nnumbers[0] = 10; // First element"
    },
    {
      "language": "Python",
      "syntax": "list_name = [val1, val2] or list_name = list()",
      "example": "numbers = [0] * 5 # [0, 0, 0, 0, 0]\nfruits = [\"Apple\", \"Banana\", \"Orange\"]\nnumbers[0] = 10 # First element"
    },
    {
      "language": "JavaScript",
      "syntax": "let arrayName = [val1, val2]; or let arrayName = new Array(size);",
      "example": "let numbers = new Array(5); // [empty × 5]\nlet fruits = [\"Apple\", \"Banana\", \"Orange\"];\nnumbers[0] = 10; // First element"
    },
    {
      "language": "TypeScript",
      "syntax": "let arrayName: type[] = [val1, val2];",
      "example": "let numbers: number[] = new Array(5);\nlet fruits: string[] = [\"Apple\", \"Banana\", \"Orange\"];\nnumbers[0] = 10; // First element"
    }
  ],
  "code_difference_explaination": "Java uses type[] syntax and requires explicit sizing. Python uses list literals with dynamic sizing. JavaScript uses array literals or Array constructor. TypeScript adds type annotations to JavaScript arrays."
}'),
                                                                               (6, 'Array Manipulation', CURRENT_TIMESTAMP, '5284917', '{
  "explaination": "Common operations to modify and work with arrays",
  "language_details": [
    {
      "language": "Java",
      "syntax": "Arrays.copyOf(), Arrays.sort(), System.arraycopy()",
      "example": "int[] numbers = {3, 1, 4, 1, 5};\nArrays.sort(numbers); // [1, 1, 3, 4, 5]\nint[] copy = Arrays.copyOf(numbers, 3); // [1, 1, 3]\nint length = numbers.length; // 5"
    },
    {
      "language": "Python",
      "syntax": "list.sort(), list.copy(), len(list)",
      "example": "numbers = [3, 1, 4, 1, 5]\nnumbers.sort() # [1, 1, 3, 4, 5]\ncopy = numbers.copy() # [1, 1, 3, 4, 5]\nlength = len(numbers) # 5"
    },
    {
      "language": "JavaScript",
      "syntax": "array.sort(), array.slice(), array.length",
      "example": "let numbers = [3, 1, 4, 1, 5];\nnumbers.sort(); // [1, 1, 3, 4, 5]\nlet copy = numbers.slice(); // [1, 1, 3, 4, 5]\nlet length = numbers.length; // 5"
    },
    {
      "language": "TypeScript",
      "syntax": "array.sort(), array.slice(), array.length",
      "example": "let numbers: number[] = [3, 1, 4, 1, 5];\nnumbers.sort(); // [1, 1, 3, 4, 5]\nlet copy: number[] = numbers.slice(); // [1, 1, 3, 4, 5]\nlet length: number = numbers.length; // 5"
    }
  ],
  "code_difference_explaination": "All languages provide similar array manipulation methods. Java uses Arrays utility class. Python and JavaScript have built-in array/list methods. TypeScript inherits JavaScript methods with type safety."
}'),
                                                                               (6, 'Multi-dimensional Arrays', CURRENT_TIMESTAMP, '5284917', '{
  "explaination": "Arrays with multiple dimensions (2D, 3D, etc.) for tabular data",
  "language_details": [
    {
      "language": "Java",
      "syntax": "type[][] arrayName = new type[rows][cols];",
      "example": "int[][] matrix = new int[3][3]; // 3x3 matrix\nmatrix[0][0] = 1;\nmatrix[1][1] = 2;\n// [[1, 0, 0], [0, 2, 0], [0, 0, 0]]\n\nint[][] jagged = new int[3][]; // Jagged array\njagged[0] = new int[2];\njagged[1] = new int[3];"
    },
    {
      "language": "Python",
      "syntax": "list_name = [[val, val], [val, val]]",
      "example": "matrix = [[0] * 3 for _ in range(3)] # 3x3 matrix\nmatrix[0][0] = 1\nmatrix[1][1] = 2\n# [[1, 0, 0], [0, 2, 0], [0, 0, 0]]\n\njagged = [[1, 2], [3, 4, 5], [6]] # Jagged list"
    },
    {
      "language": "JavaScript",
      "syntax": "let arrayName = [[val, val], [val, val]];",
      "example": "let matrix = Array(3).fill().map(() => Array(3).fill(0)); // 3x3\nmatrix[0][0] = 1;\nmatrix[1][1] = 2;\n// [[1, 0, 0], [0, 2, 0], [0, 0, 0]]\n\nlet jagged = [[1, 2], [3, 4, 5], [6]]; // Jagged array"
    },
    {
      "language": "TypeScript",
      "syntax": "let arrayName: type[][] = [[val, val], [val, val]];",
      "example": "let matrix: number[][] = Array(3).fill(null).map(() => Array(3).fill(0));\nmatrix[0][0] = 1;\nmatrix[1][1] = 2;\n// [[1, 0, 0], [0, 2, 0], [0, 0, 0]]\n\nlet jagged: number[][] = [[1, 2], [3, 4, 5], [6]]; // Jagged array"
    }
  ],
  "code_difference_explaination": "Java supports true multi-dimensional arrays with fixed dimensions. Python, JavaScript and TypeScript use lists/arrays of lists/arrays, which can be jagged (rows of different lengths). Initialization syntax varies significantly between languages."
}');


-- Problems for Main Topic 1: Java Data Types & Variables

-- Topic: Primitive Data Types (topic_id: 1)
INSERT INTO problems (problem_id, topic_id, title, description, difficulty) VALUES
                                                                                (1, 1, 'Temperature Converter', 'Write a program to convert Celsius to Fahrenheit. The formula is: F = (C × 9/5) + 32', 'EASY'),
                                                                                (2, 1, 'Circle Measurements', 'Calculate area and circumference of a circle given its radius. Use π = 3.14159', 'EASY'),
                                                                                (3, 1, 'Student Grade Calculator', 'Calculate average grade of a student from 3 subjects and determine if passed (average ≥ 60)', 'MEDIUM'),
                                                                                (4, 1, 'Data Type Size Calculator', 'Create a program that demonstrates the size and range of different primitive data types', 'HARD');

-- Topic: Variables Declaration (topic_id: 2)
INSERT INTO problems (problem_id, topic_id, title, description, difficulty) VALUES
                                                                                (5, 2, 'Variable Swapping', 'Swap values of two variables without using a third variable', 'EASY'),
                                                                                (6, 2, 'Constants Calculator', 'Create a program that uses constants for mathematical calculations (PI, gravity, etc.)', 'EASY'),
                                                                                (7, 2, 'Employee Payroll', 'Calculate employee salary with basic pay, overtime, and deductions using appropriate variables', 'MEDIUM'),
                                                                                (8, 2, 'Type Conversion Challenge', 'Demonstrate various type conversions between different data types', 'HARD');

-- Topic: Type Casting (topic_id: 3)
INSERT INTO problems (problem_id, topic_id, title, description, difficulty) VALUES
                                                                                (9, 3, 'Explicit Casting', 'Convert double to int and demonstrate data loss during conversion', 'EASY'),
                                                                                (10, 3, 'String to Number', 'Convert string representations of numbers to actual numeric types and perform calculations', 'EASY'),
                                                                                (11, 3, 'Mixed Type Calculator', 'Create a calculator that handles mixed data types and performs appropriate casting', 'MEDIUM'),
                                                                                (12, 3, 'Safe Type Conversion', 'Implement a robust type conversion system with error handling for invalid conversions', 'HARD');

-- Problems for Main Topic 2: Conditional Statements

-- Topic: If-Else Statements (topic_id: 4)
INSERT INTO problems (problem_id, topic_id, title, description, difficulty) VALUES
                                                                                (13, 4, 'Number Classification', 'Check if a number is positive, negative, or zero using if-else statements', 'EASY'),
                                                                                (14, 4, 'Age Category Checker', 'Determine age category: child (0-12), teen (13-19), adult (20-59), senior (60+)', 'EASY'),
                                                                                (15, 4, 'Quadratic Equation Solver', 'Solve quadratic equation and handle different cases (real roots, complex roots, equal roots)', 'MEDIUM'),
                                                                                (16, 4, 'Nested Condition Challenge', 'Create a complex decision system using multiple nested if-else statements', 'HARD');

-- Topic: Switch Statements (topic_id: 5)
INSERT INTO problems (problem_id, topic_id, title, description, difficulty) VALUES
                                                                                (17, 5, 'Day of Week', 'Given a number (1-7), print the corresponding day of the week using switch statement', 'EASY'),
                                                                                (18, 5, 'Simple Calculator', 'Create a calculator that performs basic operations (+, -, *, /) using switch statement', 'EASY'),
                                                                                (19, 5, 'Grade to GPA Converter', 'Convert letter grades (A, B, C, D, F) to GPA points using switch statement', 'MEDIUM'),
                                                                                (20, 5, 'Month Days Calculator', 'Given a month number, return number of days in that month (consider leap years)', 'HARD');

-- Topic: Ternary Operator (topic_id: 6)
INSERT INTO problems (problem_id, topic_id, title, description, difficulty) VALUES
                                                                                (21, 6, 'Minimum of Two', 'Find the minimum of two numbers using ternary operator', 'EASY'),
                                                                                (22, 6, 'Even Odd Checker', 'Check if a number is even or odd using ternary operator', 'EASY'),
                                                                                (23, 6, 'Voting Eligibility', 'Check voting eligibility based on age and citizenship using nested ternary operators', 'MEDIUM'),
                                                                                (24, 6, 'Grade Classification', 'Classify student grade (A, B, C, D, F) based on score using multiple ternary operators', 'HARD');

-- Problems for Main Topic 3: Loops & Iteration

-- Topic: For Loops (topic_id: 7)
INSERT INTO problems (problem_id, topic_id, title, description, difficulty) VALUES
                                                                                (25, 7, 'Multiplication Table', 'Generate multiplication table for a given number using for loop', 'EASY'),
                                                                                (26, 7, 'Factorial Calculator', 'Calculate factorial of a number using for loop', 'EASY'),
                                                                                (27, 7, 'Prime Number Checker', 'Check if a number is prime using for loop and optimization techniques', 'MEDIUM'),
                                                                                (28, 7, 'Pattern Printing', 'Print various patterns (pyramid, diamond, etc.) using nested for loops', 'HARD');

-- Topic: While Loops (topic_id: 8)
INSERT INTO problems (problem_id, topic_id, title, description, difficulty) VALUES
                                                                                (29, 8, 'Sum of Digits', 'Calculate sum of digits of a number using while loop', 'EASY'),
                                                                                (30, 8, 'Number Reversal', 'Reverse a number using while loop', 'EASY'),
                                                                                (31, 8, 'Collatz Sequence', 'Generate Collatz sequence for a given number using while loop', 'MEDIUM'),
                                                                                (32, 8, 'Digital Root Calculator', 'Calculate digital root of a number using while loop', 'HARD');

-- Topic: For-Each Loops (topic_id: 9)
INSERT INTO problems (problem_id, topic_id, title, description, difficulty) VALUES
                                                                                (33, 9, 'Array Sum Calculator', 'Calculate sum of all elements in an array using for-each loop', 'EASY'),
                                                                                (34, 9, 'Maximum Element Finder', 'Find maximum element in an array using for-each loop', 'EASY'),
                                                                                (35, 9, 'Duplicate Detector', 'Find duplicate elements in an array using for-each loop', 'MEDIUM'),
                                                                                (36, 9, 'Frequency Counter', 'Count frequency of each element in an array using for-each loop', 'HARD');

-- Problems for Main Topic 4: Methods & Functions

-- Topic: Function Declaration (topic_id: 10)
INSERT INTO problems (problem_id, topic_id, title, description, difficulty) VALUES
                                                                                (37, 10, 'Simple Greeting Function', 'Create a function that takes a name and returns a greeting message', 'EASY'),
                                                                                (38, 10, 'Mathematical Operations', 'Create separate functions for addition, subtraction, multiplication, and division', 'EASY'),
                                                                                (39, 10, 'Palindrome Checker', 'Create a function that checks if a string is palindrome', 'MEDIUM'),
                                                                                (40, 10, 'Bank Account System', 'Create multiple functions for bank operations (deposit, withdraw, check balance)', 'HARD');

-- Topic: Parameters & Return Types (topic_id: 11)
INSERT INTO problems (problem_id, topic_id, title, description, difficulty) VALUES
                                                                                (41, 11, 'Rectangle Area Calculator', 'Create a function that calculates area of rectangle with parameters and return type', 'EASY'),
                                                                                (42, 11, 'String Manipulator', 'Create functions that manipulate strings with different parameters and return types', 'EASY'),
                                                                                (43, 11, 'Student Record System', 'Create functions to handle student records with multiple parameters and complex return types', 'MEDIUM'),
                                                                                (44, 11, 'Scientific Calculator', 'Implement scientific calculator functions with various parameters and return types', 'HARD');

-- Topic: Method Overloading (topic_id: 12)
INSERT INTO problems (problem_id, topic_id, title, description, difficulty) VALUES
                                                                                (45, 12, 'Area Calculator Overload', 'Create overloaded methods to calculate area of different shapes', 'EASY'),
                                                                                (46, 12, 'Print Function Overload', 'Create overloaded print functions for different data types', 'EASY'),
                                                                                (47, 12, 'Calculator Overloading', 'Create overloaded methods for calculator with different parameter types', 'MEDIUM'),
                                                                                (48, 12, 'Data Processor', 'Create overloaded methods to process different types of data structures', 'HARD');

-- Problems for Main Topic 5: String Manipulation

-- Topic: String Concatenation (topic_id: 13)
INSERT INTO problems (problem_id, topic_id, title, description, difficulty) VALUES
                                                                                (49, 13, 'Full Name Generator', 'Concatenate first name and last name to create full name', 'EASY'),
                                                                                (50, 13, 'Address Builder', 'Build complete address by concatenating street, city, state, and zip code', 'EASY'),
                                                                                (51, 13, 'SQL Query Builder', 'Build SQL queries by concatenating different clauses and conditions', 'MEDIUM'),
                                                                                (52, 13, 'Dynamic Template Engine', 'Create a template engine that concatenates dynamic content with templates', 'HARD');

-- Topic: String Methods (topic_id: 14)
INSERT INTO problems (problem_id, topic_id, title, description, difficulty) VALUES
                                                                                (53, 14, 'String Validator', 'Validate strings using various string methods (length, contains, etc.)', 'EASY'),
                                                                                (54, 14, 'Text Formatter', 'Format text using string methods (uppercase, lowercase, trim, etc.)', 'EASY'),
                                                                                (55, 14, 'Password Strength Checker', 'Check password strength using multiple string methods and conditions', 'MEDIUM'),
                                                                                (56, 14, 'Text Analyzer', 'Analyze text for various metrics using comprehensive string methods', 'HARD');

-- Topic: String Comparison (topic_id: 15)
INSERT INTO problems (problem_id, topic_id, title, description, difficulty) VALUES
                                                                                (57, 15, 'Case Insensitive Login', 'Implement login system with case-insensitive username comparison', 'EASY'),
                                                                                (58, 15, 'String Sorting', 'Sort array of strings using comparison methods', 'EASY'),
                                                                                (59, 15, 'Anagram Checker', 'Check if two strings are anagrams using string comparison techniques', 'MEDIUM'),
                                                                                (60, 15, 'Advanced Search System', 'Implement search system with various comparison options (exact, partial, fuzzy)', 'HARD');

-- Problems for Main Topic 6: Arrays & Collections

-- Topic: Array Declaration (topic_id: 16)
INSERT INTO problems (problem_id, topic_id, title, description, difficulty) VALUES
                                                                                (61, 16, 'Basic Array Initialization', 'Declare and initialize arrays of different data types with various methods', 'EASY'),
                                                                                (62, 16, 'Array Element Access', 'Access and modify array elements using different indexing techniques', 'EASY'),
                                                                                (63, 16, 'Dynamic Array Creator', 'Create arrays dynamically based on user input or conditions', 'MEDIUM'),
                                                                                (64, 16, 'Multi-type Array System', 'Create systems that work with arrays of different data types', 'HARD');

-- Topic: Array Manipulation (topic_id: 17)
INSERT INTO problems (problem_id, topic_id, title, description, difficulty) VALUES
                                                                                (65, 17, 'Array Reversal', 'Reverse the elements of an array using different techniques', 'EASY'),
                                                                                (66, 17, 'Element Search', 'Search for elements in array using linear and binary search', 'EASY'),
                                                                                (67, 17, 'Array Sorting', 'Implement different sorting algorithms for arrays', 'MEDIUM'),
                                                                                (68, 17, 'Array Operations', 'Implement complex array operations (rotation, partitioning, etc.)', 'HARD');

-- Topic: Multi-dimensional Arrays (topic_id: 18)
INSERT INTO problems (problem_id, topic_id, title, description, difficulty) VALUES
                                                                                (69, 18, 'Matrix Initialization', 'Create and initialize 2D arrays (matrices) with different values', 'EASY'),
                                                                                (70, 18, 'Matrix Operations', 'Perform basic matrix operations (addition, subtraction) on 2D arrays', 'EASY'),
                                                                                (71, 18, 'Matrix Multiplication', 'Implement matrix multiplication for 2D arrays', 'MEDIUM'),
                                                                                (72, 18, 'Game Board System', 'Create game board systems using multi-dimensional arrays with complex logic', 'HARD');




-- Test Cases for Problems 1-4 (Primitive Data Types)
INSERT INTO problem_test_cases (test_case_id, problem_id, is_public, input, expected_output) VALUES
-- Problem 1: Temperature Converter
(1, 1, true, '0', '32.0'),      -- 0°C = 32°F
(2, 1, true, '100', '212.0'),   -- 100°C = 212°F
(3, 1, true, '-40', '-40.0'),   -- -40°C = -40°F
(4, 1, false, '37', '98.6'),    -- 37°C = 98.6°F

-- Problem 2: Circle Measurements
(5, 2, true, '5', 'Area: 78.53975, Circumference: 31.4159'),
(6, 2, true, '10', 'Area: 314.159, Circumference: 62.8318'),
(7, 2, true, '1', 'Area: 3.14159, Circumference: 6.28318'),
(8, 2, false, '7.5', 'Area: 176.7144375, Circumference: 47.12385'),

-- Problem 3: Student Grade Calculator
(9, 3, true, '70 80 90', 'Average: 80.0, Status: Passed'),
(10, 3, true, '50 55 60', 'Average: 55.0, Status: Failed'),
(11, 3, true, '85 90 95', 'Average: 90.0, Status: Passed'),
(12, 3, false, '59 60 61', 'Average: 60.0, Status: Passed'),

-- Problem 4: Data Type Size Calculator
(13, 4, true, 'byte', 'Size: 1 byte, Range: -128 to 127'),
(14, 4, true, 'int', 'Size: 4 bytes, Range: -2147483648 to 2147483647'),
(15, 4, true, 'double', 'Size: 8 bytes, Range: 4.9E-324 to 1.7976931348623157E308'),
(16, 4, false, 'char', 'Size: 2 bytes, Range: 0 to 65535');

-- Test Cases for Problems 5-8 (Variables Declaration)
INSERT INTO problem_test_cases (test_case_id, problem_id, is_public, input, expected_output) VALUES
-- Problem 5: Variable Swapping
(17, 5, true, '10 20', '20 10'),
(18, 5, true, '5 8', '8 5'),
(19, 5, true, '-3 7', '7 -3'),
(20, 5, false, '100 200', '200 100'),

-- Problem 6: Constants Calculator
(21, 6, true, 'circle 5', 'Area: 78.53975, Circumference: 31.4159'),
(22, 6, true, 'gravity 10', 'Force: 98.0'),
(23, 6, true, 'speed_of_light 2', 'Energy: 1.8E17'),
(24, 6, false, 'circle 2.5', 'Area: 19.6349375, Circumference: 15.70795'),

-- Problem 7: Employee Payroll
(25, 7, true, '5000 10 500', 'Basic: 5000, Overtime: 500, Deductions: 500, Net: 5000'),
(26, 7, true, '3000 5 300', 'Basic: 3000, Overtime: 250, Deductions: 300, Net: 2950'),
(27, 7, true, '4000 0 400', 'Basic: 4000, Overtime: 0, Deductions: 400, Net: 3600'),
(28, 7, false, '6000 20 800', 'Basic: 6000, Overtime: 1000, Deductions: 800, Net: 6200'),

-- Problem 8: Type Conversion Challenge
(29, 8, true, 'int_to_double 5', '5.0'),
(30, 8, true, 'double_to_int 3.14', '3'),
(31, 8, true, 'string_to_int "123"', '123'),
(32, 8, false, 'char_to_int A', '65');

-- Test Cases for Problems 9-12 (Type Casting)
INSERT INTO problem_test_cases (test_case_id, problem_id, is_public, input, expected_output) VALUES
-- Problem 9: Explicit Casting
(33, 9, true, '3.14', '3'),
(34, 9, true, '9.99', '9'),
(35, 9, true, '-2.75', '-2'),
(36, 9, false, '100.50', '100'),

-- Problem 10: String to Number
(37, 10, true, '"25" "15"', '40'),
(38, 10, true, '"3.14" "2.86"', '6.0'),
(39, 10, true, '"100" "50"', '150'),
(40, 10, false, '"7.5" "2.5"', '10.0'),

-- Problem 11: Mixed Type Calculator
(41, 11, true, '5 3.14', '8.14'),
(42, 11, true, '10 2.5', '12.5'),
(43, 11, true, '7 1.5', '8.5'),
(44, 11, false, '15 3.33', '18.33'),

-- Problem 12: Safe Type Conversion
(45, 12, true, '"123"', '123'),
(46, 12, true, '"abc"', 'Conversion Error'),
(47, 12, true, '"45.67"', '45.67'),
(48, 12, false, '"12.34.56"', 'Conversion Error');

-- Test Cases for Problems 13-16 (If-Else Statements)
INSERT INTO problem_test_cases (test_case_id, problem_id, is_public, input, expected_output) VALUES
-- Problem 13: Number Classification
(49, 13, true, '5', 'Positive'),
(50, 13, true, '-3', 'Negative'),
(51, 13, true, '0', 'Zero'),
(52, 13, false, '-10', 'Negative'),

-- Problem 14: Age Category Checker
(53, 14, true, '8', 'Child'),
(54, 14, true, '16', 'Teen'),
(55, 14, true, '25', 'Adult'),
(56, 14, false, '65', 'Senior'),

-- Problem 15: Quadratic Equation Solver
(57, 15, true, '1 -5 6', 'Roots: 3.0, 2.0'),
(58, 15, true, '1 2 1', 'Root: -1.0'),
(59, 15, true, '1 1 1', 'Complex Roots'),
(60, 15, false, '2 -4 2', 'Root: 1.0'),

-- Problem 16: Nested Condition Challenge
(61, 16, true, '18 true', 'Eligible to vote and drive'),
(62, 16, true, '16 true', 'Cannot vote but can learn to drive'),
(63, 16, true, '20 false', 'Eligible but not citizen'),
(64, 16, false, '14 false', 'Too young for both');

-- Test Cases for Problems 17-20 (Switch Statements)
INSERT INTO problem_test_cases (test_case_id, problem_id, is_public, input, expected_output) VALUES
-- Problem 17: Day of Week
(65, 17, true, '1', 'Monday'),
(66, 17, true, '3', 'Wednesday'),
(67, 17, true, '7', 'Sunday'),
(68, 17, false, '8', 'Invalid day'),

-- Problem 18: Simple Calculator
(69, 18, true, '10 + 5', '15'),
(70, 18, true, '10 - 5', '5'),
(71, 18, true, '10 * 5', '50'),
(72, 18, false, '10 / 5', '2'),

-- Problem 19: Grade to GPA Converter
(73, 19, true, 'A', '4.0'),
(74, 19, true, 'B', '3.0'),
(75, 19, true, 'C', '2.0'),
(76, 19, false, 'F', '0.0'),

-- Problem 20: Month Days Calculator
(77, 20, true, '2 2020', '29'),
(78, 20, true, '2 2021', '28'),
(79, 20, true, '4 2023', '30'),
(80, 20, false, '1 2023', '31');

-- Test Cases for Problems 21-24 (Ternary Operator)
INSERT INTO problem_test_cases (test_case_id, problem_id, is_public, input, expected_output) VALUES
-- Problem 21: Minimum of Two
(81, 21, true, '10 20', '10'),
(82, 21, true, '25 15', '15'),
(83, 21, true, '-5 -10', '-10'),
(84, 21, false, '7 7', '7'),

-- Problem 22: Even Odd Checker
(85, 22, true, '4', 'Even'),
(86, 22, true, '7', 'Odd'),
(87, 22, true, '0', 'Even'),
(88, 22, false, '15', 'Odd'),

-- Problem 23: Voting Eligibility
(89, 23, true, '18 true', 'Eligible'),
(90, 23, true, '17 true', 'Not Eligible'),
(91, 23, true, '18 false', 'Not Eligible'),
(92, 23, false, '21 true', 'Eligible'),

-- Problem 24: Grade Classification
(93, 24, true, '95', 'A'),
(94, 24, true, '85', 'B'),
(95, 24, true, '75', 'C'),
(96, 24, false, '65', 'D');

-- Test Cases for Problems 25-28 (For Loops)
INSERT INTO problem_test_cases (test_case_id, problem_id, is_public, input, expected_output) VALUES
-- Problem 25: Multiplication Table
(97, 25, true, '5', '5x1=5, 5x2=10, ..., 5x10=50'),
(98, 25, true, '7', '7x1=7, 7x2=14, ..., 7x10=70'),
(99, 25, true, '3', '3x1=3, 3x2=6, ..., 3x10=30'),
(100, 25, false, '12', '12x1=12, 12x2=24, ..., 12x10=120'),

-- Problem 26: Factorial Calculator
(101, 26, true, '5', '120'),
(102, 26, true, '0', '1'),
(103, 26, true, '3', '6'),
(104, 26, false, '7', '5040'),

-- Problem 27: Prime Number Checker
(105, 27, true, '7', 'Prime'),
(106, 27, true, '9', 'Not Prime'),
(107, 27, true, '2', 'Prime'),
(108, 27, false, '1', 'Not Prime'),

-- Problem 28: Pattern Printing
(109, 28, true, '5', '*, **, ***, ****, *****'),
(110, 28, true, '3', '*, **, ***'),
(111, 28, true, '4', '*, **, ***, ****'),
(112, 28, false, '6', '*, **, ***, ****, *****, ******');

-- Test Cases for Problems 29-32 (While Loops)
INSERT INTO problem_test_cases (test_case_id, problem_id, is_public, input, expected_output) VALUES
-- Problem 29: Sum of Digits
(113, 29, true, '123', '6'),
(114, 29, true, '456', '15'),
(115, 29, true, '1001', '2'),
(116, 29, false, '999', '27'),

-- Problem 30: Number Reversal
(117, 30, true, '123', '321'),
(118, 30, true, '100', '1'),
(119, 30, true, '4567', '7654'),
(120, 30, false, '1200', '21'),

-- Problem 31: Collatz Sequence
(121, 31, true, '6', '6, 3, 10, 5, 16, 8, 4, 2, 1'),
(122, 31, true, '3', '3, 10, 5, 16, 8, 4, 2, 1'),
(123, 31, true, '7', '7, 22, 11, 34, 17, 52, 26, 13, 40, 20, 10, 5, 16, 8, 4, 2, 1'),
(124, 31, false, '1', '1'),

-- Problem 32: Digital Root Calculator
(125, 32, true, '123', '6'),
(126, 32, true, '456', '6'),
(127, 32, true, '9875', '2'),
(128, 32, false, '999', '9');

-- Test Cases for Problems 33-36 (For-Each Loops)
INSERT INTO problem_test_cases (test_case_id, problem_id, is_public, input, expected_output) VALUES
-- Problem 33: Array Sum Calculator
(129, 33, true, '1 2 3 4 5', '15'),
(130, 33, true, '10 20 30', '60'),
(131, 33, true, '-1 0 1', '0'),
(132, 33, false, '2 4 6 8', '20'),

-- Problem 34: Maximum Element Finder
(133, 34, true, '1 5 3 9 2', '9'),
(134, 34, true, '-1 -5 -3', '-1'),
(135, 34, true, '10 20 30 20 10', '30'),
(136, 34, false, '7 3 8 1 9', '9'),

-- Problem 35: Duplicate Detector
(137, 35, true, '1 2 3 2 4', '2'),
(138, 35, true, '5 6 7 8 5', '5'),
(139, 35, true, '1 2 3 4', 'No duplicates'),
(140, 35, false, '1 1 2 2 3', '1, 2'),

-- Problem 36: Frequency Counter
(141, 36, true, '1 2 2 3 3 3', '1:1, 2:2, 3:3'),
(142, 36, true, 'a b a c b a', 'a:3, b:2, c:1'),
(143, 36, true, '5 5 5 5', '5:4'),
(144, 36, false, '1 2 1 2 3', '1:2, 2:2, 3:1');

-- Test Cases for Problems 37-40 (Function Declaration)
INSERT INTO problem_test_cases (test_case_id, problem_id, is_public, input, expected_output) VALUES
-- Problem 37: Simple Greeting Function
(145, 37, true, 'Alice', 'Hello, Alice!'),
(146, 37, true, 'Bob', 'Hello, Bob!'),
(147, 37, true, 'World', 'Hello, World!'),
(148, 37, false, 'Java', 'Hello, Java!'),

-- Problem 38: Mathematical Operations
(149, 38, true, 'add 5 3', '8'),
(150, 38, true, 'subtract 10 4', '6'),
(151, 38, true, 'multiply 7 6', '42'),
(152, 38, false, 'divide 15 3', '5'),

-- Problem 39: Palindrome Checker
(153, 39, true, 'racecar', 'Palindrome'),
(154, 39, true, 'hello', 'Not Palindrome'),
(155, 39, true, 'madam', 'Palindrome'),
(156, 39, false, 'A man a plan a canal Panama', 'Palindrome'),

-- Problem 40: Bank Account System
(157, 40, true, 'deposit 1000', 'Balance: 1000'),
(158, 40, true, 'withdraw 500', 'Balance: 500'),
(159, 40, true, 'check_balance', 'Balance: 1000'),
(160, 40, false, 'withdraw 1500', 'Insufficient funds');

-- Test Cases for Problems 41-44 (Parameters & Return Types)
INSERT INTO problem_test_cases (test_case_id, problem_id, is_public, input, expected_output) VALUES
-- Problem 41: Rectangle Area Calculator
(161, 41, true, '5 3', '15'),
(162, 41, true, '10 4', '40'),
(163, 41, true, '7 2', '14'),
(164, 41, false, '12 8', '96'),

-- Problem 42: String Manipulator
(165, 42, true, 'reverse hello', 'olleh'),
(166, 42, true, 'uppercase world', 'WORLD'),
(167, 42, true, 'length programming', '11'),
(168, 42, false, 'concat Java Script', 'JavaScript'),

-- Problem 43: Student Record System
(169, 43, true, 'add Alice 85', 'Student added: Alice - 85'),
(170, 43, true, 'get_grade Alice', '85'),
(171, 43, true, 'get_average', '85.0'),
(172, 43, false, 'add Bob 90', 'Student added: Bob - 90'),

-- Problem 44: Scientific Calculator
(173, 44, true, 'sin 0', '0.0'),
(174, 44, true, 'cos 0', '1.0'),
(175, 44, true, 'log 100', '2.0'),
(176, 44, false, 'pow 2 3', '8.0');

-- Test Cases for Problems 45-48 (Method Overloading)
INSERT INTO problem_test_cases (test_case_id, problem_id, is_public, input, expected_output) VALUES
-- Problem 45: Area Calculator Overload
(177, 45, true, 'circle 5', '78.53975'),
(178, 45, true, 'rectangle 4 6', '24'),
(179, 45, true, 'triangle 3 4', '6.0'),
(180, 45, false, 'square 5', '25'),

-- Problem 46: Print Function Overload
(181, 46, true, 'int 42', '42'),
(182, 46, true, 'double 3.14', '3.14'),
(183, 46, true, 'string hello', 'hello'),
(184, 46, false, 'boolean true', 'true'),

-- Problem 47: Calculator Overloading
(185, 47, true, 'add 5 3', '8'),
(186, 47, true, 'add 2.5 3.5', '6.0'),
(187, 47, true, 'add "Hello " "World"', 'Hello World'),
(188, 47, false, 'add 10 20 30', '60'),

-- Problem 48: Data Processor
(189, 48, true, 'array 1 2 3', 'Sum: 6'),
(190, 48, true, 'list 4 5 6', 'Sum: 15'),
(191, 48, true, 'set 1 1 2 2', 'Sum: 3'),
(192, 48, false, 'map a:1 b:2', 'Sum: 3');

-- Test Cases for Problems 49-52 (String Concatenation)
INSERT INTO problem_test_cases (test_case_id, problem_id, is_public, input, expected_output) VALUES
-- Problem 49: Full Name Generator
(193, 49, true, 'John Doe', 'John Doe'),
(194, 49, true, 'Alice Smith', 'Alice Smith'),
(195, 49, true, 'Bob Johnson', 'Bob Johnson'),
(196, 49, false, 'Carol Davis', 'Carol Davis'),

-- Problem 50: Address Builder
(197, 50, true, '123 Main St Springfield IL 62704', '123 Main St, Springfield, IL 62704'),
(198, 50, true, '456 Oak Ave Chicago IL 60601', '456 Oak Ave, Chicago, IL 60601'),
(199, 50, true, '789 Pine Rd NewYork NY 10001', '789 Pine Rd, NewYork, NY 10001'),
(200, 50, false, '321 Elm St Boston MA 02108', '321 Elm St, Boston, MA 02108'),

-- Problem 51: SQL Query Builder
(201, 51, true, 'SELECT * FROM users WHERE age > 18', 'SELECT * FROM users WHERE age > 18'),
(202, 51, true, 'SELECT name, email FROM customers WHERE city="Chicago"', 'SELECT name, email FROM customers WHERE city="Chicago"'),
(203, 51, true, 'UPDATE products SET price=19.99 WHERE id=5', 'UPDATE products SET price=19.99 WHERE id=5'),
(204, 51, false, 'DELETE FROM orders WHERE status="cancelled"', 'DELETE FROM orders WHERE status="cancelled"'),

-- Problem 52: Dynamic Template Engine
(205, 52, true, 'Hello {name} Alice', 'Hello Alice'),
(206, 52, true, 'Welcome {user} to {app} Bob MyApp', 'Welcome Bob to MyApp'),
(207, 52, true, 'The {animal} jumped over the {object} fox fence', 'The fox jumped over the fence'),
(208, 52, false, 'Today is {day} and time is {time} Monday 10:30', 'Today is Monday and time is 10:30');

-- Test Cases for Problems 53-56 (String Methods)
INSERT INTO problem_test_cases (test_case_id, problem_id, is_public, input, expected_output) VALUES
-- Problem 53: String Validator
(209, 53, true, 'hello 5', 'Valid'),
(210, 53, true, 'hi 10', 'Too short'),
(211, 53, true, 'verylongstring 5', 'Too long'),
(212, 53, false, 'test@email 8', 'Valid'),

-- Problem 54: Text Formatter
(213, 54, true, 'hello world', 'HELLO WORLD'),
(214, 54, true, '  trim me  ', 'TRIM ME'),
(215, 54, true, 'MiXeD CaSe', 'MIXED CASE'),
(216, 54, false, 'proper title', 'Proper Title'),

-- Problem 55: Password Strength Checker
(217, 55, true, 'Weak123', 'Weak'),
(218, 55, true, 'Strong@Password123', 'Strong'),
(219, 55, true, 'short', 'Too short'),
(220, 55, false, 'NoNumbersHere!', 'Medium'),

-- Problem 56: Text Analyzer
(221, 56, true, 'Hello world!', 'Words: 2, Characters: 12, Sentences: 1'),
(222, 56, true, 'This is a test. This is only a test.', 'Words: 8, Characters: 35, Sentences: 2'),
(223, 56, true, 'Programming is fun!', 'Words: 3, Characters: 19, Sentences: 1'),
(224, 56, false, 'Hello. How are you? I am fine.', 'Words: 6, Characters: 26, Sentences: 3');

-- Test Cases for Problems 57-60 (String Comparison)
INSERT INTO problem_test_cases (test_case_id, problem_id, is_public, input, expected_output) VALUES
-- Problem 57: Case Insensitive Login
(225, 57, true, 'admin ADMIN', 'Login successful'),
(226, 57, true, 'user USER', 'Login successful'),
(227, 57, true, 'admin wrongpass', 'Login failed'),
(228, 57, false, 'Admin ADMIN', 'Login successful'),

-- Problem 58: String Sorting
(229, 58, true, 'banana apple cherry', 'apple banana cherry'),
(230, 58, true, 'zebra cat dog', 'cat dog zebra'),
(231, 58, true, '3 1 2', '1 2 3'),
(232, 58, false, 'beta alpha gamma', 'alpha beta gamma'),

-- Problem 59: Anagram Checker
(233, 59, true, 'listen silent', 'Anagrams'),
(234, 59, true, 'hello world', 'Not Anagrams'),
(235, 59, true, 'debitcard badcredit', 'Anagrams'),
(236, 59, false, 'funeral realfun', 'Anagrams'),

-- Problem 60: Advanced Search System
(237, 60, true, 'exact hello hello world', 'Found'),
(238, 60, true, 'partial hello helloworld', 'Found'),
(239, 60, true, 'fuzzy helo hello', 'Found'),
(240, 60, false, 'exact test testing', 'Not found');

-- Test Cases for Problems 61-64 (Array Declaration)
INSERT INTO problem_test_cases (test_case_id, problem_id, is_public, input, expected_output) VALUES
-- Problem 61: Basic Array Initialization
(241, 61, true, 'int 5', '[0, 0, 0, 0, 0]'),
(242, 61, true, 'string 3', '[null, null, null]'),
(243, 61, true, 'double 4', '[0.0, 0.0, 0.0, 0.0]'),
(244, 61, false, 'boolean 2', '[false, false]'),

-- Problem 62: Array Element Access
(245, 62, true, '1 2 3 get 0', '1'),
(246, 62, true, '5 10 15 get 2', '15'),
(247, 62, true, 'a b c set 1 x', '[a, x, c]'),
(248, 62, false, '1 2 3 4 5 get 3', '4'),

-- Problem 63: Dynamic Array Creator
(249, 63, true, '5 even', '[0, 2, 4, 6, 8]'),
(250, 63, true, '3 odd', '[1, 3, 5]'),
(251, 63, true, '4 square', '[0, 1, 4, 9]'),
(252, 63, false, '6 fibonacci', '[0, 1, 1, 2, 3, 5]'),

-- Problem 64: Multi-type Array System
(253, 64, true, 'int 1 2 3', 'Sum: 6'),
(254, 64, true, 'double 1.5 2.5 3.5', 'Sum: 7.5'),
(255, 64, true, 'string a b c', 'Concatenated: abc'),
(256, 64, false, 'mixed 1 2.5 three', 'Processed successfully');

-- Test Cases for Problems 65-68 (Array Manipulation)
INSERT INTO problem_test_cases (test_case_id, problem_id, is_public, input, expected_output) VALUES
-- Problem 65: Array Reversal
(257, 65, true, '1 2 3 4 5', '[5, 4, 3, 2, 1]'),
(258, 65, true, '10 20 30', '[30, 20, 10]'),
(259, 65, true, 'a b c', '[c, b, a]'),
(260, 65, false, '1', '[1]'),

-- Problem 66: Element Search
(261, 66, true, '1 2 3 4 5 3', 'Found at index 2'),
(262, 66, true, '10 20 30 40 25', 'Not found'),
(263, 66, true, 'a b c d b', 'Found at index 1'),
(264, 66, false, '5 10 15 20 15', 'Found at index 2'),

-- Problem 67: Array Sorting
(265, 67, true, '5 2 8 1 9', '[1, 2, 5, 8, 9]'),
(266, 67, true, '3 1 4 1 5', '[1, 1, 3, 4, 5]'),
(267, 67, true, 'z a m b', '[a, b, m, z]'),
(268, 67, false, '9 3 7 1 8', '[1, 3, 7, 8, 9]'),

-- Problem 68: Array Operations
(269, 68, true, '1 2 3 4 5 rotate 2', '[3, 4, 5, 1, 2]'),
(270, 68, true, '1 2 3 4 5 partition 3', '[[1, 2, 3], [4, 5]]'),
(271, 68, true, '1 2 3 4 5 shuffle', 'Array shuffled'),
(272, 68, false, '1 2 3 4 5 reverse', '[5, 4, 3, 2, 1]');

-- Test Cases for Problems 69-72 (Multi-dimensional Arrays)
INSERT INTO problem_test_cases (test_case_id, problem_id, is_public, input, expected_output) VALUES
-- Problem 69: Matrix Initialization
(273, 69, true, '3 3 0', '[[0, 0, 0], [0, 0, 0], [0, 0, 0]]'),
(274, 69, true, '2 2 1', '[[1, 1], [1, 1]]'),
(275, 69, true, '2 3 5', '[[5, 5, 5], [5, 5, 5]]'),
(276, 69, false, '4 4 -1', '[[-1, -1, -1, -1], [-1, -1, -1, -1], [-1, -1, -1, -1], [-1, -1, -1, -1]]'),

-- Problem 70: Matrix Operations
(277, 70, true, '1 2 3 4 add 5 6 7 8', '[[6, 8], [10, 12]]'),
(278, 70, true, '9 8 7 6 subtract 1 2 3 4', '[[8, 6], [4, 2]]'),
(279, 70, true, '1 0 0 1 identity', '[[1, 0], [0, 1]]'),
(280, 70, false, '2 3 4 5 transpose', '[[2, 4], [3, 5]]'),

-- Problem 71: Matrix Multiplication
(281, 71, true, '1 2 3 4 multiply 2 0 1 2', '[[4, 4], [10, 8]]'),
(282, 71, true, '1 0 0 1 multiply 5 6 7 8', '[[5, 6], [7, 8]]'),
(283, 71, true, '2 3 4 1 multiply 1 2 3 4', '[[11, 16], [7, 12]]'),
(284, 71, false, '1 2 3 4 5 6 multiply 7 8 9 10 11 12', '[[58, 64], [139, 154]]'),

-- Problem 72: Game Board System
(285, 72, true, '3 3 init', '[[-, -, -], [-, -, -], [-, -, -]]'),
(286, 72, true, 'place 0 0 X', '[[X, -, -], [-, -, -], [-, -, -]]'),
(287, 72, true, 'place 1 1 O', '[[-, -, -], [-, O, -], [-, -, -]]'),
(288, 72, false, 'check_win', 'No winner');


-- MCQs for Topic 1: Primitive Data Types
INSERT INTO mcqs (mcq_id, topic_id, content) VALUES
                                                 (1, 1, '{
  "question": "Which of the following is NOT a primitive data type in Java?",
  "options": [
    "A) int",
    "B) String",
    "C) boolean",
    "D) double"
  ],
  "correct_answer": "B) String",
  "explanation": "String is a class in Java, not a primitive data type. The primitive data types are: byte, short, int, long, float, double, char, and boolean."
}'),
                                                 (2, 1, '{
  "question": "What is the default value of a boolean variable in Java?",
  "options": [
    "A) true",
    "B) false",
    "C) null",
    "D) 0"
  ],
  "correct_answer": "B) false",
  "explanation": "In Java, boolean variables are initialized to false by default."
}'),
                                                 (3, 1, '{
  "question": "Which data type would be most appropriate for storing a person''s age?",
  "options": [
    "A) float",
    "B) double",
    "C) int",
    "D) long"
  ],
  "correct_answer": "C) int",
  "explanation": "Age is typically a whole number and doesn''t require decimal points. int is sufficient for age values (0-150)."
}'),
                                                 (4, 1, '{
  "question": "What is the size of a char data type in Java?",
  "options": [
    "A) 1 byte",
    "B) 2 bytes",
    "C) 4 bytes",
    "D) 8 bytes"
  ],
  "correct_answer": "B) 2 bytes",
  "explanation": "In Java, char is 2 bytes (16 bits) to support Unicode characters."
}'),
                                                 (5, 1, '{
  "question": "Which of these declarations will cause a compilation error?",
  "options": [
    "A) int x = 10;",
    "B) float y = 3.14;",
    "C) double z = 2.5;",
    "D) boolean flag = true;"
  ],
  "correct_answer": "B) float y = 3.14;",
  "explanation": "3.14 is a double literal. To assign to float, you need to use 3.14f or cast it."
}'),
                                                 (6, 1, '{
  "question": "What is the range of values for a byte data type?",
  "options": [
    "A) 0 to 255",
    "B) -128 to 127",
    "C) -32768 to 32767",
    "D) 0 to 65535"
  ],
  "correct_answer": "B) -128 to 127",
  "explanation": "byte is 8-bit signed two''s complement integer with range -128 to 127."
}'),
                                                 (7, 1, '{
  "question": "Which data type should be used for precise monetary calculations?",
  "options": [
    "A) float",
    "B) double",
    "C) int",
    "D) BigDecimal"
  ],
  "correct_answer": "D) BigDecimal",
  "explanation": "For precise monetary calculations, BigDecimal is recommended because float and double can have precision issues with decimal values."
}'),
                                                 (8, 1, '{
  "question": "What happens when you try to store 130 in a byte variable?",
  "options": [
    "A) It stores 130 normally",
    "B) Compilation error",
    "C) Runtime exception",
    "D) It wraps around to -126"
  ],
  "correct_answer": "B) Compilation error",
  "explanation": "130 is outside the byte range (-128 to 127), so it causes a compilation error: possible lossy conversion."
}'),
                                                 (9, 1, '{
  "question": "Which of these is a valid character literal?",
  "options": [
    "A) ''A''",
    "B) \"A\"",
    "C) ''AB''",
    "D) ''65''"
  ],
  "correct_answer": "A) ''A''",
  "explanation": "Character literals use single quotes and can contain exactly one character."
}'),
                                                 (10, 1, '{
  "question": "What is the default value of an int array element?",
  "options": [
    "A) 1",
    "B) 0",
    "C) -1",
    "D) null"
  ],
  "correct_answer": "B) 0",
  "explanation": "All numeric types in arrays are initialized to 0 by default."
}');

-- MCQs for Topic 2: Variables Declaration
INSERT INTO mcqs (mcq_id, topic_id, content) VALUES
                                                 (11, 2, '{
  "question": "Which keyword is used to declare a constant variable in Java?",
  "options": [
    "A) constant",
    "B) final",
    "C) static",
    "D) const"
  ],
  "correct_answer": "B) final",
  "explanation": "The ''final'' keyword is used to declare constants in Java. ''const'' is a reserved word but not used."
}'),
                                                 (12, 2, '{
  "question": "What is the naming convention for constants in Java?",
  "options": [
    "A) camelCase",
    "B) PascalCase",
    "C) UPPER_CASE",
    "D) lower_case"
  ],
  "correct_answer": "C) UPPER_CASE",
  "explanation": "Constants should be in UPPER_CASE with underscores separating words, e.g., MAX_SIZE, PI."
}'),
                                                 (13, 2, '{
  "question": "Which of these is a valid variable name in Java?",
  "options": [
    "A) 2ndValue",
    "B) my-variable",
    "C) _temp",
    "D) class"
  ],
  "correct_answer": "C) _temp",
  "explanation": "Variable names can start with underscore or letter, cannot start with digit, cannot contain hyphens, and cannot be reserved words."
}'),
                                                 (14, 2, '{
  "question": "What is the scope of a local variable?",
  "options": [
    "A) Entire class",
    "B) Entire package",
    "C) The method where it''s declared",
    "D) The entire program"
  ],
  "correct_answer": "C) The method where it''s declared",
  "explanation": "Local variables are only accessible within the method or block where they are declared."
}'),
                                                 (15, 2, '{
  "question": "Which of these declarations creates an uninitialized variable?",
  "options": [
    "A) int x = 0;",
    "B) int x;",
    "C) final int x = 5;",
    "D) int x = null;"
  ],
  "correct_answer": "B) int x;",
  "explanation": "int x; declares but doesn''t initialize the variable. It must be initialized before use."
}'),
                                                 (16, 2, '{
  "question": "What is the default value of an instance variable of type String?",
  "options": [
    "A) \"\"",
    "B) \"null\"",
    "C) null",
    "D) undefined"
  ],
  "correct_answer": "C) null",
  "explanation": "All reference types, including String, are initialized to null by default."
}'),
                                                 (17, 2, '{
  "question": "Which keyword allows a variable to be accessed without creating an instance?",
  "options": [
    "A) final",
    "B) static",
    "C) volatile",
    "D) transient"
  ],
  "correct_answer": "B) static",
  "explanation": "static variables belong to the class rather than instances and can be accessed using ClassName.variableName."
}'),
                                                 (18, 2, '{
  "question": "What is the output: int x = 5; System.out.println(x++ + ++x);",
  "options": [
    "A) 10",
    "B) 11",
    "C) 12",
    "D) 13"
  ],
  "correct_answer": "C) 12",
  "explanation": "x++ returns 5 then x becomes 6, ++x makes x 7 and returns 7, so 5 + 7 = 12."
}'),
                                                 (19, 2, '{
  "question": "Which of these is NOT a valid variable declaration?",
  "options": [
    "A) int _x = 10;",
    "B) int $x = 20;",
    "C) int 1x = 30;",
    "D) int x1 = 40;"
  ],
  "correct_answer": "C) int 1x = 30;",
  "explanation": "Variable names cannot start with a digit. They must start with a letter, underscore, or dollar sign."
}'),
                                                 (20, 2, '{
  "question": "What does the ''final'' keyword prevent when applied to a variable?",
  "options": [
    "A) Declaration",
    "B) Initialization",
    "C) Modification",
    "D) Access"
  ],
  "correct_answer": "C) Modification",
  "explanation": "A final variable can only be assigned once and cannot be modified afterwards."
}');

-- MCQs for Topic 3: Type Casting
INSERT INTO mcqs (mcq_id, topic_id, content) VALUES
                                                 (21, 3, '{
  "question": "What is widening conversion in Java?",
  "options": [
    "A) Converting to a smaller data type",
    "B) Converting to a larger data type",
    "C) Converting between unrelated types",
    "D) Converting objects to primitives"
  ],
  "correct_answer": "B) Converting to a larger data type",
  "explanation": "Widening conversion happens automatically when converting to a larger data type (e.g., int to long)."
}'),
                                                 (22, 3, '{
  "question": "Which of these requires explicit casting?",
  "options": [
    "A) int to long",
    "B) double to float",
    "C) byte to int",
    "D) short to int"
  ],
  "correct_answer": "B) double to float",
  "explanation": "Converting from double to float is narrowing and requires explicit casting: float f = (float) doubleValue;"
}'),
                                                 (23, 3, '{
  "question": "What is the result of: double d = 5 / 2;",
  "options": [
    "A) 2.5",
    "B) 2.0",
    "C) 2",
    "D) Compilation error"
  ],
  "correct_answer": "B) 2.0",
  "explanation": "5/2 is integer division resulting in 2, which is then widened to double 2.0."
}'),
                                                 (24, 3, '{
  "question": "What happens when you cast a double value 9.99 to int?",
  "options": [
    "A) 9.99",
    "B) 10",
    "C) 9",
    "D) Compilation error"
  ],
  "correct_answer": "C) 9",
  "explanation": "Casting double to int truncates the decimal part, resulting in 9."
}'),
                                                 (25, 3, '{
  "question": "Which method converts a String to int in Java?",
  "options": [
    "A) String.toInt()",
    "B) Integer.parseInt()",
    "C) String.parseInt()",
    "D) Integer.toInt()"
  ],
  "correct_answer": "B) Integer.parseInt()",
  "explanation": "Integer.parseInt(String) is used to convert String to int in Java."
}'),
                                                 (26, 3, '{
  "question": "What is autoboxing in Java?",
  "options": [
    "A) Automatic conversion from primitive to wrapper",
    "B) Automatic conversion from wrapper to primitive",
    "C) Automatic type inference",
    "D) Automatic memory management"
  ],
  "correct_answer": "A) Automatic conversion from primitive to wrapper",
  "explanation": "Autoboxing automatically converts primitives to their corresponding wrapper classes (e.g., int to Integer)."
}'),
                                                 (27, 3, '{
  "question": "What is the output: System.out.println((int)''A'');",
  "options": [
    "A) A",
    "B) 65",
    "C) 97",
    "D) Compilation error"
  ],
  "correct_answer": "B) 65",
  "explanation": "Casting char ''A'' to int gives its ASCII value, which is 65."
}'),
                                                 (28, 3, '{
  "question": "Which conversion may result in loss of precision?",
  "options": [
    "A) int to long",
    "B) float to double",
    "C) double to float",
    "D) byte to short"
  ],
  "correct_answer": "C) double to float",
  "explanation": "Converting double to float may lose precision as float has fewer bits for decimal precision."
}'),
                                                 (29, 3, '{
  "question": "What is the result of: String s = "" + 123;",
  "options": [
    "A) Compilation error",
    "B) Runtime error",
    "C) \"123\"",
    "D) 123"
  ],
  "correct_answer": "C) \"123\"",
  "explanation": "Using + operator with String and int converts the int to String, resulting in \"123\"."
}'),
                                                 (30, 3, '{
  "question": "Which of these is a valid type conversion?",
  "options": [
    "A) boolean to int",
    "B) int to boolean",
    "C) String to int",
    "D) char to int"
  ],
  "correct_answer": "D) char to int",
  "explanation": "char can be converted to int (widening conversion). boolean cannot be converted to/from numeric types."
}');

-- MCQs for Topic 4: If-Else Statements
INSERT INTO mcqs (mcq_id, topic_id, content) VALUES
                                                 (31, 4, '{
  "question": "What is the output if x = 5: if(x > 3) System.out.println(\\\"A\\\"); else System.out.println(\\\"B\\\");",
  "options": [
    "A) A",
    "B) B",
    "C) AB",
    "D) No output"
  ],
  "correct_answer": "A) A",
  "explanation": "Since 5 > 3 is true, the if block executes and prints \\\"A\\\"."
}'),
                                                 (32, 4, '{
  "question": "Which operator has the highest precedence in conditions?",
  "options": [
    "A) &&",
    "B) ||",
    "C) !",
    "D) =="
  ],
  "correct_answer": "C) !",
  "explanation": "Logical NOT (!) has the highest precedence, followed by relational operators, then &&, then ||."
}'),
                                                 (33, 4, '{
  "question": "What is short-circuit evaluation in if statements?",
  "options": [
    "A) Evaluating all conditions always",
    "B) Stopping evaluation when result is known",
    "C) Using shorter variable names",
    "D) Compiler optimization"
  ],
  "correct_answer": "B) Stopping evaluation when result is known",
  "explanation": "With &&, if left side is false, right side isn''t evaluated. With ||, if left side is true, right side isn''t evaluated."
}'),
                                                 (34, 4, '{
  "question": "What is the output: int x = 10; if(x = 5) System.out.println(\\\"Hello\\\");",
  "options": [
    "A) Hello",
    "B) No output",
    "C) Compilation error",
    "D) Runtime error"
  ],
  "correct_answer": "C) Compilation error",
  "explanation": "In Java, if condition must be boolean. x = 5 is assignment, not comparison. Should be x == 5."
}'),
                                                 (35, 4, '{
  "question": "Which is equivalent to: if(!(x > 5 && y < 10))",
  "options": [
    "A) if(x <= 5 && y >= 10)",
    "B) if(x > 5 || y < 10)",
    "C) if(x <= 5 || y >= 10)",
    "D) if(x < 5 && y > 10)"
  ],
  "correct_answer": "C) if(x <= 5 || y >= 10)",
  "explanation": "Using De Morgan''s law: !(A && B) is equivalent to !A || !B."
}'),
                                                 (36, 4, '{
  "question": "What is dangling else problem?",
  "options": [
    "A) Else without if",
    "B) Ambiguity in which if an else belongs to",
    "C) Missing else statement",
    "D) Nested else statements"
  ],
  "correct_answer": "B) Ambiguity in which if an else belongs to",
  "explanation": "Dangling else occurs when there are multiple if statements and it''s unclear which if the else belongs to. Java solves this by associating else with nearest if."
}'),
                                                 (37, 4, '{
  "question": "Which is NOT a valid if statement?",
  "options": [
    "A) if(true) {}",
    "B) if(1) {}",
    "C) if(x == 5) {}",
    "D) if(flag) {}"
  ],
  "correct_answer": "B) if(1) {}",
  "explanation": "Java requires boolean in if condition. 1 is int, not boolean."
}'),
                                                 (38, 4, '{
  "question": "What is the output: int x = 0; if(x = 0) System.out.println(\\\"Zero\\\"); else System.out.println(\\\"Non-zero\\\");",
  "options": [
    "A) Zero",
    "B) Non-zero",
    "C) Compilation error",
    "D) Runtime error"
  ],
  "correct_answer": "C) Compilation error",
  "explanation": "x = 0 is assignment, not comparison. Should be x == 0. Assignment returns int, not boolean."
}'),
                                                 (39, 4, '{
  "question": "Which statement about if-else is true?",
  "options": [
    "A) Else is mandatory",
    "B) Multiple else blocks are allowed",
    "C) If can exist without else",
    "D) Conditions must be simple variables"
  ],
  "correct_answer": "C) If can exist without else",
  "explanation": "Else clause is optional in if statements. You can have if without else."
}'),
                                                 (40, 4, '{
  "question": "What is the purpose of else if ladder?",
  "options": [
    "A) To handle multiple conditions sequentially",
    "B) To create infinite loops",
    "C) To improve performance",
    "D) To reduce code size"
  ],
  "correct_answer": "A) To handle multiple conditions sequentially",
  "explanation": "Else if ladder allows checking multiple conditions one after another until one is true."
}');

-- Continue with remaining topics (showing pattern for first 4 topics)
-- MCQs for Topic 5: Switch Statements
INSERT INTO mcqs (mcq_id, topic_id, content) VALUES
                                                 (41, 5, '{
  "question": "Which types are allowed in switch statement in Java?",
  "options": [
    "A) byte, short, int, char, String, enum",
    "B) All primitive types",
    "C) All reference types",
    "D) Only int and String"
  ],
  "correct_answer": "A) byte, short, int, char, String, enum",
  "explanation": "Switch supports byte, short, int, char, String (since Java 7), and enum types."
}'),
                                                 (42, 5, '{
  "question": "What happens if break is omitted in switch case?",
  "options": [
    "A) Compilation error",
    "B) Runtime error",
    "C) Fall-through to next case",
    "D) Default case executes"
  ],
  "correct_answer": "C) Fall-through to next case",
  "explanation": "Without break, execution continues to the next case statement (fall-through behavior)."
}'),
                                                 (43, 5, '{
  "question": "Which is valid switch syntax?",
  "options": [
    "A) switch x { case 1: ... }",
    "B) switch(x) { case 1: ... }",
    "C) switch { case x=1: ... }",
    "D) switch(x) { case 1 ... }"
  ],
  "correct_answer": "B) switch(x) { case 1: ... }",
  "explanation": "Correct syntax requires parentheses around expression and colon after case values."
}'),
                                                 (44, 5, '{
  "question": "What is the purpose of default case?",
  "options": [
    "A) It must be first case",
    "B) It executes when no case matches",
    "C) It''s mandatory",
    "D) It breaks the switch"
  ],
  "correct_answer": "B) It executes when no case matches",
  "explanation": "Default case is optional and executes when none of the case values match the expression."
}'),
                                                 (45, 5, '{
  "question": "Can switch work with boolean expressions?",
  "options": [
    "A) Yes, always",
    "B) No, never",
    "C) Only with true/false",
    "D) Only in latest Java"
  ],
  "correct_answer": "B) No, never",
  "explanation": "Switch cannot work with boolean expressions. Use if-else for boolean conditions."
}'),
                                                 (46, 5, '{
  "question": "What is the output: int x = 2; switch(x) { case 1: System.out.print(\\\"One\\\"); case 2: System.out.print(\\\"Two\\\"); case 3: System.out.print(\\\"Three\\\"); }",
  "options": [
    "A) Two",
    "B) TwoThree",
    "C) OneTwoThree",
    "D) Compilation error"
  ],
  "correct_answer": "B) TwoThree",
  "explanation": "Without break statements, execution falls through from case 2 to case 3."
}'),
                                                 (47, 5, '{
  "question": "Which is NOT allowed in case label?",
  "options": [
    "A) Constant value",
    "B) Variable",
    "C) final variable",
    "D) Enum value"
  ],
  "correct_answer": "B) Variable",
  "explanation": "Case labels must be constant expressions, not variables (unless they are final variables)."
}'),
                                                 (48, 5, '{
  "question": "What is switch expression (Java 14+)?",
  "options": [
    "A) Switch that returns a value",
    "B) Switch with lambda syntax",
    "C) Switch without break",
    "D) Switch with pattern matching"
  ],
  "correct_answer": "A) Switch that returns a value",
  "explanation": "Switch expressions (Java 14+) can return values using yield or arrow syntax."
}'),
                                                 (49, 5, '{
  "question": "Can we use null in switch statement?",
  "options": [
    "A) Yes, always",
    "B) No, throws NullPointerException",
    "C) Only with String",
    "D) Only with default case"
  ],
  "correct_answer": "B) No, throws NullPointerException",
  "explanation": "If switch expression is null, it throws NullPointerException at runtime."
}'),
                                                 (50, 5, '{
  "question": "What is the advantage of switch over if-else?",
  "options": [
    "A) More powerful conditions",
    "B) Better performance for multiple values",
    "C) Handles boolean expressions",
    "D) More readable for complex conditions"
  ],
  "correct_answer": "B) Better performance for multiple values",
  "explanation": "Switch can be optimized using jump tables, making it faster than if-else for many discrete values."
}');

-- MCQs for Topic 6: Ternary Operator
INSERT INTO mcqs (mcq_id, topic_id, content) VALUES
                                                 (51, 6, '{
  "question": "What is the syntax of ternary operator?",
  "options": [
    "A) condition ? value",
    "B) condition ? value1 : value2",
    "C) condition : value1 ? value2",
    "D) condition ? value1 ? value2"
  ],
  "correct_answer": "B) condition ? value1 : value2",
  "explanation": "Ternary operator syntax: condition ? value_if_true : value_if_false"
}'),
                                                 (52, 6, '{
  "question": "What is the result: int x = 10; int y = x > 5 ? 1 : 0;",
  "options": [
    "A) 0",
    "B) 1",
    "C) 10",
    "D) 5"
  ],
  "correct_answer": "B) 1",
  "explanation": "Since x > 5 is true, the ternary operator returns 1."
}'),
                                                 (53, 6, '{
  "question": "Can ternary operator be used without assignment?",
  "options": [
    "A) Yes, always",
    "B) No, never",
    "C) Only in print statements",
    "D) Only with method calls"
  ],
  "correct_answer": "B) No, never",
  "explanation": "Ternary operator must be used in an expression context (assignment, return, etc.)."
}'),
                                                 (54, 6, '{
  "question": "What is the output: System.out.println(true ? \\\"Yes\\\" : \\\"No\\\");",
  "options": [
    "A) Yes",
    "B) No",
    "C) true",
    "D) Compilation error"
  ],
  "correct_answer": "A) Yes",
  "explanation": "Since condition is true, first value \\\"Yes\\\" is returned and printed."
}'),
                                                 (55, 6, '{
  "question": "Which is equivalent to: int max = a > b ? a : b;",
  "options": [
    "A) if(a > b) max = a; else max = b;",
    "B) while(a > b) max = a;",
    "C) max = a > b;",
    "D) switch(a > b) { case true: max = a; }"
  ],
  "correct_answer": "A) if(a > b) max = a; else max = b;",
  "explanation": "The ternary operator is shorthand for simple if-else assignments."
}'),
                                                 (56, 6, '{
  "question": "What happens if types don''t match in ternary branches?",
  "options": [
    "A) Compilation error",
    "B) Runtime error",
    "C) Automatic casting",
    "D) Null is returned"
  ],
  "correct_answer": "C) Automatic casting",
  "explanation": "Java performs automatic type promotion if the types in both branches are compatible."
}'),
                                                 (57, 6, '{
  "question": "Can ternary operator be nested?",
  "options": [
    "A) Yes",
    "B) No",
    "C) Only two levels",
    "D) Only with parentheses"
  ],
  "correct_answer": "A) Yes",
  "explanation": "Ternary operators can be nested, but it reduces readability: a > b ? (x > y ? 1 : 2) : 3"
}'),
                                                 (58, 6, '{
  "question": "What is the result: int x = 5; String result = x > 0 ? \\\"Positive\\\" : x < 0 ? \\\"Negative\\\" : \\\"Zero\\\";",
  "options": [
    "A) Positive",
    "B) Negative",
    "C) Zero",
    "D) Compilation error"
  ],
  "correct_answer": "A) Positive",
  "explanation": "This is nested ternary: since x > 0 is true, returns \\\"Positive\\\"."
}'),
                                                 (59, 6, '{
  "question": "Which has higher precedence: ternary or assignment?",
  "options": [
    "A) Ternary",
    "B) Assignment",
    "C) Same",
    "D) Depends on context"
  ],
  "correct_answer": "A) Ternary",
  "explanation": "Ternary operator has higher precedence than assignment, so it evaluates first."
}'),
                                                 (60, 6, '{
  "question": "When should you avoid ternary operator?",
  "options": [
    "A) Simple conditions",
    "B) Complex nested conditions",
    "C) Assignment statements",
    "D) Return statements"
  ],
  "correct_answer": "B) Complex nested conditions",
  "explanation": "Avoid nested ternary operators as they make code hard to read and maintain."
}');

-- Continuing this pattern for all 18 topics would create 180 MCQs
-- Here''s the template for remaining topics:

-- MCQs for Topic 7: For Loops
INSERT INTO mcqs (mcq_id, topic_id, content) VALUES
                                                 (61, 7, '{
  "question": "What is the syntax of for loop?",
  "options": [
    "A) for(initialization; condition; update)",
    "B) for(condition; initialization; update)",
    "C) for(update; condition; initialization)",
    "D) for(initialization; update; condition)"
  ],
  "correct_answer": "A) for(initialization; condition; update)",
  "explanation": "Standard for loop syntax: for(initialization; condition; update) { // code }"
}'),
                                                 (62, 7, '{
  "question": "How many times does this loop run: for(int i=0; i<5; i++)",
  "options": [
    "A) 4",
    "B) 5",
    "C) 6",
    "D) Infinite"
  ],
  "correct_answer": "B) 5",
  "explanation": "i values: 0,1,2,3,4 - that''s 5 iterations."
}'),
                                                 (63, 7, '{
  "question": "What is an infinite for loop?",
  "options": [
    "A) for(;;)",
    "B) for(int i=0; i<10; i--)",
    "C) for(int i=0; true; i++)",
    "D) All of the above"
  ],
  "correct_answer": "D) All of the above",
  "explanation": "All these forms create infinite loops as condition never becomes false."
}'),
                                                 (64, 7, '{
  "question": "What is the scope of loop variable in for(int i=0; ...)?",
  "options": [
    "A) Entire class",
    "B) Entire method",
    "C) Only within the loop",
    "D) Global"
  ],
  "correct_answer": "C) Only within the loop",
  "explanation": "Loop variable declared in for statement is only accessible within the loop block."
}'),
                                                 (65, 7, '{
  "question": "Can we have multiple variables in for loop?",
  "options": [
    "A) Yes, in initialization only",
    "B) Yes, in all three parts",
    "C) No, only one variable",
    "D) Only in update part"
  ],
  "correct_answer": "A) Yes, in initialization only",
  "explanation": "Multiple variables can be declared in initialization: for(int i=0, j=0; i<5; i++)"
}'),
                                                 (66, 7, '{
  "question": "What is enhanced for loop used for?",
  "options": [
    "A) Iterating arrays/collections",
    "B) Complex conditions",
    "C) Infinite loops",
    "D) Parallel processing"
  ],
  "correct_answer": "A) Iterating arrays/collections",
  "explanation": "Enhanced for loop (for-each) simplifies iteration over arrays and collections."
}'),
                                                 (67, 7, '{
  "question": "What is the output: for(int i=0; i<3; i++) { if(i==1) break; System.out.print(i); }",
  "options": [
    "A) 0",
    "B) 01",
    "C) 012",
    "D) No output"
  ],
  "correct_answer": "A) 0",
  "explanation": "Loop breaks when i==1, so only i=0 is printed."
}'),
                                                 (68, 7, '{
  "question": "What does continue do in for loop?",
  "options": [
    "A) Exits loop",
    "B) Skips to next iteration",
    "C) Restarts loop",
    "D) Breaks all loops"
  ],
  "correct_answer": "B) Skips to next iteration",
  "explanation": "continue skips remaining code in current iteration and moves to next iteration."
}'),
                                                 (69, 7, '{
  "question": "Can we use floating point in for loop counter?",
  "options": [
    "A) Yes, always",
    "B) No, never",
    "C) Yes, but not recommended",
    "D) Only with double"
  ],
  "correct_answer": "C) Yes, but not recommended",
  "explanation": "Floating point can be used but may cause precision issues in loop control."
}'),
                                                 (70, 7, '{
  "question": "What is nested for loop?",
  "options": [
    "A) Loop inside another loop",
    "B) Multiple loops in same method",
    "C) Loop with multiple conditions",
    "D) Recursive loop"
  ],
  "correct_answer": "A) Loop inside another loop",
  "explanation": "Nested for loop is a loop inside another loop, commonly used for 2D arrays/matrices."
}');

-- MCQs for Topic 8: While Loops
INSERT INTO mcqs (mcq_id, topic_id, content) VALUES
                                                 (71, 8, '{
  "question": "What is the main difference between while and do-while?",
  "options": [
    "A) Syntax",
    "B) do-while executes at least once",
    "C) while is faster",
    "D) do-while has condition first"
  ],
  "correct_answer": "B) do-while executes at least once",
  "explanation": "do-while checks condition after execution, so it always runs at least once."
}'),
                                                 (72, 8, '{
  "question": "When is while loop preferred over for loop?",
  "options": [
    "A) When number of iterations is unknown",
    "B) When iterating arrays",
    "C) When counter is needed",
    "D) For fixed iterations"
  ],
  "correct_answer": "A) When number of iterations is unknown",
  "explanation": "while is better when iterations depend on dynamic conditions rather than fixed count."
}'),
                                                 (73, 8, '{
  "question": "What is the risk of while(true)?",
  "options": [
    "A) Compilation error",
    "B) Infinite loop",
    "C) Memory leak",
    "D) No risk"
  ],
  "correct_answer": "B) Infinite loop",
  "explanation": "while(true) creates infinite loop unless broken with break or return."
}'),
                                                 (74, 8, '{
  "question": "How to avoid infinite loops?",
  "options": [
    "A) Use proper loop condition",
    "B) Include break statements",
    "C) Ensure loop variable updates",
    "D) All of the above"
  ],
  "correct_answer": "D) All of the above",
  "explanation": "All these practices help prevent infinite loops."
}'),
                                                 (75, 8, '{
  "question": "What is the output: int i=1; while(i<5) { System.out.print(i); i++; }",
  "options": [
    "A) 1234",
    "B) 12345",
    "C) 2345",
    "D) 1235"
  ],
  "correct_answer": "A) 1234",
  "explanation": "Loop runs for i=1,2,3,4 and stops when i=5."
}'),
                                                 (76, 8, '{
  "question": "Can while loop have empty body?",
  "options": [
    "A) Yes, with semicolon",
    "B) No, compilation error",
    "C) Only with comments",
    "D) Only in certain cases"
  ],
  "correct_answer": "A) Yes, with semicolon",
  "explanation": "while(condition); is valid but creates empty loop body."
}'),
                                                 (77, 8, '{
  "question": "What is do-while syntax?",
  "options": [
    "A) do { } while(condition);",
    "B) while(condition) do { }",
    "C) do while(condition) { }",
    "D) do { } while condition"
  ],
  "correct_answer": "A) do { } while(condition);",
  "explanation": "Correct syntax requires do { } while(condition); with semicolon."
}'),
                                                 (78, 8, '{
  "question": "When to use do-while?",
  "options": [
    "A) Menu-driven programs",
    "B) Input validation",
    "C) When first iteration must run",
    "D) All of the above"
  ],
  "correct_answer": "D) All of the above",
  "explanation": "do-while is ideal when you need to execute at least once before checking condition."
}'),
                                                 (79, 8, '{
  "question": "What is loop counter?",
  "options": [
    "A) Variable controlling loop iterations",
    "B) Number of loops completed",
    "C) Break statement counter",
    "D) Time taken by loop"
  ],
  "correct_answer": "A) Variable controlling loop iterations",
  "explanation": "Loop counter is a variable that controls how many times the loop executes."
}'),
                                                 (80, 8, '{
  "question": "What is the output: int x=5; do { System.out.print(x); x--; } while(x>0);",
  "options": [
    "A) 54321",
    "B) 5432",
    "C) 543210",
    "D) 5"
  ],
  "correct_answer": "A) 54321",
  "explanation": "Loop runs for x=5,4,3,2,1 and stops when x=0."
}');

-- This pattern continues for all 18 topics, creating 180 MCQs total
-- The remaining topics would follow the same structure with appropriate questions


-- MCQs for Topic 9: For-Each Loops
INSERT INTO mcqs (mcq_id, topic_id, content) VALUES
                                                 (81, 9, '{
  "question": "What is the main advantage of for-each loop?",
  "options": [
    "A) Better performance",
    "B) No need for index management",
    "C) Works with all data structures",
    "D) Allows element modification"
  ],
  "correct_answer": "B) No need for index management",
  "explanation": "For-each loop automatically iterates through elements without requiring index variable management."
}'),
                                                 (82, 9, '{
  "question": "Which collections can for-each loop iterate over?",
  "options": [
    "A) Arrays only",
    "B) Arrays and Collections",
    "C) Any Iterable object",
    "D) Only List and Set"
  ],
  "correct_answer": "C) Any Iterable object",
  "explanation": "For-each loop works with arrays and any class implementing Iterable interface."
}'),
                                                 (83, 9, '{
  "question": "What is the syntax of for-each loop?",
  "options": [
    "A) for(type var : collection)",
    "B) for(var : collection)",
    "C) for(collection : var)",
    "D) for(type collection : var)"
  ],
  "correct_answer": "A) for(type var : collection)",
  "explanation": "Correct syntax: for(ElementType element : collection) { }"
}'),
                                                 (84, 9, '{
  "question": "Can we modify elements using for-each loop?",
  "options": [
    "A) Yes, always",
    "B) No, never",
    "C) Only primitive types",
    "D) Only reference types"
  ],
  "correct_answer": "D) Only reference types",
  "explanation": "For reference types, you can modify object state but cannot reassign the reference itself."
}'),
                                                 (85, 9, '{
  "question": "What happens if collection is null in for-each?",
  "options": [
    "A) No output",
    "B) NullPointerException",
    "C) Compilation error",
    "D) Infinite loop"
  ],
  "correct_answer": "B) NullPointerException",
  "explanation": "For-each loop throws NullPointerException if the collection/array is null."
}'),
                                                 (86, 9, '{
  "question": "Can we get current index in for-each loop?",
  "options": [
    "A) Yes, automatically",
    "B) No, not directly",
    "C) Only with arrays",
    "D) Using special syntax"
  ],
  "correct_answer": "B) No, not directly",
  "explanation": "For-each doesn''t provide index. Use traditional for-loop or maintain counter variable if index is needed."
}'),
                                                 (87, 9, '{
  "question": "What is the output: int[] arr = {1,2,3}; for(int x : arr) { x = x*2; } System.out.println(Arrays.toString(arr));",
  "options": [
    "A) [2,4,6]",
    "B) [1,2,3]",
    "C) [0,0,0]",
    "D) Compilation error"
  ],
  "correct_answer": "B) [1,2,3]",
  "explanation": "Modifying loop variable x doesn''t affect original array elements for primitives."
}'),
                                                 (88, 9, '{
  "question": "Which is faster: for-each or traditional for-loop?",
  "options": [
    "A) For-each is always faster",
    "B) Traditional for-loop is always faster",
    "C) Similar performance",
    "D) Depends on collection type"
  ],
  "correct_answer": "C) Similar performance",
  "explanation": "For-each has similar performance to traditional for-loop for arrays and ArrayList."
}'),
                                                 (89, 9, '{
  "question": "Can we use break/continue in for-each?",
  "options": [
    "A) Yes",
    "B) No",
    "C) Only break",
    "D) Only continue"
  ],
  "correct_answer": "A) Yes",
  "explanation": "For-each loop supports break and continue statements like traditional loops."
}'),
                                                 (90, 9, '{
  "question": "When should you NOT use for-each loop?",
  "options": [
    "A) When you need to modify array elements",
    "B) When you need index information",
    "C) When iterating backwards",
    "D) All of the above"
  ],
  "correct_answer": "D) All of the above",
  "explanation": "Use traditional for-loop when you need index, want to modify elements, or iterate in reverse order."
}');

-- MCQs for Topic 10: Function Declaration
INSERT INTO mcqs (mcq_id, topic_id, content) VALUES
                                                 (91, 10, '{
  "question": "What is a method signature in Java?",
  "options": [
    "A) Method name only",
    "B) Method name + return type",
    "C) Method name + parameters",
    "D) Method name + parameters + return type"
  ],
  "correct_answer": "C) Method name + parameters",
  "explanation": "Method signature consists of method name and parameter types (excluding return type)."
}'),
                                                 (92, 10, '{
  "question": "What is the purpose of return type 'void'?",
  "options": [
    "A) Method returns nothing",
    "B) Method can return any type",
    "C) Method returns null",
    "D) Method returns empty string"
  ],
  "correct_answer": "A) Method returns nothing",
  "explanation": "void indicates the method doesn''t return any value."
}'),
                                                 (93, 10, '{
  "question": "What is method overloading?",
  "options": [
    "A) Same method name, different return types",
    "B) Same method name, different parameters",
    "C) Same method in different classes",
    "D) Method with too many lines"
  ],
  "correct_answer": "B) Same method name, different parameters",
  "explanation": "Method overloading means multiple methods with same name but different parameter lists."
}'),
                                                 (94, 10, '{
  "question": "What is the main advantage of using methods?",
  "options": [
    "A) Code reusability",
    "B) Better performance",
    "C) Smaller file size",
    "D) Automatic documentation"
  ],
  "correct_answer": "A) Code reusability",
  "explanation": "Methods promote code reusability and make programs more modular and maintainable."
}'),
                                                 (95, 10, '{
  "question": "What is a parameter in method definition?",
  "options": [
    "A) Value passed to method",
    "B) Variable in method declaration",
    "C) Return value of method",
    "D) Method name"
  ],
  "correct_answer": "B) Variable in method declaration",
  "explanation": "Parameter is the variable in method declaration. Argument is the actual value passed."
}'),
                                                 (96, 10, '{
  "question": "What is the difference between parameter and argument?",
  "options": [
    "A) No difference",
    "B) Parameter is declaration, argument is actual value",
    "C) Parameter is return type, argument is input",
    "D) Parameter is method name, argument is value"
  ],
  "correct_answer": "B) Parameter is declaration, argument is actual value",
  "explanation": "Parameter: variable in method declaration. Argument: actual value passed when calling method."
}'),
                                                 (97, 10, '{
  "question": "Can a method have multiple return statements?",
  "options": [
    "A) Yes",
    "B) No",
    "C) Only in void methods",
    "D) Only two return statements"
  ],
  "correct_answer": "A) Yes",
  "explanation": "A method can have multiple return statements, but only one executes in any method call."
}'),
                                                 (98, 10, '{
  "question": "What is method scope?",
  "options": [
    "A) Where method can be called from",
    "B) Variables accessible within method",
    "C) Both A and B",
    "D) Method return type"
  ],
  "correct_answer": "C) Both A and B",
  "explanation": "Method scope includes where method is accessible and what variables it can access."
}'),
                                                 (99, 10, '{
  "question": "What is a static method?",
  "options": [
    "A) Method that doesn''t change",
    "B) Method belonging to class, not instance",
    "C) Method that returns constant",
    "D) Fast executing method"
  ],
  "correct_answer": "B) Method belonging to class, not instance",
  "explanation": "Static methods belong to the class and can be called without creating an instance."
}'),
                                                 (100, 10, '{
  "question": "What is the 'this' keyword in methods?",
  "options": [
    "A) Refers to current object",
    "B) Refers to parent class",
    "C) Refers to static context",
    "D) Refers to return value"
  ],
  "correct_answer": "A) Refers to current object",
  "explanation": "'this' refers to the current object instance in non-static methods."
}');

-- MCQs for Topic 11: Parameters & Return Types
INSERT INTO mcqs (mcq_id, topic_id, content) VALUES
                                                 (101, 11, '{
  "question": "What is pass-by-value in Java?",
  "options": [
    "A) Original variable is passed",
    "B) Copy of value is passed",
    "C) Reference is passed",
    "D) Memory address is passed"
  ],
  "correct_answer": "B) Copy of value is passed",
  "explanation": "Java is always pass-by-value - a copy of the value is passed to methods."
}'),
                                                 (102, 11, '{
  "question": "What is varargs in Java?",
  "options": [
    "A) Variable arguments",
    "B) Various arguments",
    "C) Valid arguments",
    "D) Void arguments"
  ],
  "correct_answer": "A) Variable arguments",
  "explanation": "Varargs (type... name) allows methods to accept variable number of arguments."
}'),
                                                 (103, 11, '{
  "question": "Where should varargs parameter be placed?",
  "options": [
    "A) First parameter",
    "B) Last parameter",
    "C) Any position",
    "D) Middle position"
  ],
  "correct_answer": "B) Last parameter",
  "explanation": "Varargs parameter must be the last parameter in method declaration."
}'),
                                                 (104, 11, '{
  "question": "What is method return type?",
  "options": [
    "A) Type of value method returns",
    "B) Type of parameters",
    "C) Type of method name",
    "D) Type of class"
  ],
  "correct_answer": "A) Type of value method returns",
  "explanation": "Return type specifies what type of value the method will return."
}'),
                                                 (105, 11, '{
  "question": "Can a method return an array?",
  "options": [
    "A) Yes",
    "B) No",
    "C) Only primitive arrays",
    "D) Only object arrays"
  ],
  "correct_answer": "A) Yes",
  "explanation": "Methods can return arrays of any type: int[], String[], etc."
}'),
                                                 (106, 11, '{
  "question": "What is the default return type if not specified?",
  "options": [
    "A) void",
    "B) int",
    "C) Object",
    "D) Must be specified"
  ],
  "correct_answer": "D) Must be specified",
  "explanation": "Return type is mandatory in Java method declarations."
}'),
                                                 (107, 11, '{
  "question": "What happens if return type doesn''t match returned value?",
  "options": [
    "A) Automatic conversion",
    "B) Compilation error",
    "C) Runtime error",
    "D) Null is returned"
  ],
  "correct_answer": "B) Compilation error",
  "explanation": "Compiler checks that returned value type matches declared return type."
}'),
                                                 (108, 11, '{
  "question": "Can void method have return statement?",
  "options": [
    "A) Yes, with value",
    "B) Yes, without value",
    "C) No, never",
    "D) Only in certain cases"
  ],
  "correct_answer": "B) Yes, without value",
  "explanation": "void methods can use 'return;' without value to exit early."
}'),
(109, 11, '{
  "question": "What is covariant return type?",
  "options": [
    "A) Returning subclass in overriding method",
    "B) Returning superclass",
    "C) Returning different types",
    "D) Returning arrays"
  ],
  "correct_answer": "A) Returning subclass in overriding method",
  "explanation": "Covariant return allows overriding method to return subclass of original return type."
}'),
(110, 11, '{
  "question": "What is the output: public int getNumber() { return 10.5; }",
  "options": [
    "A) 10",
    "B) 10.5",
    "C) Compilation error",
    "D) Runtime error"
  ],
  "correct_answer": "C) Compilation error",
  "explanation": "Cannot return double where int is expected - lossy conversion."
}');

-- MCQs for Topic 12: Method Overloading
INSERT INTO mcqs (mcq_id, topic_id, content) VALUES
                                                 (111, 12, '{
  "question": "What is required for method overloading?",
  "options": [
    "A) Different return types",
    "B) Different parameter lists",
    "C) Different method names",
    "D) Different access modifiers"
  ],
  "correct_answer": "B) Different parameter lists",
  "explanation": "Method overloading requires different parameter types, count, or order."
}'),
                                                 (112, 12, '{
  "question": "Can overloaded methods have different return types?",
  "options": [
    "A) Yes, always",
    "B) No, never",
    "C) Only if parameters are different",
    "D) Only for void methods"
  ],
  "correct_answer": "C) Only if parameters are different",
  "explanation": "Return type alone cannot differentiate overloaded methods - parameters must differ."
}'),
                                                 (113, 12, '{
  "question": "What is constructor overloading?",
  "options": [
    "A) Multiple constructors with different parameters",
    "B) Constructors with different names",
    "C) Constructors in different classes",
    "D) Constructors with different return types"
  ],
  "correct_answer": "A) Multiple constructors with different parameters",
  "explanation": "Constructor overloading means multiple constructors with different parameter lists."
}'),
                                                 (114, 12, '{
  "question": "How does compiler choose overloaded method?",
  "options": [
    "A) By method name only",
    "B) By parameters at compile time",
    "C) By return type",
    "D) At runtime"
  ],
  "correct_answer": "B) By parameters at compile time",
  "explanation": "Method overloading resolution happens at compile time based on parameter types."
}'),
                                                 (115, 12, '{
  "question": "Can main method be overloaded?",
  "options": [
    "A) Yes",
    "B) No",
    "C) Only in same class",
    "D) Only with different name"
  ],
  "correct_answer": "A) Yes",
  "explanation": "main method can be overloaded, but only public static void main(String[]) is execution entry point."
}'),
                                                 (116, 12, '{
  "question": "What is the output: void print(int x) { SOP(\\\"int\\\"); } void print(double x) { SOP(\\\"double\\\"); } print(5);",
  "options": [
    "A) int",
    "B) double",
    "C) Compilation error",
    "D) Runtime error"
  ],
  "correct_answer": "A) int",
  "explanation": "Exact match (int) is preferred over widening conversion (int to double)."
}'),
                                                 (117, 12, '{
  "question": "What is automatic type promotion in overloading?",
  "options": [
    "A) byte → short → int → long → float → double",
    "B) int → double → float → long",
    "C) char → int → double → float",
    "D) boolean → int → double"
  ],
  "correct_answer": "A) byte → short → int → long → float → double",
  "explanation": "This is the widening conversion hierarchy used in overloaded method resolution."
}'),
                                                 (118, 12, '{
  "question": "Can static methods be overloaded?",
  "options": [
    "A) Yes",
    "B) No",
    "C) Only in parent class",
    "D) Only with instance methods"
  ],
  "correct_answer": "A) Yes",
  "explanation": "Static methods can be overloaded like instance methods."
}'),
                                                 (119, 12, '{
  "question": "What is ambiguous method call?",
  "options": [
    "A) Compiler cannot choose between overloaded methods",
    "B) Method with unclear name",
    "C) Method with too many parameters",
    "D) Recursive method"
  ],
  "correct_answer": "A) Compiler cannot choose between overloaded methods",
  "explanation": "Ambiguous call occurs when multiple overloaded methods match equally well."
}'),
                                                 (120, 12, '{
  "question": "What is the difference between overloading and overriding?",
  "options": [
    "A) Overloading - same class, Overriding - parent-child",
    "B) Overloading - different classes, Overriding - same class",
    "C) Both are same",
    "D) Overloading for methods, Overriding for variables"
  ],
  "correct_answer": "A) Overloading - same class, Overriding - parent-child",
  "explanation": "Overloading: same class, same method name, different parameters. Overriding: inheritance, same method signature."
}');

-- MCQs for Topic 13: String Concatenation
INSERT INTO mcqs (mcq_id, topic_id, content) VALUES
                                                 (121, 13, '{
  "question": "What operator is used for string concatenation?",
  "options": [
    "A) +",
    "B) &",
    "C) .",
    "D) concat"
  ],
  "correct_answer": "A) +",
  "explanation": "+ operator is overloaded in Java for string concatenation."
}'),
                                                 (122, 13, '{
  "question": "What is the result: \\\"Hello\\\" + \\\"World\\\"?",
  "options": [
    "A) HelloWorld",
    "B) Hello World",
    "C) Hello+World",
    "D) Compilation error"
  ],
  "correct_answer": "A) HelloWorld",
  "explanation": "String concatenation using + operator joins strings without spaces."
}'),
                                                 (123, 13, '{
  "question": "What is the output: \\\"Result: \\\" + 10 + 5?",
  "options": [
    "A) Result: 15",
    "B) Result: 105",
    "C) Result: 10+5",
    "D) Compilation error"
  ],
  "correct_answer": "B) Result: 105",
  "explanation": "Left to right evaluation: \\\"Result: \\\" + 10 = \\\"Result: 10\\\", then + 5 = \\\"Result: 105\\\"."
}'),
                                                 (124, 13, '{
  "question": "What is StringBuilder used for?",
  "options": [
    "A) Efficient string concatenation",
    "B) String comparison",
    "C) String splitting",
    "D) String formatting"
  ],
  "correct_answer": "A) Efficient string concatenation",
  "explanation": "StringBuilder is mutable and efficient for multiple string concatenations."
}'),
                                                 (125, 13, '{
  "question": "When should you use StringBuilder over + operator?",
  "options": [
    "A) Single concatenation",
    "B) Multiple concatenations in loop",
    "C) Always",
    "D) Never"
  ],
  "correct_answer": "B) Multiple concatenations in loop",
  "explanation": "Use StringBuilder for multiple concatenations to avoid creating many temporary String objects."
}'),
                                                 (126, 13, '{
  "question": "What is String.join() method used for?",
  "options": [
    "A) Join strings with delimiter",
    "B) Split strings",
    "C) Compare strings",
    "D) Format strings"
  ],
  "correct_answer": "A) Join strings with delimiter",
  "explanation": "String.join(delimiter, elements) joins multiple strings with specified delimiter."
}'),
                                                 (127, 13, '{
  "question": "What is the output: String s = null + \\\"text\\\";",
  "options": [
    "A) nulltext",
    "B) text",
    "C) NullPointerException",
    "D) Compilation error"
  ],
  "correct_answer": "A) nulltext",
  "explanation": "null is converted to \\\"null\\\" string during concatenation."
}'),
                                                 (128, 13, '{
  "question": "What is string interning?",
  "options": [
    "A) Reusing existing string objects",
    "B) Internationalizing strings",
    "C) Internal string representation",
    "D) Internet-related strings"
  ],
  "correct_answer": "A) Reusing existing string objects",
  "explanation": "String interning stores only one copy of each distinct string value to save memory."
}'),
                                                 (129, 13, '{
  "question": "What is the difference between StringBuffer and StringBuilder?",
  "options": [
    "A) StringBuffer is synchronized, StringBuilder is not",
    "B) StringBuilder is synchronized, StringBuffer is not",
    "C) Both are same",
    "D) StringBuffer is faster"
  ],
  "correct_answer": "A) StringBuffer is synchronized, StringBuilder is not",
  "explanation": "StringBuffer is thread-safe (synchronized), StringBuilder is not synchronized but faster."
}'),
                                                 (130, 13, '{
  "question": "What is string literal pool?",
  "options": [
    "A) Memory area for string literals",
    "B) String storage in heap",
    "C) String garbage collection",
    "D) String comparison pool"
  ],
  "correct_answer": "A) Memory area for string literals",
  "explanation": "String literal pool is special memory area in heap for storing string literals to enable reuse."
}');

-- MCQs for Topic 14: String Methods
INSERT INTO mcqs (mcq_id, topic_id, content) VALUES
                                                 (131, 14, '{
  "question": "Which method returns string length?",
  "options": [
    "A) length()",
    "B) size()",
    "C) getLength()",
    "D) length"
  ],
  "correct_answer": "A) length()",
  "explanation": "String.length() returns the number of characters in the string."
}'),
                                                 (132, 14, '{
  "question": "What does substring(int beginIndex) return?",
  "options": [
    "A) String from beginIndex to end",
    "B) String from 0 to beginIndex",
    "C) Character at beginIndex",
    "D) String of specified length"
  ],
  "correct_answer": "A) String from beginIndex to end",
  "explanation": "substring(beginIndex) returns substring from beginIndex to end of string."
}'),
                                                 (133, 14, '{
  "question": "What is the difference between == and equals() for strings?",
  "options": [
    "A) == compares references, equals() compares content",
    "B) == compares content, equals() compares references",
    "C) Both are same",
    "D) == for length, equals() for content"
  ],
  "correct_answer": "A) == compares references, equals() compares content",
  "explanation": "== checks if same object, equals() checks if same character sequence."
}'),
                                                 (134, 14, '{
  "question": "What does trim() method do?",
  "options": [
    "A) Removes leading and trailing whitespace",
    "B) Removes all whitespace",
    "C) Trims string to specified length",
    "D) Removes specific characters"
  ],
  "correct_answer": "A) Removes leading and trailing whitespace",
  "explanation": "trim() removes whitespace from beginning and end of string, not from middle."
}'),
                                                 (135, 14, '{
  "question": "Which method converts string to uppercase?",
  "options": [
    "A) toUpperCase()",
    "B) upperCase()",
    "C) toUpper()",
    "D) caseUpper()"
  ],
  "correct_answer": "A) toUpperCase()",
  "explanation": "toUpperCase() converts all characters in string to uppercase."
}'),
                                                 (136, 14, '{
  "question": "What does indexOf() method return if not found?",
  "options": [
    "A) -1",
    "B) 0",
    "C) null",
    "D) false"
  ],
  "correct_answer": "A) -1",
  "explanation": "indexOf() returns -1 if the specified character or substring is not found."
}'),
                                                 (137, 14, '{
  "question": "What is the purpose of split() method?",
  "options": [
    "A) Split string into array using delimiter",
    "B) Split string into two parts",
    "C) Remove parts of string",
    "D) Compare string parts"
  ],
  "correct_answer": "A) Split string into array using delimiter",
  "explanation": "split(regex) splits string into array of substrings based on regular expression."
}'),
                                                 (138, 14, '{
  "question": "What does replace() method do?",
  "options": [
    "A) Replaces all occurrences of character/sequence",
    "B) Replaces first occurrence only",
    "C) Replaces last occurrence",
    "D) Replaces random characters"
  ],
  "correct_answer": "A) Replaces all occurrences of character/sequence",
  "explanation": "replace(oldChar, newChar) replaces ALL occurrences of oldChar with newChar."
}'),
                                                 (139, 14, '{
  "question": "What is the difference between replace() and replaceAll()?",
  "options": [
    "A) replace() uses chars, replaceAll() uses regex",
    "B) replaceAll() uses chars, replace() uses regex",
    "C) Both are same",
    "D) replace() is faster"
  ],
  "correct_answer": "A) replace() uses chars, replaceAll() uses regex",
  "explanation": "replace() works with char sequences, replaceAll() works with regular expressions."
}'),
                                                 (140, 14, '{
  "question": "What does startsWith() method check?",
  "options": [
    "A) If string begins with specified prefix",
    "B) If string ends with specified suffix",
    "C) If string contains substring",
    "D) If string matches pattern"
  ],
  "correct_answer": "A) If string begins with specified prefix",
  "explanation": "startsWith(prefix) returns true if string begins with the specified prefix."
}');

-- MCQs for Topic 15: String Comparison
INSERT INTO mcqs (mcq_id, topic_id, content) VALUES
                                                 (141, 15, '{
  "question": "Which method compares strings ignoring case?",
  "options": [
    "A) equalsIgnoreCase()",
    "B) compareToIgnoreCase()",
    "C) Both A and B",
    "D) caseInsensitiveEquals()"
  ],
  "correct_answer": "C) Both A and B",
  "explanation": "Both equalsIgnoreCase() and compareToIgnoreCase() perform case-insensitive comparison."
}'),
                                                 (142, 15, '{
  "question": "What does compareTo() return if strings are equal?",
  "options": [
    "A) 0",
    "B) 1",
    "C) -1",
    "D) true"
  ],
  "correct_answer": "A) 0",
  "explanation": "compareTo() returns 0 if strings are equal, negative if first is smaller, positive if first is larger."
}'),
                                                 (143, 15, '{
  "question": "What is lexicographical order?",
  "options": [
    "A) Dictionary order",
    "B) Alphabetical order",
    "C) Both A and B",
    "D) Random order"
  ],
  "correct_answer": "C) Both A and B",
  "explanation": "Lexicographical order is dictionary/alphabetical order used for string comparison."
}'),
                                                 (144, 15, '{
  "question": "What is the output: \\\"apple\\\".compareTo(\\\"banana\\\")?",
  "options": [
    "A) Negative number",
    "B) Positive number",
    "C) 0",
    "D) true"
  ],
  "correct_answer": "A) Negative number",
  "explanation": "\\\"apple\\\" comes before \\\"banana\\\" lexicographically, so returns negative value."
}'),
                                                 (145, 15, '{
  "question": "Which is faster: equals() or compareTo() == 0?",
  "options": [
    "A) equals()",
    "B) compareTo()",
    "C) Same speed",
    "D) Depends on string length"
  ],
  "correct_answer": "A) equals()",
  "explanation": "equals() is generally faster as it can short-circuit if references are same."
}'),
                                                 (146, 15, '{
  "question": "What does contentEquals() method do?",
  "options": [
    "A) Compares with StringBuffer/CharSequence",
    "B) Same as equals()",
    "C) Case-sensitive comparison",
    "D) Length comparison"
  ],
  "correct_answer": "A) Compares with StringBuffer/CharSequence",
  "explanation": "contentEquals() can compare String with StringBuffer, StringBuilder, or other CharSequence."
}'),
                                                 (147, 15, '{
  "question": "What is regionMatches() used for?",
  "options": [
    "A) Compare substrings of two strings",
    "B) Match entire strings",
    "C) Find regions in string",
    "D) Replace regions"
  ],
  "correct_answer": "A) Compare substrings of two strings",
  "explanation": "regionMatches() compares specific regions of two strings for equality."
}'),
                                                 (148, 15, '{
  "question": "How to check if string is empty?",
  "options": [
    "A) isEmpty()",
    "B) length() == 0",
    "C) equals(\\\"\\\")",
    "D) All of the above"
  ],
  "correct_answer": "D) All of the above",
  "explanation": "All three methods correctly check if string is empty."
}'),
                                                 (149, 15, '{
  "question": "What is the difference between null and empty string?",
  "options": [
    "A) null - no object, empty - object with no characters",
    "B) Both are same",
    "C) empty - no object, null - object with no characters",
    "D) null means space characters"
  ],
  "correct_answer": "A) null - no object, empty - object with no characters",
  "explanation": "null means no string object, empty string (\\\"\\\") is a string object with length 0."
}'),
                                                 (150, 15, '{
  "question": "What is string interning effect on comparison?",
  "options": [
    "A) == may return true for equal string literals",
    "B) equals() becomes faster",
    "C) compareTo() ignores case",
    "D) No effect"
  ],
  "correct_answer": "A) == may return true for equal string literals",
  "explanation": "String literals with same value may be same object due to interning, so == might return true."
}');

-- MCQs for Topic 16: Array Declaration
INSERT INTO mcqs (mcq_id, topic_id, content) VALUES
                                                 (151, 16, '{
  "question": "How to declare an integer array?",
  "options": [
    "A) int[] arr;",
    "B) int arr[];",
    "C) Both A and B",
    "D) array int arr;"
  ],
  "correct_answer": "C) Both A and B",
  "explanation": "Both int[] arr; and int arr[]; are valid array declarations in Java."
}'),
                                                 (152, 16, '{
  "question": "What is the default value of boolean array elements?",
  "options": [
    "A) true",
    "B) false",
    "C) null",
    "D) 0"
  ],
  "correct_answer": "B) false",
  "explanation": "boolean array elements are initialized to false by default."
}'),
                                                 (153, 16, '{
  "question": "How to initialize array with values?",
  "options": [
    "A) int[] arr = {1,2,3};",
    "B) int[] arr = new int[]{1,2,3};",
    "C) Both A and B",
    "D) int[] arr = new int[3]{1,2,3};"
  ],
  "correct_answer": "C) Both A and B",
  "explanation": "Both syntaxes are valid for array initialization with values."
}'),
                                                 (154, 16, '{
  "question": "What is array index out of bounds exception?",
  "options": [
    "A) Accessing invalid index",
    "B) Array size too large",
    "C) Null array",
    "D) Wrong data type"
  ],
  "correct_answer": "A) Accessing invalid index",
  "explanation": "ArrayIndexOutOfBoundsException occurs when accessing index < 0 or >= array length."
}'),
                                                 (155, 16, '{
  "question": "What is the length of array: int[] arr = new int[5];?",
  "options": [
    "A) 5",
    "B) 4",
    "C) 6",
    "D) 0"
  ],
  "correct_answer": "A) 5",
  "explanation": "new int[5] creates array with 5 elements, indices 0 through 4."
}'),
                                                 (156, 16, '{
  "question": "Can array size be changed after creation?",
  "options": [
    "A) Yes, always",
    "B) No, never",
    "C) Only for primitive arrays",
    "D) Only for object arrays"
  ],
  "correct_answer": "B) No, never",
  "explanation": "Array size is fixed after creation. Use ArrayList for resizable arrays."
}'),
                                                 (157, 16, '{
  "question": "How to get array length?",
  "options": [
    "A) arr.length",
    "B) arr.length()",
    "C) arr.size()",
    "D) arr.getLength()"
  ],
  "correct_answer": "A) arr.length",
  "explanation": "Arrays have length field, not method: arr.length"
}'),
                                                 (158, 16, '{
  "question": "What is anonymous array?",
  "options": [
    "A) Array without name",
    "B) Array with unknown type",
    "C) Empty array",
    "D) Large array"
  ],
  "correct_answer": "A) Array without name",
  "explanation": "Anonymous array: new int[]{1,2,3} - created without variable name, often for method arguments."
}'),
                                                 (159, 16, '{
  "question": "Can arrays store different types?",
  "options": [
    "A) Yes, always",
    "B) No, only same type",
    "C) Only primitive types",
    "D) Only object types"
  ],
  "correct_answer": "B) No, only same type",
  "explanation": "Arrays are homogeneous - all elements must be of the same declared type."
}'),
                                                 (160, 16, '{
  "question": "What is array reference?",
  "options": [
    "A) Variable pointing to array object",
    "B) Array index",
    "C) Array length",
    "D) Array element"
  ],
  "correct_answer": "A) Variable pointing to array object",
  "explanation": "Array reference is the variable that holds reference to the array object in memory."
}');

-- MCQs for Topic 17: Array Manipulation
INSERT INTO mcqs (mcq_id, topic_id, content) VALUES
                                                 (161, 17, '{
  "question": "How to copy array to another array?",
  "options": [
    "A) System.arraycopy()",
    "B) Arrays.copyOf()",
    "C) clone() method",
    "D) All of the above"
  ],
  "correct_answer": "D) All of the above",
  "explanation": "All these methods can be used to copy arrays in Java."
}'),
                                                 (162, 17, '{
  "question": "What does Arrays.sort() do?",
  "options": [
    "A) Sorts array in ascending order",
    "B) Sorts array in descending order",
    "C) Shuffles array",
    "D) Reverses array"
  ],
  "correct_answer": "A) Sorts array in ascending order",
  "explanation": "Arrays.sort() sorts array in natural ascending order."
}'),
                                                 (163, 17, '{
  "question": "How to search element in sorted array?",
  "options": [
    "A) Arrays.binarySearch()",
    "B) Arrays.search()",
    "C) Arrays.find()",
    "D) Arrays.indexOf()"
  ],
  "correct_answer": "A) Arrays.binarySearch()",
  "explanation": "Arrays.binarySearch() efficiently searches sorted array using binary search algorithm."
}'),
                                                 (164, 17, '{
  "question": "What is the time complexity of linear search?",
  "options": [
    "A) O(1)",
    "B) O(log n)",
    "C) O(n)",
    "D) O(n²)"
  ],
  "correct_answer": "C) O(n)",
  "explanation": "Linear search checks each element once, so time complexity is O(n)."
}'),
                                                 (165, 17, '{
  "question": "What does Arrays.fill() do?",
  "options": [
    "A) Fills array with specified value",
    "B) Fills array with random values",
    "C) Fills array with zeros",
    "D) Fills array from another array"
  ],
  "correct_answer": "A) Fills array with specified value",
  "explanation": "Arrays.fill(arr, value) sets all elements of array to the specified value."
}'),
                                                 (166, 17, '{
  "question": "How to compare two arrays for equality?",
  "options": [
    "A) Arrays.equals()",
    "B) arr1 == arr2",
    "C) arr1.equals(arr2)",
    "D) Arrays.compare()"
  ],
  "correct_answer": "A) Arrays.equals()",
  "explanation": "Arrays.equals() compares array contents, while == compares references."
}'),
                                                 (167, 17, '{
  "question": "What is the output: int[] arr = {1,2,3}; Arrays.toString(arr);",
  "options": [
    "A) \\\"[1, 2, 3]\\\"",
    "B) \\\"123\\\"",
    "C) \\\"1 2 3\\\"",
    "D) \\\"{1,2,3}\\\""
  ],
  "correct_answer": "A) \\\"[1, 2, 3]\\\"",
  "explanation": "Arrays.toString() returns string representation with brackets and commas."
}'),
                                                 (168, 17, '{
  "question": "What is array reversal?",
  "options": [
    "A) Changing order of elements",
    "B) Making array read-only",
    "C) Sorting in reverse",
    "D) Creating copy"
  ],
  "correct_answer": "A) Changing order of elements",
  "explanation": "Array reversal means changing element order: first becomes last, etc."
}'),
                                                 (169, 17, '{
  "question": "How to create subarray from array?",
  "options": [
    "A) Arrays.copyOfRange()",
    "B) System.arraycopy()",
    "C) substring() for arrays",
    "D) Arrays.subarray()"
  ],
  "correct_answer": "A) Arrays.copyOfRange()",
  "explanation": "Arrays.copyOfRange() creates new array containing specified range from original array."
}'),
                                                 (170, 17, '{
  "question": "What is array rotation?",
  "options": [
    "A) Shifting elements with wrap-around",
    "B) Sorting array",
    "C) Reversing array",
    "D) Copying array"
  ],
  "correct_answer": "A) Shifting elements with wrap-around",
  "explanation": "Array rotation moves elements left/right with elements wrapping around to other end."
}');

-- MCQs for Topic 18: Multi-dimensional Arrays
INSERT INTO mcqs (mcq_id, topic_id, content) VALUES
                                                 (171, 18, '{
  "question": "How to declare 2D array?",
  "options": [
    "A) int[][] matrix;",
    "B) int matrix[][];",
    "C) int[] matrix[];",
    "D) All of the above"
  ],
  "correct_answer": "D) All of the above",
  "explanation": "All three syntaxes are valid for 2D array declaration in Java."
}'),
                                                 (172, 18, '{
  "question": "What is jagged array?",
  "options": [
    "A) 2D array with different row lengths",
    "B) 3D array",
    "C) Irregular shaped array",
    "D) Sorted array"
  ],
  "correct_answer": "A) 2D array with different row lengths",
  "explanation": "Jagged array is 2D array where each row can have different number of columns."
}'),
                                                 (173, 18, '{
  "question": "How to access element in 2D array?",
  "options": [
    "A) matrix[row][col]",
    "B) matrix[row, col]",
    "C) matrix(row)(col)",
    "D) matrix.get(row, col)"
  ],
  "correct_answer": "A) matrix[row][col]",
  "explanation": "2D array elements are accessed using matrix[row][col] syntax."
}'),
                                                 (174, 18, '{
  "question": "What is the length of matrix[2][3]?",
  "options": [
    "A) matrix.length = 2, matrix[0].length = 3",
    "B) matrix.length = 3, matrix[0].length = 2",
    "C) matrix.length = 6",
    "D) Cannot determine"
  ],
  "correct_answer": "A) matrix.length = 2, matrix[0].length = 3",
  "explanation": "matrix.length gives number of rows (2), matrix[0].length gives columns in first row (3)."
}'),
                                                 (175, 18, '{
  "question": "How to initialize 2D array with values?",
  "options": [
    "A) int[][] matrix = {{1,2},{3,4}};",
    "B) int[][] matrix = new int[][]{{1,2},{3,4}};",
    "C) Both A and B",
    "D) int[][] matrix = new int[2][2]{{1,2},{3,4}};"
  ],
  "correct_answer": "C) Both A and B",
  "explanation": "Both syntaxes are valid for 2D array initialization with values."
}'),
                                                 (176, 18, '{
  "question": "What is 3D array?",
  "options": [
    "A) Array of 2D arrays",
    "B) Array with three dimensions",
    "C) Both A and B",
    "D) Cube-shaped array"
  ],
  "correct_answer": "C) Both A and B",
  "explanation": "3D array can be thought of as array of 2D arrays or array with three dimensions."
}'),
                                                 (177, 18, '{
  "question": "How to iterate through 2D array?",
  "options": [
    "A) Nested for loops",
    "B) Enhanced for loops",
    "C) While loops",
    "D) All of the above"
  ],
  "correct_answer": "D) All of the above",
  "explanation": "All loop types can be used, typically nested loops for 2D arrays."
}'),
                                                 (178, 18, '{
  "question": "What is matrix transpose?",
  "options": [
    "A) Rows become columns, columns become rows",
    "B) Reverse each row",
    "C) Sort matrix",
    "D) Copy matrix"
  ],
  "correct_answer": "A) Rows become columns, columns become rows",
  "explanation": "Matrix transpose swaps rows and columns: element at [i][j] moves to [j][i]."
}'),
                                                 (179, 18, '{
  "question": "Can 2D arrays have different column sizes?",
  "options": [
    "A) Yes, in jagged arrays",
    "B) No, always rectangular",
    "C) Only for String arrays",
    "D) Only for primitive arrays"
  ],
  "correct_answer": "A) Yes, in jagged arrays",
  "explanation": "Jagged arrays allow different column sizes for each row."
}'),
                                                 (180, 18, '{
  "question": "What is the memory layout of 2D array?",
  "options": [
    "A) Array of references to 1D arrays",
    "B) Contiguous block of all elements",
    "C) Depends on array type",
    "D) Random memory locations"
  ],
  "correct_answer": "A) Array of references to 1D arrays",
  "explanation": "In Java, 2D array is array of references, each pointing to a 1D array (row)."
}');