package com.ignite.CBL.repository;

import com.ignite.CBL.entity.Topic;
import com.ignite.CBL.entity.User;
import com.ignite.CBL.entity.UserTopicEngagement;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.ignite.CBL.entity.UserTopicEngagementId;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface UserTopicEngagementRepository extends JpaRepository<UserTopicEngagement, UserTopicEngagementId> {
    
    Optional<UserTopicEngagement> findByUser_UserIdAndTopic_TopicId(String userId, Integer topicId);
    
    boolean existsByUser_UserIdAndTopic_TopicId(String userId, Integer topicId);
    
    @Modifying
    @Transactional
    @Query("DELETE FROM UserTopicEngagement ute WHERE ute.topic.topicId = :topicId")
    void deleteByTopicId(@Param("topicId") Integer topicId);
}
