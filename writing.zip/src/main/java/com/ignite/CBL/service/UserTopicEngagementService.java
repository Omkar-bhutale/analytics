package com.ignite.CBL.service;

import com.ignite.CBL.dto.TopicEngagementDTO;

public interface UserTopicEngagementService {
    /**
     * Get or create topic engagement and ensure tracking is started
     * @param topicId The ID of the topic
     * @return The topic engagement DTO with tracking started
     */
    TopicEngagementDTO getOrStartTopicEngagement(Integer topicId);
    
    /**
     * Update the total time spent on a topic
     * @param topicId The ID of the topic
     * @param totalTimeInSeconds The total time spent in seconds
     * @return The updated topic engagement DTO
     */
    TopicEngagementDTO updateTotalTimeSpentAndMarkAsCompleted(Integer topicId, int totalTimeInSeconds, boolean isCompleted);
    
    /**
     * Mark a topic as completed for the current user
     * @param topicId The ID of the topic
     * @return The updated topic engagement DTO
     */
//    TopicEngagementDTO markTopicAsCompleted(Integer topicId);
    
    /**
     * Get topic engagement details for the current user and topic
     * @param topicId The ID of the topic
     * @return The topic engagement DTO, or null if not found
     */
    TopicEngagementDTO getTopicEngagement(Integer topicId);
}
