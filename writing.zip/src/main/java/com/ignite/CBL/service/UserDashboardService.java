package com.ignite.CBL.service;

import com.ignite.CBL.dto.UserDashboardResponceDTO;

import java.util.List;

public interface UserDashboardService {
    UserDashboardResponceDTO getUserDashboard();
    List<UserDashboardResponceDTO> getAllUsersDashboard();
}
