package com.ignite.CBL.service;

import com.ignite.CBL.dto.MainTopicSubTopicsResponceDTO;
import com.ignite.CBL.dto.TopicDTO;
import com.ignite.CBL.dto.TopicImportResponse;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface TopicService {
    
    Optional<TopicDTO> findTopicById(Integer topicId);
    
    Optional<TopicDTO> findTopicByTitle(String title);

    List<MainTopicSubTopicsResponceDTO> findAllMainTopicSubTopics();
    
    List<TopicDTO> findAllByMainTopicId(Integer mainTopicId);
    
    List<TopicDTO> findPaginatedByMainTopicId(Integer mainTopicId);
    
    TopicDTO createTopic(Integer mainTopicId, TopicDTO topicDTO);
    
    int createTopics(Integer mainTopicId, List<TopicDTO> topicDTOs);
    
    Optional<TopicDTO> updateTopic(Integer topicId, TopicDTO topicDTO);
    
    boolean deleteTopicById(Integer topicId);
    
    int deleteAllByMainTopicId(Integer mainTopicId);
    
    void deleteAll();
    
    boolean existsByTitle(String title);
    
    /**
     * Imports topics from an Excel file and creates main topics and topics if they don't exist.
     * @param file The Excel file containing main topics and topics
     * @param userId The ID of the user performing the import
     * @return TopicImportResponse containing the import results
     */
    TopicImportResponse importFromExcel(MultipartFile file, String userId);
}
