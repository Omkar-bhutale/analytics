package com.ignite.CBL.service.impl;

import com.ignite.CBL.dto.MCQDTO;
import com.ignite.CBL.entity.MCQ;
import com.ignite.CBL.entity.Topic;
import com.ignite.CBL.exception.ResourceNotFoundException;
import com.ignite.CBL.repository.MCQRepository;
import com.ignite.CBL.repository.TopicRepository;
import com.ignite.CBL.service.MCQService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class MCQServiceImpl implements MCQService {

    private final MCQRepository mcqRepository;
    private final TopicRepository topicRepository;
    private final ModelMapper modelMapper = new ModelMapper();



    @Override
    public Optional<MCQDTO> findMCQById(Integer mcqId) {
        log.debug("Finding MCQ by id: {}", mcqId);
        return mcqRepository.findMCQDTOById(mcqId);
    }

    @Override
    public List<MCQDTO> findAllMCQByTopicId(Integer topicId) {
        log.debug("Finding all MCQs for topic id: {}", topicId);
        if (!topicRepository.existsById(topicId)) {
            throw new ResourceNotFoundException("Topic not found with id: " + topicId);
        }
        return mcqRepository.findAllByTopicId(topicId);
    }

    @Override
    public Page<MCQDTO> findPaginatedMCQByTopicId(Integer topicId, Pageable pageable) {
        log.debug("Finding paginated MCQs for topic id: {}", topicId);
        if (!topicRepository.existsById(topicId)) {
            throw new ResourceNotFoundException("Topic not found with id: " + topicId);
        }
        return mcqRepository.findPaginatedByTopicId(topicId, pageable);
    }

    @Override
    public MCQDTO createMCQ(Integer topicId, MCQDTO mcqDTO) {
        log.debug("Creating new MCQ for topic id: {}", topicId);
        Topic topic = topicRepository.findById(topicId)
                .orElseThrow(() -> new ResourceNotFoundException("Topic not found with id: " + topicId));

        MCQ mcq = new MCQ();
        mcq.setContent(mcqDTO.getContent());
        mcq.setTopic(topic);
        
        return convertToDTO(mcqRepository.save(mcq));
    }

    @Override
    public int createMCQs(Integer topicId, List<MCQDTO> mcqDTOs) {
        log.debug("Creating {} MCQs for topic id: {}", mcqDTOs != null ? mcqDTOs.size() : 0, topicId);
        if (topicId == null || mcqDTOs == null || mcqDTOs.isEmpty()) {
            return 0;
        }

        Topic topic = topicRepository.findById(topicId)
                .orElseThrow(() -> new ResourceNotFoundException("Topic not found with id: " + topicId));

        List<MCQ> mcqs = mcqDTOs.stream()
                .map(dto -> {
                    MCQ mcq = new MCQ();
                    mcq.setContent(dto.getContent());
                    mcq.setTopic(topic);
                    return mcq;
                })
                .toList();

        return mcqRepository.saveAll(mcqs).size();
    }

    @Override
    public Optional<MCQDTO> updateMCQ(Integer mcqId, MCQDTO mcqDTO) {
        log.debug("Updating MCQ with id: {}", mcqId);
        return mcqRepository.findById(mcqId)
                .map(existingMCQ -> {
                    existingMCQ.setContent(mcqDTO.getContent());
                    
                    if (mcqDTO.getTopicId() != null && 
                        !mcqDTO.getTopicId().equals(existingMCQ.getTopic().getTopicId())) {
                        Topic newTopic = topicRepository.findById(mcqDTO.getTopicId())
                                .orElseThrow(() -> new ResourceNotFoundException("Topic not found with id: " + mcqDTO.getTopicId()));
                        existingMCQ.setTopic(newTopic);
                    }
                    
                    return convertToDTO(mcqRepository.save(existingMCQ));
                });
    }

    @Override
    public boolean deleteMCQById(Integer mcqId) {
        log.debug("Deleting MCQ with id: {}", mcqId);
        if (!mcqRepository.existsById(mcqId)) {
            return false;
        }
        mcqRepository.deleteById(mcqId);
        return true;
    }

    @Override
    public int deleteAllMCQByTopicId(Integer topicId) {
        log.debug("Deleting all MCQs for topic id: {}", topicId);
        if (!topicRepository.existsById(topicId)) {
            throw new ResourceNotFoundException("Topic not found with id: " + topicId);
        }
        return mcqRepository.deleteAllByTopicId(topicId);
    }

    @Override
    public long countByTopicId(Integer topicId) {
        log.debug("Counting MCQs for topic id: {}", topicId);
        if (!topicRepository.existsById(topicId)) {
            throw new ResourceNotFoundException("Topic not found with id: " + topicId);
        }
        return mcqRepository.countByTopic_TopicId(topicId);
    }

    @Override
    public boolean existsById(Integer mcqId) {
        return mcqRepository.existsByMcqId(mcqId);
    }

    // Helper method to convert entity to DTO
    private MCQDTO convertToDTO(MCQ mcq) {
        MCQDTO dto = new MCQDTO();
        dto.setMcqId(mcq.getMcqId());
        dto.setContent(mcq.getContent());
        dto.setTopicId(mcq.getTopic().getTopicId());
        return dto;
    }
}


