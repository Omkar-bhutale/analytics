package com.ignite.CBL.dto;

import com.fasterxml.jackson.databind.JsonNode;
import com.ignite.CBL.entity.Language;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.Set;

@Getter
@Setter
public class UserProblemReportDTO {
    private ProblemDTO problem;
    private boolean isSolved = false;
    private int totalAttempts;
    private Set<Language> languagesUsed;
    private JsonNode insight;
    private List<ProblemSubmissionResponceDTO> submissions;
}
