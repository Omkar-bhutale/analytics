package com.ignite.CBL.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TopicDTO {
    
    private Integer topicId;
    
    @NotBlank(message = "Title is required")
    @Size(min = 3, max = 100, message = "Title must be between {min} and {max} characters")
    private String title;
    
    @NotNull(message = "Content is required")
    private JsonNode content;
    
    private LocalDateTime createdAt;


    
    // For update operations
    public TopicDTO(String title, JsonNode content) {
        this.title = title;
        this.content = content;
    }
}
