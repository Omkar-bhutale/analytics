package com.ignite.CBL.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class AlgorithmResponceDTO {
    private Integer algorithmSubmissionId;
    private String content;
    private Boolean isCorrect;
    private Integer problemId;
    private Integer version;
    private LocalDateTime submittedAt;
}
