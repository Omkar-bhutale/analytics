package com.ignite.ttms.controller;

import com.ignite.ttms.dto.TrainResponse;
import com.ignite.ttms.dto.TrainSearchRequest;
import com.ignite.ttms.service.TrainService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/trains")
@RequiredArgsConstructor
@Tag(name = "Train Search (Public)", description = "Public APIs for searching and viewing trains")
public class TrainController {
    private final TrainService trainService;

    @PostMapping("/search")
    @Operation(summary = "Search Trains", description = "Search trains by origin and destination stations")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Trains found"),
            @ApiResponse(responseCode = "400", description = "Invalid search criteria")
    })
    public ResponseEntity<List<TrainResponse>> searchTrains(@Valid @RequestBody TrainSearchRequest request) {
        try {
            List<TrainResponse> trains = trainService.searchTrains(request);
            return ResponseEntity.ok(trains);
        } catch (RuntimeException e) {
            throw new RuntimeException("Train search failed: " + e.getMessage());
        }
    }

    @GetMapping
    @Operation(summary = "Get All Trains", description = "Retrieve all available trains")
    @ApiResponse(responseCode = "200", description = "List of all trains")
    public ResponseEntity<List<TrainResponse>> getAllTrains() {
        List<TrainResponse> trains = trainService.getAllTrains();
        return ResponseEntity.ok(trains);
    }

    @GetMapping("/{trainNumber}")
    @Operation(summary = "Get Train by Number", description = "Retrieve train details by train number")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Train found"),
            @ApiResponse(responseCode = "404", description = "Train not found")
    })
    public ResponseEntity<TrainResponse> getTrainByNumber(@PathVariable String trainNumber) {
        TrainResponse response = trainService.getTrainByNumber(trainNumber);
        return ResponseEntity.ok(response);
    }
}
