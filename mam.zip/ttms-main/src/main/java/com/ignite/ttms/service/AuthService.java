package com.ignite.ttms.service;

import com.ignite.ttms.dto.LoginRequest;
import com.ignite.ttms.dto.LoginResponse;
import com.ignite.ttms.entity.Admin;
import com.ignite.ttms.entity.Customer;
import com.ignite.ttms.repository.AdminRepository;
import com.ignite.ttms.repository.CustomerRepository;
import com.ignite.ttms.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class AuthService {
    private final AdminRepository adminRepository;
    private final CustomerRepository customerRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    public LoginResponse adminLogin(LoginRequest request) {
        Optional<Admin> adminOpt = adminRepository.findByUsername(request.getUsername());

        if (adminOpt.isPresent()) {
            Admin admin = adminOpt.get();
            if (passwordEncoder.matches(request.getPassword(), admin.getPassword())) {
                String token = jwtUtil.generateToken(admin.getUsername(), "ADMIN");
                return new LoginResponse(true, "Login successful", admin.getId(), admin.getUsername(), "ADMIN", token);
            }
        }
        return new LoginResponse(false, "Please Enter Correct UserName and Password", null, null, null, null);
    }

    public LoginResponse customerLogin(LoginRequest request) {
        Optional<Customer> customerOpt = customerRepository.findByEmail(request.getUsername());

        if (customerOpt.isPresent()) {
            Customer customer = customerOpt.get();
            if (!customer.getIsActive()) {
                return new LoginResponse(false, "Account is deactivated", null, null, null, null);
            }
            if (passwordEncoder.matches(request.getPassword(), customer.getPassword())) {
                String token = jwtUtil.generateToken(customer.getEmail(), "CUSTOMER");
                return new LoginResponse(true, "Login successful", customer.getId(), customer.getName(), "CUSTOMER", token);
            }
        }
        return new LoginResponse(false, "Please Enter Correct UserName and Password", null, null, null, null);
    }
}

