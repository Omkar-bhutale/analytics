package com.ignite.ttms.controller;

import com.ignite.ttms.dto.CustomerRequest;
import com.ignite.ttms.dto.CustomerRegistrationRequest;
import com.ignite.ttms.dto.CustomerUpdateRequest;
import com.ignite.ttms.dto.CustomerResponse;
import com.ignite.ttms.service.CustomerService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/customers")
@RequiredArgsConstructor
@Tag(name = "Customer Management", description = "APIs for customer registration and profile management")
public class CustomerController {
    private final CustomerService customerService;

    @PostMapping("/register")
    @Operation(summary = "Register Customer", description = "Register a new customer account with validation")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Customer registered successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error or email already exists")
    })
    public ResponseEntity<CustomerResponse> registerCustomer(@Valid @RequestBody CustomerRegistrationRequest request) {
        try {
            CustomerResponse response = customerService.registerCustomer(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (RuntimeException e) {
            throw new RuntimeException("Customer registration failed: " + e.getMessage());
        }
    }

    @PutMapping("/{customerId}")
    @Operation(summary = "Update Customer", description = "Update customer profile information")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Customer updated successfully"),
            @ApiResponse(responseCode = "404", description = "Customer not found"),
            @ApiResponse(responseCode = "400", description = "Validation error")
    })
    public ResponseEntity<CustomerResponse> updateCustomer(
            @PathVariable Long customerId,
            @Valid @RequestBody CustomerUpdateRequest request) {
        try {
            CustomerResponse response = customerService.updateCustomer(customerId, request);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            throw new RuntimeException("Customer update failed: " + e.getMessage());
        }
    }

    @DeleteMapping("/{customerId}")
    @Operation(summary = "Deactivate Customer", description = "Deactivate customer account")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Customer deactivated successfully"),
            @ApiResponse(responseCode = "404", description = "Customer not found")
    })
    public ResponseEntity<String> deactivateCustomer(@PathVariable Long customerId) {
        try {
            customerService.deactivateCustomer(customerId);
            return ResponseEntity.ok("Customer account deactivated successfully");
        } catch (RuntimeException e) {
            throw new RuntimeException("Customer deactivation failed: " + e.getMessage());
        }
    }

    @GetMapping("/{customerId}")
    @Operation(summary = "Get Customer Details", description = "Retrieve customer information by ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Customer found"),
            @ApiResponse(responseCode = "404", description = "Customer not found")
    })
    public ResponseEntity<CustomerResponse> getCustomer(@PathVariable Long customerId) {
        CustomerResponse response = customerService.getCustomer(customerId);
        return ResponseEntity.ok(response);
    }

    @GetMapping
    @Operation(summary = "Get All Customers", description = "Retrieve all customers (Admin only)")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Customers retrieved successfully")
    })
    public ResponseEntity<java.util.List<CustomerResponse>> getAllCustomers() {
        java.util.List<CustomerResponse> customers = customerService.getAllCustomers();
        return ResponseEntity.ok(customers);
    }

    @GetMapping("/email/{email}")
    @Operation(summary = "Get Customer by Email", description = "Retrieve customer information by email")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Customer found"),
            @ApiResponse(responseCode = "404", description = "Customer not found")
    })
    public ResponseEntity<CustomerResponse> getCustomerByEmail(@PathVariable String email) {
        CustomerResponse response = customerService.getCustomerByEmail(email);
        return ResponseEntity.ok(response);
    }

    @PutMapping("/{customerId}/activate")
    @Operation(summary = "Activate Customer", description = "Activate customer account (Admin only)")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Customer activated successfully"),
            @ApiResponse(responseCode = "404", description = "Customer not found")
    })
    public ResponseEntity<String> activateCustomer(@PathVariable Long customerId) {
        try {
            customerService.activateCustomer(customerId);
            return ResponseEntity.ok("Customer account activated successfully");
        } catch (RuntimeException e) {
            throw new RuntimeException("Customer activation failed: " + e.getMessage());
        }
    }
}
