package com.ignite.ttms.dto;

import com.ignite.ttms.entity.Booking;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookingResponse {
    private Long id;
    private String ticketId;
    private Long customerId;
    private String customerName;
    private String trainNumber;
    private String trainName;
    private String originStation;
    private String destinationStation;
    private LocalDate travelDate;
    private String travelClass;
    private Integer numberOfSeats;
    private Double totalFare;
    private Booking.BookingStatus status;
    private LocalDateTime bookingDateTime;
    private LocalDateTime cancellationDateTime;
}

