package com.ignite.ttms.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TrainResponse {
    private Long id;
    private String trainNumber;
    private String trainName;
    private String originStation;
    private String destinationStation;
    private List<String> intermediateStops;
    private LocalDateTime departureTime;
    private LocalDateTime arrivalTime;
    private Integer sleeperSeats;
    private Integer acSeats;
    private Integer availableSleeperSeats;
    private Integer availableAcSeats;
    private Double sleeperFare;
    private Double acFare;
}

