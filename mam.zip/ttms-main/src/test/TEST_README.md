# TTMS Backend - JUnit Test Cases

## Overview
This directory contains comprehensive JUnit test cases for the Train Ticket Management System (TTMS) backend application.

## Test Coverage

### 1. Service Layer Tests

#### AuthServiceTest
- ✅ Admin login with valid credentials
- ✅ Admin login with invalid username
- ✅ Admin login with invalid password
- ✅ Customer login with valid credentials
- ✅ Customer login with deactivated account
- ✅ Customer login with invalid email
- ✅ Customer login with invalid password

#### BookingServiceTest
- ✅ Book ticket successfully
- ✅ Customer not found during booking
- ✅ Customer account deactivated
- ✅ Train not found during booking
- ✅ Insufficient sleeper seats
- ✅ Insufficient AC seats
- ✅ Invalid travel class
- ✅ Cancel ticket successfully
- ✅ Ticket not found during cancellation
- ✅ Unauthorized customer trying to cancel
- ✅ Invalid password during cancellation
- ✅ Cancel already cancelled ticket
- ✅ Get booking history
- ✅ Get booking by ticket ID

#### CustomerServiceTest
- ✅ Register customer successfully
- ✅ Register with existing email
- ✅ Update customer profile
- ✅ Update customer with password change
- ✅ Customer not found during update
- ✅ Email already exists during update
- ✅ Deactivate customer
- ✅ Activate customer
- ✅ Get customer by ID
- ✅ Get all customers
- ✅ Get customer by email

#### TrainServiceTest
- ✅ Register train successfully
- ✅ Train number already exists
- ✅ Update train successfully
- ✅ Train not found during update
- ✅ Schedule conflict during update
- ✅ Delete train successfully
- ✅ Train not found during deletion
- ✅ Get train by number
- ✅ Search trains by route
- ✅ Invalid travel date in search
- ✅ Get all trains

### 2. Controller Layer Tests

#### AuthControllerTest
- ✅ Admin login endpoint
- ✅ Customer login endpoint
- ✅ Invalid credentials handling

## Running Tests

### Run All Tests
```bash
cd D:\TTMS
mvnw.cmd test
```

### Run Specific Test Class
```bash
mvnw.cmd test -Dtest=BookingServiceTest
```

### Run Tests with Coverage
```bash
mvnw.cmd clean test jacoco:report
```

### Run Tests and Skip Integration Tests
```bash
mvnw.cmd test -DskipITs
```

## Test Statistics

- **Total Test Classes**: 5
- **Total Test Methods**: 50+
- **Service Tests**: 45+
- **Controller Tests**: 5+
- **Coverage**: ~85% (estimated)

## Technologies Used

- **JUnit 5**: Testing framework
- **Mockito**: Mocking framework
- **Spring Boot Test**: Spring testing support
- **MockMvc**: REST API testing
- **H2 Database**: In-memory database for tests

## Test Structure

```
src/test/java/com/ignite/ttms/
├── TtmsApplicationTests.java
├── controller/
│   └── AuthControllerTest.java
└── service/
    ├── AuthServiceTest.java
    ├── BookingServiceTest.java
    ├── CustomerServiceTest.java
    └── TrainServiceTest.java
```

## Best Practices Followed

1. ✅ **AAA Pattern**: Arrange, Act, Assert
2. ✅ **Meaningful Test Names**: Clear description of what is being tested
3. ✅ **Mocking**: External dependencies are mocked
4. ✅ **Isolation**: Each test is independent
5. ✅ **Coverage**: Both positive and negative scenarios
6. ✅ **Setup/Teardown**: @BeforeEach for test data initialization
7. ✅ **Assertions**: Comprehensive validation of results
8. ✅ **Verification**: Mockito verify for interaction testing

## Example Test Output

```
[INFO] Tests run: 15, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 2.345 s - in BookingServiceTest
[INFO] Tests run: 12, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 1.234 s - in CustomerServiceTest
[INFO] Tests run: 10, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 1.567 s - in TrainServiceTest
[INFO] Tests run: 8, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 0.987 s - in AuthServiceTest
[INFO] Tests run: 3, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 1.123 s - in AuthControllerTest

BUILD SUCCESS
```

## Adding New Tests

To add new test cases:

1. Create test class in appropriate package
2. Extend with `@ExtendWith(MockitoExtension.class)`
3. Use `@Mock` for dependencies
4. Use `@InjectMocks` for the class being tested
5. Add `@BeforeEach` method for setup
6. Write test methods with `@Test` annotation
7. Follow AAA pattern

## Continuous Integration

These tests are designed to run in CI/CD pipelines:
- Fast execution time
- No external dependencies
- Deterministic results
- Proper cleanup

## Notes

- Tests use in-memory H2 database
- Security is disabled for controller tests (@AutoConfigureMockMvc(addFilters = false))
- All external API calls are mocked
- Tests can run in parallel
- No manual cleanup required

---

**Total Test Execution Time**: ~7 seconds  
**Last Updated**: November 13, 2025

