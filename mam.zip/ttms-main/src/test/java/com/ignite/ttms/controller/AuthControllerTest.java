package com.ignite.ttms.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ignite.ttms.dto.LoginRequest;
import com.ignite.ttms.dto.LoginResponse;
import com.ignite.ttms.service.AuthService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class AuthControllerTest {

    private MockMvc mockMvc;

    private ObjectMapper objectMapper;

    @Mock
    private AuthService authService;

    @InjectMocks
    private AuthController authController;

    private LoginRequest loginRequest;
    private LoginResponse successResponse;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(authController).build();
        objectMapper = new ObjectMapper();

        loginRequest = new LoginRequest();
        loginRequest.setUsername("admin");
        loginRequest.setPassword("admin123");

        successResponse = new LoginResponse();
        successResponse.setSuccess(true);
        successResponse.setMessage("Login successful");
        successResponse.setUserId(1L);
        successResponse.setUsername("admin");
        successResponse.setRole("ADMIN");
        successResponse.setToken("mockJwtToken");
    }

    @Test
    void testAdminLogin_Success() throws Exception {
        // Arrange
        when(authService.adminLogin(any(LoginRequest.class))).thenReturn(successResponse);

        // Act & Assert
        mockMvc.perform(post("/api/auth/admin/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(loginRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Login successful"))
                .andExpect(jsonPath("$.userId").value(1))
                .andExpect(jsonPath("$.role").value("ADMIN"))
                .andExpect(jsonPath("$.token").value("mockJwtToken"));
    }

    @Test
    void testCustomerLogin_Success() throws Exception {
        // Arrange
        successResponse.setRole("CUSTOMER");
        when(authService.customerLogin(any(LoginRequest.class))).thenReturn(successResponse);

        // Act & Assert
        mockMvc.perform(post("/api/auth/customer/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(loginRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.role").value("CUSTOMER"));
    }

    @Test
    void testAdminLogin_InvalidCredentials() throws Exception {
        // Arrange
        LoginResponse failureResponse = new LoginResponse();
        failureResponse.setSuccess(false);
        failureResponse.setMessage("Please Enter Correct UserName and Password");

        when(authService.adminLogin(any(LoginRequest.class))).thenReturn(failureResponse);

        // Act & Assert
        mockMvc.perform(post("/api/auth/admin/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(loginRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Please Enter Correct UserName and Password"));
    }
}

