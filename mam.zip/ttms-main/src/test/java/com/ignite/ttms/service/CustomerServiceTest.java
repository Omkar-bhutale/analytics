package com.ignite.ttms.service;

import com.ignite.ttms.dto.CustomerRegistrationRequest;
import com.ignite.ttms.dto.CustomerResponse;
import com.ignite.ttms.dto.CustomerUpdateRequest;
import com.ignite.ttms.entity.Customer;
import com.ignite.ttms.repository.CustomerRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CustomerServiceTest {

    @Mock
    private CustomerRepository customerRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private CustomerService customerService;

    private Customer testCustomer;
    private CustomerRegistrationRequest registrationRequest;
    private CustomerUpdateRequest updateRequest;

    @BeforeEach
    void setUp() {
        testCustomer = new Customer();
        testCustomer.setId(1L);
        testCustomer.setName("John Doe");
        testCustomer.setEmail("john@example.com");
        testCustomer.setPhoneNumber("9876543210");
        testCustomer.setAddress("123 Main Street");
        testCustomer.setPassword("$2a$10$encodedPassword");
        testCustomer.setIsActive(true);

        registrationRequest = new CustomerRegistrationRequest();
        registrationRequest.setName("John Doe");
        registrationRequest.setEmail("john@example.com");
        registrationRequest.setPhoneNumber("9876543210");
        registrationRequest.setAddress("123 Main Street");
        registrationRequest.setPassword("Password@123");

        updateRequest = new CustomerUpdateRequest();
        updateRequest.setName("John Updated");
        updateRequest.setEmail("john@example.com");
        updateRequest.setPhoneNumber("9876543210");
        updateRequest.setAddress("456 New Street");
        updateRequest.setPassword("");
    }

    @Test
    void testRegisterCustomer_Success() {
        // Arrange
        when(customerRepository.existsByEmail("john@example.com")).thenReturn(false);
        when(passwordEncoder.encode("Password@123")).thenReturn("$2a$10$encodedPassword");
        when(customerRepository.save(any(Customer.class))).thenReturn(testCustomer);

        // Act
        CustomerResponse response = customerService.registerCustomer(registrationRequest);

        // Assert
        assertNotNull(response);
        assertEquals("John Doe", response.getName());
        assertEquals("john@example.com", response.getEmail());
        assertEquals("9876543210", response.getPhoneNumber());
        assertTrue(response.getIsActive());

        verify(customerRepository, times(1)).existsByEmail("john@example.com");
        verify(passwordEncoder, times(1)).encode("Password@123");
        verify(customerRepository, times(1)).save(any(Customer.class));
    }

    @Test
    void testRegisterCustomer_EmailAlreadyExists() {
        // Arrange
        when(customerRepository.existsByEmail("john@example.com")).thenReturn(true);

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            customerService.registerCustomer(registrationRequest);
        });

        assertEquals("Email already exists", exception.getMessage());
        verify(customerRepository, times(1)).existsByEmail("john@example.com");
        verify(customerRepository, never()).save(any(Customer.class));
    }

    @Test
    void testUpdateCustomer_Success() {
        // Arrange
        when(customerRepository.findById(1L)).thenReturn(Optional.of(testCustomer));
        when(customerRepository.save(any(Customer.class))).thenReturn(testCustomer);

        // Act
        CustomerResponse response = customerService.updateCustomer(1L, updateRequest);

        // Assert
        assertNotNull(response);
        verify(customerRepository, times(1)).findById(1L);
        verify(customerRepository, times(1)).save(any(Customer.class));
    }

    @Test
    void testUpdateCustomer_WithPassword() {
        // Arrange
        updateRequest.setPassword("NewPassword@123");
        when(customerRepository.findById(1L)).thenReturn(Optional.of(testCustomer));
        when(passwordEncoder.encode("NewPassword@123")).thenReturn("$2a$10$newEncodedPassword");
        when(customerRepository.save(any(Customer.class))).thenReturn(testCustomer);

        // Act
        CustomerResponse response = customerService.updateCustomer(1L, updateRequest);

        // Assert
        assertNotNull(response);
        verify(passwordEncoder, times(1)).encode("NewPassword@123");
        verify(customerRepository, times(1)).save(any(Customer.class));
    }

    @Test
    void testUpdateCustomer_CustomerNotFound() {
        // Arrange
        when(customerRepository.findById(1L)).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            customerService.updateCustomer(1L, updateRequest);
        });

        assertEquals("Customer not found", exception.getMessage());
        verify(customerRepository, times(1)).findById(1L);
        verify(customerRepository, never()).save(any(Customer.class));
    }

    @Test
    void testUpdateCustomer_EmailAlreadyExists() {
        // Arrange
        updateRequest.setEmail("newemail@example.com");
        when(customerRepository.findById(1L)).thenReturn(Optional.of(testCustomer));
        when(customerRepository.existsByEmail("newemail@example.com")).thenReturn(true);

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            customerService.updateCustomer(1L, updateRequest);
        });

        assertEquals("Email already exists", exception.getMessage());
        verify(customerRepository, never()).save(any(Customer.class));
    }

    @Test
    void testDeactivateCustomer_Success() {
        // Arrange
        when(customerRepository.findById(1L)).thenReturn(Optional.of(testCustomer));
        when(customerRepository.save(any(Customer.class))).thenReturn(testCustomer);

        // Act
        customerService.deactivateCustomer(1L);

        // Assert
        verify(customerRepository, times(1)).findById(1L);
        verify(customerRepository, times(1)).save(any(Customer.class));
    }

    @Test
    void testActivateCustomer_Success() {
        // Arrange
        testCustomer.setIsActive(false);
        when(customerRepository.findById(1L)).thenReturn(Optional.of(testCustomer));
        when(customerRepository.save(any(Customer.class))).thenReturn(testCustomer);

        // Act
        customerService.activateCustomer(1L);

        // Assert
        verify(customerRepository, times(1)).findById(1L);
        verify(customerRepository, times(1)).save(any(Customer.class));
    }

    @Test
    void testGetCustomer_Success() {
        // Arrange
        when(customerRepository.findById(1L)).thenReturn(Optional.of(testCustomer));

        // Act
        CustomerResponse response = customerService.getCustomer(1L);

        // Assert
        assertNotNull(response);
        assertEquals(1L, response.getId());
        assertEquals("John Doe", response.getName());
        verify(customerRepository, times(1)).findById(1L);
    }

    @Test
    void testGetCustomer_NotFound() {
        // Arrange
        when(customerRepository.findById(1L)).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            customerService.getCustomer(1L);
        });

        assertEquals("Customer not found", exception.getMessage());
    }

    @Test
    void testGetAllCustomers_Success() {
        // Arrange
        List<Customer> customers = new ArrayList<>();
        customers.add(testCustomer);
        when(customerRepository.findAll()).thenReturn(customers);

        // Act
        List<CustomerResponse> result = customerService.getAllCustomers();

        // Assert
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("John Doe", result.get(0).getName());
        verify(customerRepository, times(1)).findAll();
    }

    @Test
    void testGetCustomerByEmail_Success() {
        // Arrange
        when(customerRepository.findByEmail("john@example.com")).thenReturn(Optional.of(testCustomer));

        // Act
        CustomerResponse response = customerService.getCustomerByEmail("john@example.com");

        // Assert
        assertNotNull(response);
        assertEquals("john@example.com", response.getEmail());
        verify(customerRepository, times(1)).findByEmail("john@example.com");
    }

    @Test
    void testGetCustomerByEmail_NotFound() {
        // Arrange
        when(customerRepository.findByEmail("notfound@example.com")).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            customerService.getCustomerByEmail("notfound@example.com");
        });

        assertEquals("Customer not found", exception.getMessage());
    }
}

