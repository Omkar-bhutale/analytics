import React, { useState, useEffect } from 'react';
import { customerAPI } from '../services/api';
import { toast } from 'react-toastify';

const AdminCustomers = () => {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCustomers();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const fetchCustomers = async () => {
    try {
      const response = await customerAPI.getAll();
      setCustomers(response.data);
    } catch (error) {
      toast.error('Failed to fetch customers');
    } finally {
      setLoading(false);
    }
  };

  const handleActivate = async (customerId) => {
    try {
      await customerAPI.activate(customerId);
      toast.success('Customer activated successfully');
      fetchCustomers();
    } catch (error) {
      toast.error('Failed to activate customer');
    }
  };

  const handleDeactivate = async (customerId) => {
    if (!window.confirm('Are you sure you want to deactivate this customer?')) {
      return;
    }

    try {
      await customerAPI.deactivate(customerId);
      toast.success('Customer deactivated successfully');
      fetchCustomers();
    } catch (error) {
      toast.error('Failed to deactivate customer');
    }
  };

  if (loading) {
    return (
      <div className="page">
        <div className="container">
          <div className="loading">
            <div className="spinner"></div>
            <p>Loading customers...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="container">
        <h2>Manage Customers</h2>

        {customers.length > 0 ? (
          <div>
            {customers.map((customer) => (
              <div key={customer.id} className="card" style={{ marginBottom: '1rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start' }}>
                  <div style={{ flex: 1 }}>
                    <h3 style={{ marginBottom: '1rem' }}>{customer.name}</h3>
                    <div className="train-details">
                      <div className="detail-item">
                        <div className="detail-label">Email</div>
                        <div className="detail-value">{customer.email}</div>
                      </div>
                      <div className="detail-item">
                        <div className="detail-label">Phone</div>
                        <div className="detail-value">{customer.phoneNumber}</div>
                      </div>
                      <div className="detail-item">
                        <div className="detail-label">Address</div>
                        <div className="detail-value">{customer.address}</div>
                      </div>
                      <div className="detail-item">
                        <div className="detail-label">Status</div>
                        <div className="detail-value">
                          <span className={`status-badge ${customer.isActive ? 'status-confirmed' : 'status-cancelled'}`}>
                            {customer.isActive ? 'Active' : 'Inactive'}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div>
                    {customer.isActive ? (
                      <button
                        className="btn btn-danger"
                        onClick={() => handleDeactivate(customer.id)}
                      >
                        Deactivate
                      </button>
                    ) : (
                      <button
                        className="btn btn-success"
                        onClick={() => handleActivate(customer.id)}
                      >
                        Activate
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="empty-state">
            <h3>No customers found</h3>
            <p>No customers have registered yet</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminCustomers;

