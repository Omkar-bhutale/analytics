import React, { useState, useEffect } from 'react';
import { trainAPI } from '../services/api';
import { toast } from 'react-toastify';

const AdminTrains = () => {
  const [trains, setTrains] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('list');
  const [editingTrain, setEditingTrain] = useState(null);
  const [formData, setFormData] = useState({
    trainNumber: '',
    trainName: '',
    originStation: '',
    destinationStation: '',
    intermediateStops: [],
    departureTime: '',
    arrivalTime: '',
    sleeperSeats: '',
    acSeats: '',
    sleeperFare: '',
    acFare: '',
  });
  const [intermediateStopInput, setIntermediateStopInput] = useState('');

  useEffect(() => {
    fetchTrains();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const fetchTrains = async () => {
    try {
      const response = await trainAPI.getAll();
      setTrains(response.data);
    } catch (error) {
      toast.error('Failed to fetch trains');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const resetForm = () => {
    setFormData({
      trainNumber: '',
      trainName: '',
      originStation: '',
      destinationStation: '',
      intermediateStops: [],
      departureTime: '',
      arrivalTime: '',
      sleeperSeats: '',
      acSeats: '',
      sleeperFare: '',
      acFare: '',
    });
    setIntermediateStopInput('');
    setEditingTrain(null);
  };

  const addIntermediateStop = () => {
    const trimmedInput = intermediateStopInput.trim();

    if (!trimmedInput) {
      toast.warning('Please enter a station name');
      return;
    }

    if (formData.intermediateStops.includes(trimmedInput)) {
      toast.warning('This station is already added');
      return;
    }

    setFormData({
      ...formData,
      intermediateStops: [...formData.intermediateStops, trimmedInput]
    });
    setIntermediateStopInput('');
    toast.success(`Added: ${trimmedInput}`);
  };

  const removeIntermediateStop = (index) => {
    setFormData({
      ...formData,
      intermediateStops: formData.intermediateStops.filter((_, i) => i !== index)
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Prepare data with proper formatting
      const trainData = {
        ...formData,
        sleeperSeats: parseInt(formData.sleeperSeats),
        acSeats: parseInt(formData.acSeats),
        sleeperFare: parseFloat(formData.sleeperFare),
        acFare: parseFloat(formData.acFare),
        intermediateStops: formData.intermediateStops || []
      };

      if (editingTrain) {
        await trainAPI.update(editingTrain.trainNumber, trainData);
        toast.success('Train updated successfully');
      } else {
        await trainAPI.create(trainData);
        toast.success('Train added successfully');
      }

      resetForm();
      setActiveTab('list');
      fetchTrains();
    } catch (error) {
      console.error('Train operation error:', error);
      const errorMessage = error.response?.data?.message ||
                          error.response?.data?.errors?.[0]?.defaultMessage ||
                          error.message ||
                          'Operation failed. Please check all fields.';
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (train) => {
    setEditingTrain(train);
    setFormData({
      trainNumber: train.trainNumber,
      trainName: train.trainName,
      originStation: train.originStation,
      destinationStation: train.destinationStation,
      intermediateStops: train.intermediateStops || [],
      departureTime: train.departureTime.slice(0, 16),
      arrivalTime: train.arrivalTime.slice(0, 16),
      sleeperSeats: train.sleeperSeats,
      acSeats: train.acSeats,
      sleeperFare: train.sleeperFare,
      acFare: train.acFare,

    });
    setActiveTab('add');
  };

  const handleDelete = async (trainNumber) => {
    if (!window.confirm('Are you sure you want to delete this train?')) {
      return;
    }

    try {
      await trainAPI.delete(trainNumber);
      toast.success('Train deleted successfully');
      fetchTrains();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to delete train');
    }
  };

  return (
    <div className="page">
      <div className="container">
        <h2>Manage Trains</h2>

        <div className="tabs">
          <button
            className={`tab ${activeTab === 'list' ? 'active' : ''}`}
            onClick={() => { setActiveTab('list'); resetForm(); }}
          >
            Train List
          </button>
          <button
            className={`tab ${activeTab === 'add' ? 'active' : ''}`}
            onClick={() => setActiveTab('add')}
          >
            {editingTrain ? 'Edit Train' : 'Add Train'}
          </button>
        </div>

        {activeTab === 'list' ? (
          loading ? (
            <div className="loading">
              <div className="spinner"></div>
              <p>Loading trains...</p>
            </div>
          ) : trains.length > 0 ? (
            <div>
              {trains.map((train) => (
                <div key={train.id} className="train-card">
                  <div className="train-header">
                    <div>
                      <div className="train-number">{train.trainNumber}</div>
                      <div className="train-name">{train.trainName}</div>
                    </div>
                  </div>

                  <div className="train-route">
                    <span>{train.originStation}</span>
                    <span className="route-arrow">→</span>
                    <span>{train.destinationStation}</span>
                  </div>

                  {train.intermediateStops && train.intermediateStops.length > 0 && (
                    <div style={{
                      marginBottom: '1rem',
                      padding: '0.75rem',
                      background: '#f8f9fa',
                      borderRadius: '4px'
                    }}>
                      <div style={{ fontSize: '0.85rem', color: '#666', marginBottom: '0.5rem', fontWeight: '600' }}>
                        Intermediate Stops:
                      </div>
                      <ul style={{
                        margin: 0,
                        paddingLeft: '1.5rem',
                        listStyleType: 'disc'
                      }}>
                        {train.intermediateStops.map((stop, index) => (
                          <li
                            key={index}
                            style={{
                              fontSize: '0.95rem',
                              color: '#333',
                              marginBottom: '0.25rem'
                            }}
                          >
                            {stop}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  <div className="train-details">
                    <div className="detail-item">
                      <div className="detail-label">Departure</div>
                      <div className="detail-value">
                        {new Date(train.departureTime).toLocaleString()}
                      </div>
                    </div>
                    <div className="detail-item">
                      <div className="detail-label">Arrival</div>
                      <div className="detail-value">
                        {new Date(train.arrivalTime).toLocaleString()}
                      </div>
                    </div>
                  </div>

                  <div className="seat-info">
                    <div className="seat-type">
                      <h4>Sleeper</h4>
                      <p>Total: {train.sleeperSeats}</p>
                      <p>Available: {train.availableSleeperSeats}</p>
                      <p>Fare: ₹{train.sleeperFare}</p>
                    </div>
                    <div className="seat-type">
                      <h4>AC</h4>
                      <p>Total: {train.acSeats}</p>
                      <p>Available: {train.availableAcSeats}</p>
                      <p>Fare: ₹{train.acFare}</p>
                    </div>
                  </div>

                  <div style={{ display: 'flex', gap: '1rem' }}>
                    <button className="btn btn-primary" onClick={() => handleEdit(train)}>
                      Edit
                    </button>
                    <button className="btn btn-danger" onClick={() => handleDelete(train.trainNumber)}>
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="empty-state">
              <h3>No trains found</h3>
              <p>Add your first train to get started</p>
            </div>
          )
        ) : (
          <div className="card">
            <h3>{editingTrain ? 'Edit Train' : 'Add New Train'}</h3>
            <form onSubmit={handleSubmit}>
              <div className="form-row">
                <div className="form-group">
                  <label>Train Number *</label>
                  <input
                    type="text"
                    name="trainNumber"
                    value={formData.trainNumber}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Train Name *</label>
                  <input
                    type="text"
                    name="trainName"
                    value={formData.trainName}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Origin Station *</label>
                  <input
                    type="text"
                    name="originStation"
                    value={formData.originStation}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Destination Station *</label>
                  <input
                    type="text"
                    name="destinationStation"
                    value={formData.destinationStation}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>

              <div className="form-group">
                <label>Intermediate Stops (Optional)</label>
                <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '0.5rem' }}>
                  <input
                    type="text"
                    value={intermediateStopInput}
                    onChange={(e) => setIntermediateStopInput(e.target.value)}
                    placeholder="Enter station name"
                    onKeyPress={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addIntermediateStop();
                      }
                    }}
                  />
                  <button 
                    type="button" 
                    className="btn btn-secondary" 
                    onClick={addIntermediateStop}
                    style={{ whiteSpace: 'nowrap' }}
                  >
                    Add Stop
                  </button>
                </div>
                {formData.intermediateStops.length > 0 && (
                  <div style={{ 
                    padding: '0.75rem',
                    background: '#f8f9fa',
                    borderRadius: '4px',
                    marginTop: '0.5rem'
                  }}>
                    <div style={{ fontSize: '0.85rem', color: '#666', marginBottom: '0.5rem', fontWeight: '600' }}>
                      Added Stops ({formData.intermediateStops.length}):
                    </div>
                    <ul style={{
                      margin: 0,
                      paddingLeft: '1.5rem',
                      listStyleType: 'decimal'
                    }}>
                      {formData.intermediateStops.map((stop, index) => (
                        <li
                          key={index}
                          style={{
                            fontSize: '0.95rem',
                            color: '#333',
                            marginBottom: '0.5rem',
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center'
                          }}
                        >
                          <span>{stop}</span>
                          <button
                            type="button"
                            onClick={() => removeIntermediateStop(index)}
                            className="btn btn-danger"
                            style={{
                              padding: '0.25rem 0.5rem',
                              fontSize: '0.8rem',
                              marginLeft: '1rem'
                            }}
                          >
                            Remove
                          </button>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Departure Time *</label>
                  <input
                    type="datetime-local"
                    name="departureTime"
                    value={formData.departureTime}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Arrival Time *</label>
                  <input
                    type="datetime-local"
                    name="arrivalTime"
                    value={formData.arrivalTime}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Sleeper Seats *</label>
                  <input
                    type="number"
                    name="sleeperSeats"
                    value={formData.sleeperSeats}
                    onChange={handleChange}
                    min="0"
                    required
                  />
                </div>
                <div className="form-group">
                  <label>AC Seats *</label>
                  <input
                    type="number"
                    name="acSeats"
                    value={formData.acSeats}
                    onChange={handleChange}
                    min="0"
                    required
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Sleeper Fare (₹) *</label>
                  <input
                    type="number"
                    name="sleeperFare"
                    value={formData.sleeperFare}
                    onChange={handleChange}
                    step="0.01"
                    min="0"
                    required
                  />
                </div>
                <div className="form-group">
                  <label>AC Fare (₹) *</label>
                  <input
                    type="number"
                    name="acFare"
                    value={formData.acFare}
                    onChange={handleChange}
                    step="0.01"
                    min="0"
                    required
                  />
                </div>
              </div>

              <div style={{ display: 'flex', gap: '1rem' }}>
                <button type="submit" className="btn btn-primary" disabled={loading}>
                  {loading ? 'Saving...' : editingTrain ? 'Update Train' : 'Add Train'}
                </button>
                {editingTrain && (
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={() => { resetForm(); setActiveTab('list'); }}
                  >
                    Cancel
                  </button>
                )}
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminTrains;

