import React, { useState, useEffect } from 'react';
import { bookingAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';

const MyBookings = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [cancellingBooking, setCancellingBooking] = useState(null);
  const [password, setPassword] = useState('');
  const { user } = useAuth();

  useEffect(() => {
    fetchBookings();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const fetchBookings = async () => {
    try {
      const response = await bookingAPI.getByCustomer(user.userId);
      setBookings(response.data);
    } catch (error) {
      toast.error('Failed to fetch bookings');
    } finally {
      setLoading(false);
    }
  };

  const handleCancelBooking = async (booking) => {
    setCancellingBooking(booking);
    setPassword('');
  };

  const confirmCancellation = async (e) => {
    e.preventDefault();

    if (!password) {
      toast.error('Please enter your password');
      return;
    }

    if (!cancellingBooking.ticketId) {
      toast.error('Ticket ID is missing');
      console.error('Booking data:', cancellingBooking);
      return;
    }

    if (!user.userId) {
      toast.error('User ID is missing');
      console.error('User data:', user);
      return;
    }

    try {
      const cancellationData = {
        ticketId: cancellingBooking.ticketId,
        password: password,
        customerId: user.userId
      };

      console.log('=== CANCELLATION REQUEST ===');
      console.log('Ticket ID:', cancellationData.ticketId);
      console.log('Customer ID:', cancellationData.customerId);
      console.log('Password length:', password.length);
      console.log('Full payload:', JSON.stringify(cancellationData));
      console.log('==========================');

      const response = await bookingAPI.cancel(cancellationData);
      console.log('Cancellation response:', response);
      toast.success(response.data || 'Booking cancelled successfully');
      setCancellingBooking(null);
      setPassword('');
      fetchBookings();
    } catch (error) {
      console.error('Cancellation error:', error);
      console.error('Error response data:', error.response?.data);
      console.error('Error response status:', error.response?.status);

      let errorMessage = 'Failed to cancel booking';

      if (error.response?.data) {
        const data = error.response.data;
        // Handle different error response formats
        if (typeof data === 'string') {
          errorMessage = data;
        } else if (data.message) {
          errorMessage = data.message;
        } else if (data.error) {
          errorMessage = data.error;
        } else if (data.validationErrors) {
          // Handle validation errors
          const validationMessages = Object.values(data.validationErrors).join(', ');
          errorMessage = validationMessages || 'Validation failed';
        }
      } else if (error.message) {
        errorMessage = error.message;
      }

      toast.error(errorMessage);
    }
  };

  const closeCancelModal = () => {
    setCancellingBooking(null);
    setPassword('');
  };

  if (loading) {
    return (
      <div className="page">
        <div className="container">
          <div className="loading">
            <div className="spinner"></div>
            <p>Loading bookings...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="container">
        <h2>My Bookings</h2>

        {bookings.length > 0 ? (
          <div>
            {bookings.map((booking) => (
              <div key={booking.id} className="booking-card">
                <div className="booking-header">
                  <div>
                    <div className="booking-id">Booking #{booking.id}</div>
                    <div>Ticket ID: {booking.ticketId}</div>
                  </div>
                  <span className={`status-badge status-${booking.status.toLowerCase()}`}>
                    {booking.status}
                  </span>
                </div>

                <div className="train-route">
                  <span><strong>Train:</strong> {booking.trainName} ({booking.trainNumber})</span>
                </div>

                <div className="train-details">
                  <div className="detail-item">
                    <div className="detail-label">Seat Type</div>
                    <div className="detail-value">{booking.travelClass}</div>
                  </div>
                  <div className="detail-item">
                    <div className="detail-label">Number of Seats</div>
                    <div className="detail-value">{booking.numberOfSeats}</div>
                  </div>
                  <div className="detail-item">
                    <div className="detail-label">Total Fare</div>
                    <div className="detail-value">₹{booking.totalFare}</div>
                  </div>
                  <div className="detail-item">
                    <div className="detail-label">Booking Date</div>
                    <div className="detail-value">
                      {new Date(booking.bookingDateTime).toLocaleDateString()}
                    </div>
                  </div>
                </div>

                {booking.status === 'CONFIRMED' && (
                  <button
                    className="btn btn-danger"
                    onClick={() => handleCancelBooking(booking)}
                  >
                    Cancel Booking
                  </button>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="empty-state">
            <h3>No bookings found</h3>
            <p>You haven't made any bookings yet</p>
          </div>
        )}

        {cancellingBooking && (
          <div className="modal-overlay" onClick={closeCancelModal}>
            <div className="modal" onClick={(e) => e.stopPropagation()}>
              <span className="modal-close" onClick={closeCancelModal}>&times;</span>
              <h3>Cancel Booking</h3>
              <p>Are you sure you want to cancel this booking?</p>
              <p><strong>Ticket ID:</strong> {cancellingBooking.ticketId}</p>
              <p><strong>Train:</strong> {cancellingBooking.trainName}</p>

              <form onSubmit={confirmCancellation}>
                <div className="form-group">
                  <label>Enter your password to confirm cancellation</label>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter password"
                    required
                    autoFocus
                  />
                </div>

                <div style={{ display: 'flex', gap: '1rem' }}>
                  <button type="submit" className="btn btn-danger">
                    Confirm Cancellation
                  </button>
                  <button type="button" className="btn btn-secondary" onClick={closeCancelModal}>
                    Close
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MyBookings;

