import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { authAPI } from '../services/api';
import { toast } from 'react-toastify';

const Login = () => {
  const [loginType, setLoginType] = useState('customer');
  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();
  const { login } = useAuth();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = loginType === 'admin'
        ? await authAPI.adminLogin(formData)
        : await authAPI.customerLogin(formData);

      const data = response.data;

      if (data.success) {
        login(
          {
            userId: data.userId,
            username: data.username, // Use username from backend response
            role: data.role,
          },
          data.token
        );
        toast.success(data.message);

        if (data.role === 'ADMIN') {
          navigate('/admin/trains');
        } else {
          navigate('/search-trains');
        }
      } else {
        toast.error(data.message);
      }
    } catch (error) {
      toast.error(error.response?.data?.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page">
      <div className="container">
        <div className="card" style={{ maxWidth: '500px', margin: '0 auto' }}>
          <h2>Login</h2>

          <div className="tabs">
            <button
              className={`tab ${loginType === 'customer' ? 'active' : ''}`}
              onClick={() => setLoginType('customer')}
            >
              Customer
            </button>
            <button
              className={`tab ${loginType === 'admin' ? 'active' : ''}`}
              onClick={() => setLoginType('admin')}
            >
              Admin
            </button>
          </div>

          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>{loginType === 'admin' ? 'Username' : 'Email'}</label>
              <input
                type="text"
                name="username"
                value={formData.username}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <label>Password</label>
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                required
              />
            </div>

            <button type="submit" className="btn btn-primary btn-block" disabled={loading}>
              {loading ? 'Logging in...' : 'Login'}
            </button>
          </form>

          {loginType === 'customer' && (
            <p style={{ marginTop: '1rem', textAlign: 'center' }}>
              Don't have an account? <Link to="/register">Register here</Link>
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default Login;

